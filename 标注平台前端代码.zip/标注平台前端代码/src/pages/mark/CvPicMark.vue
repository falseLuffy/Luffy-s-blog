<!-- CV标注 -->
<template>
  <mark-tpl class="cv-pic" :appType="appType" :param="param" @query="query" @setQueryData="setQueryData" @valid="valid" @save="save">
    <div slot="answer" class="cvanswer-wrapper">
      <div class="single-img" ref="singleWrapper">
        <img :src="param.src" ref="singleImg" alt="识别图片">
        <div class="cvbtn-wrapper" v-if="!readonly">
          <el-button size="small"  type="success" plain @click="firstSure" @keyup="firstSure">初标确定（T）</el-button>
          <el-button size="small"  type="danger" plain @click="backFirst" @keyup="backFirst">返回初标（B）</el-button>
        </div>
      </div>

      <ul class="compare-imgs" ref="compareWrapper">
        <li v-for="(item,index) in param.relatedImages" :key="index" @click="imgClick(item)" :class="{active: item.active,final: item.finalResult == item.name}" :style="{height:childHeight}" v-show="item.show">
          <img :src="item.src" alt="匹配图片">
          <i class="iconfont icon-success" v-if="item.active"></i>
        </li>
      </ul>
    </div>
  </mark-tpl>
</template>

<script>
import { mapMutations } from "vuex";
import MarkTpl from "./MarkTpl";
import { APPTYPE } from "assets/scripts/code";
import { setMarkData } from "assets/scripts/common";

export default {
  name: "CvPicMark",
  components: {
    MarkTpl
  },
  data() {
    return {
      appType: APPTYPE.CV,
      mcType: "",
      readonly: false,
      showSuccess: false,
      showError: false,
      childHeight: 0,
      lastSelect: false,
      param: {
        oldnames: null,
        oldfinal: "",
        selectedResult: new Set([]), //初选
        finalResult: "", //终选
        name: "",
        src: "",
        jump: false,
        extra: {},
        checkResult: "",
        checkerEdit: null,
        relatedImages: [
          {
            name: "",
            src: "",
            score: "",
            extra: {}
          }
        ]
      }
    };
  },
  methods: {
    ...mapMutations(["showLoading", "closeLoading"]),
    /**
     * 查询数据
     * @param param 请求参数
     * @param isCookie 是否是缓存
     */
    query(param, isCookie) {
      this.showLoading();
      delete param.dataId;
      this.$api.mark
        .getMarkFile(param)
        .then(res => {
          this.closeLoading();
          if (isCookie) {
            setMarkData(param.userTaskItemId, res);
          } else {
            setMarkData(param.userTaskItemId, res);
            this.setQueryData(res);
          }
        })
        .catch(() => {
          this.closeLoading();
        });
    },

    /**
     * 请求数据后的内容处理
     * @param res 请求的数据
     */
    setQueryData(res) {
      const mcType = this.mcType;
      let nameData;

      // 标注页面
      if (mcType == 0) {
        if (res.markedData) {
          nameData = res.markedData;
        }
      }

      // 检查页面
      if (mcType == 1) {
        if (res.checkedData) {
          nameData = res.checkedData;
        } else if (res.markedData) {
          nameData = res.markedData;
        }
      }

      // 将带分数的数据转换成不带分数的,不影响修改前的数据--8.20
      if (
        nameData &&
        nameData.selectedResult &&
        nameData.selectedResult.length > 0 &&
        nameData.selectedResult[0].name
      ) {
        let newSelectedResult = [];
        nameData.selectedResult.forEach(item => {
          newSelectedResult.push(item.name);
        });
        nameData.selectedResult = newSelectedResult;
      }
      if (
        nameData &&
        nameData.finalResult &&
        nameData.finalResult.length > 0 &&
        nameData.finalResult[0].name
      ) {
        nameData.finalResult = nameData.finalResult[0].name;
      }

      let finalResultArr = []; // 终选
      let selectedArr = []; // 初选
      let otherArr = []; // 未选

      // 获取标注文件
      res.data.relatedImages.forEach(item => {
        // 本地测试
        //item.src = "/static/person.jpg";
        // 是否初选
        if (nameData) {
          item.active =
            nameData.selectedResult.indexOf(item.name) > -1 ? true : false;
          // 终选名称
          item.finalResult = nameData.finalResult || "";
        } else {
          item.active = false;
          item.finalResult = "";
        }

        // 初始全部显示
        item.show = true;

        // 页面数据重新排序
        if (nameData && item.name === nameData.finalResult) {
          finalResultArr[0] = item;
        } else if (nameData && nameData.selectedResult.includes(item.name)) {
          selectedArr.push(item);
        } else {
          otherArr.push(item);
        }
      });

      // 页面数据重新排序
      res.data.relatedImages = finalResultArr
        .concat(selectedArr)
        .concat(otherArr);

      this.param = res.data;
      if (nameData && nameData.finalResult) {
        this.param.finalResult = nameData.finalResult || "";
      }

      this.lastSelect = false;

      // 将选中的name放到selectedResult
      this.param.selectedResult = nameData
        ? new Set([...nameData.selectedResult])
        : new Set([]);

      if (mcType == 1) {
        // 用于判断是否检查-记录修改前数据
        this.param.oldnames = JSON.parse(
          JSON.stringify(res.markedData.selectedResult)
        );
        this.param.oldfinal = res.markedData.finalResult || "";

        // // 检查结果
        // this.param.checkResult = res.checkResult;

        // // 是否检查
        // this.param.checkerEdit = res.checkedData ? true : false;
      }

      // 获取数据后，才可以点击下一条，防止快速点击事件
      this.param.clicked = false;
      if (this.param.keycodetimer) {
        this.param.keycodetimer = null;
        clearTimeout(this.param.keycodetimer);
      }

      // 滚动条滚至最顶
      document.querySelector(".compare-imgs").scrollTo(0, 0);
    },

    /**
     * 校验
     */
    valid() {
      // 没有选择终标
      const selectedResult = [...this.param.selectedResult],
        len = selectedResult.length,
        _finalResult = this.param.finalResult;

      if (
        (!_finalResult || (_finalResult && !_finalResult.length)) &&
        len > 0
      ) {
        // 只选了一个
        if (len === 1) {
          this.param.finalResult = selectedResult[0];
        } else if (!this.param.jump) {
          this.param.valid = false;
          this.param.validMsg = "请锁定匹配度最高的一张图片";
          return;
        }
      }

      // cv人脸匹配检错-检查
      // if (this.mcType == 1) {
      //   // 检查是否更改了
      //   const checkBefore = new Set(this.param.oldnames);
      //   const checkAfter = new Set([...this.param.selectedResult]);
      //   this.judgeCheckEdit(checkBefore, checkAfter);

      //   // 终选不同，也表示检查了
      //   if (
      //     this.param.oldfinal !== this.param.finalResult &&
      //     (!!this.param.oldfinal || !!this.param.finalResult)
      //   ) {
      //     this.param.checkerEdit = true;
      //   }
      // }
    },

    /**
     * 判断检查员是否修改
     * @param checkBefore 检查前的数据
     * @param checkAfter 检查后的数据
     */
    judgeCheckEdit(checkBefore, checkAfter) {
      if (checkAfter.size != checkBefore.size) {
        this.param.checkerEdit = true;
      } else {
        let diff = new Set([...checkBefore].filter(x => !checkAfter.has(x)));
        this.param.checkerEdit = diff.size > 0 ? true : false;
      }
    },

    /**
     * 保存数据
     */
    save() {
      // cv人脸识别保存name
      let selectedArr = [...this.param.selectedResult],
        final = this.param.finalResult ? this.param.finalResult : "";

      let selectedResult = [],
        finalResult = [];

      this.param.relatedImages.forEach(item => {
        // 终选
        if (final && item.name === final) {
          finalResult.push({
            name: final,
            score: item.score
          });
        }
        // 初选
        if (selectedArr.includes(item.name)) {
          selectedResult.push({
            name: item.name,
            score: item.score
          });
        }
      });

      this.param.checkResult = this.param.checkerEdit ? 2 : 1;
      this.param.commitData = {
        selectedResult: selectedResult,
        finalResult: finalResult
      };
    },

    // 选择图片
    imgClick(item) {
      if (this.readonly) {
        return;
      }
      // 终选
      if (this.lastSelect) {
        this.param.finalResult =
          this.param.finalResult == item.name ? "" : item.name;
        this.param.relatedImages.forEach(item => {
          item.finalResult = this.param.finalResult;
        });
      } else {
        item.active = !item.active;
        const name = item.name;
        this.param.selectedResult[item.active ? "add" : "delete"](name);

        // 如果当前是终选，取消之
        if (item.finalResult === item.name) {
          this.param.finalResult = "";
          this.param.relatedImages.forEach(item => {
            item.finalResult = this.param.finalResult;
          });
        }
      }
    },

    // 初标确定
    firstSure() {
      this.param.relatedImages.forEach(item => {
        item.show = item.active ? true : false;
      });
      // 开始终选
      this.lastSelect = true;
    },

    // 返回初标
    backFirst() {
      this.param.relatedImages.forEach(item => {
        item.show = true;
      });

      this.lastSelect = false;
    },

    // 更改图片的位置大小
    changeImgPos() {
      // 1、更改小图的高度
      const compareWrapper = this.$refs.compareWrapper;
      const childWidth = compareWrapper.clientWidth * 0.25 - 10;

      if (compareWrapper.children.length > 0) {
        this.childHeight = childWidth + "px";

        // 根据浏览器的高度，判断小图容器高度容纳几张小图
        const bodyHeight =
          document.documentElement.clientHeight || document.body.clientHeight;

        let showNumber;
        showNumber = bodyHeight > 1000 ? 3 : 2;

        var childWrapperHeight = showNumber * childWidth + 20 + "px";
        compareWrapper.style.height = childWrapperHeight;
      }

      // 2、更改大图的高度及位置
      const singleWrapper = this.$refs.singleWrapper;
      let singleWrapperW = singleWrapper.clientWidth + "px";
      singleWrapper.style.height = singleWrapperW;
    },

    // 设置快捷键
    setKeys(e) {
      let that = this;
      const keyCode = e.keyCode || e.which;
      // 初标确定
      if (keyCode === 84) {
        that.firstSure();
      }

      // 返回初标
      if (keyCode === 66) {
        that.backFirst();
      }
    }
  },

  created() {
    let task = JSON.parse(window.sessionStorage.getItem("task"));
    // 1检查,0标注
    this.mcType = task.type;
    this.readonly = task.readonly;
  },

  mounted() {
    this.changeImgPos();
    document.addEventListener("keyup", this.setKeys);
    document.body.onresize = () => {
      this.changeImgPos();
    };
  },

  beforeRouteLeave(to, from, next) {
    document.removeEventListener("keyup", this.setKeys);
    next();
  }
};
</script>

<style lang="less" scoped>
.cvanswer-wrapper {
  overflow: hidden;
  .single-img {
    position: relative;
    float: left;
    width: 25%;
    border: #fbfbfb 1px solid;
    box-shadow: #f4f4f5 1px 1px 2px;
    box-sizing: border-box;
    text-align: center;
    img {
      width: 100%;
      height: 100%;
      min-width: 250px;
      min-height: 250px;
    }
    span {
      display: block;
      margin-top: 10px;
    }

    .cvbtn-wrapper {
      margin: 0 auto;
      display: inline-block;
      text-align: center;
      margin-top: 30px;
      button {
        padding: 9px;
      }
    }
  }

  .compare-imgs {
    float: left;
    width: 75%;
    box-sizing: border-box;
    overflow-y: auto;
    li {
      width: calc(~"25% - 10px");
      overflow: hidden;
      box-sizing: border-box;
      float: left;
      margin-bottom: 10px;
      margin-left: 10px;
      cursor: pointer;
      border: #fbfbfb 1px solid;
      box-shadow: #f4f4f5 1px 1px 2px;
      img {
        width: 100%;
        height: 100%;
      }
      .icon-success {
        position: absolute;
        right: 0;
        bottom: 0;
        color: #67c23a;
        font-size: 30px;
        z-index: 999;
      }
      .icon-like1 {
        position: absolute;
        right: 0;
        bottom: 4px;
        color: #f56c6c;
        font-size: 26px;
        z-index: 999;
      }
      position: relative;
      &::before,
      &.active::after {
        position: absolute;
        background: black;
        opacity: 0.2;
        left: 0;
        right: 0;
        bottom: 0;
        top: 0;
        content: "";
      }
      &.active::after {
        opacity: 0.1;
      }
      &::before {
        display: none;
      }
      &:hover:before {
        display: block;
      }
      &.final {
        border: #f56c6c 6px solid;
      }
    }
  }
}
</style>





<template>
  <section class="dialog">
    <el-form
      ref="userForm"
      :model="userForm"
      :rules="userRules"
      label-width="110px"
      labelPosition="right"
      size="small"
    >
      <el-form-item prop="login" label="用户账号:">
        <el-input v-model="userForm.login" placeholder="请输入用户账号"></el-input>
      </el-form-item>
      <el-form-item prop="cnName" label="用户姓名:">
        <el-input name="cnName" v-model="userForm.cnName" :maxlength="30" placeholder="请输入用户名称"></el-input>
      </el-form-item>

      <el-form-item prop="password" label="用户密码:">
        <el-input type="password" v-model="userForm.password" placeholder="请输入密码"></el-input>
      </el-form-item>
      <el-form-item prop="authoritie" label="用户权限:">
        <el-select name="authoritie" v-model="userForm.authoritie" placeholder="请选择用户权限">
          <el-option
            v-for="(item,index) in authoritiesList"
            :key="index"
            :label="item.label"
            :value="item.value"
          ></el-option>
        </el-select>
      </el-form-item>
    </el-form>
    <div slot="footer" align="center" class="section-footer">
      <el-button type="primary" size="small" @click="createUser">确定</el-button>
      <el-button size="small" @click="hide">取消</el-button>
    </div>
  </section>
</template>

<script>
import { formValid } from "assets/scripts/common";
import { APPID } from "assets/scripts/code";
export default {
  name: "NewUser",

  data() {
    return {
      userForm: {
        login: "",
        cnName: "",
        password: "",
        authorities: [],
        authoritie: "",
        appId: APPID
      },
      userRules: {
        login: [
          { required: true, message: "请输入用户名称", trigger: "blur" },
          { validator: formValid.nullValidator, trigger: "blur" }
        ],
        authoritie: [
          { required: true, message: "请选择用户权限", trigger: "change" }
        ]
      },
      authoritiesList: [
        { label: "普通用户", value: "ROLE_USER" },
        { label: "应用管理员", value: "ROLE_DW_APPADMIN" },
        { label: "开发者", value: "ROLE_DW_DEVELOPER" }
      ]
    };
  },
  methods: {
    // 新建用户
    createUser() {
      this.$refs.userForm.validate(valid => {
        if (valid) {
          this.userForm.authorities.push(this.userForm.authoritie);
          delete this.userForm.authoritie;
          this.$api.project.addUser(this.userForm).then(
            res => {
              this.hide();
              this.$message.success("创建成功");
              this.userForm.authorities = [];
              this.$emit("success");
            },
            error => {
              this.$emit("error");
            }
          );
        }
      });
    },

    //重置表单
    resetForm() {
      this.$refs.userForm.resetFields();
      this.$refs.userForm.clearValidate();
    },

    // 隐藏
    hide() {
      this.resetForm();
      this.$emit("hide");
    }
  },
  mounted() {}
};
</script>

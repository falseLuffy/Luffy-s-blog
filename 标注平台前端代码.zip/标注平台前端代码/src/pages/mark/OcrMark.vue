<!-- OCR标注 -->
<template>
  <mark-tpl
    class="ocr-mark"
    :appType="appType"
    :keysList="keysList"
    :param="param"
    @query="query"
    @setQueryData="setQueryData"
    @valid="valid"
    @save="save"
  >
    <!-- 标题 -->
    <div class="ocr-title" slot="title">
      <span class="overflow" :title="param.name">({{param.name}})</span>
      <template>
        <el-button type="danger" size="small" v-if="param.bad" @click="availableClick">坏数据</el-button>
        <el-button type="danger" size="small" class="btn-plain" v-else @click="availableClick">标为坏数据</el-button>
      </template>
    </div>
    <div slot="answer" class="ocr-answer" :style="{height: drawHeight}">
      <!-- 绘制区域 -->
      <div class="draw-area">
        <div ref="canvas" id="canvas" :class="{'is-drag':selectActive == 2,'is-point':shapeType}"></div>

        <!-- 辅助工具 -->
        <ul class="help-tool">
          <li :class="{active: screenActive}" @click="screenClick">
            <i class="iconfont icon-screen"></i>
            <span>筛选</span>
          </li>
          <!-- 二选一 -->
          <li :class="{active: selectActive == 1}" @click="chooseClick">
            <i class="iconfont icon-choose"></i>
            <span>选择</span>
          </li>
          <li :class="{active: selectActive == 2}" @click="moveClick">
            <i class="iconfont icon-move"></i>
            <span>拖拽</span>
          </li>
        </ul>
        <div class="screen-lables" v-if="screenActive">
          <span
            v-for="item of param.labels"
            class="overflow"
            :title="item.cname"
            :key="item.cname"
            :class="{active: screenNames.includes(item.cname)}"
            @click="screenItemClick(item)"
          >{{item.cname}}</span>
        </div>
      </div>

      <!-- 绘制工具 -->
      <div class="draw-tools">
        <div class="tools">
          <dl @click="shapeClick(1)" :class="{active:shapeType == 1}">
            <dt class="iconfont icon-polygon"></dt>
            <dd>多边形</dd>
          </dl>
          <dl @click="shapeClick(2)" :class="{active:shapeType == 2}">
            <dt class="iconfont icon-rect"></dt>
            <dd>矩形</dd>
          </dl>
        </div>

        <div class="area">
          <div class="tool-title">区域</div>
          <ul class="area-list" :style="{height: areaHeight}">
            <li
              v-for="(item,index) of param.result"
              :key="index"
              :class="{active:activeItem.id == item.id}"
              @click="areaItemClick(item)"
            >
              <i class="iconfont icon-rect-circle" v-if="item.region == 'rect'"></i>
              <i class="iconfont icon-polygon-circle" v-else></i>
              <el-input
                size="small"
                v-model="activeItem.text"
                v-if="activeItem.id == item.id"
                @change="updateResult"
                :readonly="readonly"
              ></el-input>
              <span class="overflow" :title="item.text" v-else>{{item.text}}</span>
            </li>
          </ul>
        </div>

        <div class="tags">
          <div class="tool-title">编辑详情</div>
          <span class="tags-attrs">物理属性</span>
          <ul class="tags-list" v-if="param.labels">
            <li
              v-for="item of param.labels"
              class="overflow"
              :title="item.cname"
              :key="item.cname"
              :class="{active:activeItem.type == item.cname}"
              @click="editItemClick(item)"
            >{{item.cname}}</li>
          </ul>
        </div>

        <div class="content">
          <div class="tool-title">内容</div>
          <el-input
            size="small"
            type="textarea"
            v-model="activeItem.text"
            @change="updateResult"
            :readonly="readonly"
            :max="1000"
          ></el-input>
        </div>
      </div>
    </div>
  </mark-tpl>
</template>

<script>
import MarkTpl from "./MarkTpl";
import { APPTYPE } from "assets/scripts/code";
import { setMarkData } from "assets/scripts/common";
import OcrSet from "assets/scripts/ocr";
import SVG from "svg.js";
import "svg.draggable.js";
import "svg.select.js";
import "svg.resize.js";
import "svg.pan-zoom.js";

export default {
  name: "ocrMark",
  components: {
    MarkTpl
  },

  data() {
    return {
      keysList: OcrSet.keys,
      screenIds: [], // 筛选的ID
      screenNames: [], // 筛选的Names
      appType: APPTYPE.OCR,
      mcType: "",
      readonly: false,
      drawHeight: OcrSet.drawHeight, // - 192
      areaHeight: OcrSet.areaHeight, // -492
      screenActive: false,
      selectActive: null, // 1表示选择，2表示拖拽
      activeItem: {}, // 当前激活形状
      shapeIdNum: 0,
      selectShape: null, // 当前选中的形状
      drawStatus: false, // 标识是否正在绘制
      currentDraw: null, // 正在绘制的图像
      shapeType: null, // 1多边形绘制，2矩形绘制
      zoom: 1,
      draw: null,
      lineX: null, // 活动的X
      lineY: null, // 活动的Y
      mainImage: null,
      drawGroup: null, // 存放操作组
      groupZoom: null, // 存放zoom对象
      param: {
        name: "",
        zoom: 1,
        labels: [],
        url: "",
        bad: false, // "0"好 "1"坏
        result: []
      }
    };
  },

  methods: {
    /**
     * 查询数据
     * @param param 请求参数
     * @param isCookie 是否是缓存
     */
    query(param, isCookie) {
      let id = param.userTaskItemId;
      delete param.dataId;
      this.$api.mark
        .getMarkFile(param)
        .then(res => {
          res.userTaskItemId = id;
          if (isCookie) {
            setMarkData(id, res);
          } else {
            setMarkData(id, res);
            this.setQueryData(res);
          }
        })
        .catch(() => {});
    },

    /**
     * 请求数据后的内容处理
     * @param res 请求的数据
     */
    setQueryData(res) {
      let ocrData;
      let mcType = this.mcType;

      // 1）检查
      if (mcType == 1) {
        ocrData = res.checkedData ? res.checkedData : res.markedData;
      } else if (res.markedData && mcType == 0) {
        // 2）标注
        ocrData = res.markedData;
      } else if (!res.markedData) {
        // 3）没有标注
        ocrData = res.data;
      }

      // 数据赋值
      this.param = Object.assign({}, this.param, res.data);
      this.param.bad = ocrData.bad ? ocrData.bad : false;
      this.param.result = ocrData.result ? ocrData.result : [];

      // 渲染图形
      this.$nextTick(() => {
        this.clearDraw();
        this.drawSvg();
      });

      // 获取数据后，才可以点击下一条，防止快速点击事件
      this.param.clicked = false;
      if (this.param.keycodetimer) {
        this.param.keycodetimer = null;
        clearTimeout(this.param.keycodetimer);
      }
    },

    /**
     * 画布及数据清除
     */
    clearDraw() {
      // SVG移除
      if (this.draw) {
        this.draw.remove();
      }
      // 业务操作数据清空
      this.zoom = 1;
      this.draw = null;
      this.lineX = null; // 活动的X
      this.lineY = null; // 活动的Y
      this.activeItem = {};
      this.shapeIdNum = 0;
      this.selectActive = null;
      this.screenActive = false;
      this.screenIds = []; // 筛选的ID
      this.screenNames = [];
      this.selectShape = null; // 当前选中的形状
      this.drawStatus = false; // 标识是否正在绘制
      this.currentDraw = null; // 正在绘制的图像
      this.shapeType = null; // 1多边形绘制，2矩形绘制
      this.mainImage = null;
      this.drawGroup = null; // 存放操作组
      this.groupZoom = null;
    },

    /**
     * 图形的绘制
     */
    drawSvg() {
      let that = this;

      // 初始化
      that.draw = SVG("canvas").size("100%", "100%");

      // 绘制图像
      that.mainImage = that.draw.image(that.param.url).loaded(function(loader) {
        // 图片加载后，设置图片大小
        this.size(loader.width, loader.height);

        // 绘制一个图形组合
        that.drawGroup = that.draw.group();

        // 给组合加入边框
        let borderRect = that.drawGroup
          .rect(loader.width, loader.height)
          .stroke(OcrSet.imageBorder)
          .fill("none");

        // 给图形组合加辅助线，只有鼠标移入地时候才显示，先绘制dom
        that.lineX = that.drawGroup.line(0, 0, 0, 0).stroke(OcrSet.imageLine);
        that.lineY = that.drawGroup.line(0, 0, 0, 0).stroke(OcrSet.imageLine);

        // 将图像也放入组合中
        that.drawGroup.add(this).attr(OcrSet.groupId);
        that.groupZoom = that.drawGroup.panZoom(OcrSet.zoomOpt);

        // 初始化图片，自适应最好的宽高比例
        that.setInitZoom(loader.width, loader.height);

        // 设置事件
        if (!this.readonly) {
          that.setEvents();
        }

        // 有图形数据则渲染数据
        let result = that.param.result;
        if (result && result.length > 0) {
          that.param.result.forEach(item => {
            if (item.region == "rect") {
              that.drawRectData(item);
            }

            if (item.region == "area") {
              that.drawPolygoData(item);
            }

            // 获取最大的id数
            let n = Number(item.id.substring(2));
            if (n > that.shapeIdNum) {
              that.shapeIdNum = n;
            }
          });
        }
      });
    },

    /**
     * 设置自适应的宽高
     * @param imgW 图片的宽
     * @param imgH 图片的高
     */
    setInitZoom(imgW, imgH) {
      let that = this,
        canvasW = that.$refs.canvas.clientWidth,
        canvasH = that.$refs.canvas.clientHeight,
        imgRate = imgW < imgH ? imgW / imgH : imgH / imgW;

      let gap = 20;
      let newImgH, newImgW;

      // 将图片的高度显示的跟编辑区一样
      newImgH = canvasH - gap;
      newImgW = (newImgH * imgW) / imgH; // 按比例缩放

      // 以宽为准
      let gapW = canvasW - newImgW;
      let x;
      let y = gap / 2;

      // 原图很小
      if (gapW < 0) {
        x = 0;
      } else {
        x = gapW / 2;
      }

      // 缩放比例计算
      let zoom = newImgH / imgH;
      x = x / (1 - zoom);
      y = y / (1 - zoom);
      that.groupZoom.zoom(zoom, x, y);
    },

    /**
     * 赋值最新的zoom
     */
    getZoom() {
      this.param.zoom = this.groupZoom.transform.scaleX;
    },

    /**
     * 事件设置
     */
    setEvents() {
      let that = this;
      // 鼠标移动事件
      that.drawGroup.on("mousemove", that.mousemoveEvt, that);

      // 鼠标移出事件
      that.drawGroup.on("mouseleave", that.mouseleaveEvt, that);

      // 鼠标点下
      that.drawGroup.on("mousedown", that.mousedownEvt, that);

      // 鼠标松开
      that.drawGroup.on("mouseup", that.mouseupEvt, that);

      // 图片拖拽限制
      that.drawGroup.off("dragend").on("dragend", function(e) {
        // 图片的宽高及位置
        let { x, y, scaleX } = this.transform();
        let w = that.mainImage.width() * scaleX;
        let h = that.mainImage.height() * scaleX;
        let gap = 60;
        // 左限制
        if (x < 0 && Math.abs(x) > w - gap) {
          x = -(w - gap);
        }

        // 上限制
        if (y < 0 && Math.abs(y) > h - gap) {
          y = -(h - gap);
        }

        let canvasW = that.$refs.canvas.clientWidth,
          canvasH = that.$refs.canvas.clientHeight;

        // 右限制
        if (x > 0 && x > canvasW - gap) {
          x = canvasW - gap;
        }

        // 下限制
        if (y > 0 && y > canvasH - gap) {
          y = canvasH - gap;
        }

        that.groupZoom.setPosition(x, y, scaleX);
      });
    },

    /**
     * 鼠标移入事件
     */
    mousemoveEvt(e) {
      e.preventDefault();

      // 当前标注的图形，1多边形，2矩形
      let shapeType = this.shapeType;
      if (shapeType) {
        // 显示指示线
        this.drawCursor(e);
        // 多边形-画线
        if (shapeType == 1) {
          if (this.drawStatus && this.currentDraw) {
            let currentDraw = this.currentDraw; // 当前绘制的实例
            let points = currentDraw.array().value.slice(0);
            let { zx, zy } = this.getPointer(e);
            points.splice(-1, 1, [zx, zy]);
            currentDraw.plot(points);
          }
        } else {
          this.drawMoveRect(e);
        }
      }
    },

    /**
     * 绘制指示线
     */
    drawCursor(e) {
      // 重置，防止错乱
      let { x, y, scaleX } = this.drawGroup.transform();
      this.groupZoom.setPosition(x, y, scaleX);

      // 重绘
      let { zx, zy } = this.getPointer(e);
      let w = this.mainImage.width();
      let h = this.mainImage.height();

      this.lineX.front().plot(0, zy + 1, w, zy + 1);
      this.lineY.front().plot(zx + 1, 0, zx + 1, h);
    },

    /**
     * 鼠标移动时，绘制矩形
     */
    drawMoveRect(e) {
      let { x, y } = this.activeItem;
      if (x && y && this.drawStatus) {
        let { zx, zy } = this.getPointer(e);
        let currentDraw = this.currentDraw;

        if (!currentDraw) {
          this.currentDraw = this.drawGroup
            .rect(0, 0)
            .move(x, y)
            .fill(OcrSet.rect)
            .stroke(OcrSet.rectStroke);
        } else {
          this.getZoom();
          let width = Math.abs(zx - x),
            height = Math.abs(zy - y),
            mx = Math.min(zx, x),
            my = Math.min(zy, y);
          this.currentDraw.size(width, height).move(mx, my);
        }
      }
    },

    /**
     *鼠标移开
     */
    mouseleaveEvt(e) {
      // 隐藏指示线
      this.resetLine();

      // 如果正在绘图状态
      // 多边形，少于2个点消失，多于2个点绘制成图
      if (this.shapeType == 1 && this.drawStatus) {
        let num = this.activeItem.pointnum;
        let isOK = this.checkDrawIsOk();
        if (num < 2 || !isOK) {
          this.currentDraw.remove();
          this.currentDraw = null;
          this.drawStatus = false;
          this.activeItem.points = [];
          this.activeItem.pointnum = 0;
        } else {
          this.drawPolygoDone(e);
        }
      }

      // 矩形，绘制成图
      if (this.shapeType == 2 && this.drawStatus) {
        this.mouseupEvt(e);
      }
    },

    /**
     * 完成多边形的绘制
     */
    drawPolygoDone(e) {
      let { zx, zy } = this.getPointer(e);
      let { points, pointnum } = this.activeItem;
      // 记录结束点数据
      this.activeItem.points.push([zx, zy]);
      this.activeItem.pointnum++;
      // 图形绘制完毕
      this.drawDone();
    },

    /**
     * 隐藏指示线
     */
    resetLine() {
      this.lineX.front().plot(0, 0, 0, 0);
      this.lineY.front().plot(0, 0, 0, 0);
    },

    /**
     * 鼠标点下事件
     * 绘制 shapeType 1,2
     * 选择 selectActive 1
     */
    mousedownEvt(e) {
      e.preventDefault();
      // 1绘制多边形
      if (this.shapeType == 1) {
        if (e.button == 0) {
          let { zx, zy } = this.getPointer(e);
          this.drawStatus = true;
          this.activeItem.pointnum++;
          this.activeItem.points.push([zx, zy]);
          // 左键,绘制
          this.drawPolygo(e);
        }

        // 结束绘制-右键,结束绘制
        if (e.button == 2) {
          this.mouseleaveEvt(e);
        }
      }

      // 2绘制矩形-开始绘制
      if (this.shapeType == 2) {
        if (e.button == 0) {
          let { zx, zy } = this.getPointer(e);
          this.drawStatus = true;
          this.activeItem.x = zx;
          this.activeItem.y = zy;
        }
      }
    },

    /**
     * 绘制多边形-过程
     */
    drawPolygo(e) {
      // 获取当前已绘制的点信息
      let { pointnum, points, id } = this.activeItem;
      if (pointnum > 0 && this.drawStatus) {
        let { zx, zy } = this.getPointer(e);
        let currentDraw = this.currentDraw;
        if (!currentDraw) {
          points.push([zx, zy]);
          this.currentDraw = this.drawGroup
            .polygon(points)
            .fill(OcrSet.polygo)
            .stroke(OcrSet.rectStroke)
            .attr({ id: id });
        } else {
          points = this.currentDraw.array().value.slice(0);
          points.push([zx, zy]);
          this.currentDraw.plot(points);
        }
      }
    },

    /**
     * 鼠标松开事件
     */
    mouseupEvt(e) {
      e.preventDefault();
      // 矩形绘制完毕
      if (this.shapeType == 2 && this.drawStatus) {
        // 记录结束点
        let { zx, zy } = this.getPointer(e);
        let { x, y } = this.activeItem;
        this.activeItem.x = Math.min(zx, x);
        this.activeItem.y = Math.min(zy, y);
        this.activeItem.w = Math.abs(zx - x);
        this.activeItem.h = Math.abs(zy - y);
        let isOK = this.checkDrawIsOk();
        this.resetLine();
        if (isOK) {
          this.drawDone();
        } else {
          this.drawStatus = false;
          if (this.currentDraw) {
            this.currentDraw.draggable(false);
            this.currentDraw
              .selectize(false, { deepSelect: true })
              .resize("stop");
            this.currentDraw.remove();
          }
          this.currentDraw = null;
        }
      }
    },

    /**
     * 校验绘制的矩形是否符合标准，必须大于20*20
     */
    checkDrawIsOk() {
      if (this.currentDraw) {
        let w = this.currentDraw.width();
        let h = this.currentDraw.height();
        let rW = this.mainImage.width() / 100;
        let rH = this.mainImage.height() / 100;
        if (h > rH && w > rW) {
          return true;
        } else {
          this.$message.error("绘制区域太小");
          return false;
        }
      } else {
        return false;
      }
    },

    /**
     * 绘制图形完成后的操作
     */
    drawDone() {
      // 生成id
      let index = this.shapeIdNum + 1;
      this.shapeIdNum++;
      let id = this.shapeType == 2 ? `r-${index}` : `p-${index}`;

      // 赋值id
      this.activeItem.text = id;
      this.activeItem.id = id;
      if (this.currentDraw) {
        this.currentDraw.attr({ id: id });
      }
      let item = { ...this.activeItem };

      // 将当前图形设置为选中
      let hasShape = this.changeSelectShape(item.id);
      if (hasShape) {
        // 去除当前绘制
        this.shapeType = null;
        this.drawStatus = false;
        this.currentDraw = null;

        // 更新当前数据
        this.param.result.push(item);
        this.selectActive = 1;
      }
    },

    /**
     * 获取当前点的信息
     */
    getPointer(e) {
      let x = e.layerX || e.offsetX,
        y = e.layerY || e.offsetY,
        t = this.groupZoom.transform,
        rx = x - t.x,
        ry = y - t.y;

      this.getZoom();
      let zx = rx / this.param.zoom;
      let zy = ry / this.param.zoom;
      return {
        zx: zx, // 绝对位置
        zy: zy
      };
    },

    /**
     * 渲染已知数据的矩形
     */
    drawRectData(rectdata) {
      let { x, y, w, h, id } = rectdata;
      let rect = this.drawGroup
        .rect(w, h)
        .move(x, y)
        .fill(OcrSet.rect)
        .stroke(OcrSet.rectStroke)
        .attr({ id: id });

      this.shapeBindEvent(rect);
    },

    /**
     * 绘制已知数据的多边形
     */
    drawPolygoData(data) {
      let { pointnum, points, id } = data;
      // 对points进行转换
      points.forEach((item, index) => {
        let items = item.split(",");
        items[0] = Number(items[0]);
        items[1] = Number(items[1]);
        points[index] = items;
      });
      let polygo = this.drawGroup
        .polygon(points)
        .fill(OcrSet.polygo)
        .stroke(OcrSet.rectStroke)
        .attr({ id: id });

      this.shapeBindEvent(polygo);
    },

    /**
     * 对图形的事件绑定
     */
    shapeBindEvent(svgItem) {
      let that = this;

      if (!this.readonly) {
        // 大小改变,更新activeItem
        svgItem.off("resizedone").on("resizedone", function() {
          that.changeSelectShapePos(this);
        });

        // 拖拽后,更新activeItem
        svgItem.off("dragend").on("dragend", function(e) {
          that.changeSelectShapePos(this, e);
        });
      }

      // 点击事件
      svgItem.off("click").on("click", function() {
        // 正在绘制的时候不管用
        // 拖拽的时候不管用
        if (that.selectActive == 2 || that.shapeType) {
          return;
        }

        let selectId = this.id();
        // 点自己不管用
        if (selectId === that.activeItem.id) {
          return;
        }

        // 更新当前的activeItem
        let selectItem = that.param.result.find(item => {
          if (item.id === selectId) {
            return item;
          }
        });

        that.areaItemClick(selectItem);
      });
    },

    /**
     * 对选中的图形进行操作
     */
    changeSelectShape(id) {
      let that = this;
      // 销毁上一个
      if (this.selectShape) {
        this.selectShape.removeClass("svg-highlight");
        this.selectShape.draggable(false);
        // 取消选中
        this.selectShape.selectize(false, { deepSelect: true }).resize("stop");
      }

      if (!id) {
        return false;
      }

      // 激活当前选中
      this.selectShape = SVG.get(id).addClass("svg-highlight");
      if (!this.selectShape) {
        return false;
      }

      if (!this.readonly) {
        let that = this;
        // 当前图形可操作
        this.selectShape.selectize(OcrSet.selectOpt).resize();

        // 选中图形可拖拽，并只能在图像中进行拖拽
        this.selectShape.draggable({
          minX: 0,
          minY: 0,
          maxX: that.mainImage.width(),
          maxY: that.mainImage.height()
        });
        that.shapeBindEvent(this.selectShape);
      }

      this.$nextTick(() => {
        let points = SVG.select(".svg_select_points").members;
        let width = this.mainImage.width();

        if (width < 1000 || width > 2000) {
          points.forEach(item => {
            if (item.type == "circle") {
              item.addClass(
                width > 2000 ? "svg-circle-big" : "svg-circle-small"
              );
            }
          });
        }
      });
      return true;
    },

    /**
     * 改变当前选中图形的位置和大小，更新数据
     */
    changeSelectShapePos(obj, e) {
      let { region } = this.activeItem;

      // 矩形
      if (region == "rect") {
        this.activeItem.x = obj.x();
        this.activeItem.y = obj.y();
        this.activeItem.w = obj.width();
        this.activeItem.h = obj.height();
      }
      // 多边形
      if (region == "area") {
        this.activeItem.points = obj.array().value.slice(0);
        this.activeItem.pointnum = this.activeItem.points.length;
      }
      // 同步值到result
      this.updateResult();
    },

    /**
     * 将最新的activeItem的数据写入到result中
     */
    updateResult() {
      let activeItem = { ...this.activeItem };
      this.param.result.find((item, index) => {
        if (item.id === activeItem.id) {
          this.param.result.splice(index, 1, activeItem);
        }
      });
    },

    /**
     * 点击筛选按钮
     */
    screenClick() {
      this.screenActive = !this.screenActive;
    },

    /**
     * 点击子类型筛选
     */
    screenItemClick(item) {
      item.active = !item.active;
      this.screenNames = [];
      this.param.labels.forEach(item => {
        if (item.active) {
          this.screenNames.push(item.cname);
        }
      });

      // 没选则全部显示
      if (this.screenNames.length == 0) {
        if (!this.readonly && this.selectShape) {
          this.selectShape.selectize({ deepSelect: true }).resize();
        }

        this.param.result.forEach(item => {
          SVG.get(item.id).show();
        });

        return;
      }

      this.queryResult();
    },

    /**
     * 根据结果控制图形的显示与隐藏
     */
    queryResult() {
      // 获取显示的ids
      this.screenIds = [];

      // 根据names找id;
      this.screenNames.forEach(item => {
        this.param.result.forEach(result => {
          // 显示
          if (result.type === item) {
            this.screenIds.push(result.id);
          }
        });
      });

      // 获取当前选择框的id
      if (!this.readonly && this.selectShape) {
        let selectId = this.selectShape.id();

        // 对于选中框
        if (!this.screenIds.includes(selectId)) {
          this.selectShape
            .selectize(false, { deepSelect: true })
            .resize("stop");
        } else {
          this.selectShape.selectize({ deepSelect: true }).resize();
        }
      }

      // 显示ids
      this.param.result.forEach(item => {
        if (!this.screenIds.includes(item.id)) {
          SVG.get(item.id).hide();
        } else {
          SVG.get(item.id).show();
        }
      });
    },

    /**
     * 点击选择按钮
     */
    chooseClick() {
      if (this.readonly) {
        return;
      }

      this.selectActive = this.selectActive == 1 ? "" : 1;
      this.drawGroup.draggable(false);
      this.shapeType = null;

      if (this.selectShape) {
        let that = this;
        this.selectShape.draggable({
          minX: 0,
          minY: 0,
          maxX: that.mainImage.width(),
          maxY: that.mainImage.height()
        });
      }
    },

    /**
     * 点击拖拽按钮
     */
    moveClick(keycode) {
      this.selectActive = this.selectActive == 2 ? "" : 2;
      this.drawGroup.draggable();

      if (this.selectShape) {
        this.selectShape.draggable(false);
      }

      this.shapeType = null;
    },

    /**
     * 点击形状
     * @param type 1，多边形，2，矩形
     */
    shapeClick(type) {
      if (this.readonly) {
        return;
      }

      if (this.param.bad) {
        this.$message.error("坏数据不可标记");
        return;
      }

      let newItem = this.createItem(type);
      this.activeItem = newItem;

      // 当前绘制图形标识
      this.shapeType = type;
      // 当前激活组件赋值

      // 取消选择按钮
      this.selectActive = null;

      // 禁止大拖拽
      this.drawGroup.draggable(false);
      this.changeSelectShape();
    },

    /**
     * 创建形状数据
     * @param type 1 多边形，2 矩形
     */
    createItem(type) {
      let obj = {
        region: type == 1 ? "area" : "rect", // rect/area
        text: "", // 内容
        type: "" // 物理属性
      };

      if (type == 1) {
        obj.points = [];
        obj.pointnum = 0;
      } else {
        obj.w = "";
        obj.h = "";
        obj.x = "";
        obj.y = "";
      }

      return { ...obj };
    },

    /**
     * 区域内容点击
     */
    areaItemClick(item) {
      // 当前处理数据
      this.activeItem = item;

      let { id } = this.activeItem;

      // 当前处理SVG选中
      this.changeSelectShape(id);
    },

    /**
     * 物理属性的选择
     */
    editItemClick(item) {
      if (this.readonly) {
        return;
      }
      this.activeItem.type = item.cname;
      this.updateResult();
    },

    /**
     * 校验
     */
    valid() {
      if (this.param.bad) {
        return true;
      } else {
        // 必须有一个
        let results = this.param.result;
        if (results.length == 0) {
          this.param.valid = false;
          this.param.validMsg = "至少需要一个标记属性的绘图框";
          return;
        } else {
          // 必须都有标签
          let isAllMark = true;

          results.forEach(item => {
            if (!item.type) {
              isAllMark = false;
            }
          });

          if (!isAllMark) {
            this.param.valid = false;
            this.param.validMsg = "存在没有标签的绘图框";
            return;
          }
        }
      }
    },

    /**
     * 保存数据,只保存需要保存的数据
     */
    save() {
      // 将points转换成字符串格式
      this.param.result.forEach((item, index) => {
        let points = item.points;
        if (points && points.length > 0) {
          // 防止第一个点信息重复
          if (points[0] == points[1] && points.length == item.pointnum + 1) {
            points.splice(0, 1);
          }

          item.points.forEach((unit, index) => {
            item.points[index] = unit.toString();
          });
        }
      });

      this.param.commitData = {
        result: this.param.result,
        bad: this.param.bad
      };
    },

    /**
     * 标为好数据
     */
    availableClick() {
      if (this.readonly || (this.mcType == 1 && !this.param.bad)) {
        return;
      }
      let nowStatus = this.param.bad;
      if (nowStatus == "0") {
        if (this.param.result.length > 0) {
          this.$confirm(
            "标记为坏数据后，已标注内容将会被清除，确认标记吗？",
            "",
            {
              lockScroll: false
            }
          )
            .then(() => {
              this.param.bad = true;
              this.param.result = [];
              this.clearDraw();
              this.drawSvg();
            })
            .catch(() => {});
        } else {
          this.param.bad = true;
        }
      } else {
        this.param.bad = false;
      }
    },

    /**
     * 根据浏览器的高度赋值高度，保证在可视范围内进行操作
     */
    getHeight() {
      let $body = document.documentElement
        ? document.documentElement
        : document.body;
      let bodyH = $body.clientHeight;
      this.drawHeight = bodyH - 192 + "px";
      this.areaHeight = bodyH - 526 + "px";
    },

    /**
     * 设置快捷键
     */
    setKeys(e) {
      let that = this;
      const keyCode = e.keyCode || e.which;

      // 如果在文本框中则不可以使用快捷键
      var type = e.srcElement ? e.srcElement.type : e.target.type; // 看当前所处环境
      if (type === "text" || type === "textarea") {
        return;
      }

      // 选择多边形Z
      if (keyCode == 90 && !this.drawStatus) {
        this.shapeClick(1);
      }

      // 选择矩形A
      if (keyCode == 65 && !this.drawStatus) {
        this.shapeClick(2);
      }

      // 选择筛选S
      if (keyCode == 83) {
        this.screenClick();
      }

      // 选择拖拽X
      if (keyCode == 88) {
        this.moveClick(88);
      }

      // 删除DEL
      if (keyCode == 46) {
        if (this.readonly) {
          return;
        }
        if (this.selectShape) {
          this.$confirm("是否删除当前选中的图形？", "", {
            lockScroll: false
          })
            .then(() => {
              this.param.result.find((item, index) => {
                if (item.id === this.activeItem.id) {
                  this.param.result.splice(index, 1);
                  this.activeItem = {};

                  this.selectShape.draggable(false);
                  this.selectShape
                    .selectize(false, { deepSelect: true })
                    .resize("stop");
                  this.selectShape.remove();
                  this.selectShape = null;
                }
              });
            })
            .catch(() => {});
        }
      }
    }
  },

  created() {
    let task = JSON.parse(window.sessionStorage.getItem("task"));
    // 1检查,0标注
    this.mcType = task.type;
    this.readonly = task.readonly;
    this.task = task;
  },

  mounted() {
    document.removeEventListener("keyup", this.setKeys);
    document.addEventListener("keyup", this.setKeys);
    document.getElementsByTagName("html")[0].scrollTo(0, 100);
    // 区域高度
    this.getHeight();
    window.onresize = () => {
      this.getHeight();
    };

    window.oncontextmenu = function(e) {
      e.preventDefault();
    };
  },

  beforeRouteLeave(to, from, next) {
    document.removeEventListener("keyup", this.setKeys);
    next();
  }
};
</script>

<style lang="less" scoped>
.ocr-mark {
  .ocr-title {
    display: inline-block;
    display: flex;
    align-items: center;
    .overflow {
      display: inline-block;
      max-width: 400px;
      margin-right: 10px;
    }
  }
  .ocr-answer {
    overflow: hidden;
    height: 434px;
    box-sizing: border-box;
    margin: -10px;
  }
  .draw-area,
  .draw-tools {
    position: relative;
    float: left;
    width: 75%;
    height: 100%;
    overflow: hidden;
    box-sizing: border-box;
    .help-tool {
      position: absolute;
      right: 0;
      top: 0;
      border-left: 1px solid #ececec;
      li {
        padding: 10px 0;
        border-bottom: 1px solid #ececec;
        background: #fff;
        width: 38px;
        font-size: 12px;
        cursor: pointer;
        text-align: center;
        .iconfont {
          margin-right: 0px;
          font-size: 16px;
        }
        span {
          display: block;
          margin-top: 5px;
        }

        &.active {
          background-color: #e0fdee;
        }
      }
    }
  }

  .draw-tools {
    border-left: 1px solid #e8e8e8;
    width: 25%;
    box-sizing: border-box;
    .tools {
      overflow: hidden;
      dl {
        float: left;
        width: 24%;
        text-align: center;
        margin: 10px 13% 10px 13%;
        padding: 2px;
        box-sizing: border-box;
        cursor: pointer;
        dt {
          font-size: 30px;
          text-align: center;
        }
        &:last-child {
          position: relative;
          top: 3px;
          dd {
            margin-left: -8px;
          }
        }
        &.active {
          border-radius: 4px;
          background-color: #e8e8e8;
        }
      }
      .iconfont {
        color: #f9b9c4;
      }
      .icon-rect {
        font-size: 27px;
        color: #71f5ea;
      }
    }
    .tool-title {
      padding: 0 10px;
      text-align: left;
      font-weight: bold;
      background: #f5f5f5;
      line-height: 32px;
      clear: both;
    }
    .area-list {
      overflow-y: auto;
      li {
        height: 35px;
        cursor: pointer;
        line-height: 35px;
        margin-bottom: 1px;
        .iconfont {
          color: #c5c5c5;
          position: relative;
          top: -10px;
          left: 4px;
        }
        .overflow {
          display: inline-block;
          max-width: 80%;
        }
        &.active {
          background-color: #e0fdee;
          line-height: 27px;
          .iconfont {
            top: 3px;
          }
          .el-input__inner {
            border: none;
            background-color: transparent;
            padding: 0;
          }
        }
      }
      .el-input {
        width: 80%;
      }
    }
    .tags-attrs {
      padding: 0 10px;
      line-height: 30px;
      color: #999;
    }
    .tags-list {
      height: 90px;
      overflow-y: auto;
      li {
        display: inline-block;
        border-radius: 2px;
        border: 1px solid #eee;
        width: 29%;
        height: 30px;
        line-height: 30px;
        text-align: center;
        margin: 5px 0px 5px 5px;
        cursor: pointer;
        &.active {
          background-color: #e0fdee;
        }
      }
    }
  }

  .draw-area {
    #canvas {
      width: 100%;
      height: 100%;
    }
    .screen-lables {
      position: absolute;
      right: 38px;
      top: 0;
      background: #fff;
      border: 1px solid #ececec;
      padding: 10px 5px 5px 10px;
      width: 218px;
      box-sizing: border-box;
      box-shadow: -1px 1px 2px rgba(0, 0, 0, 0.3);
      .overflow {
        display: inline-block;
        width: 60px;
        text-align: center;
        padding: 5px 0;
        border: 1px solid #ececec;
        margin: 0px 5px 5px 0;
        cursor: pointer;
        &.active {
          background-color: #e0fdee;
        }
      }
    }
  }
}
</style>

<style lang="less">
.ocr-mark {
  .svg_select_boundingRect {
    stroke-width: 1;
    stroke-dasharray: 3;
    stroke: rgb(254, 0, 255);
    stroke-width: 2;
    fill-opacity: 0.2;
    fill: rgb(54, 86, 191);
    pointer-events: none;
  }
  .svg_select_points {
    fill: #f56c6c;
    r: 15;
  }

  .svg-circle-big {
    r: 25;
  }

  .svg-circle-small {
    r: 6;
  }

  .svg_select_points_rot {
    opacity: 0;
  }
  .is-drag #ocrDrawGroup {
    cursor: move;
  }

  .is-point #ocrDrawGroup {
    cursor: pointer;
  }

  .svg_select_boundingRect {
    stroke-opacity: 0;
  }

  .svg-highlight {
    stroke-opacity: 1;
    stroke-dasharray: 20, 20;
    stroke-dashoffset: 500;
    animation: animation-dash 5s linear alternate infinite;
  }

  @keyframes animation-dash {
    to {
      stroke-dashoffset: 0;
    }
  }

  .svg_select_points_lt {
    cursor: se-resize;
  }
  .svg_select_points_rt {
    cursor: ne-resize;
  }
  .svg_select_points_rb {
    cursor: nw-resize;
  }
  .svg_select_points_lb {
    cursor: ne-resize;
  }
  .svg_select_points_t {
    cursor: n-resize;
  }
  .svg_select_points_r {
    cursor: e-resize;
  }
  .svg_select_points_b {
    cursor: s-resize;
  }
  .svg_select_points_l {
    cursor: e-resize;
  }
}
</style>









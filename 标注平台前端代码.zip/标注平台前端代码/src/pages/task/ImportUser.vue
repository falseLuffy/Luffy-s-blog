<template>
  <el-container class="import-user" v-loading="loading" element-loading-text="正在请求">
    <el-header class="dialog-header">
      <el-form
        size="small"
        :inline="true"
        :model="queryForm"
        ref="queryForm"
        @submit.native.prevent
      >
        <el-form-item label prop="name">
          <el-input
            name="name"
            v-model="queryForm.name"
            clearable
            :maxlength="30"
            autofocus
            placeholder="请输入用户名称"
            suffix-icon="el-icon-search"
            @keyup.enter.native="query(1)"
            @change="query(1)"
          ></el-input>
        </el-form-item>
      </el-form>
    </el-header>

    <!-- 列表 -->
    <el-main class="dialog-main">
      <!-- 用户列表 -->
      <div class="user-table">
        <el-table
          size="small"
          ref="userTable"
          :data="userData"
          @selection-change="changeUserFun"
          @row-click="rowClick"
          align="center"
          border
          height="352"
        >
          <el-table-column type="selection" width="50" :selectable="userSelected"></el-table-column>
          <el-table-column label="用户名" :show-overflow-tooltip="true">
            <template slot-scope="scope">
              <span class="font-grey" v-if="scope.row.selected">{{scope.row.login}}</span>
              <span v-else>{{scope.row.login}}</span>
            </template>
          </el-table-column>
          <el-table-column label="用户姓名" :show-overflow-tooltip="true">
            <template slot-scope="scope">
              <span class="font-grey" v-if="scope.row.selected">{{scope.row.cnName}}</span>
              <span v-else>{{scope.row.cnName}}</span>
            </template>
          </el-table-column>
        </el-table>
        <el-pagination
          @size-change="sizeChange"
          @current-change="pageChange"
          align="left"
          :current-page="queryForm.currentPage"
          :page-size="queryForm.pageSize"
          layout="total, prev, pager, next"
          :total="total"
        ></el-pagination>
      </div>

      <!-- 已选列表 -->
      <el-table
        size="small"
        class="dis-table"
        :data="distribute"
        align="center"
        border
        height="352"
      >
        <el-table-column label="候选用户">
          <template slot-scope="scope">
            <span
              :title="scope.row.cnName+'（'+scope.row.login+'）'"
            >{{scope.row.cnName}}（{{scope.row.login}}）</span>
            <i class="iconfont icon-del" title="移除" @click="removeDistribute(scope.row)"></i>
          </template>
        </el-table-column>
      </el-table>
    </el-main>
    <el-footer>
      <div align="right">
        <el-button type="primary" size="small" @click="confirm">确定提交</el-button>
        <el-button size="small" @click="cancel">取消</el-button>
      </div>
    </el-footer>
  </el-container>
</template>
<script>
import { APPID } from "assets/scripts/code";
export default {
  props: ["orgId"],
  mounted() {
    this.query();
  },
  data() {
    return {
      distribute: [],
      userData: [],
      queryForm: {
        name: "",
        currentPage: 1,
        pageSize: 10
      },
      total: 0,
      loading: false
    };
  },
  methods: {
    //分页
    sizeChange(size) {
      this.queryForm.pageSize = size;
      this.query(1);
    },

    pageChange(page) {
      this.queryForm.currentPage = page;
      this.query();
    },

    //获取待添加用户列表
    query(resetPage) {
      if (resetPage == 1) {
        this.queryForm.currentPage = 1;
      }

      let param = {
        page: this.queryForm.currentPage - 1,
        size: this.queryForm.pageSize,
        appId: APPID,
        value: this.queryForm.name
      };

      this.$api.user.searchUser(param).then(
        res => {
          let { content, totalElements } = res;
          this.userData = content;
          this.userData.forEach(user => {
            if (
              user.authorities.indexOf("ROLE_DW_SUPERADMIN") > -1 ||
              user.authorities.indexOf("ROLE_DW_APPADMIN") > -1
            ) {
              this.$set(user, "selected", true);
            }
          });
          this.updateUserData();
          this.total = totalElements;
        },
        error => {}
      );
    },

    //选择用户
    changeUserFun(user) {
      if (!this.distribute.length) {
        this.distribute = JSON.parse(JSON.stringify(user));
      }
      this.userData.forEach(item => {
        user.find(unit => {
          if (unit.id === item.id) {
            this.$set(item, "selected", true);
            if (this.distribute.length > 0) {
              let hasUser = false;
              this.distribute.find(dis => {
                if (dis.id === unit.id) {
                  hasUser = true;
                }
              });
              if (!hasUser) {
                this.distribute.push(JSON.parse(JSON.stringify(item)));
              }
            }
          }
        });
      });
    },

    // 用户选中
    userSelected(row) {
      if (row.selected) {
        return false;
      } else {
        return true;
      }
    },

    // 移除用户
    removeDistribute(row) {
      // 移除distribute中的数据
      this.distribute = this.distribute.filter(item => {
        return item.id !== row.id;
      });
      this.updateUserData();
    },

    // 根据候选更新用户
    updateUserData() {
      this.userData.forEach(item => {
        if (this.distribute.length > 0) {
          let findFlag = false;
          this.distribute.find(unit => {
            if (unit.id === item.id) {
              this.$set(item, "selected", true);
              findFlag = true;
            }
          });

          if (
            !findFlag &&
            !(
              item.authorities.indexOf("ROLE_DW_SUPERADMIN") > -1 ||
              item.authorities.indexOf("ROLE_DW_APPADMIN") > -1
            )
          ) {
            this.$set(item, "selected", false);
            this.$refs.userTable.toggleRowSelection(item, false);
          }
        } else {
          if (
            item.authorities.indexOf("ROLE_DW_SUPERADMIN") > -1 ||
            item.authorities.indexOf("ROLE_DW_APPADMIN") > -1
          ) {
            this.$set(item, "selected", true);
          } else {
            this.$set(item, "selected", false);
            this.$refs.userTable.toggleRowSelection(item, false);
          }
        }
      });
    },

    //取消导入
    cancel() {
      this.$emit("close");
    },

    //确认导入
    confirm() {
      let login = [];
      if (this.distribute.length > 0) {
        this.distribute.forEach(item => {
          login.push(item.login);
        });
      }

      let param = {
        orgId: this.orgId,
        login: login,
        stopOnfailure: false
      };
      this.loading = true;
      this.$api.user.addUserdeputies(param).then(
        res => {
          this.loading = false;
          this.$emit("query");
          this.cancel();
        },
        error => {
          this.loading = false;
        }
      );
    },

    // 点击行toggle复选框
    rowClick(row) {
      if (
        row.authorities.indexOf("ROLE_DW_SUPERADMIN") > -1 ||
        row.authorities.indexOf("ROLE_DW_APPADMIN") > -1
      ) {
        this.$refs.userTable.toggleRowSelection(row, false);
      } else {
        this.$refs.userTable.toggleRowSelection(row, true);
      }
    }
  }
};
</script>
<style rel="stylesheet/less" lang="less">
.el-dialog__body {
  padding: 10px;
}
.el-container {
  .el-header.dialog-header {
    height: 40px !important;
    padding: 0 15px;
  }
  .el-main.dialog-main {
    margin-top: 0;
    padding: 15px;
    min-height: 100px !important;
    margin-bottom: 0;
    .el-table td {
      padding: 3px 0 !important;
    }
    .el-pagination {
      min-height: 30px !important;
    }
    .el-table__empty-block {
      min-height: 168px;
    }
  }
}

.import-user {
  .remain-num {
    display: inline-block;
    height: 30px;
    line-height: 38px;
    margin-right: 20px;
  }
  .user-table,
  .dis-table {
    float: left;
    width: 40%;
  }

  .user-table {
    width: 50%;
    margin-right: 10%;
    // span {
    //   white-space: nowrap;
    //   text-overflow: ellipsis;
    //   -o-text-overflow: ellipsis;
    //   overflow: hidden;
    // }
  }
  .dis-table {
    span {
      white-space: nowrap;
      text-overflow: ellipsis;
      -o-text-overflow: ellipsis;
      overflow: hidden;
    }
    .icon-del {
      color: #7e8287;
      position: absolute;
      left: 230px;
      font-size: 14px;
      top: 5px;
      cursor: pointer;
    }
  }
  .dialog-main {
    position: relative;
    .icon-change {
      position: absolute;
      top: 170px;
      left: 404px;
      font-size: 30px;
      color: #7d7f82;
    }
  }
}
</style>
<style lang="less">
.import-user {
  .el-table--scrollable-y .el-table__body-wrapper {
    overflow-y: auto !important;
  }
  td {
    cursor: pointer;
  }
  .el-table .cell,
  .el-table th div {
    padding-right: 50px;
  }
}
</style>




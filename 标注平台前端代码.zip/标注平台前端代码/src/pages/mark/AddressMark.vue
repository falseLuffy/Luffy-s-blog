<template>
  <mark-tpl
    class="address-mark"
    :appType="appType"
    :param="param"
    @query="query"
    @setQueryData="setQueryData"
    @valid="valid"
    @save="save"
  >
    <!-- 标题 -->
    <div class="address-title" slot="title">
      <span class="overflow">{{param.value}}</span>
      <template>
        <el-button
          type="danger"
          :disabled="mcType === 1"
          size="small"
          v-if="param.quality === -10"
          @click="availableClick"
        >坏数据</el-button>
        <el-button type="danger" size="small" class="btn-plain" v-else @click="availableClick">标为坏数据</el-button>
      </template>
    </div>

    <div slot="answer" class="address-answer">
      <!--标注区域-->
      <div class="mark-content">
        <h2>
          <span>[{{getLevel}}]</span>
          {{param.value}}
        </h2>
        <el-form class="forms" ref="form" :model="form" label-width="100px">
          <el-form-item label="名称类别：">
            <el-radio-group v-model="form.nameType" @change="handleType">
              <el-radio label="1">标准名</el-radio>
              <el-radio label="3">别名</el-radio>
              <el-radio label="2">错误名</el-radio>
              <el-radio label="4">其它</el-radio>
            </el-radio-group>
          </el-form-item>

          <!-- <el-form-item label="属性类别：" v-show="protoShow">
            <span class="protype">{{this.param.level}}</span>
            <el-radio-group v-model="form.proType">
              <el-radio label="1">正确</el-radio>
              <el-radio label="0">错误</el-radio>
            </el-radio-group>
          </el-form-item>-->

          <el-form-item label="标准名：" v-if="normalShow">
            <el-select
              v-model="form.normal"
              :remote-method="remoteMethod"
              filterable
              remote
              clearable
              :loading="loading"
              placeholder="请输入标准名"
              @change="selectName"
            >
              <el-option
                v-for="(item,index) in normalName"
                :key="index"
                :label="item"
                :value="item"
              ></el-option>
              <el-option label="其它" value="other"></el-option>
            </el-select>
          </el-form-item>

          <el-form-item label="备注：" v-if="descShow">
            <el-input type="text" clearable style="width:184px" v-model="form.desc"></el-input>
          </el-form-item>
        </el-form>
      </div>

      <!--地图区域-->
      <v-map :FsearchName="searchName" :Fkeyword="keyword" :Flocation="location"/>
    </div>
  </mark-tpl>
</template>

<script>
import MarkTpl from "./MarkTpl";
import { APPTYPE } from "assets/scripts/code";
import { setMarkData } from "assets/scripts/common";
import VMap from "../components/Map";

export default {
  name: "AddressMark",
  components: {
    MarkTpl,
    VMap
  },
  data() {
    return {
      appType: APPTYPE.ADDRESS,
      mcType: "",
      task: null,
      readonly: false,
      loading: false,
      searchName: "",
      markTitle: "",
      location: "",
      keyword: "",
      // protoShow:true,
      normalShow: false,
      descShow: false,
      normalName: [],
      form: {
        nameType: "1",
        // proType:'1',
        normal: "",
        desc: ""
      },
      param: {
        name: "",
        url: "",
        quality: 0, // "0"好 "-10"坏
        result: {}
      }
    };
  },

  created() {
    let task = JSON.parse(window.sessionStorage.getItem("task"));
    // 1检查,0标注
    this.mcType = task.type;
    this.readonly = task.readonly;
    this.task = task;
  },

  computed: {
    getLevel() {
      let result = "";
      const level = this.param.level;
      switch (level) {
        case "province":
          result = `${level}(省份)`;
          break;
        case "city":
          result = `${level}(市级)`;
        case "area":
          result = `${level}(县级)`;
          break;
        case "town":
          result = `${level}(乡镇街道级)`;
        case "village":
          result = `${level}(社区级)`;
          break;
        case "road":
          result = `${level}(街路巷)`;
        default:
          break;
      }
      return result;
    }
  },

  methods: {
    /**
     * 查询数据
     * @param param 请求参数
     * @param isCookie 是否是缓存
     */
    query(param, isCookie) {
      let id = param.userTaskItemId;
      delete param.dataId;
      this.$api.mark
        .getMarkFile(param)
        .then(res => {
          res.userTaskItemId = id;
          if (isCookie) {
            setMarkData(id, res);
          } else {
            setMarkData(id, res);
            this.setQueryData(res);
          }
        })
        .catch(() => {});
    },

    /**
     * 请求数据后的内容处理
     * @param res 请求的数据
     */
    setQueryData(res) {
      // reset
      this.form = {
        nameType: "1",
        normal: "",
        desc: ""
      };
      this.normalName = [];
      this.normalShow = false;
      this.descShow = false;
      // this.protoShow = true;
      // 设置
      let addressData;
      let mcType = this.mcType;

      // 1）检查
      if (mcType === 1) {
        addressData = res.checkedData ? res.checkedData : res.markedData;
      } else if (res.markedData && mcType === 0) {
        // 2）标注
        addressData = res.markedData;
      } else if (!res.markedData) {
        // 3）没有标注
        addressData = res.data;
      }
      // 数据赋值
      this.param = { ...this.param, ...res.data };
      this.param.quality =
        addressData.quality === -10 ? addressData.quality : 0;
      this.param.sourcePath = res.sourcePath;
      this.param.result = addressData.result ? addressData.result : {};
      if (addressData.result) {
        this.form.nameType = addressData.result.tag.toString();
        this.form.normal = addressData.result.stand;
        this.form.desc = addressData.result.remark;
        this.normalShow = addressData.result.tag === 3;
        this.descShow = addressData.result.stand === "other";
      }

      this.searchName = this.param.value;
      this.keyword = this.param.value;
      this.location = this.param.province;
      // 获取数据后，才可以点击下一条，防止快速点击事件
      this.param.clicked = false;
      if (this.param.keycodetimer) {
        this.param.keycodetimer = null;
        clearTimeout(this.param.keycodetimer);
      }
    },

    // 模糊查询标准名
    _getBlurName(query) {
      const param = {
        searchValue: query,
        locationLevel: this.param.level,
        page: 1,
        size: 10
      };
      this.$api.mark.getBlurName(param).then(res => {
        this.loading = false;
        let { content } = res;
        this.normalName = content;
      });
    },

    remoteMethod(query) {
      if (query !== "") {
        this.loading = true;
        this._getBlurName(query);
      } else {
        this.normalName = [];
      }
    },

    // 选择标准名
    handleType(val) {
      this.descShow = false;
      this.form.normal = "";
      val === "3" ? (this.normalShow = true) : (this.normalShow = false);
      // val === '2'||val ==='4'? this.protoShow = false: this.protoShow = true
    },

    //标准名中选择其它选项
    selectName(val) {
      val === "other" ? (this.descShow = true) : (this.descShow = false);
    },

    availableClick() {
      if (this.readonly || (this.mcType === 1 && !this.param.quality === -10)) {
        return;
      }
      let nowStatus = this.param.quality;
      if (nowStatus === 0) {
        if (this.param.result.length) {
          this.$confirm(
            "标记为坏数据后，已标注内容将会被清除，确认标记吗？",
            "",
            {
              lockScroll: false
            }
          )
            .then(() => {
              this.param.quality = -10;
              this.param.result = [];
            })
            .catch(() => {});
        } else {
          this.param.quality = -10;
        }
      } else {
        this.param.quality = 0;
      }
    },

    /**
     * 校验
     */
    valid() {
      if (this.param.quality === -10) {
        return true;
      } else {
        if (this.normalShow && this.form.normal === "") {
          this.param.valid = false;
          this.param.validMsg = "请选择一个标准名";
        }
        if (this.descShow && this.form.desc === "") {
          this.param.valid = false;
          this.param.validMsg = "请输入一个标准名";
        }
      }
    },

    /**
     * 保存数据,只保存需要保存的数据
     */
    save() {
      const results = {
        tag: +this.form.nameType,
        stand: this.form.normal,
        remark: this.form.desc
      };
      this.param.commitData = {
        result: results,
        quality: this.param.quality
      };
    }
  }
};
</script>

<style lang="less" scoped>
.address-mark {
  .address-title {
    display: flex;
    align-items: center;
    .overflow {
      display: inline-block;
      max-width: 400px;
      margin: 0 15px;
    }
  }
  .address-answer {
    display: flex;
    .mark-content {
      flex: 1;
      margin-right: 10px;
      h2 {
        text-align: center;
        padding: 20px;
        border-radius: 4px;
        line-height: 1.5;
        font-weight: 500;
        font-size: 20px;
        background: #f1f8fe;
        span {
          font-size: 14px;
          margin-right: 20px;
          color: #666;
        }
      }
      .forms {
        margin-top: 20px;
        .protype {
          margin-right: 10px;
          color: #888;
        }
      }
    }
  }
}
</style>



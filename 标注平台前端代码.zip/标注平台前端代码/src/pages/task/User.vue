<template>
  <el-container class="user-index">
    <el-header height="10%">
      <!-- 查询条件 -->
      <el-form
        size="small"
        :inline="true"
        ref="queryForm"
        class="query-form"
        @submit.native.prevent
      >
        <el-form-item>
          <el-input
            v-model="keyStr"
            placeholder="搜索用户名称"
            :maxlength="30"
            clearable
            suffix-icon="el-icon-search"
            @keyup.enter.native="query(1)"
            @change="query(1)"
          ></el-input>
        </el-form-item>
      </el-form>
      <el-button size="small" class="task-add" type="success" @click="importUser">导入用户</el-button>
    </el-header>
    <el-main>
      <el-table size="small" :data="userData" class="task-user-list" align="center">
        <el-table-column
          type="index"
          :index="(index)=>{return (currentPage - 1) * pageSize + index + 1}"
          label="序号"
          min-width="50"
        ></el-table-column>
        <el-table-column label="用户名" min-width="100" :show-overflow-tooltip="true">
          <template slot-scope="scope">
            <strong class="user-login" @click="userDetail(scope.row)">{{scope.row.login}}</strong>
          </template>
        </el-table-column>
        <el-table-column prop="cnName" label="用户姓名" width="400" :show-overflow-tooltip="true"></el-table-column>
        <el-table-column label="用户角色" min-width="140">
          <template slot-scope="scope">
            <el-checkbox-group
              v-model="scope.row.authorities"
              @change="changeRole(scope.row)"
              size="mini"
              v-if="!(scope.row.authorities.indexOf('ROLE_DW_APPADMIN')>-1)"
            >
              <el-checkbox-button
                v-for="(item,index) in roles"
                :label="item.id"
                :key="index"
                @change="changeBtn"
                style
              >{{item.name}}</el-checkbox-button>
            </el-checkbox-group>
          </template>
        </el-table-column>
        <el-table-column label="操作" min-width="140">
          <template slot-scope="scope">
            <el-button
              plain
              @click="delUser(scope.row.login)"
              size="mini"
              v-if="!(scope.row.authorities.indexOf('ROLE_DW_APPADMIN')>-1)"
            >移除</el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-pagination
        v-if="total > 10"
        @size-change="sizeChange"
        @current-change="pageChange"
        align="right"
        :current-page="currentPage"
        :page-sizes="[10, 20, 50, 100]"
        :page-size="pageSize"
        layout="total, sizes, prev, pager, next, jumper"
        :total="total"
      ></el-pagination>

      <!--导入用户-->
      <el-dialog width="700px" title="导入用户" :visible.sync="showUser" top="1%" :lock-scroll="false">
        <import-user @close="closeDialog" @query="query" v-if="showUser" :orgId="orgId"></import-user>
      </el-dialog>

      <el-dialog
        class="user-del"
        width="400px"
        title="删除提示"
        :visible.sync="showDel"
        top="1%"
        :lock-scroll="false"
        style="margin-top: 3%;"
      >
        <div
          class="del-danger"
          style="line-height: 28px;text-indent: 20px;font-weight: bold;"
        >移除用户后，该用户下的所有角色都被删除，请问确认删除吗？</div>
        <el-button type="primary" @click="sureDel()" style="margin-left: 280px">确认</el-button>
      </el-dialog>
    </el-main>
  </el-container>
</template>
<script>
import { mapState } from "vuex";
import ImportUser from "./ImportUser";

export default {
  components: { ImportUser },
  computed: {
    ...mapState(["user", "appInfo"])
  },
  mounted() {
    this.query();
    this.orgId = this.appInfo.orgId;
  },
  watch: {
    appInfo() {
      if (this.appInfo.orgId) {
        this.query();
        this.orgId = this.appInfo.orgId;
      }
    }
  },
  data() {
    return {
      currentPage: 1,
      pageSize: 10,
      total: 0,
      userData: [],
      oriData: [],
      showUser: false,
      showDel: false,
      delName: "",
      roleName: "",
      checked: false,
      roles: [
        { id: "ROLE_DW_MARKER", name: "标注员" },
        { id: "ROLE_DW_CHECKER", name: "检查员" }
      ],
      keyStr: "",
      orgId: "",
      isOne: false
    };
  },
  methods: {
    //用户个人统计
    userDetail(row) {
      if (row.authorities.indexOf("ROLE_DW_APPADMIN") > -1) {
        this.$message.warning("该用户为应用管理员");
        return;
      }

      window.sessionStorage.setItem("userInfo", JSON.stringify(row));
      this.$router.push({ path: "/task/userStatistics" });
    },
    //打开导入窗口
    importUser() {
      // window.sessionStorage.setItem("selectedUser",JSON.stringify(this.userData));
      this.showUser = true;
    },

    //获取用户列表
    query(resetPage) {
      if (resetPage == 1) {
        this.currentPage = 1;
      }
      if (!this.appInfo.orgId) {
        return;
      }

      let param = {
        page: this.currentPage - 1,
        size: this.pageSize,
        orgId: this.appInfo.orgId,
        value: this.keyStr
      };

      this.$api.user.getUserdeputies(param).then(res => {
        let { content, totalElements } = res;
        this.userData = content;
        if (this.userData instanceof Array && this.userData.length === 1) {
          this.isOne = true;
        } else {
          this.isOne = false;
        }
        //深拷贝
        this.oriData = JSON.parse(JSON.stringify(content));
        this.total = totalElements;
      });
    },

    // 分页
    sizeChange(size) {
      this.pageSize = size;
      this.query(1);
    },

    pageChange(page) {
      this.currentPage = page;
      this.query();
    },

    //关闭导入弹窗
    closeDialog() {
      this.showUser = false;
    },

    //打开删除用户弹窗
    delUser(name) {
      this.showDel = true;
      this.delName = name;
    },

    //确认删除用户
    sureDel(name) {
      let param = {
        orgId: this.appInfo.orgId,
        login: this.delName
      };
      //如果当页只有一条数据，删除数据后跳转到上一页
      if (this.isOne && this.currentPage !== 1) {
        this.currentPage = this.currentPage - 1;
      }
      this.$api.user.delUserdeputies(param).then(
        res => {
          this.query();
          this.showDel = false;
        },
        error => {}
      );
    },

    //添加或移除兼职
    changeRole(value) {
      //改变后的角色数组
      let roles = value.authorities;
      //获取新添加的角色
      if (roles.length > 0 && this.checked) {
        let num = roles.length - 1;
        this.roleName = roles[num];
      }
      //选中
      if (this.checked) {
        let loginArr = [];
        loginArr.push(value.login);

        //添加兼职
        this.$api.user
          .addUserdeputies({
            orgId: this.appInfo.orgId,
            roleName: this.roleName,
            login: loginArr,
            stopOnfailure: false
          })
          .then(
            res => {
              this.query();
            },
            error => {}
          );
      } else {
        //原始的角色数组
        let oriRoles = [];
        this.oriData.find(item => {
          if (item.id === value.id) {
            oriRoles = item.authorities;
          }
        });

        //找出移除的角色
        let a = new Set(oriRoles);
        let b = new Set(roles);
        let differenceRole = "";
        let array = Array.from(new Set([...a].filter(x => !b.has(x))));
        if (array.length > 0) {
          differenceRole = array[0];
        }

        // 删除兼职
        this.$api.user
          .delUserdeputies({
            orgId: this.appInfo.orgId,
            roleName: differenceRole,
            login: value.login,
            stopOnfailure: false
          })
          .then(
            res => {
              this.query();
            },
            error => {}
          );
      }
    },

    //选中或取消
    changeBtn(value) {
      this.checked = value;
    }
  }
};
</script>
<style>
.el-button--mini,
.el-button--mini.is-round {
  padding: 5px 10px;
}
.task-user-list::before {
  display: none;
}
.el-table.task-user-list {
  margin-bottom: 50px !important;
}
</style>
<style lang="less">
.user-index {
  .el-header {
    position: relative;
    padding: 20px 25px 0 25px;
    .icon-add {
      font-size: 14px;
    }
    .task-add {
      position: absolute;
      right: 24px;
      top: 20px;
    }
  }
  .task-user-list {
    .user-login {
      &:hover {
        cursor: pointer;
        color: #409eff;
      }
    }
    .el-checkbox-button.is-checked .el-checkbox-button__inner {
      background-color: #67c23a;
      border-color: #67c23a;
    }
    .el-checkbox-button__inner:hover {
      color: #606266;
      border-color: #dcdfe6;
    }
    .el-checkbox-button.is-checked:first-child .el-checkbox-button__inner {
      border-color: #dcdfe6;
      &:hover {
        color: white;
      }
    }
    .el-checkbox-button.is-checked:last-child .el-checkbox-button__inner {
      border-color: #67c23a;
      border-left: 0;
      &:hover {
        color: white;
      }
    }
    .el-checkbox-button:last-child .el-checkbox-button__inner {
      border-radius: 4px;
      margin-left: 30px;
      border-left: 1px solid #dcdfe6;
    }
    .el-checkbox-button:first-child .el-checkbox-button__inner {
      border-radius: 4px;
    }
    .el-checkbox-button.is-focus .el-checkbox-button__inner {
      border-color: #dcdfe6;
    }
    .el-button:focus,
    .el-button:hover {
      color: #606266;
      border-color: #dcdfe6;
    }
  }
  .el-table--scrollable-y .el-table__body-wrapper {
    overflow-y: hidden;
  }
  .user-del {
    .el-dialog__title {
      color: red;
    }
  }
}
</style>



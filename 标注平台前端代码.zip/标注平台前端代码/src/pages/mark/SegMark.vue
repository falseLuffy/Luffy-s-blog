<!-- 音频分段标注 -->
<template>
  <mark-tpl
    class="seg-mark"
    :appType="appType"
    :keysList="keysList"
    :param="param"
    @query="query"
    @setQueryData="setQueryData"
    @valid="valid"
    @save="save"
    @extraEvt="clearRegion"
  >
    <div slot="answer">
      <div class="seg-title">
        <span class="overflow" :title="param.wav_file">{{param.wav_file}}</span>
        <template>
          <el-button size="small" type="danger" v-if="param.bad" @click="availableClick">不可用</el-button>
          <el-button
            size="small"
            type="danger"
            class="btn-plain"
            v-else
            @click="availableClick"
          >标为不可用</el-button>
        </template>
      </div>
      <!-- 音频 -->
      <mark-audio
        v-if="audio"
        ref="markAudio"
        :audio="audio"
        :region="true"
        :leavemusic="leavemusic"
        :regionRead="regionRead"
        @ready="audioReady"
        @setActiveRegion="setActiveRegion"
        @deleteRow="deleteRow"
        @getListData="getListData"
      ></mark-audio>
      <!-- 表单 -->
      <el-form
        ref="markForm"
        :model="markForm"
        :rules="markRules"
        :inline="true"
        v-if="!this.readonly"
        label-width="110px"
        :class="['seg-form',{'form-active': rowActiveId}]"
      >
        <!-- 开始 -->
        <el-form-item prop="xmin" label="开始（秒）：">
          <el-input-number
            :min="0"
            :max="duration"
            :precision="2"
            :step="0.01"
            size="mini"
            v-model="markForm.xmin"
            @change="xminChange(true)"
          ></el-input-number>
        </el-form-item>
        <!-- 结束 -->
        <el-form-item prop="xmax" label="结束（秒）：">
          <el-input-number
            :min="0"
            :max="duration"
            :precision="2"
            :step="0.01"
            size="mini"
            v-model="markForm.xmax"
            @change="xmaxChange(true)"
          ></el-input-number>
        </el-form-item>
        <!-- 时间间隔 -->
        <el-form-item label="间隔时间：">
          <span class="font-success">{{timeLength}}秒</span>
        </el-form-item>
        <el-row class="seg-text">
          <!-- 内容 -->
          <el-form-item prop="text" label="内容：">
            <el-input
              size="small"
              placeholder="请输入内容"
              :maxlength="200"
              type="textarea"
              :rows="3"
              v-model="markForm.text"
            ></el-input>
          </el-form-item>
          <el-button size="mini" @click="addSegment">保存</el-button>
        </el-row>
      </el-form>
      <!-- 列表显示 -->
      <el-table
        border
        size="small"
        class="seg-table"
        :data="param.resultTxt"
        :row-class-name="tableRowClassName"
        @row-dblclick="selctSegment"
      >
        <el-table-column width="80" type="index" label="序号"></el-table-column>
        <el-table-column label="开始（秒）" prop="xmin"></el-table-column>
        <el-table-column label="结束（秒）" prop="xmax"></el-table-column>
        <el-table-column label="时长（秒）">
          <template slot-scope="scope">{{(scope.row.xmax - scope.row.xmin).toFixed(2)}}</template>
        </el-table-column>
        <el-table-column min-width="200" label="内容">
          <template slot-scope="scope">
            <span v-html="scope.row.text" style="display: inline-block;white-space: pre-wrap;"></span>
          </template>
        </el-table-column>
        <el-table-column min-width="100" label="操作" v-if="!this.readonly">
          <template slot-scope="scope">
            <!-- <el-button size="mini" @click="editSegment(scope.row,scope.$index)">修改</el-button> -->
            <el-button size="mini" @click="removeSegment(scope.row,scope.$index)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
  </mark-tpl>
</template>
<script>
import MarkTpl from "./MarkTpl";
import MarkAudio from "@/pages/common/Audio";
import { APPTYPE } from "assets/scripts/code";
import { formValid, setMarkData } from "assets/scripts/common";
export default {
  name: "segMark",
  components: {
    MarkTpl,
    MarkAudio
  },
  computed: {
    // 时间间隔
    timeLength() {
      const max = this.markForm.xmax;
      const min = this.markForm.xmin;
      return ((max ? max : 0) - (min ? min : 0)).toFixed(2);
    }
  },
  data() {
    return {
      keysList: [
        {
          name: "功能说明",
          key: "快捷键"
        },
        {
          name: "播放切换",
          key: "Q"
        },
        {
          name: "删除标注",
          key: "DELETE"
        },
        {
          name: "保存并下一条",
          key: "空格"
        }
      ],
      appType: APPTYPE.YP,
      mcType: "",
      markForm: {
        xmin: "",
        xmax: "",
        text: ""
      },
      activeRegion: {}, // 当前正在操作的region
      rowActiveId: null,

      selectRegion: {},
      region: true,
      regionRead: false,
      duration: 0,
      audio: null,
      leavemusic: false,
      readonly: false,
      param: this.getResetData(),
      showSuccess: false,
      showError: false,
      wavesurfer: null,
      markRules: {
        xmin: [
          { required: true, message: "请输入开始时间", trigger: "change" }
        ],
        xmax: [
          { required: true, message: "请输入结束时间", trigger: "change" }
        ],
        text: [
          { required: true, message: "请输入内容", trigger: "blur" }
          // { validator: formValid.specialKeyValidator, trigger: "blur" }
        ]
      }
    };
  },
  methods: {
    /**
     * 更改表格的样式
     */
    tableRowClassName(res) {
      if (
        this.param.resultTxt[res.rowIndex].regionId == this.rowActiveId &&
        this.rowActiveId
      ) {
        return "success-row";
      } else {
        return "";
      }
    },

    /**
     * 查询数据
     * @param param 请求参数
     * @param isCookie 是否是缓存
     */
    query(param, isCookie) {
      let id = param.userTaskItemId;
      let dataId = param.dataId;
      delete param.dataId;

      this.$api.mark
        .getMarkFile(param)
        .then(res => {
          res.userTaskItemId = id;
          res.dataId = dataId;
          if (isCookie) {
            setMarkData(id, res);
          } else {
            setMarkData(id, res);
            this.setQueryData(res);
          }
        })
        .catch(() => {});
    },

    /**
     * 请求数据后的内容处理
     * @param res 请求的数据
     */
    setQueryData(res) {
      this.param = this.getResetData();

      this.markForm = {
        xmin: "",
        xmax: "",
        text: ""
      };

      let segData;
      let mcType = this.mcType;

      // 1）检查
      if (mcType == 1) {
        segData = res.checkedData ? res.checkedData : res.markedData;
      } else if (res.markedData && mcType == 0) {
        // 2）标注
        segData = res.markedData;
      } else if (!res.markedData) {
        // 3）没有标注
        segData = res.data;
      }

      this.param = Object.assign({}, this.param, segData);
      this.progress = true;

      //音频加载
      let reqUrl = location.origin;
      this.audio = `${reqUrl}/base/datawood-processor/download/source/${res.dataId}`;

      // 获取数据后，才可以点击下一条，防止快速点击事件
      this.param.clicked = false;
      if (this.param.keycodetimer) {
        this.param.keycodetimer = null;
        clearTimeout(this.param.keycodetimer);
      }

      this.$nextTick(() => {
        // 存储数据绘制区域
        if (this.param.resultTxt && this.param.resultTxt.length > 0) {
          this.param.resultTxt = this.$refs.markAudio.getResults(
            this.param.resultTxt
          );
        }
      });
    },

    /**
     * 重置数据
     */
    getResetData() {
      this.rowActiveId = null;
      return {
        bad: false,
        wav_file: "",
        resultTxt: []
      };
    },

    /**
     * 校验
     */
    valid() {
      // if (this.readonly) {
      //   this.$refs.markAudio.clearRegion();
      //   return true;
      // }

      // 判断最大值
      let results = this.param.resultTxt;
      let max = 0;
      // 判断交叉
      let isMerge = false;

      for (var i = 0, len = results.length; i < len; i++) {
        // 最大值
        let item = results[i];
        let cMin = item.xmin;
        let cMax = item.xmax;
        if (max < cMax) {
          max = cMax;
        }

        // 交叉
        if (i > 0 && !isMerge) {
          let rMin = results[i - 1].xmin;
          let rMax = results[i - 1].xmax;

          if (
            (cMin < rMin && cMax > rMin) ||
            (cMin < rMax && cMax > rMax) ||
            (cMin >= rMin && cMax <= rMax)
          ) {
            isMerge = true;
            break;
          }
        }
      }
      // 超过最大值
      if (this.duration < max) {
        this.param.valid = false;
        this.param.validMsg = "存在超过音频总时长的标注片段";
        return;
      }

      // 有交叉
      if (isMerge) {
        this.param.valid = false;
        this.param.validMsg = "存在交叉时间的标注片段";
        return;
      }
    },

    /**
     * 保存数据，这里不做处理，直接返回this.param
     */
    save() {
      // 数据清空
      // this.$refs.markAudio.clearRegion();

      // 音频长存储
      this.param.xmin = 0;
      this.param.xmax = this.duration;

      // 删除reginID
      if (this.param.resultTxt && this.param.resultTxt.length > 0) {
        this.param.resultTxt.forEach(item => {
          delete item.regionId;
        });
      }
      return true;
    },

    /**
     * 清除区间
     */
    clearRegion() {
      this.$refs.markAudio.clearRegion();
    },

    /**
     * 音频更改激活区域
     */
    setActiveRegion(res) {
      let { start, end, text, id } = res;
      this.markForm.xmin = start;
      this.markForm.xmax = end;

      if (text !== undefined) {
        this.markForm.text = text;
      }

      this.rowActiveId = id;
    },

    /**
     * 输入开始时间
     */
    xminChange(boolean) {
      if (boolean !== true) {
        return;
      }
      let { xmin, xmax } = this.markForm;
      if (xmax && xmin > xmax) {
        this.$message.error("开始时间不可大于结束时间");
        this.markForm.xmin = xmax;
        this.$nextTick(() => {
          this.markForm.xmin = xmax;
        });
      }

      // 更新激活区域数据
      this.$refs.markAudio.updateActiveRegion(this.markForm);
    },

    /**
     * 输入结束时间
     */
    xmaxChange(boolean) {
      if (boolean !== true) {
        return;
      }
      let { xmin, xmax } = this.markForm;

      if (xmin && xmax && xmax < xmin) {
        this.$message.error("结束时间不可小于开始时间");
        this.markForm.xmax = xmin;
        this.$nextTick(() => {
          this.markForm.xmax = xmin;
        });
      }

      // 更新激活区域数据
      this.$refs.markAudio.updateActiveRegion(this.markForm);
    },

    /**
     * 最大秒赋值
     */
    audioReady(duration, wavesurfer) {
      this.duration = duration;
      this.wavesurfer = wavesurfer;
    },

    /**
     * 文件可用点击
     */
    availableClick() {
      // 只读，检查员不可以改好数据
      if (this.readonly || (this.mcType == 1 && !this.param.bad)) {
        return;
      }

      this.param.bad = !this.param.bad;
    },

    /**
     * 插入片段
     */
    addSegment() {
      this.$refs.markForm.validate(flag => {
        if (flag) {
          if (this.timeLength < 0) {
            this.$message.warning("开始时间不可大于结束时间");
            return;
          }

          if (this.markForm.xmax == 0) {
            this.$message.warning("结束时间必须大于0");
            return;
          }

          let canAdd = true;
          let results = this.param.resultTxt;
          let activeIndex = -1;

          // 获取激活行的下标
          if (this.rowActiveId) {
            activeIndex = results.findIndex(item => {
              return item.regionId == this.rowActiveId;
            });
          }

          // 判断是否重复
          if (results.length > 0) {
            for (let i = 0, len = results.length; i < len; i++) {
              let index = activeIndex > -1 && activeIndex === i ? null : i;

              if (index !== null) {
                let cMin = parseFloat(this.markForm.xmin),
                  cMax = parseFloat(this.markForm.xmax),
                  rMin = parseFloat(results[index].xmin),
                  rMax = parseFloat(results[index].xmax);
                if (
                  (cMin < rMin && cMax > rMin) ||
                  (cMin < rMax && cMax > rMax) ||
                  (cMin >= rMin && cMax <= rMax)
                ) {
                  canAdd = false;
                  break;
                }
              }
            }
          }

          if (canAdd) {
            let currentData = { ...this.markForm };
            let regionId = this.$refs.markAudio.appendRegionToData(
              currentData.text
            );
            currentData.regionId = regionId;

            // 修改
            if (activeIndex > -1) {
              results.splice(activeIndex, 1, currentData);
            } else {
              results.push(currentData);
            }

            this.$refs.markForm.resetFields();
            results.sort((a, b) => {
              return a.xmin - b.xmin;
            });

            this.rowActiveId = null;
          } else {
            this.$message.warning("该分段已添加");
          }
        } else {
          return false;
        }
      });
    },

    /**
     * 删除片段
     * @param row 删除的行
     * @param index 删除的序号
     */
    removeSegment(row, index) {
      this.$confirm("您确定删除该段吗？", "", { lockScroll: false })
        .then(() => {
          // 删除标注图形
          let id = row.regionId;
          this.$refs.markAudio.removeRegion(id);

          this.param.resultTxt = this.param.resultTxt.filter((item, i) => {
            return i != index;
          });
        })
        .catch(() => {});
    },

    // 通过id删除
    deleteRow(id) {
      this.$confirm("您确定删除该段吗？", "", {
        lockScroll: false
      })
        .then(() => {
          this.param.resultTxt = this.param.resultTxt.filter((item, i) => {
            return item.regionId != id;
          });

          this.$refs.markAudio.removeRegion(id);
        })
        .catch(() => {});
    },

    /**
     * 通过id获取数据
     */
    getListData(id) {
      let res;
      res = this.param.resultTxt.filter((item, i) => {
        return item.regionId === id;
      });

      this.$refs.markAudio.updateIdRegion(res && res[0] ? { ...res[0] } : "");
    },

    /**
     * 编辑片段
     * @param seg 片段信息
     * @param index 片段序号
     */
    editSegment(seg, index) {
      this.$prompt(
        "时间段" + seg.xmin + "秒-" + seg.xmax + "秒",
        "标注内容修改",
        {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          inputType: "textarea",
          inputValue: seg.text,
          lockScroll: false,
          inputValidator: value => {
            // let pattern = new RegExp(
            //   "[`~!@#$^&%*()=|{}':;',\\[\\].<>/?~！@#￥……&*（）——|{}【】‘；：”“'。，、？]"
            // );
            // if (pattern.test(value) || /\s+/g.test(value)) {
            //   return "只能输入纯文本，不可输入特殊字符包括空格和换行";
            // }
            if (value.replace(/(^\s*)|(\s*$)/g, "") == "") {
              return "修改内容不能为空";
            }
            if (value.length > 200) {
              return "不能超过200个字符";
            }
          }
        }
      )
        .then(({ value }) => {
          seg.text = value;
        })
        .catch(() => {});
    },

    /**
     * 选择区域
     */
    selctSegment(row, event) {
      event.preventDefault();
      let isSelf =
        this.rowActiveId && this.rowActiveId === row.regionId ? true : false;
      this.$refs.markAudio.changeActiveRegion(row.regionId, isSelf);
    },
 
    /**
     * 设置最大小数位
     * @param param 设置数最大是6位小数
     */
    setNumber(param) {
      let obj = { ...this.markForm };
      let str = obj[param].toString();
      let index = str.indexOf(".");
      if (index > -1 && str.substring(index + 1).length > 6) {
        this.markForm[param] = Number(Number(str).toFixed(6));
      }
    },

    /**
     * 组件离开前
     */
    leave() {
      if (this.wavesurfer) {
        this.leavemusic = !this.leavemusic;
      }
    }
  },
  created() {
    let task = JSON.parse(window.sessionStorage.getItem("task"));
    this.task = task;
    // 1检查,0标注
    this.mcType = task.type;
    this.readonly = task.readonly;

    if (this.readonly) {
      this.regionRead = true;
    }
  },

  // /**
  //  * 离开前操作，暂停播放音乐
  //  */
  beforeRouteLeave(to, from, next) {
    this.leave();
    this.$nextTick(() => {
      next();
    });
  }
};
</script>

<style rel="stylesheet/less"  lang="less" scoped>
.font-success {
  font-weight: bold;
}
.seg-mark {
  .seg-title {
    .overflow {
      display: inline-block;
      max-width: 60%;
      margin-right: 10px;
      line-height: 22px;
      position: relative;
      top: 5px;
    }
  }
  .seg-form {
    border: transparent 2px solid;
    border-radius: 2px;
  }
  .form-active {
    border: #3ae33f 1px solid;
    position: relative;
    &:after {
      content: "正在编辑";
      display: inline-block;
      background: #3ae33f;
      position: absolute;
      right: 2px;
      top: 2px;
      padding: 4px 6px;
      font-size: 12px;
      color: #fff;
    }
  }
}
</style>

<style lang="less">
.seg-table {
  margin-top: 10px;
  .el-table__empty-text:before {
    display: none;
  }
  tr {
    cursor: pointer;
  }

  .success-row {
    background: #89b498 !important;
    color: black;
    &:hover {
      background: #89b498 !important;
      color: black;
      td {
        background: #89b498 !important;
        color: black;
      }
    }
  }
}

.seg-text {
  textarea {
    width: 420px;
  }
  button {
    margin-top: 46px;
  }
}

.seg-mark {
  .el-form-item__error {
    padding-top: 0px;
  }
}
</style>






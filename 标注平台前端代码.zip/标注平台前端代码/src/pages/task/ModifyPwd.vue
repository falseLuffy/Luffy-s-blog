<template>
  <section class="dialog">
    <el-form
      size="small"
      ref="userForm"
      :model="userForm"
      :rules="userRules"
      label-width="120px"
      labelPosition="right"
      @submit.native.prevent
    >
      <el-form-item prop="oldPassword" label="请输入旧密码:">
        <el-input
          name="oldPassword"
          type="password"
          v-model="userForm.oldPassword"
          :maxlength="30"
          placeholder="请输入旧密码"
        ></el-input>
      </el-form-item>
      <el-form-item prop="newPassword" label="请输入新密码:">
        <el-input
          name="newPassword"
          type="password"
          v-model="userForm.newPassword"
          placeholder="请输入新密码"
        ></el-input>
      </el-form-item>
      <el-form-item prop="surePassword" label="请确认新密码:">
        <el-input
          name="surePassword"
          type="password"
          v-model="userForm.surePassword"
          placeholder="再次确认新密码"
        ></el-input>
      </el-form-item>
    </el-form>
    <div slot="footer" align="right" class="section-footer">
      <el-button size="small" @click="hide">取消</el-button>
      <el-button type="primary" size="small" @click="modifyPwd">确定</el-button>
    </div>
  </section>
</template>

<script>
import { formValid } from "assets/scripts/common";
export default {
  name: "ModifyPwd",
  data() {
    return {
      userForm: {
        oldPassword: "",
        newPassword: "",
        surePassword: ""
      },
      userRules: {
        oldPassword: [
          { required: true, message: "请输入旧密码", trigger: "blur" },
          { validator: formValid.passwordValidator, trigger: "blur" },
          { min: 8, max: 16, message: "长度在 8 到 16 个字符", trigger: "blur" }
        ],
        newPassword: [
          { required: true, message: "请输入新密码", trigger: "blur" },
          { validator: formValid.passwordValidator, trigger: "blur" },
          { min: 8, max: 16, message: "长度在 8 到 16 个字符", trigger: "blur" }
        ],
        surePassword: [
          { required: true, message: "请输入确认密码", trigger: "blur" },
          { validator: formValid.passwordValidator, trigger: "blur" },
          { min: 8, max: 16, message: "长度在 8 到 16 个字符", trigger: "blur" }
        ]
      }
    };
  },
  methods: {
    // 更新密码
    modifyPwd() {
      this.$refs.userForm.validate(valid => {
        if (valid) {
          if (this.userForm.newPassword == this.userForm.surePassword) {
            this.$api.user
              .modifyPwd(this.userForm)
              .then(() => {
                this.hide();
                this.$message.success("密码修改成功");
                this.$emit("success");
              })
              .catch(() => {});
          } else {
            this.$message.warning("新密码与确认密码不一致，请重新输入");
          }
        }
      });
    },

    // 重置表单
    resetForm() {
      this.$refs.userForm.resetFields();
      this.$refs.userForm.clearValidate();
    },

    //隐藏
    hide() {
      this.resetForm();
    }
  }
};
</script>

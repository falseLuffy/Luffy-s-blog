<!-- 选择标注员 -->
<template>
  <el-container class="dispense-marker">
    <el-header class="dialog-header">
      <el-form
        size="small"
        :inline="true"
        :model="queryForm"
        ref="queryForm"
        @submit.native.prevent
      >
        <span class="remain-num">
          可分配任务总数：
          <strong>{{remainNum}}</strong>
        </span>
        <el-form-item>
          <el-input
            v-model="queryForm.value"
            clearable
            :maxlength="30"
            autofocus
            placeholder="搜索标注员名称"
            suffix-icon="el-icon-search"
            @keyup.enter.native="query(1)"
            @change="query(1)"
          ></el-input>
        </el-form-item>

        <el-form-item style="float:right">
          <el-button type="success" @click="countAvgNum">平均分配</el-button>
        </el-form-item>
      </el-form>
    </el-header>

    <!-- 列表 -->
    <el-main class="dialog-main">
      <!-- 用户列表 -->
      <div class="user-table">
        <el-table
          size="small"
          ref="userTable"
          :data="userData"
          @selection-change="changeUserFun"
          @row-click="rowClick"
          align="center"
          border
          height="352"
          v-loading="loading"
          element-loading-text="正在请求"
        >
          <el-table-column type="selection" width="50" :selectable="userSelected"></el-table-column>
          <el-table-column label="标注员" :show-overflow-tooltip="true">
            <template slot-scope="scope">
              <span
                class="font-grey"
                v-if="scope.row.selected"
              >{{scope.row.name}}（{{scope.row.userId}}）</span>
              <span v-else>{{scope.row.name}}（{{scope.row.userId}}）</span>
            </template>
          </el-table-column>
          <el-table-column label="当前未完成任务量" :show-overflow-tooltip="true">
            <template slot-scope="scope">
              <span class="font-grey" v-if="scope.row.selected">{{scope.row.incomplete}}</span>
              <span v-else>{{scope.row.incomplete}}</span>
            </template>
          </el-table-column>
        </el-table>
        <el-pagination
          @size-change="sizeChange"
          @current-change="pageChange"
          align="left"
          :current-page="queryForm.page"
          :page-size="queryForm.size"
          layout="total, prev, pager, next"
          :total="total"
        ></el-pagination>
      </div>

      <!-- 已选列表 -->
      <el-table
        size="small"
        class="dis-table"
        :data="distribute"
        align="center"
        border
        height="352"
      >
        <el-table-column label="候选标注员" :show-overflow-tooltip="true">
          <template slot-scope="scope">
            <span>{{scope.row.name}}（{{scope.row.userId}}）</span>
          </template>
        </el-table-column>
        <el-table-column label="分配数量">
          <template slot-scope="scope">
            <el-input-number size="small" v-model="scope.row.disNum" :min="0" :precision="0"></el-input-number>
            <i class="iconfont icon-del" title="移除" @click="removeDistribute(scope.row)"></i>
          </template>
        </el-table-column>
      </el-table>
    </el-main>
    <el-footer>
      <div align="right">
        <el-button type="primary" size="small" @click="confirm">确定提交</el-button>
        <el-button size="small" @click="hide">取消</el-button>
      </div>
    </el-footer>
  </el-container>
</template>

<script>
import { mapState, mapMutations } from "vuex";
export default {
  name: "chooseMarker",
  props: ["taskId", "totalNum"],
  computed: {
    ...mapState(["appInfo"]),
    //剩余可分配数量
    remainNum() {
      let total = this.totalNum;
      if (!total) return 0;
      var disNums = 0;
      if (this.distribute.length > 0) {
        this.distribute.forEach((item, i) => {
          disNums += item.disNum ? item.disNum : 0;
        });
      }
      var num = total - disNums;
      if (num < 0) {
        this.$message.error("数量超出可分配数量");
        this.canCommit = false;
      } else {
        this.canCommit = true;
      }
      return num > 0 ? num : 0;
    }
  },

  data() {
    return {
      loading: false,
      canCommit: true,
      userData: [], // 用户列表
      distribute: [], // 分配的人员列表
      queryForm: {
        orgId: "",
        value: "",
        page: 1,
        size: 10
      },
      total: 0,
      multiSelection: []
    };
  },
  methods: {
    ...mapMutations(["showLoading", "closeLoading"]),
    //分页
    sizeChange(size) {
      this.queryForm.size = size;
      this.query(1);
    },
    pageChange(page) {
      this.queryForm.page = page;
      this.query();
    },

    // 选中用户：选中后的用户列表禁用，分配列表加入，如果没有则直接添加，有则不动
    changeUserFun(user, row) {
      if (!this.distribute.length) {
        this.distribute = JSON.parse(JSON.stringify(user));
      }
      this.userData.forEach(item => {
        user.find(unit => {
          if (unit.userId === item.userId) {
            this.$set(item, "selected", true);
            if (this.distribute.length > 0) {
              let hasUser = false;
              this.distribute.find(dis => {
                if (dis.userId === unit.userId) {
                  hasUser = true;
                }
              });
              if (!hasUser) {
                this.distribute.push(JSON.parse(JSON.stringify(item)));
              }
            }
          }
        });
      });
    },

    // 点击行toggle复选框
    rowClick(row) {
      this.$refs.userTable.toggleRowSelection(row, true);
    },

    // 用户选中
    userSelected(row) {
      if (row.selected) {
        return false;
      } else {
        return true;
      }
    },

    // 根据候选更新标注员
    updateUserData() {
      this.userData.forEach(item => {
        if (this.distribute.length > 0) {
          //如果item.userId在distribute里，则禁用，否则开放
          let findFlag = false;
          this.distribute.find(unit => {
            if (unit.userId === item.userId) {
              this.$set(item, "selected", true);
              findFlag = true;
            }
          });

          if (!findFlag) {
            this.$set(item, "selected", false);
            this.$refs.userTable.toggleRowSelection(item, false);
          }
        } else {
          this.$set(item, "selected", false);
          this.$refs.userTable.toggleRowSelection(item, false);
        }
      });
    },

    // 移除用户
    removeDistribute(row) {
      // 移除distribute中的数据
      this.distribute = this.distribute.filter(item => {
        return item.userId !== row.userId;
      });

      this.updateUserData();
    },

    // 查询用户列表
    query(resetPage) {
      if (resetPage == 1) {
        this.queryForm.page = 1;
      }
      this.queryForm.orgId = this.appInfo.orgId;
      this.loading = true;
      this.$api.task
        .markerList(this.queryForm)
        .then(res => {
          this.loading = false;
          let { content, totalElements } = res;
          this.userData = content;
          this.total = totalElements;
          this.updateUserData();
        })
        .catch(() => {
          this.loading = false;
        });
    },

    // 平均分配
    countAvgNum() {
      if (this.distribute == null || this.distribute.length == 0) {
        this.$message.warning("请添加分配对象");
        return;
      }

      // 防止缓存不变
      this.distribute.forEach(item => {
        item.disNum = 0;
      });

      let total = this.remainNum,
        dataLength = this.distribute.length;

      //当分配的数量大于总数的时候
      if (total < dataLength) {
        // 前面几个都是1,后面的是0
        var num = total;
        this.distribute.forEach(item => {
          if (num > 0) {
            item.disNum = 1;
            num--;
          } else {
            item.disNum = 0;
          }
        });
      } else {
        this.avgNum = parseInt(total / dataLength)
          ? parseInt(total / dataLength)
          : 0;
        this.distribute = this.distribute.map(value => {
          value.disNum = this.avgNum;
          return value;
        });
        this.distribute[dataLength - 1].disNum =
          total - this.avgNum * (dataLength - 1);
      }
    },

    //确定
    confirm() {
      if (this.distribute == null || this.distribute.length == 0) {
        this.$message.error("请添加候选标注员");
        return;
      }

      let zeroDepsNum = false,
        assignedNum = 0;
      this.distribute.forEach(item => {
        if (!item.disNum) {
          zeroDepsNum = true;
        } else {
          assignedNum += item.disNum;
        }
      });
      if (zeroDepsNum) {
        this.$message.error("分配条数不能为0或空");
        return;
      }

      if (!this.canCommit) {
        this.$message.error("数量超出可分配数量");
        return;
      }

      let param = {
        taskId: this.taskId,
        distribute: this.distribute.map(item => {
          return { userId: item.userId, count: item.disNum };
        })
      };

      this.$confirm("标注员分配后将不可修改，确认提交分配吗？", "", {
        lockScroll: false
      })
        .then(res => {
          this.showLoading();
          //提交
          this.$api.task
            .distributeMarker(param)
            .then(res => {
              this.closeLoading();
              this.$message.success("提交成功");
              this.$emit("selected");
            })
            .catch(() => {
              this.closeLoading();
            });
        })
        .catch(() => {});
    },

    //隐藏
    hide() {
      this.$emit("hide");
    }
  },

  mounted() {
    this.query();
  }
};
</script>

<style rel="stylesheet/less" lang="less">
.el-dialog__body {
  padding: 10px;
}
.el-container {
  .el-header.dialog-header {
    height: 40px !important;
    padding: 0 15px;
  }
  .el-main.dialog-main {
    margin-top: 0;
    padding: 15px;
    min-height: 100px !important;
    margin-bottom: 0;
    .el-table td {
      padding: 3px 0 !important;
    }
    .el-pagination {
      min-height: 30px !important;
    }
    .el-table__empty-block {
      min-height: 168px;
    }
  }
}

.dispense-marker {
  .remain-num {
    display: inline-block;
    height: 30px;
    line-height: 38px;
    margin-right: 20px;
  }
  .user-table,
  .dis-table {
    float: left;
    width: 55%;
  }

  .user-table {
    width: 40%;
    margin-right: 5%;
    .el-table__row {
      cursor: pointer;
    }
  }
  .dis-table {
    .icon-del {
      color: #7e8287;
      position: relative;
      left: 10px;
      top: 5px;
      cursor: pointer;
    }
    .el-table .cell {
      line-height: 26px;
    }
  }
  .dialog-main {
    position: relative;
    .icon-change {
      position: absolute;
      top: 170px;
      left: 404px;
      font-size: 30px;
      color: #7d7f82;
    }
  }
}
</style>



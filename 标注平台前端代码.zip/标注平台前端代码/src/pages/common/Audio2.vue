<!-- 音频组件 -->
<template>
  <div class="mark-audio">
    <!-- 音频 -->
    <div class="wave-wrapper" id="waveWrapper">
      <div
        class="wave-container"
        :style="{width: waveContainerWidth}"
        @click="containerClick($event)"
        v-loading="progress"
        element-loading-background="rgba(0, 0, 0, 0.8)"
      >
        <div
          id="waveform"
          ref="waveform"
          class="wave-form"
          :style="{width: waveFormWidth,left: waveFormLeft}"
          @click.stop
        >
          <!-- <el-progress :percentage="percent" :stroke-width="8" v-if="progress"></el-progress> -->
        </div>
        <!-- 自定义指示线 -->
        <div class="wave-cursor" v-show="cursorShow" :style="{left: cursorLeft}"></div>
      </div>
    </div>

    <!-- 音频控制按钮 -->
    <div class="audio-group">
      <el-button
        type="primary"
        @click="play"
        size="small"
        :class="{'loop': (activeRegion && activeRegion.id)}"
      >
        <i :class="['iconfont',{'icon-run':runIcon,'icon-pause':!runIcon}]"></i>
        <span>{{playText}}</span>
      </el-button>
      <el-button type="warning" @click="stop" size="small">
        <i class="iconfont icon-stop"></i>重置
      </el-button>

      <div class="volume">
        <div class="volume-content">
          <i class="iconfont icon-voice"></i>
          <el-slider v-model="volume" @change="setVolume"></el-slider>
        </div>
      </div>

      <div class="time-show">
        <span class="time-text">时间：</span>
        <span class="font-primary current-time">{{currentTime}}秒</span>
        <span class="time-text">时长：</span>
        <span class="duration-time">{{duration}}秒</span>
      </div>
    </div>
  </div>
</template>

<script>
import WaveSurfer from "wavesurfer.js/dist/wavesurfer.js";
export default {
  props: ["audio", "leavemusic", "region", "regionRead"],
  data() {
    return {
      color1: "rgba(254, 240, 240, 0.5)", // 已选
      color3: "rgba(230, 189, 189, 0.8)", // 选中
      duration: 0,
      currentTime: 0,
      progress: true,
      percent: 0,
      wavesurfer: null,
      waveRegionBind: false,
      regionArray: {}, // 最终绘制的区域图形
      activeRegion: null, // 当前正在编辑的
      newRegion: false, // 是否手动更新
      volume: 50,
      playText: "播放",
      runIcon: true,
      results: null,
      autoPause: false,

      waveContainerWidth: "100%",
      waveFormWidth: "100%",
      waveFormLeft: 0,
      cursorShow: false,
      fromFinish: false,
      cursorLeft: 0,
      audioInfo: {},
      rangeBit: 600000, // 1分钟
      segNumbers: 0, // 段的总数
      blobPools: {}, // 请求过的blob
      currentSeg: null //正在播放的段
    };
  },

  components: {},

  watch: {
    // 控制音频源
    audio() {
      this.reset();
      this.audioPlay();
    },

    // 离开页面，停止音频播放
    leavemusic() {
      if (this.leavemusic) {
        this.wavesurfer.destroy();
        document.removeEventListener("keyup", this.setKeys);
      }
    }
  },

  methods: {
    reset() {
      this.duration = 0;
      this.currentTime = 0;
      this.progress = true;
      this.percent = 0;
      this.playText = "播放";
      this.runIcon = true;
      this.activeRegion = null;

      // 大音频参数
      this.audioInfo = {};
      this.segNumbers = 0;
      this.waveContainerWidth = "100%";
      this.waveFormWidth = "100%";
      this.waveFormLeft = 0;
      this.cursorShow = false;
      this.cursorLeft = 0;
      this.blobPools={}, // 请求过的blob
      this.currentSeg=null
    },

    /**
     * 获取当前时间
     */
    getCurrentTime(num) {
      if (num) {
        return Number(this.wavesurfer.getCurrentTime().toFixed(num));
      } else {
        return Number(this.wavesurfer.getCurrentTime().toFixed(2));
      }
    },

    /**
     * 音频初始化
     */
    audioPlay() {
      let that = this;
      // 获取音频信息
      this.$api.mark
        .getAudioInfo({
          path: this.audio
        })
        .then(res => {
          this.audioInfo = res;

          // 音频时长
          this.duration = Number((res.duration / 1000).toFixed(3));

          // 音频总段数
          this.segNumbers = Math.ceil(res.size / this.rangeBit);
          console.log("段总数", this.segNumbers);

          // 外层的宽度--音频总宽度
          this.waveContainerWidth = Math.round(this.duration * 20) + "px";
          let maxWidth = document
            .getElementById("waveform")
            .getBoundingClientRect().width;

          this.waveFormWidth = maxWidth + "px";

          // 创建wavesurfer
          if (!this.wavesurfer) {
            this.wavesurfer = WaveSurfer.create({
              container: this.$refs.waveform,
              waveColor: "#368666", //波纹
              progressColor: "#6d9e8b",
              hideScrollbar: true,
              cursorColor: "#fff",
              height: 80,
              responsive: true,
              scrollParent: true,
              maxCanvasWidth: 50000
            });
          };

          // 采样率赋值
          // this.wavesurfer.backend.ac.sampleRate = 22050

          console.log("前段的ac",this.wavesurfer.backend.ac);

          // 第一次获取音频片段
          this.getAudioSeg(1, false, true);
        })
        .catch(() => {});
    },

    /**
     * 获取音频片段
     * @param segNumber 加载第几段
     * @param justCache 仅仅缓存 true 仅缓存不加载
     * @param initLoad 初始加载
     */
    getAudioSeg(segNumber, justCache, initLoad) {
      console.log("请求了一次".segNumber);
      let that = this;
      let xhr = new XMLHttpRequest();
      let reqUrl = location.origin;
      xhr.open(
        "GET",
        `${reqUrl}/storage/api/audio/${this.audioInfo.code}`,
        true
      );
      xhr.responseType = "arraybuffer";

      let startBit = this.rangeBit * (segNumber - 1);
      let endBit = this.rangeBit * segNumber;
      xhr.setRequestHeader("Range", `bytes=${startBit}-${endBit}`);

      xhr.onload = function() {
        if (this.status === 206) {
          let type = xhr.getResponseHeader("Content-Type");
          let blob = new Blob([this.response], { type: type });

          // 加入缓存中
          that.blobPools[segNumber] = blob;
          console.log("缓存数据", that.blobPools);

          // 第一次加载第一段
          if (initLoad) {
            that.wavesurfer.loadBlob(blob);
            that.currentSeg = 1;
            that.wavesurferEvt();
          } else if (!justCache) {
            that.currentSeg = segNumber;
            that.wavesurfer.loadBlob(blob);
          }
        }
      };
      xhr.send();
    },

    /**
     * 绑定的wavesurfer事件
     */
    wavesurferEvt() {
      let that = this;

      // 加载时候
      this.wavesurfer.on("loading", percents => {
        this.percent = percents;
        window.sessionStorage.setItem("audioProgress", true);
      });

      // 加载成功
      this.wavesurfer.on("ready", () => {
        this.progress = false;
        window.sessionStorage.removeItem("audioProgress");

        this.$emit("ready", this.duration, this.wavesurfer);

        let canvasWidth = that.$refs.waveform.querySelector("canvas").width;
        if (canvasWidth) {
          this.waveFormWidth = canvasWidth + "px";
        }

       
        // 预加载下一段        
        if(this.currentSeg !== this.segNumbers){
          this.getAudioSeg(this.currentSeg + 1,true);
          // 自动播放来的
          if(this.fromFinish){
            this.fromFinish = false;
            this.play();
          }
        }
      });

      // 播放中
      this.wavesurfer.on("audioprocess", res => {
        let leftTime = parseFloat(this.waveFormLeft) / 20;
        this.currentTime = Number((res + leftTime).toFixed(2));
      });

      // 结束播放
      this.wavesurfer.on("finish", () => {
        this.setPause();
        // 不是最后一段，就加载下一段
        
        if (this.currentSeg !== this.segNumbers) {
          let nextSeg = this.currentSeg + 1;

          this.progress = true;
          //位移
            this.waveFormLeft = parseFloat(this.waveFormWidth) + parseFloat(this.waveFormLeft) + "px"

            console.log(this.waveFormLeft)

          // 有缓存数据
          if (this.blobPools[nextSeg]) {           

            

            // 加载缓存数据
            this.wavesurfer.loadBlob(this.blobPools[nextSeg]);

            // 更改当前的播放段数
            this.currentSeg = nextSeg;
            
          } else {
            this.getAudioSeg(nextSeg);
          }

          this.fromFinish = true;
        }
      });

      // 暂停播放
      this.wavesurfer.on("pause", res => {});

      // seek
      this.wavesurfer.on("seek", pos => {
        this.cursorShow = false;
        that.currentTime = that.getCurrentTime();
      });

      // 加载失败
      this.wavesurfer.on("error", () => {
        this.progress = false;
        window.sessionStorage.removeItem("audioProgress");
      });
    },

    /**
     * 点击容器
     */
    containerClick(e) {
      let offsetX = e.offsetX;
      this.cursorShow = true;
      this.cursorLeft = offsetX + "px";

      // 获取当前时间节点
      this.currentTime = offsetX / 20;

      // 获取字节所在TODO
      let currentBit = (this.audioInfo.bitrate * this.currentTime * 1024) / 8;
      // let {size,duration} = this.audioInfo;
      // let currentBit = size / duration * this.currentTime * 1000;
      let seg = Math.ceil(currentBit / this.rangeBit);
    },

    /**
     * 获取当前的字节
     */
    getNowBit(time) {
      let { bitrate } = this.audioInfo;
      return bitrate * time * 128;
    },

    /**
     * 取消上个激活，恢复位置
     */
    cancelActiveRegion() {
      let that = this;
      let activeId =
        this.activeRegion && this.activeRegion.id ? this.activeRegion.id : null;

      // 取消当前激活,，恢复原样
      if (activeId) {
        if (that.regionArray[activeId]) {
          // 获取列表中的数据，始终显示列表保存的数据，防止修改后不保存导致位置偏差
          this.$emit("getListData", activeId);
        } else {
          that.activeRegion.remove();
        }
      }

      // 编辑区域清空
      this.$emit("setActiveRegion", {
        start: 0,
        end: 0,
        text: ""
      });
      this.activeRegion = null;
    },

    /**
     * 从外部更新对应id的区域
     */
    updateIdRegion(res) {
      if (res) {
        let { regionId, text, xmin, xmax } = res;
        this.regionArray[regionId].update({
          color: this.color1,
          drag: false,
          start: xmin,
          end: xmax
        });
        this.regionArray[regionId].text = text;
      }
    },

    /**
     * 外部更新激活active区域
     */
    updateActiveRegion(res) {
      let { xmin, xmax, text } = res;
      let id = new Date().getTime();

      if (!this.activeRegion) {
        if (xmax > xmin) {
          this.activeRegion = this.wavesurfer.addRegion({
            id: id,
            start: xmin,
            end: xmax,
            loop: false,
            drag: true,
            resize: true,
            color: this.color3
          });

          this.newRegion = false;

          // 更新输入区数据start, end, text, id
          this.$emit("setActiveRegion", {
            start: xmin,
            end: xmax,
            text: text,
            id: id
          });

          // 指针移动
          this.wavesurfer.seekTo(xmin / this.duration);
        }
      } else {
        this.activeRegion.update({
          start: xmin,
          end: xmax
        });
      }
    },

    /**
     * 切换激活组件
     * @id 要激活的组件
     * @isSelf 激活组件是不是自己
     */
    changeActiveRegion(id, isSelf) {
      let that = this;

      // 取消当前激活
      that.cancelActiveRegion();

      // 重置激活
      if (that.regionArray[id]) {
        that.regionArray[id].update({
          color: isSelf ? that.color1 : that.color3,
          drag: this.regionRead ? false : true,
          resize: this.regionRead ? false : true
        });
      }

      if (!isSelf) {
        // 编辑区域同步显示
        that.$emit("setActiveRegion", { ...that.regionArray[id] });
        that.activeRegion = that.regionArray[id];
      } else {
        // 取消当前激活组件
        that.cancelActiveRegion();
      }
    },

    /**
     * 获取结果并设置结果
     */
    getResults(results) {
      results.forEach((item, index) => {
        item.regionId = (index + 1) * new Date().getTime();
      });
      this.results = [...results];
      return results;
    },

    /**
     * 生成一个region
     * item.xmin, item.xmax, item.regionId,item.text
     */
    addOneRegion(item) {
      let { xmin, xmax, regionId, text } = item;
      var rId = regionId ? regionId : new Date().getTime();

      let waveRegion = this.wavesurfer.addRegion({
        id: rId,
        start: xmin,
        end: xmax,
        loop: false,
        drag: true,
        resize: true,
        color: this.color1
      });

      waveRegion.text = text;
      this.regionArray[rId] = waveRegion;

      this.regionArray[rId].update({
        drag: false,
        resize: false
      });
    },

    /**
     * 清除所有的region
     */
    clearRegion() {
      // 清空有的音频
      this.wavesurfer.unAll();
      this.wavesurfer.disableDragSelection();
      this.wavesurfer.clearRegions();
      this.activeRegion = null;
      this.regionArray = {};

      this.vedioBg = "";
    },

    /**
     * 插入下一段修改区域情况
     */
    appendRegionToData(text) {
      let that = this;
      if (this.activeRegion) {
        // 停止播放
        if (!this.runIcon) {
          this.play();
        }

        // 禁止拖拽
        this.activeRegion.update({
          resize: false,
          drag: false,
          color: that.color1
        });

        let { id, element } = this.activeRegion;
        this.activeRegion.text = text;

        // 将绘制的区域放到数组中
        this.regionArray[id] = this.activeRegion;

        // 去除当前激活组件
        this.activeRegion = null;

        return id;
      }
    },

    /**
     * 删除绘制的标注图形
     */
    removeRegion(id) {
      if (id) {
        if (this.regionArray[id]) {
          this.regionArray[id].remove();
          if (
            this.activeRegion &&
            this.activeRegion.id &&
            id === this.activeRegion.id
          ) {
            this.cancelActiveRegion();
          }
        } else {
          this.activeRegion.remove();
          this.cancelActiveRegion();
        }
      }

      if (!this.runIcon) {
        this.play();
      }
    },

    /**
     * 设置暂停
     * @param boolean true 表示仅仅改文字
     */
    setPause(type) {
      this.autoPause = false; // 表示是不是自动暂停

      this.wavesurfer.pause();
      this.runIcon = true;
      this.playText = "播放";
    },

    /**
     * 设置播放
     */
    setPlay() {
      // 循环播放选中区域
      this.wavesurfer.play();

      this.runIcon = false;
      this.playText = "暂停";
    },

    /**
     * 播放/暂停切换
     */
    play() {
      if (this.progress) {
        this.$message.warning("请等音频加载完再操作");
        return;
      }
      if (this.playText === "播放") {
        if (this.currentTime == this.duration) {
          this.wavesurfer.stop();
        }
        this.setPlay();
      } else {
        this.setPause();
      }
    },

    /**
     * 停止播放
     */
    stop() {
      if (this.progress) {
        this.$message.warning("请等音频加载完再操作");
        return;
      }
      if (this.activeRegion && this.activeRegion.id) {
        this.autoPause = false;
      }
      this.wavesurfer.stop();
      this.runIcon = true;
      this.playText = "播放";
    },

    /**
     * 设置音量
     * @param value 音量大小
     */
    setVolume(value) {
      this.volume = value;
      this.wavesurfer.setVolume(value / 100);
    },

    /**
     * 快捷键设置
     */
    setKeys(e) {
      let that = this;
      const keyCode = e.keyCode || e.which;

      // 如果在文本框中则不可以使用快捷键
      var type = e.srcElement ? e.srcElement.type : e.target.type; // 看当前所处环境

      if (type === "text" || type === "textarea") {
        return;
      }

      if (document.getElementsByClassName("v-modal").length > 0) {
        // this.$message.error("请关闭弹窗后再操作");
        e.preventDefault();
        return;
      }

      // 点击Q键
      if (keyCode === 81) {
        e.preventDefault();
        this.play();
      }

      // 点击delete键
      if (
        keyCode == 46 &&
        this.activeRegion &&
        this.activeRegion.id &&
        !this.regionRead
      ) {
        this.$emit("deleteRow", this.activeRegion.id);
      }
    }
  },

  created() {
    this.$nextTick(() => {
      this.audioPlay();
      document.addEventListener("keyup", this.setKeys);
    });
  }
};
</script>
<style rel="stylesheet/less"  lang="less" scoped>
.wave-wrapper {
  height: 80px;
  overflow-x: auto;
  overflow-y: hidden;
  position: relative;
  box-sizing: border-box;
  margin: 10px auto 0;
  .wave-container {
    position: absolute;
    top: 0;
    left: 0;
    height: 80px;
    background: #000;
    box-sizing: border-box;
    &::after {
      position: absolute;
      content: "";
      width: 100%;
      height: 1px;
      background: #368666;
      display: inline-block;
      top: 50%;
      left: 1px;
    }
    .wave-cursor {
      position: absolute;
      content: "";
      width: 1px;
      height: 80px;
      background: #fff;
      display: inline-block;
      top: 0;
      left: 0;
      z-index: 2000;
    }
  }
}
.wave-form {
  height: 80px;
  position: absolute;
  background: #000;

  background-repeat: no-repeat;
  background-size: 100% 100%;
  .el-progress {
    position: absolute;
    top: 32px;
    left: 0;
    width: 100%;
    color: #fff;
  }
}
.audio-group {
  margin-bottom: 20px;
  button {
    padding: 6px 10px 6px 25px;
    position: relative;
    &.loop {
      background-color: #3ae33f;
      border-color: #3ae33f;
    }
    .iconfont {
      position: absolute;
      top: 4px;
      left: 7px;
      font-size: 16px;
    }
  }
  .volume {
    display: inline-block;
    width: 100px;
    vertical-align: middle;
    margin-left: 30px;
    position: relative;
    .iconfont.icon-voice {
      position: absolute;
      left: -25px;
      top: 10px;
      color: #585757;
    }
  }
  .time-show {
    float: right;
    line-height: 38px;
    .time-text {
      display: inline-block;
      width: 42px;
    }
    .current-time,
    .duration-time {
      margin-right: 15px;
      font-size: 16px;
      font-weight: bold;
    }
    .current-time {
      display: inline-block;
      margin-right: 0px;
      width: 75px;
    }
  }
}
</style>

<style lang="less" scoped>
.volume .el-slider__button {
  width: 12px;
  height: 12px;
}
.el-radio + .el-radio {
  margin-left: 15px;
}
.mark-region-end {
  position: relative;
  background-color: rgba(254, 255, 255, 0.4) !important;
}
.wavesurfer-region {
  cursor: pointer;
  &::before,
  &::after {
    width: 6px;
    height: 6px;
    border-radius: 5px;
    background-color: blue;
    position: absolute;
    content: "";
    display: inline-block;
    bottom: 0;
    z-index: 9999;
  }
  &::before {
    left: -3px;
  }
  &::after {
    background-color: red;
    right: -3px;
  }
}
.mark-region-select {
  background-color: rgba(230, 189, 189, 0.7) !important;
}
</style>

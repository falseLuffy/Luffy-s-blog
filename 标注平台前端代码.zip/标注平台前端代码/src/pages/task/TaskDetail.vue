<template>
  <el-container>
    <!-- 按钮 -->
    <el-header height="5%">
      <el-button class="back-btn" size="small" @click="prevStep">返回</el-button>
    </el-header>

    <el-main>
      <!-- 任务总览 -->
      <div id="one" class="task-info">
        <div class="task-text" v-if="taskInfo">
          <strong>
            任务名：
            <span class="overflow" :title="taskInfo.name">{{taskInfo.name}}</span>
            <span class="font-primary">{{taskInfo.statusDesc}}</span>
          </strong>
          <ul>
            <li>任务类型：{{taskInfo.taskType.name}}</li>
            <li>创建时间：{{taskInfo.createDate}}</li>
            <li>任务总量：{{taskInfo.totalCount}}条</li>
            <li>批次数：{{total2}}</li>
          </ul>
        </div>

        <ul class="task-precent" v-if="taskInfo">
          <li>
            <span>已分配</span>
            <el-progress type="circle" :percentage="p1"></el-progress>
            <span>{{taskInfo.markAssignedNum}}</span>
          </li>
          <li>
            <span>标注完成</span>
            <el-progress type="circle" :percentage="p2"></el-progress>
            <span>{{taskInfo.markCompleted}}</span>
          </li>
          <li>
            <span>检查完成</span>
            <el-progress type="circle" :percentage="p3"></el-progress>
            <span>{{taskInfo.checkCompletedNum}}</span>
          </li>
          <li>
            <span>已验收</span>
            <el-progress type="circle" :percentage="p4"></el-progress>
            <span>{{taskInfo.acceptedNum}}</span>
          </li>
        </ul>

        <div class="detail-btns">
          <el-button type="primary" size="mini" @click="openDispense">分配</el-button>
          <el-button type="primary" size="mini" @click="exportTask">导出</el-button>
          <el-dropdown size="mini">
            <el-button type="primary" size="mini" class="more-btn">
              更多
              <i class="el-icon-arrow-down el-icon--right"></i>
            </el-button>
            <el-dropdown-menu slot="dropdown">
              <el-dropdown-item
                @click.native="checkConfig"
                v-if="taskInfo && taskInfo.status !== 4"
              >配置</el-dropdown-item>
              <el-dropdown-item
                @click.native="addMoreTask"
                v-if="taskInfo && taskInfo.status !== 4"
              >继续添加</el-dropdown-item>
              <el-dropdown-item @click.native="delTask">移除</el-dropdown-item>
            </el-dropdown-menu>
          </el-dropdown>
        </div>
      </div>

      <!-- 任务统计 -->
      <div id="two" class="detail-progress">
        <el-radio-group size="small" v-model="date" @change="selectDate()">
          <el-radio-button label="1">今日</el-radio-button>
          <el-radio-button label="2">本周</el-radio-button>
          <el-radio-button label="3">本月</el-radio-button>
          <el-radio-button label>全部</el-radio-button>
        </el-radio-group>

        <el-date-picker
          size="small"
          @change="queryStatistic(true)"
          class="detail-date-picker"
          v-model="dateArr"
          type="daterange"
          range-separator="至"
          start-placeholder="开始日期"
          end-placeholder="结束日期"
        ></el-date-picker>

        <ul class="detail-bars">
          <ve-bar
            :data="barData"
            :settings="barSettings"
            :colors="barColors"
            :legend-visible="false"
            :tooltip-visible="false"
            :grid="barGrid"
            :xAxis="barX"
            width="80%"
            height="200px"
          ></ve-bar>
        </ul>
      </div>

      <!-- 子任务详情 -->
      <div id="three" class="middle-table">
        <!--列表导出-->
        <export-list-data
          :exportData="exportData"
          :json_fields="json_fields"
          :name="name"
          class="export-data"
        ></export-list-data>
        <!-- tab页 -->
        <el-tabs v-model="taskType" @tab-click="query(taskType,1)">
          <el-tab-pane label="标注详情" name="mark"></el-tab-pane>
          <el-tab-pane label="检查详情" name="check"></el-tab-pane>
        </el-tabs>

        <!-- 标注 -->
        <el-table
          size="small"
          key="markTable"
          :data="markData"
          align="center"
          height="450"
          v-if="isMark"
          v-loading="loading"
          element-loading-text="正在请求"
        >
          <el-table-column prop="markerId" label="账号" width="80" :show-overflow-tooltip="true"></el-table-column>
          <el-table-column prop="markerName" label="标注员" width="100" :show-overflow-tooltip="true"></el-table-column>
          <el-table-column prop="createdDate" label="创建时间" width="140" :formatter="dateFormat"></el-table-column>
          <el-table-column prop="statusDesc" label="状态"></el-table-column>
          <el-table-column prop="totalCount" label="任务总数"></el-table-column>
          <el-table-column prop="completeCount" label="已标注数"></el-table-column>
          <el-table-column prop="commitDate" label="提交时间" width="140" :formatter="dateFormat"></el-table-column>
          <el-table-column prop="检查员" label="检查员" width="150" :show-overflow-tooltip="true">
            <template
              slot-scope="scope"
              v-if="scope.row.inspectorId"
            >{{scope.row.inspectorName}}({{scope.row.inspectorId}})</template>
          </el-table-column>
          <el-table-column label="操作" width="150">
            <template slot-scope="scope">
              <el-button
                type="primary"
                size="mini"
                @click="recovery(scope.row.id)"
                v-if="scope.row.completeCount < scope.row.totalCount && scope.row.status !== -1"
              >回收</el-button>
              <el-button v-if="taskInfo.status !==4" type="primary" size="mini" @click="view(scope.row,0)">查看</el-button>
            </template>
          </el-table-column>
        </el-table>

        <!-- 检查 -->
        <el-table
          size="small"
          key="checkTable"
          :data="checkData"
          align="center"
          height="450"
          v-else
          v-loading="loading"
          element-loading-text="正在请求"
        >
          <el-table-column prop="inspectorId" label="账号" width="80" :show-overflow-tooltip="true"></el-table-column>
          <el-table-column
            prop="inspectorName"
            label="检查员"
            width="100"
            :show-overflow-tooltip="true"
          ></el-table-column>
          <el-table-column prop="createdDate" label="创建时间" width="140" :formatter="dateFormat"></el-table-column>
          <el-table-column prop="statusDesc" label="状态"></el-table-column>
          <el-table-column prop="totalCount" label="任务总数"></el-table-column>
          <el-table-column prop="completeCount" label="已检查数"></el-table-column>
          <el-table-column prop="commitDate" label="提交时间" width="140" :formatter="dateFormat"></el-table-column>
          <el-table-column label="抽检比例">
            <template slot-scope="scope">{{scope.row.checkRate}}%</template>
          </el-table-column>
          <el-table-column label="合格率">
            <template slot-scope="scope">
              <span>{{(scope.row.accuracy*100).toFixed(2)}}%</span>
            </template>
          </el-table-column>
          <el-table-column label="标注员" width="100" :show-overflow-tooltip="true"> 
            <template
              slot-scope="scope" 
              v-if="scope.row.markerId"
            >{{scope.row.markerName}}({{scope.row.markerId}})</template>
          </el-table-column>
          <el-table-column label="操作" min-width="100">
            <template slot-scope="scope" v-if="taskInfo.status !==4">
              <el-button :disabled="scope.row.status ===3" type="primary" size="mini" @click="view(scope.row,1)">查看</el-button>
            </template>
          </el-table-column>
        </el-table>

        <!-- 分页 -->
        <el-pagination
          v-if="total > 10"
          @size-change="sizeChange"
          @current-change="pageChange"
          align="right"
          layout="total, sizes, prev, pager, next, jumper"
          :current-page="page"
          :page-sizes="[5, 10, 20, 40]"
          :page-size="size"
          :total="total"
          class="pager-wrapper"
        ></el-pagination>
      </div>

      <!-- 数据批次 -->
      <div id="four" class="datawood-table" v-loading="loading2" element-loading-text="正在请求">
        <div class="datawood-name">数据批次信息</div>
        <el-row class="datawood-add" v-if="taskInfo && taskInfo.status !== 4">
          <el-button size="small" @click="addMoreTask">
            <i class="iconfont icon-add"></i>添加新批次数据
          </el-button>
        </el-row>
        <el-table size="small" :data="batchData" align="center" height="452">
          <el-table-column
            type="index"
            label="批次"
            width="100"
            :index="(index)=>{return (page2 - 1) * size2 + index + 1}"
          ></el-table-column>
          <el-table-column prop="totalCount" sortable label="数据数量"></el-table-column>
          <el-table-column prop="description" label="数据描述"></el-table-column>
          <el-table-column prop="statusDesc" label="数据状态"></el-table-column>
          <el-table-column prop="createdDate" label="上传时间" width="140" :formatter="dateFormat"></el-table-column>
        </el-table>
        <!-- 批次分页 -->
        <el-pagination
          v-if="total2 > 10"
          @size-change="sizeChange2"
          @current-change="pageChange2"
          align="right"
          layout="total, sizes, prev, pager, next, jumper"
          :current-page="page2"
          :page-sizes="[5, 10, 20, 40]"
          :page-size="size2"
          :total="total2"
          class="pager-wrapper"
        ></el-pagination>
      </div>

      <!-- 页面导航 -->
      <sub-nav :navData="navData"></sub-nav>
    </el-main>

    <!--查看任务配置-->
    <el-dialog
      :width="width"
      title="任务配置"
      top="2%"
      :visible.sync="showConfig"
      class="task-config"
      :lock-scroll="false"
    >
      <check-config :data="taskInfo" v-if="showConfig" @cancle="closeConfig"></check-config>
    </el-dialog>

    <!--添加-->
    <el-dialog
      width="560px"
      title="添加新批次数据"
      top="2%"
      :visible.sync="showData"
      class="add-data"
      :lock-scroll="false"
    >
      <div>
        <el-form size="small" :rules="rules" ref="addTask" :model="addTask">
          <!-- 批次备注 -->
          <el-form-item label="批次备注">
            <el-input
              type="textarea"
              rows="3"
              placeholder="请输入任务的简单描述"
              v-model="addTask.description"
              style="width:410px"
            ></el-input>
          </el-form-item>

          <!-- 文件上传方式选择 -->
          <el-form-item label="上传方式">
            <el-radio-group v-model="addTask.uploadMethod" @change="uploadMethodChange">
              <el-radio label="11">输入地址</el-radio>
              <el-radio label="10">文件上传</el-radio>
            </el-radio-group>
          </el-form-item>

          <!-- 文件上传：点击 -->
          <el-form-item label-width="0px" class="upload-item" v-if="uploadShow">
            <span class="label-required">导入文件</span>
            <div class="upload-wrapper">
              <i class="iconfont icon-upload"></i>
              <input
                type="file"
                @change="upload"
                accept=".csv, application/x-rar, application/zip, text/plain, application/json"
              >
              <span class="upload-name" v-text="fileName"></span>
            </div>
            <div class="upload-error" v-show="fileEmptyInfo">请上传文件</div>
          </el-form-item>

          <!-- 文件上传：地址 -->
          <el-form-item prop="filePath" label="文件地址" v-if="urlShow">
            <el-input v-model="addTask.filePath" placeholder="请输入上传地址"></el-input>
            <a v-if="pathUrl" :href="pathUrl" target="_blank">文件上传地址</a>
          </el-form-item>
        </el-form>

        <!-- 操作按钮 -->
        <el-button size="small" type="primary" @click="submit('addTask')" class="submit">确 定</el-button>
        <el-button size="small" @click="cancel">返 回</el-button>
      </div>
    </el-dialog>

    <!--导出-->
    <el-dialog
      width="910px"
      top="2%"
      :visible.sync="showExport"
      class="task-export"
      :lock-scroll="false"
    >
      <export-list v-if="showExport" :id="taskId"></export-list>
    </el-dialog>

    <!--删除-->
    <el-dialog
      class="datawood-del"
      width="400px"
      title="删除提示"
      :visible.sync="showDel"
      :lock-scroll="false"
    >
      <div class="del-danger">移除任务后，该任务下的所有子任务都将被移除，请问确认移除吗？</div>
      <el-button size="small" type="primary" @click="sureDel()">确认</el-button>
    </el-dialog>
  </el-container>
</template>

<script>
import { mapMutations } from "vuex";
import {
  getRate,
  getWeekStartAndEnd,
  getMonthStartAndEnd,
  setNavVisible
} from "assets/scripts/common";
import subNav from "pages/common/subNav";
import CheckConfig from "./CheckConfig";
import ExportList from "./ExportList";
//数据列表导出
import ExportListData from "./ExportListData";
export default {
  name: "TaskDetail",
  components: {
    subNav,
    CheckConfig,
    ExportList,
    ExportListData
  },
  watch: {
    taskType() {
      this.status = "";
      this.isMark = this.taskType === "mark" ? true : false;
    }
  },
  data() {
    return {
      p1: 0,
      p2: 0,
      p3: 0,
      p4: 0,
      getRate: getRate,
      navData: [
        {
          name: "任务总览",
          id: "one"
        },
        {
          name: "任务统计",
          id: "two"
        },
        {
          name: "子任务详情",
          id: "three"
        },
        {
          name: "批次数据管理",
          id: "four"
        }
      ],
      date: "",
      dateArr: [],
      today: "",
      week: "",
      month: "",
      taskId: "",
      barColors: ["#67c23a"],
      barSettings: {
        label: {
          show: true,
          position: "right",
          color: "#333"
        }
      },
      barGrid: {
        show: false,
        top: "0px",
        height: "200px",
        containLabel: true,
        right: "100px"
      },
      barData: {
        columns: ["名称", "a", "数量", "b"],
        rows: []
      },
      barX: [
        {
          splitNumber: 6,
          axisTick: {
            lineStyle: {
              color: "#333333"
            }
          },
          axisLine: {
            show: true,
            lineStyle: {
              color: "#333333",
              width: 1
            }
          },
          splitLine: {
            show: false
          }
        }
      ],
      markStatusData: [
        { value: "", label: "全部" },
        { value: "-1", label: "打回" },
        { value: "1", label: "待标注" },
        { value: "2", label: "标注中" },
        { value: "3", label: "标注已提交" },
        { value: "4", label: "检查中" },
        { value: "5", label: "检查已提交" },
        { value: "6", label: "已通过" }
      ],
      checkStatusData: [
        { value: "", label: "全部" },
        { value: "1", label: "待检查" },
        { value: "2", label: "检查中" },
        { value: "3", label: "已检查" },
        { value: "4", label: "已提交" },
        { value: "-1", label: "打回" }
      ],
      loading: false,
      loading2: false,
      markData: [],
      checkData: [],
      batchData: [],
      taskname: "",
      taskId: "",
      taskType: "mark",
      isMark: true,
      page: 1,
      size: 10,
      total: 0,

      markCentage: 0,
      checkCentage: 0,
      needMark: 0,
      needCheckNum: 0,
      markedCount: 0,
      checkedCount: 0,
      taskCount: 0,
      taskInfo: null,
      showConfig: false,
      showData: false,

      //添加批次
      page2: 1,
      size2: 10,
      total2: 0,
      addTask: {
        taskId: "",
        description: "",
        uploadMethod: "11",
        filePath: "",
        file: null
      },
      pathUrl: "",
      uploadShow: false,
      urlShow: true,
      fileName: "请选择文件",
      fileEmptyInfo: false,
      rules: {
        filePath: [
          { required: true, message: "请输入文件地址", trigger: "blur" }
        ]
      },
      showExport: false,
      showDel: false,
      width: "",

      //列表导出
      exportData: [],
      json_fields: {},

      //标注详情导出字段
      mark_fields: {
        账号: "markerId",
        标注员: "markerName",
        创建时间: "createdDate",
        状态: "statusDesc",
        任务总数: "totalCount",
        已标注数: "completeCount",
        提交时间: "commitDate",
        检查员: {
          callback: value => {
            return value.inspectorName + "(" + value.inspectorId + ")";
          }
        }
      },

      //检查详情导出字段
      check_fields: {
        账号: "inspectorId",
        检查员: "inspectorName",
        创建时间: "createdDate",
        状态: "statusDesc",
        任务总数: "totalCount",
        已检查数: "completeCount",
        提交时间: "commitDate",
        抽检比例: {
          field: "checkRate",
          callback: value => {
            return value + "%";
          }
        },
        合格率: {
          callback: value => {
            return getRate(value.passCount, value.totalCount);
          }
        },
        标注员: {
          callback: value => {
            return value.markerName + "(" + value.markerId + ")";
          }
        }
      },
      name: ""
    };
  },
  methods: {
    ...mapMutations(["showLoading", "closeLoading"]),
    // 子任务详情分页
    sizeChange(size) {
      this.size = size;
      this.query();
    },

    pageChange(page) {
      this.page = page;
      this.query();
    },

    // 批次分页
    sizeChange2(size) {
      this.size2 = size;
      this.queryBatch();
    },

    pageChange2(page) {
      this.page2 = page;
      this.queryBatch();
    },

    /**
     * 获取日期信息
     */
    getDateInfo() {
      // 今天
      let today = this.$moment(new Date().getTime()).format("YYYY-MM-DD");
      this.today = [];
      this.today.push(`${today} 00:00:00`);
      this.today.push(`${today} 23:59:59`);
      // 本周
      let week = getWeekStartAndEnd(0);
      let start = this.$moment(week[0]).format("YYYY-MM-DD");
      let end = this.$moment(week[1]).format("YYYY-MM-DD");
      this.week = [];
      this.week.push(`${start} 00:00:00`);
      this.week.push(`${end} 23:59:59`);

      // 本月
      let month = getMonthStartAndEnd(0);
      let start1 = this.$moment(month[0]).format("YYYY-MM-DD");
      let end1 = this.$moment(month[1]).format("YYYY-MM-DD");
      this.month = [];
      this.month.push(`${start1} 00:00:00`);
      this.month.push(`${end1} 23:59:59`);
    },

    /**
     * 日期选择
     */
    selectDate() {
      switch (this.date) {
        case "1":
          this.dateArr = [...this.today];
          break;
        case "2":
          this.dateArr = [...this.week];
          break;
        case "3":
          this.dateArr = [...this.month];
          break;
        case "":
          this.dateArr = [];
          break;
      }
      this.queryStatistic();
    },

    /**
     * 获取任务的基本信息内容，主要是任务总数
     */
    getTaskBaseInfo() {
      this.$api.task.getTaskBaseInfo({id: this.taskId}).then(res => {
          this.taskInfo = res;
          this.queryCircle()
          // this.taskInfo.totalCount = res.totalCount;
        });
    },

    /**
     * 获取环形图数据
     */
    queryCircle() {
      let {
        markAssignedNum,
        markCompleted,
        checkCompletedNum,
        acceptedNum
      } = this.taskInfo;
      this.taskInfo.markAssignedNum = markAssignedNum ? markAssignedNum : 0;
      this.taskInfo.markCompleted = markCompleted ? markCompleted : 0;
      this.taskInfo.checkCompletedNum = checkCompletedNum
        ? checkCompletedNum
        : 0;
      this.taskInfo.acceptedNum = acceptedNum ? acceptedNum : 0;

      this.p1 = parseFloat(
        getRate(this.taskInfo.markAssignedNum, this.taskInfo.totalCount)
      );
      this.p2 = parseFloat(
        getRate(this.taskInfo.markCompleted, this.taskInfo.totalCount)
      );
      this.p3 = parseFloat(
        getRate(this.taskInfo.checkCompletedNum, this.taskInfo.totalCount)
      );
      this.p4 = parseFloat(
        getRate(this.taskInfo.acceptedNum, this.taskInfo.totalCount)
      );
    },

    /**
     * 统计信息数据
     * @param boolean true 表示日期切换
     */
    queryStatistic(boolean) {
      let dateArr = this.dateArr;
      let start;
      let end;
      let s = dateArr && dateArr.length > 0 ? dateArr[0] : "";
      let e = dateArr && dateArr.length > 0 ? dateArr[1] : "";

      // 日期切换
      if (boolean) {
        if (s && e) {
          s = this.$moment(s).format("YYYY-MM-DD");
          e = this.$moment(e).format("YYYY-MM-DD");
        }

        start = s ? s + " 00:00:00" : "";
        end = e ? e + " 23:59:59" : "";

        // 与今日/本周/本月同步
        if (this.today[0] == start && this.today[1] == end) {
          this.date = 1;
        }
        if (this.week[0] == start && this.week[1] == end) {
          this.date = 2;
        }
        if (this.month[0] == start && this.month[1] == end) {
          this.date = 3;
        }
      } else {
        start = s;
        end = e;
      }

      let param = {
        taskId: this.taskId,
        start: start,
        end: end
      };

      // 接口请求
      this.$api.task
        .detailStatistic(param)
        .then(res => {
          this.barData.rows = [
            { 名称: "已验收数据", 数量: res.hasChecked ? res.hasChecked : 0 },
            {
              名称: "已提交检查",
              数量: res.checkSubmitted ? res.checkSubmitted : 0
            },
            {
              名称: "已分配检查",
              数量: res.checkAssigned ? res.checkAssigned : 0
            },
            {
              名称: "已提交标注",
              数量: res.markSubmitted ? res.markSubmitted : 0
            },
            {
              名称: "已分配标注",
              数量: res.markAssigned ? res.markAssigned : 0
            }
          ];
        })
        .catch(() => {
          this.loading2 = false;
        });
    },

    /**
     * 子任务详情
     * @param type 任务类型
     * @param page 页数
     */
    query(type, page) {
      // 类型获取
      let taskType = type ? type : this.taskType,
        isMark = taskType === "mark";

      if (page) {
        this.page = page;
      }

      let param = {
        taskId: this.taskId,
        page: this.page,
        size: this.size
      };
      this.loading = true;

      //深拷贝请求参数
      let copyParam = JSON.parse(JSON.stringify(param));
      // 接口请求
      this.$api.task[isMark ? "detailMark" : "detailCheck"](param)
        .then(res => {
          this.loading = false;
          this.markData = [];
          this.checkData = [];
          this.exportData = [];
          this.total = 0;
          let { content, totalElements } = res;
          if (content && content.length > 0) {
            this[isMark ? "markData" : "checkData"] = content;
            this.total = totalElements;
            
            //获取全部导出数据
            this.exportData = content;
            // copyParam.page = 1;
            // copyParam.size = this.total;
            this.getExportData(type, copyParam);
          }
        })
        .catch(() => {
          this.loading = false;
        });
    },

    /**
     * 请求数据批次
     */
    queryBatch(page) {
      this.loading2 = false;

      if (page) {
        this.page2 = page;
      }

      let param = {
        taskId: this.taskId,
        page: this.page2,
        size: this.size2
      };
      this.loading2 = true;

      // 接口请求
      this.$api.task
        .detailBatch(param)
        .then(res => {
          this.loading2 = false;
          this.batchData = [];
          this.total2 = 0;
          let { content, totalElements } = res;
          if (content && content.length > 0) {
            this.batchData = content;
            this.total2 = totalElements;
          }
        })
        .catch(() => {
          this.loading2 = false;
        });
    },

    // 返回
    prevStep() {
      this.$router.push({ path: "/task/list" });
    },

    // 回收
    recovery(id) {
      this.$confirm("确认回收此任务吗？", "", { lockScroll: false })
        .then(() => {
          this.$api.task.detailWithdraw({ids: [id]}).then(() => {
              this.$message.success("回收成功");
              this.query('mark',1);
              this.getTaskBaseInfo()
              
            })
        })
    },

    // 时间格式化
    dateFormat(row, column) {
      let time = row[column.property];
      if (time === undefined || !time) {
        return "";
      }
      return this.$moment(time).format("YYYY-MM-DD HH:mm:ss");
    },

    //查看配置
    checkConfig(id) {
      if (this.taskInfo.status === 1) {
        this.width = "700px";
      } else {
        this.width = "400px";
      }
      this.showConfig = true;
    },

    //提交任务
    submit(name) {
      this.$refs[name].validate(valid => {
        if (this.uploadShow && !this.addTask.file) {
          this.fileEmptyInfo = true;
          this.fileName = "请选择文件";
          return;
        } else {
          this.fileEmptyInfo = false;
        }
        if (valid) {
          let param = Object.assign(this.addTask);
          let formData = new FormData();
          for (var i in param) {
            formData.append(i, param[i]);
          }

          this.showLoading();
          //分批上傳
          this.$api.task.batchTask(formData).then(data => {
                this.closeLoading();
                this.getTaskBaseInfo();
                this.showData = false;
                this.queryBatch();
                this.$message.success("任务批次添加成功");
              },
              error => {
                this.closeLoading();
                this.showData = false;
                this.$message.error("任务批次添加失败");
              }
            )
        }
      });
    },

    //返回首页
    cancel() {
      this.showData = false;
    },

    //上传方式切换
    uploadMethodChange(val) {
      if (val === "10") {
        this.uploadShow = true;
        this.urlShow = false;
        this.fileEmptyInfo = this.addTask.file ? false : this.fileEmptyInfo;
        if (!this.fileEmptyInfo) {
          this.fileName = "请选择文件";
        }
      } else {
        this.uploadShow = false;
        this.urlShow = true;
        this.fileEmptyInfo = false;
        this.fileName = "请选择文件";
        this.addTask.file = null;
      }
    },

    //上传文件
    upload(event) {
      const file = event.target.files[0];
      this.fileName = file.name;
      this.fileEmptyInfo = false;
      this.addTask.file = file;
    },

    closeConfig() {
      this.showConfig = false;
    },

    //获取文件访问的baseurl
    getBaseUrl() {
      this.$api.task.getStorageUrl({}).then(res => {
        this.pathUrl = res;
      });
    },

    //导出
    exportTask() {
      this.showExport = true;
    },

    //分配
    openDispense() {
      if (
        this.taskInfo.markAssignedNum >= this.taskInfo.totalCount &&
        this.taskInfo.checkAssignedNum >= this.taskInfo.totalCount
      ) {
        this.$message.warning("该任务不可分配");
      } else {
        window.sessionStorage.setItem(
          "taskInfo",
          JSON.stringify(this.taskInfo)
        );
        this.$router.push({ path: "/task/dispense" });
      }
    },

    //移除
    delTask() {
      this.showDel = true;
    },

    //确认移除
    sureDel() {
      this.$api.task
        .delTask({ id: this.taskId })
        .then(() => {
          this.$router.push({ path: "/task/list" });
          this.$message.success("任务移除成功");
          this.closeDel();
        })
        .catch(() => {});
    },

    //关闭删除弹窗
    closeDel() {
      this.showDel = false;
    },

    //继续上传
    addMoreTask() {
      this.addTask.taskId = this.taskId;
      //数据置空、默认上传url
      this.addTask.description = "";
      this.addTask.filePath = "";
      this.addTask.uploadMethod = "11";
      this.addTask.file = null;
      this.uploadShow = false;
      this.urlShow = true;
      this.fileEmptyInfo = false;
      this.fileName = "请选择文件";
      this.showData = true;
    },

    //配置导出文件的名称、字段以及导出子任务详情数据
    getExportData(type, param) {
      let taskType = type ? type : this.taskType,
        isMark = taskType === "mark";
      if (isMark) {
        this.name = "markDetail.xls";
        this.json_fields = this.mark_fields;
      } else {
        this.name = "checkDetail.xls";
        this.json_fields = this.check_fields;
      }

      // this.$api.task[isMark ? "detailMark" : "detailCheck"](param).then(res => {
      //   let { content } = res;
      //   this.exportData = content;
      // });
    },

    // 查看页面
    view(item, type) {
      // 跳转链接
      let toPath = this.taskInfo.taskType.internalUri;
      toPath = toPath.replace("mark", "task");

      // 参数改变
      item.type = type;
      item.readonly = true;
      item.count = item.totalCount;
      item.name = this.taskInfo.name;
      item.userTaskId = item.id;
      item.isApp = true;

      // 只读
      window.sessionStorage.setItem("task", JSON.stringify({ ...item }));
      window.sessionStorage.setItem("taskType", this.taskType);

      if (toPath) {
        this.$router.push(toPath);
      } else {
        this.$message.warning("该任务类型暂无标注页面");
      }
    }
  },

  mounted() {
    // 获取任务信息
    this.taskInfo = JSON.parse(window.sessionStorage.getItem("taskInfo"));
    this.taskId = this.taskInfo.id;

    let taskType = this.$route.params.taskType;
    if (taskType) {
      this.taskType = taskType;
    }

    // 获取日期信息
    this.getDateInfo();
    // 0.获取基本信息
    this.getTaskBaseInfo();
    // 1环形图数据处理，取自任务信息
    // this.queryCircle();
    // 2请求统计数据
    this.queryStatistic();
    // 3请求子任务详情
    this.query();
    // 4请求批次数据
    this.queryBatch();
    this.getBaseUrl();
  },

  beforeRouteEnter(to, from, next) {
    setNavVisible("visible");
    next();
  }
};
</script>

<style lang="less" scoped>
.el-container {
  background: #f6f6f6;
  .el-header {
    background: #fff;
    padding: 10px 15px;
    margin-bottom: 10px;
    .back-btn {
      margin-left: 10px;
    }
  }
  .task-info {
    position: relative;
    height: 200px !important;
    background: #fff;
    padding: 10px 25px;
    margin-bottom: 10px;
    .detail-btns {
      position: absolute;
      right: 10px;
    }
    .task-text,
    .task-precent {
      float: left;
      width: 25%;
      box-sizing: border-box;
    }
    .task-text {
      font-size: 16px;
      .overflow {
        display: inline-block;
        max-width: 140px;
        position: relative;
        top: 3px;
      }
      .font-primary {
        font-size: 13px;
        font-weight: normal;
        margin-left: 5px;
        background-color: #e9ee24;
        color: #fff;
        padding: 3px 8px;
        border-radius: 5px;
      }
      ul {
        margin-top: 30px;
        li {
          font-size: 14px;
          line-height: 34px;
        }
      }
    }
    .task-precent {
      width: 75%;
      span {
        display: block;
        margin-bottom: 6px;
        margin-top: 6px;
      }
      li {
        width: 15%;
        float: left;
        margin-left: 40px;
        text-align: center;
      }
    }
  }
  .el-main {
    background: #f6f6f6;
    padding: 0;
    .detail-progress {
      padding: 20px;
      margin-bottom: 10px;
      background-color: #ffffff;
      .detail-date-picker {
        margin-left: 20px;
        margin-bottom: 20px;
      }
    }
    .middle-table {
      padding: 10px 20px;
      background-color: #ffffff;
      margin-top: 10px;
      position: relative;
      .export-data {
        position: absolute;
        right: 100px;
        top:15px;
        z-index: 100;
      }
    }
  }

  .upload-item {
    .label-required {
      display: inline-block;
      text-align: right;
      font-size: 14px;
      color: #606266;
      line-height: 40px;
      padding: 0 34px 0 0;
      box-sizing: border-box;
      width: 100px;
      &::before {
        content: "*";
        color: #f56c6c;
        margin-right: 4px;
      }
    }
    .upload-wrapper {
      input {
        width: 41px;
        height: 32px;
        z-index: 100;
        position: absolute;
        opacity: 0;
        cursor: pointer;
        line-height: 32px;
        overflow: hidden;
      }
      .icon-upload {
        font-size: 30px;
        position: absolute;
        color: #6ea5de;
        cursor: pointer;
        z-index: 99;
      }
      .upload-name {
        padding-left: 50px;
      }
    }
    .el-form-item__error {
      display: none;
    }
  }
  .upload-error {
    color: #f56c6c;
    font-size: 12px;
  }
  .submit {
    margin-left: 180px;
  }
  .el-table,
  .el-pagination,
  .el-tabs,
  .datawood-add {
    width: ~"calc(100% - 75px)";
  }
  .datawood-table {
    margin-bottom: 20px;
  }
}
</style>

<style lang="less">
.detail-btns .el-button-group .el-button--primary:last-child {
  line-height: 0;
}
.detail-btns {
  .el-button + .el-button {
    margin-left: 0px;
  }
}
.detail-bars {
  .bar-item {
    margin-bottom: 20px;
    margin-left: 10px;
    display: inline-block;
    width: 50%;
  }
}

.add-data {
  a {
    margin-left: 80px;
  }
  .el-input {
    width: 80%;
  }
  .el-form-item__error {
    margin-left: 80px;
  }
}
</style>
















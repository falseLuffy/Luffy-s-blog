<template>
  <el-container>
    <el-header height="10%">
      <!-- 查询条件 -->
      <el-form
        size="small"
        :inline="true"
        ref="queryForm"
        class="query-form"
        @submit.native.prevent
      >
        <el-form-item label="用户名称：" prop="keyStr">
          <el-input name="keyStr" v-model="keyStr" placeholder="请输入用户名称" :maxlength="30" clearable></el-input>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" icon="el-icon-search" @click="query(1)">查询</el-button>
        </el-form-item>
      </el-form>
      <el-button size="small" class="task-add" type="success" @click="allUserCheck">
        <i class="iconfont icon-go" style="font-size:14px;"></i>
        批量通过
      </el-button>
    </el-header>

    <el-main>
      <el-table
        size="small"
        :data="userData"
        @selection-change="changeFun"
        style="width: 100%;"
        align="center"
      >
        <el-table-column type="selection" width="45"></el-table-column>
        <el-table-column
          type="index"
          label="序号"
          width="50"
          :index="(index)=>{return (currentPage - 1) * pageSize + index + 1}"
        ></el-table-column>
        <el-table-column prop="account" label="用户账号" min-width="140"></el-table-column>
        <el-table-column prop="name" label="用户名称" min-width="140"></el-table-column>
        <el-table-column prop="roleName" label="用户角色" min-width="150"></el-table-column>
        <el-table-column prop="projectName" label="项目名称" min-width="150"></el-table-column>
        <el-table-column prop="create_at" label="注册时间" :formatter="dateFormat" min-width="140"></el-table-column>
        <el-table-column label="操作" min-width="160">
          <template slot-scope="scope">
            <el-button size="mini" @click.native="userCheck(scope.row.uid,1)">通过</el-button>
            <el-button size="mini" @click.native="userCheck(scope.row.uid,2)">不通过</el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-pagination
        v-if="total > 10"
        @size-change="sizeChange"
        @current-change="pageChange"
        align="right"
        :current-page="currentPage"
        :page-sizes="[10, 20, 50, 100]"
        :page-size="pageSize"
        layout="total, sizes, prev, pager, next, jumper"
        :total="total"
      ></el-pagination>
    </el-main>
  </el-container>
</template>

<script>
import { mapState } from "vuex";

export default {
  computed: {
    ...mapState(["user"])
  },
  data() {
    return {
      multiSelection: [],
      canClose: false,
      userdata: null,
      keyStr: null,
      createOrd: "",
      currentPage: 1,
      pageSize: 10,
      total: 0,
      userData: []
    };
  },
  methods: {
    // 分页
    sizeChange(size) {
      this.pageSize = size;
      this.query(1);
    },
    pageChange(page) {
      this.currentPage = page;
      this.query();
    },

    // 查询
    query(resetPage) {
      if (resetPage == 1) {
        this.currentPage = 1;
      }
      let param = {
        page: this.currentPage,
        pageSize: this.pageSize,
        status: 0,
        userName: this.keyStr,
        createOrd: "DESC"
      };

      this.$api.user
        .getUsersByName(param)
        .then(data => {
          this.userData = data.list ? data.list : [];
          this.total = data.total;
        })
        .catch(() => {});
    },

    // 表格change
    changeFun(val) {
      this.multiSelection = val;
    },

    // 通过
    userCheck(uid, type) {
      let uids = [];
      if (typeof uid === "object") {
        uids = uid;
      } else {
        uids.push(uid);
      }

      let param = { uids: uids, type: type };
      this.$confirm(type === 1 ? "您确定通过吗？" : "您确定不通过吗？", "", {
        lockScroll: false
      })
        .then(() => {
          this.$api.user
            .userCheck(param)
            .then(data => {
              this.$alert(
                type === 1
                  ? "操作成功，人员审核已通过"
                  : "操作成功，人员审核不通过",
                "提示信息",
                {
                  confirmButtonText: "确定",
                  callback: action => {
                    this.multiSelection = [];
                    this.query();
                  }
                }
              );
            })
            .catch(() => {});
        })
        .catch(() => {});
    },

    // 批量通过
    allUserCheck() {
      debugger;
      if (this.multiSelection.length > 0) {
        let uids = this.multiSelection.map(item => {
          return item.uid;
        });
        this.userCheck(uids, 1);
      } else {
        this.$message.warning("请选择人员");
      }
    },

    // 日期格式化
    dateFormat(row, column) {
      let time = row[column.property];
      if (time === undefined) {
        return "";
      }
      return this.$moment(time).format("YYYY-MM-DD HH:mm");
    }
  },
  mounted() {
    this.query();
  }
};
</script>

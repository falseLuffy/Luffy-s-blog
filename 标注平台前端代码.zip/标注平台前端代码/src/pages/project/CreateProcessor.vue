<template>
  <el-container class="create">
    <el-header height="5%">
      <el-steps :active="active" finish-status="success" size="small" align-center>
        <el-step title="新建处理器"></el-step>
        <el-step title="新建过程"></el-step>
      </el-steps>
    </el-header>
    <el-main>
      <!--新建处理器-->
      <div v-show="active==0">
        <el-form
          label-position="right"
          label-width="100px"
          :model="procInfo"
          :rules="rules1"
          ref="procInfo"
          size="small"
        >
          <el-form-item label="处理器名称" prop="name">
            <el-input v-model="procInfo.name" size="small" placeholder="请输入处理器名称"></el-input>
          </el-form-item>
          <el-form-item label="处理器描述">
            <el-input
              type="textarea"
              placeholder="请输入处理器的简单描述"
              v-model="procInfo.desc"
              size="small"
            ></el-input>
          </el-form-item>
          <el-form-item label="处理器类型" prop="type">
            <el-select v-model="procInfo.type" placeholder="请选择类型" size="small">
              <el-option
                v-for="item in options"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              ></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="配置" prop="config" v-if="procInfo.type">
            <el-input v-model="procInfo.config" size="small" placeholder="请输入类型配置"></el-input>
          </el-form-item>
        </el-form>
      </div>

      <!--新建过程-->
      <div v-show="active==1">
        <el-form
          label-position="right"
          label-width="100px"
          :model="processInfo"
          :rules="rules2"
          ref="processInfo"
          size="small"
        >
          <el-form-item label="过程名称" prop="name" placeholder="请输入过程的名称">
            <el-input v-model="processInfo.name" size="small"></el-input>
          </el-form-item>
          <el-form-item label="过程描述" prop="desc">
            <el-input
              type="textarea"
              placeholder="请输入过程的简单描述"
              v-model="processInfo.desc"
              size="small"
            ></el-input>
          </el-form-item>
          <el-form-item label="引擎类型">
            <el-radio-group v-model="type" size="small">
              <el-radio :label="1">默认引擎</el-radio>
            </el-radio-group>
          </el-form-item>
        </el-form>
        <!--代码块-->
        <codemirror v-model="processInfo.content" :options="cmOptions" class="code"></codemirror>
      </div>

    </el-main>
    <el-footer class="create-btns">
      <template v-if="active==0">
        <el-button size="small" type="primary" @click="oneSubmit">下一步</el-button>
        <el-button size="small" @click="backList">返回处理器列表</el-button>
      </template>
      <template v-if="active==1">
        <el-button size="small" type="primary" @click="twoSubmit">完成创建</el-button>
        <el-button size="small" @click="backList">返回处理器列表</el-button>
      </template>
    </el-footer>
  </el-container>
</template>
<script>
import { codemirror } from "vue-codemirror";
require("codemirror/mode/python/python.js");
require("codemirror/mode/javascript/javascript.js");
require("codemirror/mode/clike/clike.js");
require("codemirror/mode/shell/shell.js");
require("codemirror/theme/blackboard.css");
require("codemirror/keymap/vim.js");
require("codemirror/keymap/sublime.js");
require("codemirror/keymap/emacs.js");
require("codemirror/addon/hint/show-hint.css");
require("codemirror/addon/hint/show-hint.js");
require("codemirror/addon/hint/javascript-hint.js");
export default {
  components: {
    codemirror
  },
  data() {
    return {
      type: true,
      active: 0,

      //处理器
      procInfo: {
        name: "",
        desc: "",
        type: "",
        config: "",
        version: "1"
      },
      options: [
        {
          value: "PRE",
          label: "预处理器"
        },
        {
          value: "ANALYSIS",
          label: "分析处理器"
        },
        {
          value: "EXPORT",
          label: "导出处理器"
        }
      ],
      processData: [],
      processorId: "",
      rules1: {
        name: [
          { required: true, message: "请输入处理器名称", trigger: "blur" }
        ],
        type: [
          { required: true, message: "请输入处理器类型", trigger: "change" }
        ],
        config: [{ required: true, message: "请输入类型配置", trigger: "blur" }]
      },

      //过程
      processInfo: {
        name: "",
        desc: "",
        engineType: "DEFAULTENGINE",
        content: ""
      },
      type: 1,
      cmOptions: {
        tabSize: 4,
        mode: "text/javascript",
        theme: "blackboard",
        lineNumbers: true,
        line: true,
        extraKeys: { Ctrl: "autocomplete" }
      },
      rules2: {
        name: [{ required: true, message: "请输入处理器名称", trigger: "blur" }]
      }
    };
  },

  methods: {
    next() {
      if (this.active++ > 1) this.active = 0;
    },

    //新建处理器
    oneSubmit() {
      this.$refs.procInfo.validate(valid => {
        if (valid) {
          this.$api.project.createProcessor(this.procInfo).then(res => {
            let { id } = res;
            this.processorId = id;
            this.next();
          });
        }
      });
    },

    //返回处理器列表
    backList() {
      this.$router.push({ path: "/project/processor" });
    },

    //新建过程
    twoSubmit() {
      this.$refs.processInfo.validate(valid => {
        this.processInfo.processorId = this.processorId;
        if (valid) {
          this.$api.project.createProcess(this.processInfo).then(res => {
            this.next();
            this.backList();
          });
        }
      });
    }
  }
};
</script>
<style lang="less" scoped>
.create {
  .el-main {
    padding-top: 50px;
    margin: 0 auto;
    width: 680px;
  }
  .el-footer {
    padding-top: 30px;
    padding-bottom: 100px;
    &.create-btns {
      text-align: center;
    }
  }
}
</style>




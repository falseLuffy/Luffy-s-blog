module.exports = file => require('pages/' + file + '.vue').default

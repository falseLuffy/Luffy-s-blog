<template>
  <el-container class="project-user">
    <el-header height="10%">
      <!-- 查询条件 -->
      <el-form
        size="small"
        :inline="true"
        ref="queryForm"
        class="query-form"
        @submit.native.prevent
      >
        <el-form-item>
          <el-input
            v-model="keyStr"
            placeholder="搜索用户名称"
            :maxlength="30"
            clearable
            suffix-icon="el-icon-search"
            @keyup.enter.native="query(1)"
            @change="query(1)"
          ></el-input>
        </el-form-item>
      </el-form>
      <span class="fileinput-button">
        <span class="upload-title">
          <i class="el-icon-download"></i>导入用户
        </span>
        <input
          class="upload-file"
          @change="upload"
          type="file"
          accept="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel"
        >
      </span>
      <el-button size="small" class="task-add" type="success" @click="openNew">
        <i class="iconfont icon-add"></i>
        新增用户
      </el-button>
    </el-header>
    <!-- 表格 -->
    <el-main>
      <el-table size="small" :data="userData" align="center" height="450">
        <el-table-column
          type="index"
          :index="(index)=>{return (currentPage - 1) * pageSize + index + 1}"
          label="序号"
          min-width="50"
        ></el-table-column>
        <el-table-column prop="login" label="用户账号" min-width="140" :show-overflow-tooltip="true"></el-table-column>
        <el-table-column prop="cnName" label="用户姓名" min-width="140" :show-overflow-tooltip="true"></el-table-column>
        <el-table-column prop="roleName" label="用户角色" min-width="140"></el-table-column>
        <el-table-column prop="createdDate" label="创建时间" :formatter="dateFormat" min-width="100"></el-table-column>
        <el-table-column label="操作" min-width="180">
          <template slot-scope="scope">
            <el-button
              size="mini"
              @click="openCheck(scope.row)"
              type="primary"
              :disabled="scope.row.roleName==='超级管理员'||scope.row.roleName==='开发者'"
            >查看</el-button>
            <el-button size="mini" @click="openPwd(scope.row.login)" type="primary">重置密码</el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-pagination
        @size-change="sizeChange"
        @current-change="pageChange"
        align="right"
        :current-page="currentPage"
        :page-sizes="[10, 20, 50, 100]"
        :page-size="pageSize"
        layout="total, sizes, prev, pager, next, jumper"
        :total="total"
        v-show="total > 10"
      ></el-pagination>
      <!-- 弹窗 -->
      <el-dialog
        width="460px"
        title="创建用户"
        :visible.sync="showNewUDalg"
        center
        :showClose="canClose"
        :lock-scroll="false"
      >
        <new-user
          @success="query(1)"
          @hide="hideAddDialog"
          @error="hideAddDialog"
          v-if="showNewUDalg"
        ></new-user>
      </el-dialog>
      <el-dialog
        width="600px"
        title="用户详情"
        :visible.sync="showCheckUDalg"
        center
        :showClose="canClose"
      >
        <check-user :userdata="userdata" v-if="showCheckUDalg" @hide="hideCheckDialog"></check-user>
      </el-dialog>
      <el-dialog
        width="460px"
        title="重置密码"
        :visible.sync="showResetPwdDalg"
        center
        :showClose="canClose"
        :lock-scroll="false"
      >
        <reset-pwd :login="login" @hide="hideResetPwd" v-if="showResetPwdDalg"></reset-pwd>
      </el-dialog>
    </el-main>
  </el-container>
</template>
<script>
import NewUser from "./NewUser";
import CheckUser from "./CheckUser";
import ResetPwd from "pages/common/ResetPwd";
import { APPID } from "assets/scripts/code";
import { mapMutations } from "vuex";
export default {
  components: { NewUser, CheckUser, ResetPwd },
  data() {
    return {
      login: "",
      canClose: true,
      userdata: null,
      keyStr: null,
      currentPage: 1,
      pageSize: 10,
      total: 0,
      userData: [],
      showNewUDalg: false,
      showCheckUDalg: false,
      showResetPwdDalg: false
    };
  },
  methods: {
    ...mapMutations(["showLoading", "closeLoading"]),
    upload(event) {
      let param = {
        file: event.target.files[0],
        appId: APPID
      };
      let formData = new FormData();
      for (var i in param) {
        formData.append(i, param[i]);
      }
      // 文件上传
      this.showLoading();
      this.$api.project
        .importUsers(formData)
        .then(res => {
          this.query(1);
          this.closeLoading();
        })
        .catch(() => {
          this.closeLoading();
        });
    },
    // 分页
    sizeChange(size) {
      this.pageSize = size;
      this.query(1);
    },
    pageChange(page) {
      this.currentPage = page;
      this.query();
    },

    //查询全部用户
    query(resetPage) {
      if (resetPage == 1) {
        this.currentPage = 1;
      }

      let param = {
        page: this.currentPage - 1,
        size: this.pageSize,
        appId: APPID,
        sort: "createdDate,desc",
        value: this.keyStr
      };
      this.getUser(param);
    },

    //新增
    openNew() {
      this.showNewUDalg = true;
    },

    //查看
    openCheck(row) {
      this.userdata = row;
      this.showCheckUDalg = true;
    },

    //关闭查看窗口
    hideCheckDialog() {
      this.showCheckUDalg = false;
    },

    //重置密码
    openPwd(name) {
      this.login = name;
      this.showResetPwdDalg = true;
    },

    // 格式化时间
    dateFormat(row, column) {
      let time = row[column.property];
      if (time === undefined) {
        return "";
      }
      return this.$moment(time).format("YYYY-MM-DD HH:mm");
    },

    //关闭新增dialog
    hideAddDialog() {
      this.showNewUDalg = false;
    },

    //关闭密码重置
    hideResetPwd() {
      this.showResetPwdDalg = false;
    },

    //用户查询
    getUser(param) {
      this.$api.project
        .getUserSearch(param)
        .then(res => {
          let { content, totalElements } = res;
          this.userData = content;
          this.userData.forEach(user => {
            if (user.authorities.indexOf("ROLE_DW_SUPERADMIN") > -1) {
              user["roleName"] = "超级管理员";
              return false;
            } else if (user.authorities.indexOf("ROLE_DW_DEVELOPER") > -1) {
              user["roleName"] = "开发者";
              return false;
            } else if (user.authorities.indexOf("ROLE_DW_APPADMIN") > -1) {
              user["roleName"] = "应用管理员";
              return false;
            } else {
              user["roleName"] = "普通用户";
            }
          });
          this.total = totalElements;
        })
        .catch(() => {});
    }
  },
  computed: {},
  mounted() {
    this.query(1);
  }
};
</script>
<style lang="less">
.project-user {
  .key-str {
    width: 25%;
    margin-left: 65%;
  }

  .el-header {
    position: relative;
    padding: 20px 25px 0 25px;
    .icon-add {
      font-size: 14px;
    }
    .fileinput-button {
      position: relative;
      display: inline-block;
      overflow: hidden;
      line-height: 18px;
      color: #fff;
      background-color: #67c23a;
      padding: 6px 8px;
      border-radius: 4px;
      top: -50px;
      left: 210px;
      .upload-file {
        position: absolute;
        right: 0px;
        top: 0px;
        opacity: 0;
      }
    }

    .task-add {
      position: absolute;
      right: 24px;
      top: 20px;
    }
  }
  .el-button--mini,
  .el-button--mini.is-round {
    padding: 5px 10px;
  }
}
</style>





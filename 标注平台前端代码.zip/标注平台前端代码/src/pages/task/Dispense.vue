<!-- 分配页面 -->
<template>
  <el-container class="task-dispense">
    <!-- 头部按钮 -->
    <el-header height="5%">
      <el-button class="back-btn" size="small" @click="cancel">返回</el-button>
    </el-header>
    <!-- 主体内容 -->
    <el-main>
      <!-- 任务信息 -->
      <el-row class="task-info-dispense">
        <strong>{{taskInfo.name}}</strong>
        <ul>
          <li>
            <span>&nbsp;&nbsp;&nbsp;创建人：</span>
            <span>{{createdBy}}</span>
            <span style="margin-left:30px;">创建时间：</span>
            <span>{{createdDate}}</span>
          </li>
          <li>
            <span>任务类型：</span>
            <span>{{taskType}}</span>
          </li>
          <li>
            <span>当前状态：</span>
            <span v-if="!readonly">
              可分配数量
              <strong>{{remainNum}}</strong>条
            </span>
            <strong class="font-danger" v-else>任务正在解析中，暂不可分配，请稍后刷新页面查看！</strong>
          </li>
        </ul>
      </el-row>
      <!-- 筛选条件 -->
      <el-row class="dispense-form">
        <div class="form-btns">
          <!-- 标注 -->
          <el-button
            size="small"
            type="success"
            align="left"
            @click="dispensePeople"
            v-show="markShow && markBtnShow"
          >
            <i class="iconfont icon-choose"></i>
            分配{{disType === "mark" ? '标注' :'检查'}}
          </el-button>
          <!-- 检查 -->
          <el-button size="small" type="primary" @click="batchCheckNum" v-show="checkShow">
            <i class="iconfont icon-choose"></i>批量选择
          </el-button>
        </div>
        <el-tabs v-model="disType" @tab-click="change(disType)">
          <el-tab-pane label="标注任务" name="mark"></el-tab-pane>
          <el-tab-pane
            label="检查任务"
            name="check"
            v-if="taskInfo && taskInfo.whetherCheck.code !== 40"
          ></el-tab-pane>
        </el-tabs>
      </el-row>

      <!-- 标注列表 -->
      <div id="mark" v-show="markShow" class="dispense-grid">
        <!-- 任务信息 -->
        <el-table
          size="small"
          class="dis-table"
          :data="markData"
          align="center"
          border
          height="361"
          v-loading="markloading"
          element-loading-text="正在请求"
        >
          <el-table-column type="index" label="序号" min-width="80"></el-table-column>
          <el-table-column label="标注员" min-width="140" :show-overflow-tooltip="true">
            <template slot-scope="scope">
              <span>{{scope.row.markerName}}（{{scope.row.markerId}}）</span>
            </template>
          </el-table-column>
          <el-table-column prop="totalCount" label="分配任务量" min-width="140"></el-table-column>
          <el-table-column prop="createDate" label="分配时间" min-width="140" :formatter="dateFormat"></el-table-column>
        </el-table>

        <!-- 分页 -->
        <el-pagination
          v-if="markTotal > 10"
          @size-change="sizeChange"
          @current-change="pageChange"
          align="right"
          layout="total, sizes, prev, pager, next, jumper"
          :current-page="page"
          :page-sizes="[5, 10, 20, 40]"
          :page-size="size"
          :total="markTotal"
          class="pager-wrapper"
        ></el-pagination>

      </div>

      <!-- 检查列表 -->
      <div
        id="check"
        v-show="checkShow"
        class="dispense-grid"
        v-if="taskInfo && taskInfo.whetherCheck.code !== 40"
      >
        <el-row>
          <el-input
            size="small"
            class="dis-search"
            v-model="searchName"
            clearable
            :maxlength="30"
            autofocus
            placeholder="搜索标注员名称"
            suffix-icon="el-icon-search"
            @keyup.enter.native="query(1)"
            @change="query(1)"
          ></el-input>
          <el-checkbox size="small" v-model="unDisCheck" @change="query(1)">未分配检查</el-checkbox>
        </el-row>
        <el-table
          size="small"
          class="dis-table"
          :data="checkData"
          align="center"
          @selection-change="changeCheckFun"
          v-show="checkShow"
          border
          height="372"
          v-loading="checkloading"
          element-loading-text="正在请求"
        >
          <el-table-column type="selection" width="50" :selectable="checkSelected"></el-table-column>
          <el-table-column type="index" label="序号" min-width="140"></el-table-column>
          <el-table-column label="标注员" min-width="140" :show-overflow-tooltip="true">
            <template slot-scope="scope">
              <span>{{scope.row.markerName}}（{{scope.row.markerId}}）</span>
            </template>
          </el-table-column>
          <el-table-column prop="commitDate" label="标注提交时间" min-width="140" :formatter="dateFormat"></el-table-column>
          <el-table-column prop="totalCount" label="数据数" min-width="140"></el-table-column>
          <el-table-column prop="createDate" label="检查分配时间" min-width="140" :formatter="dateFormat"></el-table-column>
          <el-table-column
            label="检查员"
            prop="inspectorName"
            min-width="140"
            :show-overflow-tooltip="true"
          >
            <template slot-scope="scope">
              <span
                v-if="scope.row.inspectorId"
                class="font-primary"
              >{{scope.row.inspectorName}}（{{scope.row.inspectorId}}）</span>
              <el-button
                v-else
                size="mini"
                @click="chooseChecker(scope.row.id,scope.row.markerId)"
              >请选择</el-button>
            </template>
          </el-table-column>
        </el-table>

        <!-- 分页 -->
      <el-pagination
        v-if="checkTotal > 10"
        @size-change="sizeChange"
        @current-change="pageChange"
        align="right"
        layout="total, sizes, prev, pager, next, jumper"
        :current-page="page"
        :page-sizes="[5, 10, 20, 40]"
        :page-size="size"
        :total="checkTotal"
        class="pager-wrapper"
      ></el-pagination>

      </div>

      

      <el-dialog
        width="1000px"
        top="1%"
        title="分配标注员"
        :visible.sync="showMarker"
        :lock-scroll="false"
      >
        <choose-marker
          v-if="showMarker"
          :totalNum="remainNum"
          :taskId="taskInfo.id"
          @selected="selectMarker"
          @hide="hideMarker"
        ></choose-marker>
      </el-dialog>

      <el-dialog
        width="680px"
        top="2%"
        title="选择检查员"
        :visible.sync="showChecker"
        :lock-scroll="false"
      >
        <choose-checker
          v-if="showChecker"
          @selected="selectChecker"
          @hide="hideChecker"
          :ids="selectIds"
          :markerIds="markerIds"
        ></choose-checker>
      </el-dialog>
    </el-main>
  </el-container>
</template>
}
<script>
import { mapState } from "vuex";
import ChooseMarker from "./ChooseMarker";
import ChooseChecker from "./ChooseChecker";

export default {
  components: { ChooseChecker, ChooseMarker },
  computed: {
    ...mapState(["user"])
  },
  data() {
    return {
      markloading: false,
      checkloading: false,
      selectIds: [],
      markerIds: [],
      showMarker: false,
      showChecker: false,
      markShow: true,
      markBtnShow: false,
      checkShow: false,
      userIds: [],
      taskInfo: null, //当条任务信息
      total: 0,
      markTotal:0,
      checkTotal:0,
      disType: "mark",
      remainNum: 0,
      searchName: "",
      unDisCheck: false,
      page: 1,
      size: 10,
      total: 0,
      sort: "createdDate,DESC",
      markData: [],
      checkData: [],
      checkSelectArr: [],
      readonly: false,
      createdBy: "",
      createdDate: "",
      taskType: ""
    };
  },
  methods: {
    //返回
    cancel() {
      this.$router.push({ path: "/task/list" });
    },

    //分页
    sizeChange(size) {
      this.size = size;
      this.query(1);
    },
    pageChange(page) {
      this.page = page;
      this.query();
    },

    // 输入框搜索
    query(page) {
      if (page) {
        this.page = page;
      }
      if (this.markShow) {
        this.queryList(0);
      } else {
        this.queryList(1);
      }
    },

    // 获取任务列表,0标注，1检查
    queryList(type) {
      this[type == 0 ? "markloading" : "checkloading"] = true;
      let param = {
        page: this.page,
        size: this.size,
        sort: this.sort,
        taskId: this.taskInfo.id
      };

      if (type == 1) {
        param.marker = this.searchName;

        if (this.unDisCheck) {
          param.distributed = false;
        }
      }
      this.$api.task[type == 0 ? "distributeMarkList" : "distributeCheckList"](
        param
      )
        .then(res => {
          this[type == 0 ? "markloading" : "checkloading"] = false;
          let { content, totalElements, availableCount } = res;
          // 标注
          if (type == 0) {
            this.markData = content;
            this.remainNum = availableCount;
            this.markBtnShow = true;
            this.markTotal = totalElements;
          }
          // 检查
          if (type == 1) {
            this.checkData = content;
            this.checkTotal = totalElements;
          }
        })
        .catch(() => {
          this[type == 0 ? "markloading" : "checkloading"] = false;
        });
    },

    // 标注页面按时间筛选
    markSortChange() {
      let sort = this.sort;
      this.sort = sort ? "" : "createdDate,DESC";
      this.queryList(0);
    },

    //改变标注/检查显示
    change(disType) {
      var disType = disType ? disType : this.disType;
      this.page = 1;
      if (disType == "check") {
        this.queryList(1);
      }

      this.setShow(disType);
    },

    // 显示标注员分配
    selectMarker() {
      this.showMarker = false;
      this.queryList(0);
    },

    // 隐藏标注员分配
    hideMarker() {
      this.showMarker = false;
    },

    //分配对象
    dispensePeople() {
      if (this.disType === "mark") {
        if (this.remainNum === 0) {
          this.$message.warning("没有可分配的任务");
          return;
        }
        this.showMarker = true;
      }

      if (this.disType === "check") {
        if (this.checkData.length === 0) {
          this.$message.warning("没有可分配的任务");
          return;
        }
        this.showChecker = true;
      }
    },

    // 检查员选中
    checkSelected(row) {
      if (row.inspectorName || row.inspectorId) {
        return false;
      } else {
        return true;
      }
    },

    // 多选检查员
    changeCheckFun(val) {
      this.checkSelectArr = val;
    },

    // 选择检查员
    chooseChecker(id, markerId) {
      this.selectIds = [];
      this.selectIds.push(id);

      this.markerIds = [];
      this.markerIds.push(markerId);

      this.showChecker = true;
    },

    // 选择检查员后
    selectChecker() {
      this.showChecker = false;
      this.query(1);
    },

    // 批量分配检查员
    batchCheckNum() {
      if (!this.checkSelectArr.length) {
        this.$message.warning("请选择标注员");
        return;
      }
      this.selectIds = [];
      this.markerIds = [];

      this.checkSelectArr.forEach(item => {
        this.selectIds.push(item.id);
        this.markerIds.push(item.markerId);
      });

      this.showChecker = true;
    },

    // 隐藏检查员分配
    hideChecker() {
      this.showChecker = false;
    },

    //展示tab
    setShow(type) {
      this.markShow = type === "mark" ? true : false;
      this.checkShow = type === "check" ? true : false;
    },

    // 时间格式化
    dateFormat(row, column) {
      let time = row[column.property];
      if (time === undefined || !time) {
        return "";
      }
      return this.$moment(time).format("YYYY-MM-DD HH:mm:ss");
    }
  },
  created() {
    // 进入页面先判断是否可分配
    this.taskInfo = JSON.parse(window.sessionStorage.getItem("taskInfo"));
    this.$api.task
      .distributeJudge({ taskId: this.taskInfo.id })
      .then(res => {
        if (res) {
          let {
            ready,
            createdBy,
            createdByName,
            createdDate,
            taskType,
            totalCount
          } = res;

          this.createdBy = createdByName
            ? `${createdByName}(${createdBy})`
            : createdBy;
          this.createdDate = createdDate;
          this.taskType = taskType.name;
          this.taskInfo.totalCount = totalCount;

          if (ready) {
            this.queryList(0);
          } else {
            this.$message.error("任务正在解析中，暂不可分配，请稍后查看！");
            this.readonly = true;
          }
        }
      })
      .catch(() => {});
  }
};
</script>

<style rel="stylesheet/less" lang="less">
.el-container.task-dispense {
  background: #f6f6f6;
  .el-header {
    background: #fff;
    padding: 10px 15px;
  }

  .el-main {
    font-size: 14px;
    background: #fff;
    padding: 20px 15px;
    min-height: 460px;
    margin-top: 10px;
    .task-info-dispense {
      ul {
        margin: 15px 0 10px 0;
        li {
          color: #646464;
          margin-top: 15px;
          span:first-child {
            display: inline-block;
            width: 80px;
          }
        }
      }
    }
    .dispense-form {
      position: relative;
    }
    .form-btns {
      position: absolute;
      right: 0;
      z-index: 999;
      button {
        padding: 8px 6px;
        margin-left: 10px;
      }

      .iconfont {
        font-size: 14px;
      }
    }
    .dispense-grid {
      padding-bottom: 20px;
      .el-row {
        margin-bottom: 10px;
      }
      .el-table__empty-block {
        min-height: 270px;
      }
    }
    .el-table th {
      background: #f5f7fa;
    }
    .dis-search {
      float: right;
      width: 200px;
    }
  }

  .font-primary {
    font-weight: bold;
  }
  .el-pagination {
    margin-top: 0px;
  }
}
.el-table.dis-table {
  td {
    padding: 4px 0;
  }
}
</style>










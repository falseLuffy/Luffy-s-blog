// 标注相关接口
import {
  $get,
  $post,
  concatPageInfo
} from '../http';

// 任务列表
const getMarkList = data => {
  let url = 'base/datawood-manager/api/user-tasks?';
  for (let i in data) {
    url += `${i}=${data[i]}&`
  }
  url += "sort=createdDate,DESC&sort=id,DESC";
  return $get(url, {})
};

const getMapDetail = data =>{
  return $get(`http://api.map.baidu.com/place/v2/detail?uid=395fe82b0c19ca50a2d230e8&output=json&scope=2&ak=w4POp2AmwnCd35rKPWSYX3NdWuG6Dq0h`)
}

// 标注信息
const getMarkInfo = data => {
  return $get(`base/datawood-manager/api/workload/today/?userId=${data.userId}&applicationId=${data.applicationId}`, {})
};

// 获取标注文件列表
const getPage = data => {
  return $get('base/datawood-manager/api/user-task-items', data)
};

// 获取标注文件列表
const getMarkFile = data => {
  return $get('base/datawood-processor/api/markData', data)
};

// 保存标注文件列表
const saveMarkFile = data => {
  return $post('base/datawood-processor/api/markData', data)
};

// 提交标注
const commitMarkTask = data => {
  return $post('base/datawood-manager/api/user-tasks/commit', data)
};

// 调整检查比例
const changeCheckRate = data => {
  return $post('base/datawood-manager/api/user-tasks/check-rate/reset', data)
};

// 任务打回
const taskReject = data => {
  return $post('base/datawood-manager/api/user-tasks/reject', data)
};

//可领取任务列表
const receiveTaskList = data => {
  return $get('base/datawood-manager/api/receive/tasks', data)
}

//参与标注
const receiveMark = data => {
  return $post('base/datawood-manager/api/receive/mark', data);
}

//检查员领取任务--用户列表
const receiveCheckUserList = data => {
  return $get('base/datawood-manager/api/receive/user-tasks', data)
}

const receiveCheck = data => {
  return $post('base/datawood-manager/api/receive/check', data)
}

// 获取音频的基本信息
const getAudioInfo = data => {
  return $get('base/storage/api/audio/info', data)
}

//标注任务小结
const getMarkSum = data => {
  let id = data.id;
  delete data.id;
  return $get(`base/datawood-manager/api/user-task/mark-summary/${id}`, data);
}

// 标准名模糊查询
const getBlurName = data => {
  return $get('base/datawood-processor/api/standardName/search',data)
}


export default {
  getMapDetail,
  getBlurName,
  getMarkList,
  getMarkInfo,
  getPage,
  getMarkFile,
  saveMarkFile,
  commitMarkTask,
  changeCheckRate,
  taskReject,
  receiveTaskList,
  receiveMark,
  receiveCheckUserList,
  receiveCheck,
  getAudioInfo,
  getMarkSum
}

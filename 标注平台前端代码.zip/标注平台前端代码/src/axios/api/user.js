// 用户相关接口
import {
  $get,
  $post,
  $delete
} from '../http';
import { SIGTERM } from 'constants';

// 注册用户
const registUser = data =>{
  return $post('base/usercenter/api/register', data)
};

// 登陆
const login = data =>{
  return $post('base/usercenter/auth/login',data)
};

// 人员查询
const searchUser = data =>{
  return $get('base/usercenter/api/users/search',data);
}

//添加兼职
const addUserdeputies = data =>{
  return $post('base/usercenter/api/userdeputies',data);
}

//获取兼职列表
const getUserdeputies = data =>{
  return $get('base/usercenter/api/userdeputies/rolesmerger',data);
}

//获取个人兼职列表
const getDeputiesList = data =>{
  return $get('base/usercenter/api/userdeputies/user',data);
}

//删除兼职
const delUserdeputies = data =>{
  return $delete('base/usercenter/api/userdeputies',data);
}

// 获取当前用户信息
const getUserInfo = data =>{
  return $get('base/usercenter/api/account')
}

//修改当前用户密码
const changePwd = data => {
  delete data.login;
  return $post('base/usercenter/api/account/change-password',data)
}



export default {
  getDeputiesList,
  registUser,
  login,
  searchUser,
  getUserInfo,
  addUserdeputies,
  getUserdeputies,
  delUserdeputies,
  changePwd
}

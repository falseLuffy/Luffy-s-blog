import Vue from 'vue'
import Router from 'vue-router'
import Cookies from 'js-cookie'
import store from '@/store'
import {
  setRouterMap
} from "assets/scripts/common"
import {
  datawoodRole
} from "assets/scripts/code"
import {
  MessageBox
} from 'element-ui'

const _import = require('./_import_' + process.env.NODE_ENV)
Vue.use(Router)

import Layout from 'pages/layout/Layout'

export let router = new Router({
  routes: [{
    path: '/login',
    component: _import('login/Login'),
    hidden: true
  },
    {
      path: '/404',
      component: _import('common/404'),
      hidden: true
    },
    {
      path: '/500',
      component: _import('common/500'),
      hidden: true
    }
  ]
})

export const asyncRouterMap = [{
  // 应用管理员
  icon: 'iconfont icon-app',
  path: '/task',
  component: Layout,
  redirect: '/task/index',
  name: '应用管理',
  meta: {
    role: ['ROLE_DW_APPADMIN']
  },
  children: [{
    path: 'index',
    hidden: true,
    component: _import('task/Task'),
    name: '应用首页',
    meta: {
      role: ['ROLE_DW_APPADMIN']
    }
  }]
},
  {
    icon: 'iconfont icon-rwlb',
    path: '/task',
    component: Layout,
    redirect: '/task/list',
    name: '任务管理',
    meta: {
      role: ['ROLE_DW_APPADMIN']
    },
    children: [{
      path: 'list',
      hidden: true,
      component: _import('task/TaskList'),
      name: '任务管理',
      meta: {
        role: ['ROLE_DW_APPADMIN']
      }
    },
      {
        path: 'dispense',
        hidden: true,
        component: _import('task/Dispense'),
        name: '任务分配',
        meta: {
          role: ['ROLE_DW_APPADMIN']
        }
      },
      {
        path: 'create',
        hidden: true,
        component: _import('task/Create'),
        name: '任务新建',
        meta: {
          role: ['ROLE_DW_APPADMIN']
        }
      },
      {
        path: 'taskDetail',
        hidden: true,
        component: _import('task/TaskDetail'),
        name: '任务详情',
        meta: {
          role: ['ROLE_DW_APPADMIN']
        }
      },
      {
        path: 'accept',
        hidden: true,
        component: _import('task/Accept'),
        name: '任务验收',
        meta: {
          role: ['ROLE_DW_APPADMIN']
        }
      },
      {
        path: 'rank',
        hidden: true,
        component: _import('task/TaskRank'),
        name: '数据龙虎榜',
        meta: {
          role: ['ROLE_DW_APPADMIN']
        }
      }, {
        path: 'cvpic',
        hidden: true,
        component: _import('mark/CvPicMark'),
        name: 'CV标注（人脸匹配）',
        meta: {
          role: ['ROLE_DW_APPADMIN']
        }
      }, {
        path: 'seg',
        hidden: true,
        component: _import('mark/SegMark'),
        name: '音频标注（分段标注）',
        meta: {
          role: ['ROLE_DW_APPADMIN']
        }
      }, {
        path: 'layer',
        hidden: true,
        component: _import('mark/LayerMark'),
        name: '音频标注（分层标注）',
        meta: {
          role: ['ROLE_DW_APPADMIN']
        }
      }, {
        path: 'ocr',
        hidden: true,
        component: _import('mark/OcrMark'),
        name: 'OCR标注',
        meta: {
          role: ['ROLE_DW_APPADMIN']
        }
      }, {
        path: 'lawOcr',
        hidden: true,
        component: _import('mark/LawOcrMark'),
        name: '政法OCR标注',
        meta: {
          role: ['ROLE_DW_APPADMIN']
        }
      }, {
        path: 'location',
        hidden: true,
        component: _import('mark/AddressMark'),
        name: '政法OCR标注',
        meta: {
          role: ['ROLE_USER']
        }
      }, {
        path: 'rule/:id',
        hidden: true,
        component: _import('mark/RuleMark'),
        name: '知识点标注',
        meta: {
          role: ['ROLE_DW_APPADMIN']
        }
      }, {
        path: 'cn/:id',
        hidden: true,
        component: _import('mark/CnMark'),
        name: '中文检错标注',
        meta: {
          role: ['ROLE_DW_APPADMIN']
        }
      }, {
        path: 'en/:id',
        hidden: true,
        component: _import('mark/EnMark'),
        name: '英文检错标注',
        meta: {
          role: ['ROLE_DW_APPADMIN']
        }
      }, {
        path: 'taskReport',
        hidden: true,
        component: _import('task/TaskReport'),
        name: '任务报告',
        meta: {
          role: ['ROLE_DW_APPADMIN']
        }
      }
    ]
  },
  {
    icon: 'iconfont icon-rygl',
    path: '/task',
    component: Layout,
    redirect: '/task/user',
    name: '人员管理',
    meta: {
      role: ['ROLE_DW_APPADMIN']
    },
    children: [{
      path: 'user',
      hidden: true,
      component: _import('task/User'),
      name: '人员管理',
      meta: {
        role: ['ROLE_DW_APPADMIN']
      }
    }, {
      path: 'userStatistics',
      hidden: true,
      component: _import('task/UserStatistics'),
      name: '个人统计',
      meta: {
        role: ['ROLE_DW_APPADMIN']
      }
    }]
  },
  {
    icon: 'iconfont icon-dict2',
    path: '/task',
    component: Layout,
    redirect: '/task/dict',
    name: '字典管理',
    meta: {
      role: ['ROLE_DW_APPADMIN']
    },
    children: [{
      path: 'dict',
      hidden: true,
      component: _import('task/DictList'),
      name: '字典管理',
      meta: {
        role: ['ROLE_DW_APPADMIN']
      }
    }, {
      path: 'editDict',
      hidden: true,
      component: _import('task/EditDict'),
      name: '字典编辑',
      meta: {
        role: ['ROLE_DW_APPADMIN']
      }
    }]
  },
  {
    icon: 'iconfont icon-databack',
    path: '/task',
    component: Layout,
    redirect: '/task/badData',
    name: '数据回收',
    meta: {
      role: ['ROLE_DW_APPADMIN']
    },
    children: [{
      path: 'badData',
      hidden: true,
      component: _import('task/BadDataBack'),
      name: '数据回收',
      meta: {
        role: ['ROLE_DW_APPADMIN']
      }
    }]
  },
  //超级管理员
  {
    icon: 'iconfont icon-yhlb',
    path: '/project',
    component: Layout,
    redirect: '/project/user',
    name: '用户列表',
    meta: {
      role: ['ROLE_DW_SUPERADMIN']
    },
    children: [{
      path: 'user',
      hidden: true,
      component: _import('project/User'),
      name: '用户列表',
      meta: {
        role: ['ROLE_DW_SUPERADMIN']
      }
    }]
  },
  {
    icon: 'iconfont icon-rwlb',
    path: '/project',
    component: Layout,
    redirect: '/project/index',
    name: '应用管理',
    meta: {
      role: ['ROLE_DW_SUPERADMIN']
    },
    children: [{
      path: 'index',
      hidden: true,
      component: _import('project/Project'),
      name: '应用管理',
      meta: {
        role: ['ROLE_DW_SUPERADMIN']
      }
    }, {
      path: 'edit',
      hidden: true,
      component: _import('project/EditProj'),
      name: '应用配置',
      meta: {
        role: ['ROLE_DW_SUPERADMIN']
      }
    }]
  },
  {
    icon: 'iconfont icon-processor',
    path: '/project',
    component: Layout,
    redirect: '/project/processor',
    name: '处理器管理',
    meta: {
      role: ['ROLE_DW_SUPERADMIN']
    },
    children: [{
      path: 'processor',
      hidden: true,
      component: _import('project/Processor'),
      name: '处理器管理',
      meta: {
        role: ['ROLE_DW_SUPERADMIN']
      }
    }, {
      path: 'createProcessor',
      hidden: true,
      component: _import('project/CreateProcessor'),
      name: '新建处理器',
      meta: {
        role: ['ROLE_DW_SUPERADMIN']
      }
    }]
  },


  // 普通用户
  {
    icon: 'iconfont icon-rwlb',
    path: '/mark',
    component: Layout,
    redirect: '/mark/index',
    name: '标注管理',
    meta: {
      role: ['ROLE_USER']
    },
    children: [{
      path: 'index',
      component: _import('mark/Mark'),
      name: '我的任务',
      meta: {
        role: ['ROLE_USER']
      }
    }, {
      path: 'cvpic',
      hidden: true,
      component: _import('mark/CvPicMark'),
      name: 'CV标注（人脸匹配）',
      meta: {
        role: ['ROLE_USER']
      }
    }, {
      path: 'seg',
      hidden: true,
      component: _import('mark/SegMark'),
      name: '音频标注（分段标注）',
      meta: {
        role: ['ROLE_USER']
      }
    }, {
      path: 'layer',
      hidden: true,
      component: _import('mark/LayerMark'),
      name: '音频标注（分层标注）',
      meta: {
        role: ['ROLE_USER']
      }
    }, {
      path: 'ocr',
      hidden: true,
      component: _import('mark/OcrMark'),
      name: 'OCR标注',
      meta: {
        role: ['ROLE_USER']
      }
    }, {
      path: 'lawOcr',
      hidden: true,
      component: _import('mark/LawOcrMark'),
      name: '政法OCR标注',
      meta: {
        role: ['ROLE_USER']
      }
    }, {
      path: 'location',
      hidden: true,
      component: _import('mark/AddressMark'),
      name: '地址标注',
      meta: {
        role: ['ROLE_USER']
      }
    }, {
      path: 'address',
      hidden: true,
      component: _import('mark/locationMark'),
      name: '地址标注',
      meta: {
        role: ['ROLE_USER']
      }
    }, {
      path: 'rule/:id',
      hidden: true,
      component: _import('mark/RuleMark'),
      name: '知识点标注',
      meta: {
        role: ['ROLE_USER']
      }
    }, {
      path: 'cn/:id',
      hidden: true,
      component: _import('mark/CnMark'),
      name: '中文检错标注',
      meta: {
        role: ['ROLE_USER']
      }
    }, {
      path: 'en/:id',
      hidden: true,
      component: _import('mark/EnMark'),
      name: '英文检错标注',
      meta: {
        role: ['ROLE_USER']
      }
    }]
  },
  {
    icon: 'iconfont icon-taskpool',
    path: '/mark',
    component: Layout,
    redirect: '/mark/index',
    name: '标注管理',
    meta: {
      role: ['ROLE_USER']
    },
    children: [{
      path: 'taskpool',
      component: _import('mark/MarkPool'),
      name: '任务池',
      meta: {
        role: ['ROLE_USER']
      }
    },
      {
        path: 'taskDetail',
        hidden: true,
        component: _import('mark/MarkDetail'),
        name: '可领取任务详情',
        meta: {
          role: ['ROLE_DW_APPADMIN']
        }
      },
    ]
  }
]

router.beforeEach((to, from, next) => {
  if (from.meta.leaveConfirm) {
    MessageBox.confirm('此操作将离开该页面,请确认数据已保存,确定离开吗?', '提示', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'info',
    }).then(() => {
      beforeInvoker(to, from, next)
    }).catch(() => {
    });
  } else {
    beforeInvoker(to, from, next)
  }
});

function beforeInvoker(to, from, next) {
  const user = Cookies.get('accessUser');
  const state = store.state;

  let role = user ? JSON.parse(user).role : null;
  let toPath = to.path;

  if (role) {
    //已登陆过，无需再登陆直接进入首页
    if ((toPath === '/login' || toPath === '/') && state.routers.length > 0) {
      next({
        path: state.routers[0].path
      })
    } else {
      // 普通用户mark;应用管理员task;超管project,如果访问的地址和缓存用户不一致，则重写登陆
      if ((role === datawoodRole.superAdmin && !toPath.startsWith('/project')) ||
        (role === datawoodRole.appAdmin && !toPath.startsWith('/task')) ||
        (role === datawoodRole.user && !toPath.startsWith('/mark'))) {
        // 清除缓存
        store.commit("clearUserInfo");
        next('/login');
      } else {
        //数据丢失，从cookie获取后重新获取路由
        if (!state.user.role) {
          setRouterMap(user);
          next({
            path: toPath ? toPath : state.routers[0].path
          })
        } else {
          next()
        }
      }

    }
  } else {
    if (toPath === '/login') {
      next()
    } else {
      next('/login')
    }
  }

}

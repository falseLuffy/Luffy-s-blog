import apiList from './api/index';

const install = function(Vue) {
  Vue.prototype.$api = apiList;
};

export default install

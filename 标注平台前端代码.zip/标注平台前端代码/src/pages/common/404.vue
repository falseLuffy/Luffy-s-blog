<template>
  <div class="container-block">
    <div class="exception-content" style>
      <img
        src="https://img.alicdn.com/tfs/TB1txw7bNrI8KJjy0FpXXb5hVXa-260-260.png"
        class="imgException"
        alt="页面不存在"
      >
      <div class="prompt">
        <h3 class="title" style="color: rgb(51, 51, 51);">抱歉，你访问的页面不存在</h3>
        <p class="description" style="color: rgb(102, 102, 102);">
          您要找的页面没有找到，请返回
          <a href="#">首页</a>继续浏览
        </p>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  methods: {
    back: function() {
      this.$router.push({ path: "/login" });
    }
  }
};
</script>

<style lang="less" scoped>
.container-block {
  background-color: rgb(255, 255, 255);
  border-radius: 6px;
  padding: 20px;
  margin-bottom: 20px;
}
.exception-content {
  display: flex;
  justify-content: center;
  align-items: center;
}
@media screen and (max-width: 720px) {
  .exception-content {
    min-height: 200px;
    .imgException {
      max-width: 100px;
      margin-right: 10px;
    }
    .title {
      font-size: 14px;
      margin: 10px 0;
    }
    .description {
      font-size: 12px;
    }
  }
}

@media screen and (min-width: 721px) and (max-width: 1199px) {
  .exception-content {
    min-height: 300px;
    .imgException {
      max-width: 180px;
      margin-right: 30px;
    }
    .title {
      font-size: 20px;
      margin: 10px 0;
    }
    .description {
      font-size: 14px;
    }
  }
}

@media screen and (min-width: 1200px) {
  .exception-content {
    min-height: 500px;
    .imgException {
      max-width: 260px;
      margin-right: 50px;
    }
    .title {
      font-size: 24px;
      margin: 20px 0;
    }
    .description {
      font-size: 16px;
    }
  }
}
</style>

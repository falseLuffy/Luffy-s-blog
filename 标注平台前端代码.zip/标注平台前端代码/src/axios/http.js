import axios from 'axios'
import Cookies from "js-cookie"
import config from './config'
import store from '@/store'
import {
  router
} from '@/router'
import {
  APICODE
} from 'assets/scripts/code'
import {
  createHeader
} from 'assets/scripts/common'
import {
  Message
} from 'element-ui'


// 请求拦截器
axios.interceptors.request.use(
  config => {
    let token = Cookies.get('accessToken');
    let user = Cookies.get('accessUser');
    if (!token && !user) {
      router.push({
        path: "/login"
      });
    } else {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },

  error => {
    store.commit('closeLoading');
    const errorInfo = error.response
    if (errorInfo) {
      Message.error('请求' + errorInfo.status)
    }
    return Promise.reject(error)
  }
)

// 响应拦截器
axios.interceptors.response.use(
  response => {
    if (response.status === 200 || response.status === 201) {
      let data;
      if (response.data == undefined) {
        data = JSON.parse(response.request.responseText)
      } else {
        data = response.data
      };
      return data;
    } else {
      store.commit('closeLoading');
      Message.error(data.retdesc || '请求失败');
      return Promise.reject();
    }
  },
  error => {
    //返回接口的错误信息
    if (error.response && error.response.data.errorCode) {
      Message.error(APICODE[error.response.data.errorCode] || error.response.data.detail)
      store.commit('closeLoading');
      return Promise.reject(error);
    }

    // 401 过期，重登    
    if (error.response) {
      if (error.response.status === 401) {
        Cookies.remove('accessToken');
        Cookies.remove('accessUser');
        router.push({
          path: "/login"
        });
        Message.error('登陆过期');
      }
      if (error.response.data && error.response.data.message) {
        Message.error(error.response.data.message);
      }
      store.commit('closeLoading');
      return Promise.reject(error) // 返回接口返回的错误信息
    };

    Message.error('请求失败');
    store.commit('closeLoading');
    return Promise.reject(error)

  }
)

//GET请求
export const $get = function (method, params) {
  return new Promise((resolve, reject) => {
    axios({
      method: 'get',
      url: method,
      headers: createHeader(config.token),
      params,
      baseURL: "/"
    }).then(res => {
      resolve(res)
    }).catch(error => {
      reject(error)
    })
  })
}

//POST请求
export const $post = function (method, param, isformdata) {
  return new Promise((resolve, reject) => {
    axios({
      method: 'post',
      url: method,
      headers: createHeader(config.token, isformdata),
      data: param ? param : "",
      baseURL: "/"
    }).then(res => {
      resolve(res)
    }).catch(error => {
      reject(error)
    })
  })
}

//DELETE请求
export const $delete = function (method, params) {
  return new Promise((resolve, reject) => {
    axios({
      method: 'delete',
      url: method,
      headers: createHeader(config.token),
      params,
      baseURL: "/"
    }).then(res => {
      resolve(res)
    }).catch(error => {
      reject(error)
    })
  })
}

//PUT请求
export const $put = function (method, params) {
  return new Promise((resolve, reject) => {
    axios({
      method: 'put',
      url: method,
      headers: createHeader(config.token),
      data: params ? params : "",
      baseURL: "/"
    }).then(res => {
      resolve(res)
    }).catch(error => {
      reject(error)
    })
  })
}

// 将分页信息拼接在url上
export function concatPageInfo(data, url) {
  let obj = {
    url: `${url}?page=${data.page}&size=${data.size}`
  };

  if (data.sort) {
    obj.url = obj.url + '&sort=' + data.sort;
    delete data.sort;
  };

  delete data.page;
  delete data.size;
  obj.data = data;
  return obj;
}

<template>
  <section class="dialog" style="margin-bottom: 5px">
    <el-form ref="userForm" :model="userForm" :rules="userRules">
      <div>
        <el-form-item style="margin-bottom: 5px">
          <span>请输入新密码</span>
        </el-form-item>
        <el-form-item prop="newPassword" style="margin-bottom: 5px">
          <el-input name="newPassword" type="password" v-model="userForm.newPassword"></el-input>
        </el-form-item>
        <el-form-item>
          <a class="reset-pwd" @click="resetPwd">恢复初始密码</a>
        </el-form-item>
      </div>
    </el-form>
    <div slot="footer" align="right" class="section-footer">
      <el-button size="small" @click="hide">取消</el-button>
      <el-button type="primary" size="small" @click="commit">确定</el-button>
    </div>
  </section>
</template>

<script>
import { formValid } from "assets/scripts/common";
import { APPID } from "assets/scripts/code";

export default {
  name: "ResetPwd",
  props: ["login", "type"],
  data() {
    return {
      userForm: {
        newPassword: ""
      },
      userRules: {
        newPassword: [
          { required: true, message: "请输入重置密码", trigger: "blur" },
          { validator: formValid.passwordValidator, trigger: "blur" },
          { min: 8, max: 16, message: "长度在 8 到 16 个字符", trigger: "blur" }
        ]
      }
    };
  },
  methods: {
    // 重置
    commit() {
      this.$refs.userForm.validate(valid => {
        if (valid) {
          let param = {
            password: this.userForm.newPassword,
            login: this.login,
            appId: APPID
          };
          
          if (this.type === 1) {
            //当前用户修改密码
            this.$api.user.changePwd(param).then(
              () => {
                this.hide();
                this.$message.success("密码修改成功");
                this.$emit("success");
              },
              error => {
                debugger
                this.$message.error("密码修改失败");
              }
            );
          } else {
            //超级管理员重置密码
            this.$api.project.resetPwd(param).then(
              () => {
                this.hide();
                this.$message.success("密码重置成功");
                this.$emit("success");
              },
              error => {
                this.$message.error("密码重置失败");
              }
            );
          }
        }
      });
    },

    //重置
    resetPwd() {
      this.userForm.newPassword = "12345678";
      this.$refs.userForm.clearValidate();
    },

    // 表单恢复
    resetForm() {
      this.$refs.userForm.resetFields();
      this.$refs.userForm.clearValidate();
    },

    //dialog关闭
    hide() {
      this.resetForm();
      this.$emit("hide");
    }
  },
  mounted() {}
};
</script>

<style lang="less" scoped>
.reset-pwd {
  color: #2299dd;
  cursor: pointer;
}
</style>


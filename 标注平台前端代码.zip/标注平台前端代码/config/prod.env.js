'use strict'
/**
 * @param IP_URL 域名对应的IP地址
 * @param HAS_CODE 是否显示二维码
 */

module.exports = {
  NODE_ENV: '"production"',
  HAS_CODE: false
}
<template>
  <el-container class="project-processor">
    <el-header height="10%">
      <!-- 查询条件 -->
      <el-form
        :inline="true"
        ref="queryForm"
        class="query-form"
        @submit.native.prevent
        size="small"
      >
        <el-form-item>
          <el-input
            v-model="keyStr"
            placeholder="搜索处理器名称"
            :maxlength="30"
            clearable
            suffix-icon="el-icon-search"
            @keyup.enter.native="query(1)"
            @change="query(1)"
          ></el-input>
        </el-form-item>
      </el-form>
      <el-button class="processor-add" type="success" @click="openNewProce" size="small">
        <i class="iconfont icon-add"></i>
        新增处理器
      </el-button>
    </el-header>
    <el-main>
      <el-table
        :data="processorData"
        align="center"
        height="450"
        size="small"
        v-loading="loading"
        element-loading-text="正在请求"
      >
        <el-table-column
          type="index"
          label="序号"
          min-width="50"
          :index="(index)=>{return (currentPage - 1) * pageSize + index + 1}"
        ></el-table-column>
        <el-table-column prop="name" label="处理器名称" width="180" :show-overflow-tooltip="true"></el-table-column>
        <el-table-column prop="createdDate" label="创建时间" width="200"></el-table-column>
        <el-table-column prop="desc" label="处理器描述" min-width="250" :show-overflow-tooltip="true"></el-table-column>
        <el-table-column
          prop="typeDesc"
          label="处理器类型"
          min-width="250"
          :show-overflow-tooltip="true"
        ></el-table-column>
        <el-table-column prop="createdBy" label="创建人" min-width="250" :show-overflow-tooltip="true"></el-table-column>
        <el-table-column label="操作" min-width="180">
          <template slot-scope="scope">
            <el-button size="mini" type="primary" @click="editProcessor(scope.row.id)">编辑</el-button>
            <el-button size="mini" type="primary" @click="delProcessor(scope.row.id)">移除</el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-pagination
        @size-change="sizeChange"
        @current-change="pageChange"
        align="right"
        :current-page="currentPage"
        :page-sizes="[10, 20, 50, 100]"
        :page-size="pageSize"
        layout="total, sizes, prev, pager, next, jumper"
        :total="total"
        v-show="total > 10"
      ></el-pagination>
    </el-main>

    <el-dialog
      class="create-processor"
      width="800px"
      title="编辑处理器"
      :visible.sync="isShowNewDailog"
      center
      :showClose="false"
      :lock-scroll="false"
    >
      <new-processor
        v-if="isShowNewDailog"
        @cancel="closeDailog"
        :processorId="id"
        @query="query(1)"
      ></new-processor>
    </el-dialog>
  </el-container>
</template>
<script>
import NewProcessor from "./NewProcessor";
import { mapMutations } from "vuex";
export default {
  components: {
    NewProcessor
  },
  computed: {},
  data() {
    return {
      keyStr: "",
      isShowNewDailog: false,
      processorData: [],
      total: 0,
      pageSize: 10,
      currentPage: 1,
      id: "",
      loading: false
    };
  },
  methods: {
    ...mapMutations(["showLoading", "closeLoading"]),
    sizeChange(size) {
      this.pageSize = size;
      this.query(1);
    },

    pageChange(page) {
      this.currentPage = page;
      this.query();
    },

    //打开新建窗口
    openNewProce() {
      // this.isShowNewDailog = true;
      this.$router.push({ path: "/project/CreateProcessor" });
    },

    //关闭弹窗
    closeDailog() {
      this.isShowNewDailog = false;
    },

    //编辑处理器
    editProcessor(id) {
      this.id = id;
      this.isShowNewDailog = true;
    },

    //删除处理器
    delProcessor(id) {
      this.$confirm("确认删除该处理器吗？").then(res => {
        this.loading = true;
        this.$api.project.delProcessor({ id: id }).then(res => {
          this.query();
          this.loading = false;
        });
      });
    },

    //获取处理器列表
    query(resetPage) {
      if (resetPage == 1) {
        this.currentPage = 1;
      }

      let param = {
        name: this.keyStr,
        page: this.currentPage,
        size: this.pageSize,
        sort: "createdDate,DESC"
      };
      this.loading = true;
      this.$api.project.getProcessorList(param).then(res => {
        this.loading = false;
        let { content, totalElements } = res;
        this.processorData = content;
        this.total = totalElements;
      });
    }
  },
  mounted() {
    this.query(1);
  }
};
</script>
<style lang="less">
.project-processor {
  .el-header {
    position: relative;
    padding: 20px 25px 0 25px;
    .icon-add {
      font-size: 14px;
    }
    .processor-add {
      position: absolute;
      right: 24px;
      top: 20px;
    }
  }
  .el-button--mini,
  .el-button--mini.is-round {
    padding: 5px 10px;
  }
  .create-processor {
    .el-dialog--center {
      margin-top: 2% !important;
    }
  }
}
</style>



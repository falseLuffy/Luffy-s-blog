<!-- 知识点标注 -->
<template>
  <mark-tpl
    class="rule-mark"
    :appType="appType"
    :param="param"
    @query="query"
    @setQueryData="setQueryData"
    @valid="valid"
    @save="save"
  >
    <!-- 标题 -->
    <span slot="subtitle" v-if="param.cycoreId" class="rule-id">（id：{{param.cycoreId}}）</span>
    <div class="rule-title" slot="title">
      <template>
        <el-button size="small" type="danger" v-if="param.isBad" @click="availableClick">坏数据</el-button>
        <el-button size="small" type="danger" class="btn-plain" v-else @click="availableClick">标为坏数据</el-button>
      </template>
    </div>
    <div slot="answer" class="rule-content">
      <div class="rule-left">
        <!-- 题目 -->
        <div
          class="rule-q"
          v-if="param.answers && param.answers.length > 0"
          v-for="(item,index) of param.answers"
          :key="index"
        >
          <span v-html="cleanData(item.desc)"></span>
          <ul class="rule-q-o" v-if="item.options && item.options.length > 0">
            <li
              v-for="(unit,index) of item.options"
              :key="index"
              :title="unit.desc"
              class="overflow"
            >
              <span class="o-index">{{unit.index}})</span>
              <span v-html="unit.desc"></span>
            </li>
          </ul>
        </div>

        <!-- 标注详情 -->
        <div
          v-if="wholeMark"
          @click="wholeMarkClick"
          :class="["rule-d",{active: activeItem === "whole"}]"
        >
          <strong>整题标注</strong>
          <el-button size="mini" type="success" style="float:right" v-if="wholeSelected">已选</el-button>
          <ul class="rule-d-s" v-if="wholeSelectedList.length > 0">
            <li
              class="overflow"
              v-for="item of wholeSelectedList"
              :key="item.id"
              :title="item.text ? item.text : item.label"
            >{{item.text ? item.text : item.label}}</li>
          </ul>
        </div>

        <!-- 答案 -->
        <div class="rule-a" v-show="answerShow">
          <strong>正确答案：
            <el-checkbox
              class="rule-check"
              v-model="answerSelected"
              @change="checkClick(1)"
              v-if="subMark"
            ></el-checkbox>
          </strong>
          <div class="rule-wrapper">
            <div v-html="cleanData(param.answerHtml)" v-if="!answerList.length > 0"></div>
            <ul class="rule-list" v-else>
              <li
                class="rule-list-item"
                v-for="(item,index) of answerList"
                :key="index"
                @click="itemClick(1,item)"
                :class="{active: activeItem && activeItem.no === item.no && answerSelected,selected: item.markList.length > 0}"
              >
                <span class="rule-index">{{item.no}}</span>
                <span class="rule-text" v-html="cleanData(item.text)"></span>
                <template v-if="item.markList.length > 0">
                  <ul class="rule-d-s" v-if="item.markList.length > 0">
                    <li
                      class="overflow"
                      v-for="item of item.markList"
                      :key="item.id"
                      :title="item.text ? item.text : item.label"
                    >{{item.text ? item.text : item.label}}</li>
                  </ul>
                </template>
              </li>
            </ul>
          </div>
        </div>

        <!-- 解析 -->
        <div class="rule-s" v-show="analysisShow">
          <strong>解析：
            <el-checkbox
              class="rule-check"
              v-model="analysisSelected"
              @change="checkClick(2)"
              v-if="subMark"
            ></el-checkbox>
          </strong>
          <div class="rule-wrapper">
            <div v-html="cleanData(param.analysisHtml)" v-if="!analysisList.length > 0"></div>
            <ul class="rule-list" v-else>
              <li
                class="rule-list-item"
                v-for="(item,index) of analysisList"
                :key="index"
                @click="itemClick(2,item)"
                :class="{active: activeItem && activeItem.no === item.no && analysisSelected,selected: item.markList.length > 0}"
              >
                <span class="rule-index">{{item.no}}</span>
                <span class="rule-text" v-html="cleanData(item.text)"></span>
                <template v-if="item.markList.length > 0">
                  <ul class="rule-d-s" v-if="item.markList.length > 0">
                    <li
                      class="overflow"
                      v-for="item of item.markList"
                      :key="item.id"
                      :title="item.text ? item.text : item.label"
                    >{{item.text ? item.text : item.label}}</li>
                  </ul>
                </template>
              </li>
            </ul>
          </div>
        </div>
      </div>
      <!-- 树 -->
      <div class="rule-right">
        <el-tree
          v-if="showTree"
          ref="ruleTree"
          node-key="id"
          show-checkbox
          check-strictly
          :data="treeData"
          :default-expanded-keys="defaultExpand"
          :default-checked-keys="defaultChecked"
          @node-click="nodeClick"
          @check="treeChange"
        ></el-tree>
      </div>
    </div>
  </mark-tpl>
</template>
<script>
import MarkTpl from "./MarkTpl";
import { APPTYPE } from "assets/scripts/code";
import { setMarkData } from "assets/scripts/common";
export default {
  name: "ruleMark",
  components: {
    MarkTpl
  },
  data() {
    return {
      subjectType: "",
      appType: APPTYPE.RULE,
      mcType: "",
      param: {
        isBad: false,
        badReason: null,
        cycoreId: "",
        analysisHtml: "",
        answerHtml: "",
        answers: []
      },
      treeData1: [
        {
          id: 1,
          label: "政治生活",
          children: [
            {
              id: 4,
              label: "公民的政治生活",
              children: [
                {
                  id: 9,
                  label: "为人民服务的政府",
                  children: [
                    {
                      id: 19,
                      label: "三级11"
                    },
                    {
                      id: 20,
                      label: "三级22"
                    }
                  ]
                },
                {
                  id: 10,
                  label: "当代国际社会"
                }
              ]
            }
          ]
        },
        {
          id: 2,
          label: "文化生活",
          children: [
            {
              id: 5,
              label: "文化与生活"
            },
            {
              id: 6,
              label: "传承与创新"
            }
          ]
        },
        {
          id: 3,
          label: "生活与哲学",
          children: [
            {
              id: 7,
              label: "智慧与时代精神"
            },
            {
              id: 8,
              label: "世界与追求真理"
            }
          ]
        }
      ],
      treeData: [
        {
          id: 1,
          label: "语法知识",
          children: [
            {
              id: 4,
              label: "名词",
              children: [
                {
                  id: 9,
                  label: "普通名词",
                  children: [
                    {
                      id: 19,
                      label: "专有名词",
                      children: [
                        {
                          id: 21,
                          label: "21名词"
                        },
                        {
                          id: 22,
                          label: "22名词"
                        }
                      ]
                    },
                    {
                      id: 20,
                      label: "私有名词"
                    }
                  ]
                },
                {
                  id: 10,
                  label: "名词的作用"
                }
              ]
            }
          ]
        },
        {
          id: 2,
          label: "代词",
          children: [
            {
              id: 5,
              label: "人称代词"
            },
            {
              id: 6,
              label: "反身代词"
            }
          ]
        },
        {
          id: 3,
          label: "形容词",
          children: [
            {
              id: 7,
              label: "形容词的用法"
            },
            {
              id: 8,
              label: "形容词的比较等级"
            }
          ]
        }
      ],
      baseUrl: "http://latex.codecogs.com/gif.latex?",
      defaultExpand: [], // 默认展开的树枝
      defaultChecked: [], // 默认选择的树枝
      showTree: false, // 显示树
      childChecked: false,

      wholeMark: true, // 是否是整体标注，需要根据学科来设置
      wholeSelected: false, // 是否已选
      wholeSelectedList: [], // 整体列表的数据列表
      wholeIds: "", // 对应的id

      subMark: false, // 单题标注，需要根据学科来设置
      answerSelected: false, // 选择
      analysisSelected: false, // 选择
      answerList: [], // 多条答案组合
      analysisList: [], // 多条分析组合
      answerShow: true, // 答案显示
      analysisShow: true, // 分析显示

      activeItem: null // 表示正在标注,"whole"表示整题标注
    };
  },
  methods: {
    /**
     * 查询数据
     * @param param 请求参数
     * @param isCookie 是否是缓存
     */
    query(param, isCookie) {
      let id = param.userTaskItemId;
      let dataId = param.dataId;
      delete param.dataId;

      this.$api.mark
        .getMarkFile(param)
        .then(res => {
          res.userTaskItemId = id;
          res.dataId = dataId;
          if (isCookie) {
            setMarkData(id, res);
          } else {
            setMarkData(id, res);
            this.setQueryData(res);
          }
        })
        .catch(() => {});
    },

    /**
     * 请求数据后的内容处理
     * @param res 请求的数据
     */
    setQueryData(res) {
      let ruleData;
      let mcType = this.mcType;
      // 重置数据
      this.resetData();

      // 树重新渲染后再执行其他操作
      this.$nextTick(() => {
        // 1）检查
        if (mcType == 1) {
          ruleData = res.checkedData ? res.checkedData : res.markedData;
        } else if (res.markedData && mcType == 0) {
          // 2）标注
          ruleData = res.markedData;
        } else if (!res.markedData) {
          // 3）没有标注
          ruleData = res.data;
        }

        this.param = Object.assign({}, this.param, res.data, ruleData);

        let {
          mark,
          analysisHtml,
          answerHtml,
          answer,
          analysis,
          target
        } = this.param;

        // 1、整题标注回显
        if (this.wholeMark) {
          if (mark && mark.wholeList.length > 0) {
            this.wholeSelected = true;
            this.wholeSelectedList = mark.wholeList;
            this.wholeIds = mark.whole;
            this.initTree(mark.wholeList);
          }
          this.activeItem = "whole";
        }

        // 2、单题标注回显
        if (this.subMark) {
          // 答案处理.split(/<br\s*\/?\s*>/)
          if (answer && answer.length > 0) {
            this.answerList = [...answer];
          } else {
            let answerList = answerHtml.split(/<br\s*\/?\s*>/);
            if (answerList && answerList.length > 1) {
              this.answerList = answerList.map((item, index) => {
                return {
                  no: index,
                  text: item,
                  mark: "",
                  markList: []
                };
              });
            }
          }

          // 分析处理
          if (analysis && analysis.length > 0) {
            this.analysisList = [...analysis];
          } else {
            let analysisList = analysisHtml.split(/<br\s*\/?\s*>/);
            if (analysisList && analysisList.length > 1) {
              this.analysisList = analysisList.map((item, index) => {
                return {
                  no: index,
                  text: item,
                  mark: "",
                  markList: []
                };
              });
            }
          }

          // 复选框选择
          if (target) {
            this[`${target}Selected`] = true;
            this.checkClick(target === "answer" ? 1 : 2);
          }
        }

        // 显示树
        this.showTree = true;

        // 公式图片的显示
        this.$nextTick(() => {
          this.showLatexImg();
          this.$refs.ruleTree.$el.removeEventListener(
            "keydown",
            this.$refs.ruleTree.handleKeydown
          );
        });

        // 获取数据后，才可以点击下一条，防止快速点击事件
        this.param.clicked = false;
        if (this.param.keycodetimer) {
          this.param.keycodetimer = null;
          clearTimeout(this.param.keycodetimer);
        }
      });
    },

    /**
     * 重置数据
     */
    resetData() {
      this.showTree = false; // 显示树
      this.defaultExpand = []; // 默认展开的树枝
      this.defaultChecked = []; // 默认选择的树枝
      this.target = "";
      this.wholeSelected = false; // 是否已选
      this.activeItem = null; // 表示正在标注,"whole"表示整题标注
      this.childChecked = false;

      this.param = {
        cycoreId: "",
        analysisHtml: "",
        answerHtml: "",
        answers: []
      };

      if (this.wholeMark) {
        this.wholeSelectedList = [];
        this.wholeIds = [];
        this.activeItem = "whole";
      }

      if (this.subMark) {
        this.answerSelected = false;
        this.analysisSelected = false;
        this.answerList = []; // 多条答案组合
        this.analysisList = []; // 多条分析组合
        this.answerShow = true; // 答案显示
        this.analysisShow = true; // 分析显示
      }
    },

    /**
     * 清理数据中的↵符号
     */
    cleanData(data) {
      return data.replace(/↵/g, "");
    },

    /**
     * 获取公式图片
     */
    showLatexImg() {
      let imgs = document.querySelectorAll("img");
      if (imgs && imgs.length > 0) {
        imgs.forEach(item => {
          if (item.dataset.latex) {
            let latex = decodeURI(item.dataset.latex);
            item.src = `${this.baseUrl}${latex}`;
          }
        });
      }
    },

    /**
     * 根据数据初始化树
     * @param 选中的树
     */
    initTree(treeData) {
      this.showTree = false;

      this.$nextTick(() => {
        let ids = [];
        treeData.forEach(item => {
          this.defaultExpand.push(item.id);
          ids.push(item.id);
        });

        this.defaultChecked = ids;
        this.showTree = true;
      });
    },

    /**
     * 整题标注
     */
    wholeMarkClick() {
      this.activeItem = "whole";
      if (this.wholeSelectedList.length > 0) {
        this.initTree(this.wholeSelectedList);
      } else {
        this.$refs.ruleTree.setCheckedKeys([]);
      }
    },

    /**
     * 点击checkbox
     * @param type 表示点了哪个 1答案，2分析
     */
    checkClick(type) {
      if (type == 1) {
        if (this.answerSelected) {
          this.analysisSelected = false;
          this.analysisShow = false;
        } else {
          this.analysisShow = true;
        }
      }
      if (type == 2) {
        if (this.analysisSelected) {
          this.answerSelected = false;
          this.answerShow = false;
        } else {
          this.answerShow = true;
        }
      }

      if (!this.answerSelected && !this.analysisSelected) {
        this.activeItem = null;
        this.$refs.ruleTree.setCheckedKeys([]);
      }
    },

    /**
     * 点击item
     * @param type 表示点了哪个 1答案，2分析
     * @param item 点击的元素
     */
    itemClick(type, item) {
      if (type == 1) {
        if (this.activeItem && this.activeItem.no === item.no) {
          return;
        }
        // 复选框选中
        this.answerSelected = true;
        this.checkClick(1);

        // 自身选中
        this.activeItem = item;

        // 树回显
        if (item.markList.length > 0) {
          this.initTree(item.markList);
        } else {
          this.$refs.ruleTree.setCheckedKeys([]);
        }
      }

      if (type == 2) {
        if (this.analysisItemNo === item.no) {
          return;
        }
        // 复选框选中
        this.analysisSelected = true;
        this.checkClick(2);

        // 自身选中
        this.analysisItemNo = item.no;
        this.activeItem = item;

        // 树回显
        if (item.markList.length > 0) {
          this.initTree(item.markList);
        } else {
          this.$refs.ruleTree.setCheckedKeys([]);
        }
      }
    },

    /**
     * 点击树的checkbox触发事件
     * @param data 节点对应的对象
     * @param node 树目前选中状态对象
     */
    treeChange(data, node) {
      // 父子节点不允许同时选择
      if (this.subjectType === "english") {
        let flag = this.checkBothChecked(data);
        if (!flag) {
          this.$message.error("父子节点不允许同时选择");
          this.$refs.ruleTree.setChecked(data, false);
          return;
        }
      }

      // 1 整题标注
      if (this.wholeMark && this.activeItem === "whole") {
        this.wholeMarkHandler();
      }

      // 2 单题标注
      if (this.subMark && !this.activeItem) {
        this.$message.warning("请先选择步骤");
        this.$refs.ruleTree.setCheckedKeys([]);
        return;
      }

      if (this.subMark && this.activeItem) {
        this.subMarkHandler();
      }
    },

    /**
     * 点击子节点的回调-激活复选框
     * @param data 节点对应的对象
     * @param node 节点对应的node
     * @param self 节点组件的本身
     */
    nodeClick(data, node, self) {
      if (!data.disabled) {
        // 英文学科的树不激活复选框
        if (this.subjectType === "english") {
          return;
        } else {
          // 获取当前的选中状态
          let { checked } = node;
          // 新的状态
          let newChecked = !checked;
          if (this.subMark && !this.activeItem) {
            this.$message.warning("请先选择步骤");
            this.$refs.ruleTree.setCheckedKeys([]);
            return;
          }

          // 设置样式
          this.$refs.ruleTree.setChecked(data, newChecked);

          // 1 整题标注
          if (this.wholeMark && this.activeItem === "whole") {
            this.wholeMarkHandler();
          }
          // 2 单题标注
          if (this.subMark && this.activeItem) {
            this.subMarkHandler();
          }
        }
      }
    },

    /**
     * 判断父子节点是否同选
     * @param data 当前节点对象
     */
    checkBothChecked(data) {
      let node = this.$refs.ruleTree.getNode(data);
      let checkedNode = this.$refs.ruleTree.getCheckedKeys();

      if (!node.checked) {
        return true;
      }

      let parentChecked = false;
      // 判断父辈节点
      if (node.parent) {
        let parent = node.parent;

        while (parent && !parentChecked) {
          let pid = parent.data.id;
          if (pid && checkedNode.includes(pid)) {
            parentChecked = true;
          } else {
            parent = parent.parent;
          }
        }
      }

      // 判断孩子节点
      this.childChecked = false;
      if (node.childNodes && node.childNodes.length > 0) {
        let children = node.childNodes;
        // 孩子节点的判断
        this.checkChildren(children, checkedNode);
      }

      if (parentChecked || this.childChecked) {
        return false;
      } else {
        return true;
      }
    },

    /**
     * 判断孩子节点中是不是有点击了的
     */
    checkChildren(childData, checkedNode) {
      let len = childData.length;

      if (childData && len > 0) {
        let childChecked = childData.find(item => {
          if (this.childChecked) {
            return;
          }
          let itemId = item.data.id;
          if (itemId && checkedNode.includes(itemId)) {
            this.childChecked = true;
          } else if (item.childNodes && item.childNodes.length > 0) {
            this.checkChildren(item.childNodes, checkedNode);
          }
        });
      }
    },

    /**
     * 整题标注的数据控制
     */
    wholeMarkHandler() {
      // 获取当前选中的节点信息
      let checkedNodes = this.$refs.ruleTree.getCheckedNodes();

      // 重置整题标注列表信息
      let selectedList = [];
      this.wholeSelectedList = [];
      this.wholeIds = [];

      if (checkedNodes && checkedNodes.length > 0) {
        this.wholeSelected = true;
        checkedNodes.forEach(item => {
          if (!item.disabled) {
            this.wholeSelectedList.push(item);
            selectedList.push(item.id);
          }
        });
        this.wholeIds = selectedList;
      } else {
        this.wholeSelected = false;
      }
    },

    /**
     * 单题标注的数据控制
     */
    subMarkHandler() {
      // 获取当前选中的节点信息
      let checkedNodes = this.$refs.ruleTree.getCheckedNodes();

      let checkedNode = [];
      let checkedId = [];
      checkedNodes.forEach(item => {
        if (!item.disabled) {
          checkedNode.push(item);
          checkedId.push(item.id);
        }
      });

      // 找到原数据
      this[this.answerSelected ? "answerList" : "analysisList"].find(item => {
        if (item.no === this.activeItem.no) {
          item.markList = checkedNode;
          item.mark = checkedId.join(",");
        }
      });
    },

    /**
     * 重置树的数据，如果是父级则不显示复选框
     */
    setTreeData(data) {
      data.forEach(item => {
        if (item.children && item.children.length > 0) {
          if (this.subjectType !== "english") {
            item.disabled = true;
          }
          this.setChildIndexTitle(
            item.children,
            item.text ? item.text : item.label
          );
          this.setTreeData(item.children);
        }
      });
    },

    /**
     * 给每个子节点加入父节点的label，便于获取显示
     */
    setChildIndexTitle(data, plabel) {
      data.forEach(item => {
        item.text = plabel + "/" + item.label;
      });
    },

    /**
     * 校验
     */
    valid() {
      // 标记是否标记区域
      let hasWhole = false;
      let hasSub = false;

      // 1、整题标注
      if (this.wholeMark) {
        this.param.commitData = {
          cycoreId: this.param.cycoreId
        };
        this.param.commitData.mark = {
          whole: this.wholeIds,
          wholeList: [...this.wholeSelectedList]
        };

        if (this.wholeIds.length > 0) {
          hasWhole = true;
        }

        if (!hasWhole) {
          this.param.valid = false;
          this.param.validMsg = "请选择整题标注步骤";
          return;
        }
      }

      // 2、单题标注
      if (this.subMark) {
        // 答案和解析必须选一个
        if (!this.answerSelected && !this.analysisSelected) {
          this.param.valid = false;
          this.param.validMsg = "请选择标注区域";
          return;
        }

        let subObj = {
          tbId: this.param.cycoreId,
          target: this.answerSelected ? "answer" : "analysis",
          prompt: this.param.answers[0].desc
        };

        // 答案->清空解析的数据；解析->清空答案的数据
        subObj.analysis = [...this.analysisList];
        subObj.answer = [...this.answerList];

        subObj[this.answerSelected ? "analysis" : "answer"].forEach(item => {
          item.mark = "";
          item.markList = [];
        });

        // 找小题的Mark数据
        subObj[this.answerSelected ? "answer" : "analysis"].find(item => {
          if (item.mark) {
            hasSub = true;
            return true;
          }
        });

        this.param.commitData = Object.assign(
          {},
          this.param.commitData,
          subObj
        );

        if (!hasSub) {
          this.param.valid = false;
          this.param.validMsg = "请选择小题标注步骤";
          return;
        }
      }

      return true;
    },

    /**
     * 保存数据
     */
    save() {
      return true;
    },

    /**
     * 文件可用点击
     */
    availableClick() {
      // 只读，检查员不可以改好数据
      if (this.readonly || (this.mcType == 1 && !this.param.bad)) {
        return;
      }

      this.param.bad = !this.param.bad;
    }
  },
  created() {
    let task = JSON.parse(window.sessionStorage.getItem("task"));
    this.task = task;
    // 1检查,0标注
    this.mcType = task.type;
    this.readonly = task.readonly;

    // 整题标注，默认
    this.subjectType = this.$route.params.id;
    // 小题标注
    if (this.subjectType == "math") {
      this.wholeMark = false;
      this.subMark = true;
    }
    // 对树数据进行处理-父节点不可选择，英文的可选择
    this.setTreeData(this.treeData);
  }
};
</script>

<style rel="stylesheet/less"  lang="less" scoped>
.rule-title {
  display: inline-block;
  margin-left: 20px;
}

.rule-content {
  .rule-left {
    float: left;
    box-sizing: border-box;
    width: 60%;
    padding: 10px;
    line-height: 2;
    .rule-q {
      .rule-q-o {
        border: #f1f1f1 1px solid;
        font-weight: bold;
        margin: 10px 0;
        border-radius: 2px;
        li {
          max-width: 100%;
          padding: 5px 10px;
          border-bottom: #f1f1f1 1px solid;
          box-sizing: border-box;
          &:last-child {
            border-bottom: none;
          }
        }
      }
    }
    .rule-d {
      border: #dadada 1px solid;
      border-radius: 2px;
      padding: 5px 10px;
      max-height: 250px;
      overflow-y: auto;
      overflow-x: hidden;
      cursor: pointer;
      &.active {
        border: #df8f0e 1px solid;
      }
    }

    .rule-s,
    .rule-a {
      border: #dadada 1px solid;
      margin-top: 10px;
      border-radius: 2px;
      box-sizing: border-box;
      padding: 0px;
      strong {
        padding-left: 10px;
        width: 100%;
        background: #dadada;
        display: block;
        box-sizing: border-box;
        .rule-check {
          float: right;
          margin-right: 10px;
        }
      }
      .rule-wrapper {
        padding: 5px 10px;
      }
    }

    .rule-d-s {
      li {
        max-width: 96%;
        position: relative;
        padding-left: 4%;
        &:before {
          width: 5px;
          height: 5px;
          background-color: #67c23a;
          position: absolute;
          left: 10px;
          top: 12px;
          content: "";
        }
      }
    }

    .rule-list {
      li.rule-list-item {
        position: relative;
        margin: 4px 0;
        cursor: pointer;
        border: transparent 1px solid;
        overflow: hidden;
        padding: 2px;
        box-sizing: border-box;
        &:hover {
          border: #dadada 1px solid;
        }
        &.active {
          border: #df8f0e 1px solid;
        }
        .rule-index,
        .rule-text {
          float: left;
        }
        .rule-index {
          background-color: #808080;
          width: 24px;
          height: 22px;
          text-align: center;
          line-height: 22px;
          border-radius: 2px;
          color: #fff;
          margin-right: 5px;
        }
        .rule-text {
          line-height: 22px;
          width: ~"calc(100% - 30px)";
        }

        &.selected {
          .rule-index {
            background-color: #67c23a;
          }
        }

        .icon-down {
          position: absolute;
        }
      }

      .rule-d-s li {
        padding-left: 40px;
        max-width: ~"calc(100% - 40px)";
        color: #808080;
        &::before {
          left: 30px;
        }
      }
    }
  }

  .rule-right {
    min-height: 500px;
    border: #c8c8c8 1px dashed;
    float: left;
    box-sizing: border-box;
    width: 40%;
  }
}
</style>

<style rel="stylesheet/less"  lang="less">
.el-tree-node .is-disabled {
  display: none;
}
</style>






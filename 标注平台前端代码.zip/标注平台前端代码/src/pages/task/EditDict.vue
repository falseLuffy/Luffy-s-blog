<template>
  <el-container class="dict-list" id="exportParent">
    <el-main>
      <div class="dict-list-title">字典编辑</div>
      <div class="dict-export-btns">
        <el-button @click="back()" size="mini" type="danger">返回列表</el-button>
        <div class="import-dict">
          <span>字典导入</span>
          <input @change="importDict" type="file" accept="application/xls">
        </div>
        <el-button type="primary" size="mini" @click="exportDict">字典导出</el-button>
      </div>

      <!-- 列表 -->
      <ul class="dict-content">
        <li v-if="editInfo">
          <el-row>
            <el-col :span="24">
              <strong class="ellipsis">{{editInfo.name}}</strong>
              <span
                class="dict-label"
                v-if="editInfo.label && editInfo.label.length > 0"
                v-for="(unit,index) of editInfo.label"
                :key="index"
                :style="{backgroundColor:unit.color}"
              >{{unit.text}}</span>
            </el-col>
          </el-row>
          <!-- 状态显示 -->
          <el-row class="main-font">
            <el-col :span="8">简介：{{editInfo.description}}</el-col>
            <el-col :span="6">
              <dl>
                <dt>创建人</dt>
                <dd>{{editInfo.createdBy}}</dd>
              </dl>
            </el-col>
            <el-col :span="6">
              <dl>
                <dt>更新时间</dt>
                <dd>{{dateFormat(editInfo.updateDate)}}</dd>
              </dl>
            </el-col>
          </el-row>
        </li>
      </ul>

      <!-- 树操作 -->
      <div class="dict-tree" v-if="rootId" v-loading="loading" element-loading-text="正在请求">
        <el-input
          size="small"          
          v-model="filterText"
          placeholder="请输入"
          clearable
          suffix-icon="el-icon-search"
          @keyup.enter.native="queryTree"
          @change="queryTree"
          style="width:250px;"
        ></el-input>

        <el-tree
          ref="dictTree"
          node-key="id"
          :default-expanded-keys="defaultExpandKey"
          :expand-on-click-node="false"
          :data="treeData"
          :filter-node-method="filterNode"
          @node-click="nodeClick"
          @node-expand="nodeExpand"
          @node-collapse="nodeCollapse"
        >
          <span class="custom-tree-node" slot-scope="{ node, data }">
            <span
              :class="{'active':data.id == currentId,'selected': data.selected}"
            >{{ node.label }}</span>
            <span class="icon-btns" v-if="data.id == currentId">
              <i
                class="iconfont icon-remove"
                @click.stop="remove(node,data)"
                v-if="data.id !== rootId"
              ></i>
              <i class="iconfont icon-add2" @click.stop="append(node,data)" v-if="!data.newFlag"></i>
            </span>
          </span>
        </el-tree>
      </div>

      <!-- 树编辑 -->
      <div class="dict-panel" v-if="currentId">
        <strong>节点信息</strong>
        <el-form
          size="small"
          ref="dictForm"
          :model="dictForm"
          :rules="dictRules"
          label-width="110px"
          labelPosition="right"
        >
          <el-form-item prop="label" label="节点名称:">
            <el-input
              name="label"
              v-model="dictForm.label"
              placeholder="请选择节点名称"
              :disabled="readonly"
            ></el-input>
          </el-form-item>
          <el-form-item prop="value" label="节点值:">
            <el-input
              name="value"
              v-model="dictForm.value"
              placeholder="请选择节点值"
              :disabled="readonly"
            ></el-input>
          </el-form-item>
          <el-form-item prop="description" label="节点描述:">
            <el-input
              type="textarea"
              :rows="4"
              name="description"
              v-model="dictForm.description"
              :maxlength="255"
              placeholder="请输入节点的简单描述"
              :disabled="readonly"
            ></el-input>
          </el-form-item>

          <el-form-item style="float:right" v-if="!readonly">
            <el-button size="mini" @click="cancel">取消</el-button>
            <el-button type="primary" size="mini" @click="sure">确定</el-button>
          </el-form-item>
        </el-form>
      </div>
    </el-main>
  </el-container>
</template>
}
<script>
import { mapState, mapMutations } from "vuex";
import { formSubmit } from "assets/scripts/common";

export default {
  computed: {
    ...mapState(["appInfo"])
  },
  watch: {
    appInfo() {
      if (this.appInfo.id) {
        this.getTree();
      }
    }
  },
  data() {
    return {
      filterText: "",
      rootId: null,
      defaultExpandKey: [],
      readonly: false,
      loading: false,
      editInfo: null,
      addNodeFlag: false, // 新增节点
      currentId: null, // 当前选中
      dictForm: {
        id: "",
        label: "",
        value: "",
        description: "",
        parentId: ""
      },
      dictRules: {
        label: [{ required: true, message: "请输入节点名称", trigger: "blur" }],
        value: [{ required: true, message: "请输入节点值", trigger: "blur" }]
      },
      treeData: []
    };
  },
  methods: {
    ...mapMutations(["showLoading", "closeLoading"]),
    /**
     * 导入字典
     */
    importDict(event) {
      const file = event.target.files[0];
      let formData = new FormData();
      formData.append("dictionaryId", this.editInfo.id);
      formData.append("file", file);

      this.showLoading();
      this.$api.task
        .importDict(formData)
        .then(res => {
          this.$message.success("导入成功");
          this.getTree();
        })
        .catch(() => {
          this.closeLoading();
        });
    },

    /**
     * 导出字典
     */
    exportDict() {
      let param = {
        dictId: this.editInfo.id
      };
      formSubmit(
        `/datawood-manager/api/dictionary/export-excel/${param.dictId}`,
        param
      );
      this.$confirm("操作成功，请等待文件下载");
    },

    /**
     * 过滤树
     */
    queryTree() {
      this.$refs.dictTree.filter(this.filterText);
    },

    /**
     * 搜索树
     */
    filterNode(value, data) {
      data.selected = false;
      if (!value) return true;
      if (data.label == value) {
        this.$nextTick(() => {
          data.selected = true;
          this.nodeClick(data);
        });
      } else {
        this.currentId = null;
      }
      return data.label.indexOf(value) !== -1;
    },

    /**
     * 获取树
     */
    getTree() {
      // this.rootId = null;
      this.loading = true;
      this.filterText = "";
      this.$nextTick(() => {
        this.$api.task
          .getDictTree({
            dictId: this.editInfo.id,
            level: 1
          })
          .then(res => {
            this.closeLoading();
            this.loading = false;
            let { id, name, description } = this.editInfo;

            // 加入树的根节点，并展开
            if (this.defaultExpandKey.length == 0) {
              this.rootId = new Date().getTime();
              this.defaultExpandKey.push(this.rootId);
            }

            let tree = [
              {
                id: this.rootId,
                label: name,
                value: id,
                root: true,
                description: description,
                children: []
              }
            ];

            // 加入树字典
            if (res && res.length > 0) {
              tree[0].children = res;
            }
            this.treeData = tree;
          })
          .catch(() => {
            this.closeLoading();
            this.loading = false;
          });
      });
    },

    /**
     * 点击树
     */
    nodeClick(data, node) {
      // 是否是新节点的标识
      let { newFlag, parentId } = data;
      this.addNodeFlag = newFlag;
      this.dictForm.parentId = parentId;

      // 清除上一次的校验
      if (this.$refs.dictForm) {
        this.$refs.dictForm.clearValidate();
      }

      // 自己已选无效
      if (this.currentId == data.id) {
        return;
      }

      // 显示右侧
      this.currentId = data.id;

      // 根节点可看不可改
      this.readonly = data.root ? true : false;

      // 表单赋值
      this.dictForm.label = data.label;
      this.dictForm.value = data.value;
      this.dictForm.description = data.description;
    },

    /**
     * 树展开
     */
    nodeExpand(data, node, self) {
      if (!this.defaultExpandKey.includes(data.id)) {
        this.defaultExpandKey.push(data.id);
      }
    },

    /**
     * 树折起
     */
    nodeCollapse(data, node, self) {
      let id = data.id;
      if (this.defaultExpandKey.includes(id)) {
        let index = this.defaultExpandKey.findIndex(item => {
          return item == id;
        });

        this.defaultExpandKey.splice(index, 1);
      }
    },

    /**
     * 新增节点
     */
    append(node, data) {
      // 父节点赋值
      let parentId;
      if (data.id !== this.rootId) {
        parentId = data.id;
      }

      // 展开
      node.expanded = true;
      this.defaultExpandKey.push(data.id);

      // 模拟新增一个树枝
      let id = new Date().getTime();
      const newChild = {
        id: id,
        label: "新增节点",
        value: "",
        description: "",
        parentId: parentId,
        newFlag: true
      };
      if (!data.children) {
        this.$set(data, "children", []);
      }
      data.children.push(newChild);

      // 展示右边信息
      this.$nextTick(() => {
        this.nodeClick(newChild);
      });
    },

    /**
     * 移除节点
     */
    remove(node, data) {
      // 假数据直接移除
      if (data.newFlag) {
        const parent = node.parent;
        const children = parent.data.children || parent.data;
        const index = children.findIndex(d => d.id === data.id);
        children.splice(index, 1);
        this.currentId = null;
        this.addNodeFlag = false;
      } else {
        this.$confirm("确认删除该节点吗？", "", { lockScroll: false })
          .then(() => {
            this.showLoading();
            this.$api.task
              .delDictNode({
                id: data.id
              })
              .then(res => {
                this.$message.success("删除成功");
                this.currentId = null;

                // 获取当前展开的树
                this.getTree();
                this.addNodeFlag = false;
              })
              .catch(() => {
                this.closeLoading();
              });
          })
          .catch(() => {});
      }
    },

    // 返回主页
    back() {
      this.$router.push({ path: "/task/dict" });
    },

    // 确定修改
    sure() {
      this.$refs.dictForm.validate(valid => {
        if (valid) {
          let text = this.addNodeFlag ? "添加" : "修改";

          this.$confirm(`确认${text}该节点吗？`, "", {
            lockScroll: false
          }).then(() => {
            let param = { ...this.dictForm };
            param.id = this.currentId;
            // 不是新增则去除
            if (!this.addNodeFlag) {
              delete param.parentId;
            } else {
              param.dictionaryId = this.editInfo.id;
            }

            this.showLoading();
            this.$api.task[this.addNodeFlag ? "addDictNode" : "editDictNode"](
              param
            )
              .then(() => {
                this.$message.success(`${text}成功`);
                this.getTree();

                if (this.addNodeFlag) {
                  this.currentId = null;
                }
              })
              .catch(() => {
                this.closeLoading();
              });
          });
        }
      });
    },

    // 取消
    cancel() {
      this.currentId = null;
    },

    //日期格式化
    dateFormat(time) {
      if (!time) {
        return "";
      }
      return this.$moment(time).format("YYYY-MM-DD HH:mm");
    }
  },

  mounted() {
    this.editInfo = JSON.parse(window.sessionStorage.getItem("editInfo"));
    this.rootId = new Date().getTime();
    this.getTree();
  }
};
</script>

<style rel="stylesheet/less" lang="less">
.dict-list {
  position: relative;
  padding-bottom: 20px;
  .el-container .el-main {
    padding: 0px 15px;
  }
  .el-main {
    padding-bottom: 50px;
  }

  .dict-content {
    padding: 0;
    margin-bottom: 18px;
    li {
      list-style: none;
      padding: 20px 0px;
      border-bottom: #ddd 1px dashed;
      .el-row {
        padding: 4px 0;
        font-size: 12px;
        strong {
          max-width: 300px;
          font-size: 14px;
          position: relative;
          top: 4px;
          margin-right: 10px;
        }
        .dict-label {
          color: #fff;
          padding: 3px 8px;
          text-align: center;
          border-radius: 3px;
          margin-right: 8px;
        }
      }
      .main-font {
        margin-top: 20px;
        .el-col-2 {
          text-align: center;
        }
        dd {
          margin-top: 10px;
        }
      }
      .el-icon-edit-outline {
        font-size: 18px;
        position: relative;
        left: -5px;
        &:hover {
          color: #4baffe;
        }
      }
    }
    .dict-content-empty {
      font-size: 14px;
      height: 400px;
      text-align: center;
      position: relative;
      &:before {
        display: inline-block;
        width: 110px;
        height: 90px;
        background-image: url("~@/assets/images/nodata.png");
        background-size: cover;
        content: "";
        position: absolute;
        left: 50%;
        top: 50%;
      }
      &:after {
        content: "暂无数据";
        position: absolute;
        left: calc(50% + 28px);
        top: calc(50% + 100px);
        color: #909399;
      }
    }
  }

  .dict-list-title {
    font-weight: bold;
    margin: 20px 0;
    display: inline-block;
  }

  .dict-export-btns {
    position: absolute;
    top: 25px;
    right: 20px;
  }

  .el-button--mini,
  .el-button--mini.is-round {
    padding: 5px 10px;
  }
  .el-table__empty-block {
    min-height: 250px;
  }

  .custom-tree-node {
    span:first-child {
      display: inline-block;
      height: 25px;
      line-height: 25px;
      box-sizing: border-box;
      padding: 0 4px;
    }

    .selected {
      // border: #f9c77f 1px solid;
      // border-radius: 2px;
      color: #f9c77f;
    }
    .active {
      color: #409eff;
    }
    .icon-btns {
      position: relative;
      top: 2px;
      left: 10px;
      .iconfont {
        font-size: 16px;
        &.icon-remove {
          font-size: 18px;
          margin-right: 4px;
          position: relative;
          top: 1px;
        }
        cursor: pointer;
        &:hover {
          color: #409eff;
        }
      }
    }
  }

  .dict-tree,
  .dict-panel {
    min-height: 365px;
    float: left;
    width: 30%;
    box-sizing: border-box;
  }
  .dict-panel {
    border: #ddd 1px solid;
    padding: 20px;
    width: 50%;
    strong {
      display: block;
      margin-bottom: 20px;
      border-bottom: #ddd 1px dashed;
      padding-bottom: 20px;
    }
  }
  .import-dict {
    position: relative;
    display: inline-block;
    width: 70px;
    height: 24px;
    background-color: #409eff;
    line-height: 24px;
    text-align: center;
    color: #fff;
    border-radius: 4px;
    font-size: 12px;
    overflow: hidden;
    top: 8px;
    input {
      position: absolute;
      background: red;
      height: inherit;
      left: 0;
      width: inherit;
      opacity: 0;
    }
  }

  .el-tree-node__expand-icon {
    font-size: 18px;
    padding: 0 !important;
  }
}
</style>











<!-- 政法OCR标注 -->
<template>
  <mark-tpl
    class="lawocr-mark"
    :appType="appType"
    :keysList="keysList"
    :param="param"
    @query="query"
    @setQueryData="setQueryData"
    @valid="valid"
    @save="save"
  >
    <!-- 属性操作栏 -->
    <div class="ocr-attrs" slot="title">
      <!-- 属性标签 -->
      <span v-if="!readonly">
        <span
          v-for="item of attrsList"
          :key="item.type"
          @click="attrClick(item)"
          :style="{backgroundColor:item.color}"
          :class="{'active':item.type == activeAttrValue}"
        >{{item.label}}</span>
      </span>

      <!-- 属性状态切换 -->
      <el-switch
        v-model="inheritAttr"
        inactive-text="属性继承"
        v-if="!readonly"
        @change="inheritAttrChange"
      ></el-switch>
      <el-switch v-model="showAttr" inactive-text="显示属性" @change="showAtrrChange"></el-switch>
      <el-switch
        v-model="showTemp"
        inactive-text="临时转写框"
        v-if="!readonly"
        @change="showTempChange($event)"
      ></el-switch>
    </div>

    <!-- 坏数据 -->
    <template slot="butterSlot" v-if="!readonly">
      <el-button
        class="law-button"
        type="danger"
        size="small"
        v-if="param.bad"
        @click="availableClick"
      >坏数据</el-button>
      <el-button
        class="btn-plain law-button"
        type="danger"
        size="small"
        v-else
        @click="availableClick"
      >标为坏数据</el-button>
    </template>

    <!-- 绘制区域 -->
    <div slot="answer" class="ocr-answer" :style="{height: drawHeight}">
      <!-- 绘制的图标 -->
      <div class="shape-tools">
        <dl :class="{active:shapeType == 1}" v-if="shapeType == 1">
          <dt class="iconfont icon-polygon"></dt>
        </dl>
        <dl :class="{active:shapeType == 2}" v-if="shapeType == 2">
          <dt class="iconfont icon-rect"></dt>
        </dl>
      </div>
      <div class="draw-area" ref="drawArea">
        <div
          ref="canvas"
          id="canvas"
          :class="['is-drag',{'is-point': shapeType == 1 || shapeType == 2}]"
          :style="{height: canvasHeight}"
        ></div>

        <!-- 辅助工具 -->
        <ul class="help-tool" v-if="mcType == 1 || readonly">
          <li :class="{active: screenActive}" @click="screenClick">
            <i class="iconfont icon-screen"></i>
            <span>筛选</span>
          </li>
        </ul>
        <div class="screen-lables" v-if="screenActive">
          <span
            v-for="item of screenList"
            class="overflow"
            :title="item.label"
            :key="item.type"
            :class="{active: screenNames.includes(item.type)}"
            @click.stop="screenItemClick(item)"
          >{{item.label}}</span>
        </div>

        <!-- 浮动元素 临时转写框 -->
        <el-input
          ref="tempText"
          class="temp-text"
          v-show="showTemp && activeItem && activeItem.id && !readonly && !drawStatus && activeItem.writeable"
          size="small"
          type="textarea"
          :value="activeItem.text"
          :style="[tempTextStyle]"
          @input="changeTempText($event)"
          rows="4"
        ></el-input>
      </div>

      <!-- 浮动元素 属性跟随面板 -->
      <ul id="attrsTool" class="attrs-tool" :style="[attrsToolStyle]" v-show="showAttrsTool">
        <li>请选择属性</li>
        <li
          v-for="item of attrsList"
          :key="item.type"
          @click="attrToolClick(item,true)"
          :style="{backgroundColor:item.color}"
          :class="{'active':item.type == activeAttrValue}"
        >{{item.label}}</li>
      </ul>

      <!-- 转写区域 -->
      <div class="draw-tools">
        <div class="area">
          <ul class="area-list" ref="areaList">
            <li
              v-for="(item,index) of param.result"
              :key="index"
              :ref="`areaItem${item.id}`"
              :id="item.id"
              @click="areaItemClick(item,true)"
            >
              <el-input
                :class="{'active': item.active}"
                v-if="item.writeable"
                size="small"
                type="textarea"
                :value="item.text"
                :readonly="readonly"
                @input="changeAreaText($event,item.id)"
              ></el-input>
              <el-button
                v-if="item.writeable && !readonly"
                v-show="activeItem && activeItem.id == item.id"
                size="mini"
                type="info"
                @click.stop.prevent="errorClick($event,item,true)"
              >Error</el-button>
              <span
                class="error-span"
                v-if="item.writeable && !readonly"
                v-show="activeItem && activeItem.id == item.id"
              >(F1)</span>
              <span
                v-if="!item.writeable"
                :class="['un-write',{'active': activeItem && activeItem.id == item.id,'red-active':item.active}]"
                v-focus
                @click.stop.prevent="unWriteClick(item)"
              >不可转写区域</span>
              <span class="logo" v-show="showAttr">{{item.logo}}</span>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </mark-tpl>
</template>

<script>
import MarkTpl from "./MarkTpl";
import Cookies from "js-cookie";
import { APPTYPE } from "assets/scripts/code";
import { setMarkData } from "assets/scripts/common";
import OcrSet from "assets/scripts/ocr";
import SVG from "svg.js";
import "svg.draggable.js";
import "svg.select.js";
import "svg.resize.js";
require("assets/scripts/svg-pan-zoom.js");
const token = Cookies.get("accessToken");

export default {
  name: "lawocrMark",
  components: {
    MarkTpl
  },

  data() {
    return {
      keysList: OcrSet.lawkeys,
      appType: APPTYPE.LAW,
      attrsList: [...OcrSet.attrsList],
      screenList: [...OcrSet.attrsList],
      inheritAttr: false, // 继承属性
      showAttr: true, // 显示属性
      shapeType: null, // 1多边形绘制，2矩形绘制
      showTemp: true, // 显示临时转写框
      mcType: "",
      readonly: false,
      drawHeight: OcrSet.drawHeight, // - 192
      activeItem: {}, // 当前激活形状
      currentDraw: null, // 正在绘制的图像
      drawStatus: false, // 标识是否正在绘制
      selectShape: null, // 当前选中的形状
      zoom: 1,
      canvasHeight: "100%",
      draw: null,
      lineX: null, // 活动的X
      lineY: null, // 活动的Y
      mainImage: null,
      drawGroup: null, // 存放操作组
      groupZoom: null, // 存放zoom对象
      activeAttrValue: "", // 顶部选中的属性id，默认手写
      texts: {}, // 文字组合
      showAttrsTool: false, // 跟随的属性
      attrsToolStyle: {}, // 属性样式
      htmlHeight: 0,
      htmlWidth: 0,
      batchEdit: false, //批量修改标识
      batchKey: false, //是否一直按着shift
      batchItems: {}, //批量元素
      screenActive: false,
      screenIds: [], // 筛选的ID
      screenNames: [], // 筛选的Names
      tempTextStyle: {}, // 临时转写框的位置
      moveFlag: false, // 用于函数节流
      param: {
        zoom: 1,
        url: "",
        bad: false,
        result: []
      }
    };
  },

  directives: {
    focus: {
      inserted(el) {
        if (el.querySelector("textarea")) {
          el.querySelector("textarea").focus();
        }
      }
    }
  },

  methods: {
    /**
     * 查询数据
     * @param param 请求参数
     * @param isCookie 是否是缓存
     */
    query(param, isCookie) {
      let id = param.userTaskItemId;
      delete param.dataId;
      this.$api.mark
        .getMarkFile(param)
        .then(res => {
          res.userTaskItemId = id;
          if (isCookie) {
            setMarkData(id, res);
          } else {
            setMarkData(id, res);
            this.setQueryData(res);
          }
        })
        .catch(() => {});
    },

    /**
     * 请求数据后的内容处理
     * @param res 请求的数据
     */
    setQueryData(res) {
      let ocrData;
      let mcType = this.mcType;

      // 1）检查
      if (mcType == 1) {
        ocrData = res.checkedData ? res.checkedData : res.markedData;
      } else if (res.markedData && mcType == 0) {
        // 2）标注
        ocrData = res.markedData;
      } else if (!res.markedData) {
        // 3）没有标注
        ocrData = res.data;
      }
      // 数据赋值
      this.param = { ...this.param, ...res.data };

      this.param.bad = ocrData.bad ? ocrData.bad : false;
      this.param.sourcePath = res.sourcePath;
      this.param.result = ocrData.result ? ocrData.result : [];

      // 数据处理
      this.setResults();

      // 渲染图形
      this.$nextTick(() => {
        this.clearDraw();
        this.drawSvg();
      });

      // 获取数据后，才可以点击下一条，防止快速点击事件
      this.param.clicked = false;
      if (this.param.keycodetimer) {
        this.param.keycodetimer = null;
        clearTimeout(this.param.keycodetimer);
      }
    },

    /**
     * 修改属性
     */
    setResults() {
      this.param.result.forEach(item => {
        if (!item.id) {
          item.id = new Date().getTime() * Math.random();
        }
        let type = item.type ? item.type : "handwrite";
        item.logo = OcrSet.arrtsInfo[type].logo;
        item.writeable = OcrSet.arrtsInfo[type].writeable;
        item.color = OcrSet.arrtsInfo[type].color;
        item.active = false; // 选中的标记
      });
    },

    /**
     * 画布及数据清除
     */
    clearDraw() {
      // SVG移除
      if (this.draw) {
        this.draw.remove();
      }
      // 业务操作数据清空
      this.zoom = 1;
      this.draw = null;
      this.lineX = null; // 活动的X
      this.lineY = null; // 活动的Y
      this.activeItem = {};
      this.selectShape = null; // 当前选中的形状
      this.drawStatus = false; // 标识是否正在绘制
      this.currentDraw = null; // 正在绘制的图像
      this.shapeType = null; // 1多边形绘制，2矩形绘制
      this.mainImage = null;
      this.drawGroup = null; // 存放操作组
      this.groupZoom = null;
      this.texts = {};
      this.activeAttrValue = ""; // 顶部选中的属性id，默认无
      this.showAttrsTool = false; // 跟随的属性
      this.attrsToolStyle = {};
      this.batchEdit = false; //批量修改
      this.batchKey = false;
      this.batchItems = {};
      this.screenActive = false;
      this.screenIds = []; // 筛选的ID
      this.screenNames = []; // 筛选的Names
      this.canvasHeight = "100%";
      this.moveFlag = false;
    },

    /**
     * 图形的绘制
     */
    drawSvg() {
      let that = this;

      // 初始化
      that.draw = SVG("canvas").size("100%", "100%");

      // 绘制图像
      const imgUrl = `base/storage/api/fms/content?path=${
        this.param.sourcePath
      }${that.param.url}&access_token=${token}`;
      that.mainImage = that.draw.image(imgUrl).loaded(function(loader) {
        // 图片加载后，设置图片大小
        this.size(loader.width, loader.height);

        // 绘制一个图形组合
        that.drawGroup = that.draw.group();

        // 给图形组合加辅助线，只有鼠标移入地时候才显示，先绘制dom
        that.lineX = that.drawGroup.line(0, 0, 0, 0).stroke(OcrSet.imageLine);
        that.lineY = that.drawGroup.line(0, 0, 0, 0).stroke(OcrSet.imageLine);

        // 将图像也放入组合中
        that.drawGroup.add(this).attr(OcrSet.groupId);
        that.groupZoom = that.drawGroup.panZoom(OcrSet.zoomOpt);
        that.drawGroup.draggable(true);

        // 拽动图片的时候需要移动转写框
        that.drawGroup.off("dragmove").on("dragmove", function() {
          if (!that.moveFlag && this.showTemp) {
            that.moveFlag = true;
            setTimeout(() => {
              if (that.activeItem && that.activeItem.id) {
                that.moveFlag = false;
                that.setTempPos(that.activeItem.id);
              }
            }, 50);
          }
        });

        // 图片加载后，设置图片大小
        that.setInitPos(loader.width, loader.height);

        // 设置事件
        if (!this.readonly) {
          that.setEvents();
        }

        // 有图形数据则先绘制渲染数据
        let result = that.param.result;
        if (result && result.length > 0) {
          that.param.result.forEach(item => {
            if (item.region == "rect") {
              that.drawRectData(item);
            }

            if (item.region == "area") {
              that.drawPolygoData(item);
            }
          });

          that.textareaBlur();

          // 默认选中第一个
          that.setActiveById(result[0].id);
          that.$refs.areaList.scrollTo(0, 0);
          that.setLeftPos(result[0].id);
          that.$nextTick(() => {
            if (that.showTemp) {
              that.$refs.tempText.$el.querySelector("textarea").focus();
            }
          });
        }
      });
    },

    /**
     * 设置初始化的位置，保持图片填充区域，以宽度为准
     * 如果是小图则居中显示
     * 如果是大图则满屏显示
     * @param imgW 初始宽
     * @param imgH 初始高
     */
    setInitPos(imgW, imgH) {
      let canvasW = this.$refs.canvas.clientWidth,
        canvasH = this.$refs.canvas.clientHeight,
        gap = 20,
        newImgH,
        newImgW;

      // 将图片的宽度显示的跟编辑区一样
      if (imgW > canvasW) {
        newImgW = canvasW - gap;
      } else {
        let newImgW2 = canvasW * 0.7;
        newImgW = imgW > newImgW2 ? imgW : newImgW2;
      }

      newImgH = (newImgW * imgH) / imgW; // 按比例缩放

      // 缩放比例计算
      let zoom = newImgW / imgW;

      // 如果图片太矮，则居中
      let x = (canvasW - newImgW) / 2;
      let y = 0;
      if (newImgH < canvasH) {
        y = canvasH / 2 - newImgH / 2;
      }

      this.groupZoom.setPosition(x, y, zoom);
      if (newImgH > canvasH) {
        this.canvasHeight = newImgH + 10 + "px";
      } else {
        this.canvasHeight = "100%";
      }
    },

    /**
     * 赋值最新的zoom
     */
    getZoom() {
      this.param.zoom = this.groupZoom.transform.scaleX;
    },

    /**
     * 点击筛选按钮
     */
    screenClick() {
      this.screenActive = !this.screenActive;
    },

    /**
     * 点击子类型筛选
     */
    screenItemClick(item) {
      item.active = !item.active;
      this.screenNames = [];
      this.screenList.forEach(item => {
        if (item.active) {
          this.screenNames.push(item.type);
        }
      });

      // 没选则全部显示
      if (this.screenNames.length == 0) {
        if (!this.readonly && this.selectShape) {
          this.selectShape.selectize({ deepSelect: true }).resize();
        }

        this.param.result.forEach(item => {
          SVG.get(item.id).show();
          this.texts[item.id].show();
          this.$refs["areaItem" + item.id][0].classList.remove(
            "datawood-hidden"
          );
        });

        return;
      }

      this.queryResult();
    },

    /**
     * 根据结果控制图形的显示与隐藏
     */
    queryResult() {
      // 获取显示的ids
      this.screenIds = [];

      // 根据names找id;
      this.screenNames.forEach(item => {
        this.param.result.forEach(result => {
          // 显示
          if (result.type === item) {
            this.screenIds.push(result.id);
          }
        });
      });

      // 获取当前选择框的id
      if (!this.readonly && this.selectShape) {
        let selectId = this.selectShape.id();

        // 对于选中框
        if (!this.screenIds.includes(selectId)) {
          this.selectShape
            .selectize(false, { deepSelect: true })
            .resize("stop");
        } else {
          this.selectShape.selectize({ deepSelect: true }).resize();
        }
      }

      // 显示ids
      this.param.result.forEach(item => {
        let hasId = this.screenIds.includes(item.id);
        SVG.get(item.id)[hasId ? "show" : "hide"]();
        this.texts[item.id][hasId ? "show" : "hide"]();

        let $textDom = this.$refs["areaItem" + item.id];
        if ($textDom && $textDom[0]) {
          $textDom[0].classList[hasId ? "remove" : "add"]("datawood-hidden");
        }
      });
    },

    /**
     * 事件设置
     */
    setEvents() {
      let that = this;
      // 鼠标移动事件
      that.drawGroup.on("mousemove", that.mousemoveEvt, that);

      // 鼠标移出事件
      that.drawGroup.on("mouseleave", that.mouseleaveEvt, that);

      // 鼠标点下
      that.drawGroup.on("mousedown", that.mousedownEvt, that);

      // 鼠标松开
      that.drawGroup.on("mouseup", that.mouseupEvt, that);

      // 有属性不可以拖拽
      that.drawGroup.off("beforedrag").on("beforedrag", function(e) {
        if (that.showAttrsTool) {
          that.$message.error("请先选择属性");
          return;
        }
      });

      // 图片拖拽限制
      that.drawGroup.off("dragend").on("dragend", function(e) {
        // 图片的宽高及位置
        let { x, y, scaleX } = this.transform();

        let w = that.mainImage.width() * scaleX;
        let h = that.mainImage.height() * scaleX;
        let gap = 60;
        // 左限制
        if (x < 0 && Math.abs(x) > w - gap) {
          x = -(w - gap);
        }

        // 上限制
        if (y < 0 && Math.abs(y) > h - gap) {
          y = -(h - gap);
        }

        let canvasW = that.$refs.canvas.clientWidth,
          canvasH = that.$refs.canvas.clientHeight;

        // 右限制
        if (x > 0 && x > canvasW - gap) {
          x = canvasW - gap;
        }

        // 下限制
        if (y > 0 && y > canvasH - gap) {
          y = canvasH - gap;
        }

        that.groupZoom.setPosition(x, y, scaleX);
      });
    },

    /**
     * 鼠标移入事件
     */
    mousemoveEvt(e) {
      e.preventDefault();

      // 当前标注的图形，1多边形，2矩形
      let shapeType = this.shapeType;
      if (shapeType) {
        // 显示指示线
        this.drawCursor(e);
        // 多边形-画线
        if (shapeType == 1) {
          if (this.drawStatus && this.currentDraw) {
            let currentDraw = this.currentDraw; // 当前绘制的实例
            let points = currentDraw.array().value.slice(0);
            let { zx, zy } = this.getPointer(e);
            points.splice(-1, 1, [zx, zy]);
            currentDraw.plot(points);
          }
        } else {
          this.drawMoveRect(e);
        }
      }
    },

    /**
     * 绘制指示线
     */
    drawCursor(e) {
      // 重置，防止错乱
      let { x, y, scaleX } = this.drawGroup.transform();
      this.groupZoom.setPosition(x, y, scaleX);

      // 重绘
      let { zx, zy } = this.getPointer(e);
      // zx = zx + 8;
      // zy = zy + 8;
      let w = this.mainImage.width();
      let h = this.mainImage.height();

      this.lineX.front().plot(0, zy + 1, w, zy + 1);
      this.lineY.front().plot(zx + 1, 0, zx + 1, h);
    },

    /**
     * 鼠标移动时，绘制矩形
     */
    drawMoveRect(e) {
      let { x, y, type } = this.activeItem;
      let fillStyle = OcrSet.rect;
      // 如果有type，替换对应的颜色
      let attrColor = null;
      if (type) {
        attrColor = OcrSet.arrtsInfo[type].color;
      }
      if (attrColor) {
        fillStyle.color = attrColor;
      }
      if (x && y && this.drawStatus) {
        let { zx, zy } = this.getPointer(e);
        let currentDraw = this.currentDraw;

        if (!currentDraw) {
          this.currentDraw = this.drawGroup
            .rect(0, 0)
            .move(x, y)
            .fill(fillStyle)
            .stroke(OcrSet.rectStroke);
        } else {
          this.getZoom();
          let width = Math.abs(zx - x),
            height = Math.abs(zy - y),
            mx = Math.min(zx, x),
            my = Math.min(zy, y);
          this.currentDraw.size(width, height).move(mx, my);
        }
      }
    },

    /**
     *鼠标移开
     */
    mouseleaveEvt(e) {
      // 隐藏指示线
      this.resetLine();

      // 如果正在绘图状态
      // 多边形，少于2个点消失，多于2个点绘制成图
      if (this.shapeType == 1 && this.drawStatus) {
        let num = this.activeItem.pointnum;
        let isOK = this.checkDrawIsOk();
        if (num < 2 || !isOK) {
          this.currentDraw.remove();
          this.currentDraw = null;
          this.drawStatus = false;
          this.activeItem.points = [];
          this.activeItem.pointnum = 0;
        } else {
          this.drawPolygoDone(e);
        }
      }

      // 矩形，绘制成图
      if (this.shapeType == 2 && this.drawStatus) {
        this.mouseupEvt(e);
      }
    },

    /**
     * 完成多边形的绘制
     */
    drawPolygoDone(e) {
      let { zx, zy } = this.getPointer(e);
      let { points, pointnum } = this.activeItem;
      // 记录结束点数据
      this.activeItem.points.push([zx, zy]);
      this.activeItem.pointnum++;
      // 图形绘制完毕
      this.drawDone(e);
    },

    /**
     * 隐藏指示线
     */
    resetLine() {
      this.lineX.front().plot(0, 0, 0, 0);
      this.lineY.front().plot(0, 0, 0, 0);
    },

    /**
     * 鼠标点下事件
     * 绘制 shapeType 1,2
     *
     */
    mousedownEvt(e) {
      e.preventDefault();
      if (this.showAttrsTool) {
        return;
      }

      this.textareaBlur();

      // 2绘制矩形-开始绘制
      if (this.shapeType == 2) {
        if (e.button == 0) {
          if (this.param.bad) {
            this.$message.error("坏数据不可标记");
            return;
          }
          if (!this.drawStatus) {
            this.shapeClick(2);
          }
          let { zx, zy } = this.getPointer(e);
          this.drawStatus = true;
          this.activeItem.x = zx;
          this.activeItem.y = zy;
        }
      }

      // 1绘制多边形
      if (this.shapeType == 1) {
        if (e.button == 0) {
          if (this.param.bad) {
            this.$message.error("坏数据不可标记");
            return;
          }

          if (!this.drawStatus) {
            this.shapeClick(1);
          }

          let { zx, zy } = this.getPointer(e);
          this.drawStatus = true;
          this.activeItem.pointnum++;
          this.activeItem.points.push([zx, zy]);

          // 左键,绘制
          this.drawPolygo(e);
        }

        // 结束绘制-右键,结束绘制
        if (e.button == 2) {
          this.mouseleaveEvt(e);
        }
      }
    },

    /**
     * 绘制多边形-过程
     */
    drawPolygo(e) {
      // 获取当前已绘制的点信息
      let { pointnum, points, id, type } = this.activeItem;

      let fillStyle = OcrSet.polygo;
      // 如果有type，替换对应的颜色
      let attrColor = null;
      if (type) {
        attrColor = OcrSet.arrtsInfo[type].color;
      }
      if (attrColor) {
        fillStyle.color = attrColor;
      }

      if (pointnum > 0 && this.drawStatus) {
        let { zx, zy } = this.getPointer(e);
        let currentDraw = this.currentDraw;
        if (!currentDraw) {
          points.push([zx, zy]);
          this.currentDraw = this.drawGroup
            .polygon(points)
            .fill(fillStyle)
            .stroke(OcrSet.rectStroke)
            .attr({ id: id });
        } else {
          points = this.currentDraw.array().value.slice(0);
          points.push([zx, zy]);
          this.currentDraw.plot(points);
        }
      }
    },

    /**
     * 鼠标松开事件
     */
    mouseupEvt(e) {
      e.preventDefault();
      // 矩形绘制完毕
      if (this.shapeType == 2 && this.drawStatus) {
        // 记录结束点
        let { zx, zy } = this.getPointer(e);
        let { x, y } = this.activeItem;
        this.activeItem.x = Math.min(zx, x);
        this.activeItem.y = Math.min(zy, y);
        this.activeItem.w = Math.abs(zx - x);
        this.activeItem.h = Math.abs(zy - y);
        let isOK = this.checkDrawIsOk();
        this.resetLine();
        if (isOK) {
          this.drawDone(e);
        } else {
          this.drawStatus = false;
          if (this.currentDraw) {
            this.currentDraw.draggable(false);
            this.currentDraw
              .selectize(false, { deepSelect: true })
              .resize("stop");
            this.currentDraw.remove();
          }
          this.currentDraw = null;
        }
      }
    },

    /**
     * 校验绘制的矩形是否符合标准，必须大于20*20
     */
    checkDrawIsOk() {
      if (this.currentDraw) {
        let w = this.currentDraw.width();
        let h = this.currentDraw.height();
        let rW = this.mainImage.width() / 100;
        let rH = this.mainImage.height() / 100;
        if (h > rH && w > rW) {
          return true;
        } else {
          this.$message.error("绘制区域太小");
          return false;
        }
      } else {
        return false;
      }
    },

    /**
     * 绘制图形完成后的操作
     */
    drawDone(e) {
      let { id, type, region } = this.activeItem;
      let currentDraw = this.currentDraw;

      if (currentDraw) {
        // id赋值
        currentDraw.attr({ id: id });

        // 将logo写入框框
        let logo = type ? OcrSet.arrtsInfo[type].logo : "null";
        this.texts[id] = this.drawGroup.text(logo);

        // 右上角的logo位置
        this.changeTextsPos({
          id: id,
          region: region,
          x: currentDraw.x(),
          y: currentDraw.y(),
          w: currentDraw.width(),
          cx: currentDraw.cx(),
          cy: currentDraw.cy()
        });

        // 不显示属性
        if (!this.showAttr) {
          this.texts[id].addClass("datawood-hidden");
        }
      }

      let item = { ...this.activeItem };
      let hasShape = this.changeSelectShape(item.id);
      if (hasShape) {
        // 去除当前绘制
        this.drawStatus = false;
        this.currentDraw = null;

        // 是否是可转写数据
        if (item.type) {
          let typeInfo = OcrSet.arrtsInfo[item.type];
          item.writeable = typeInfo.writeable;
          item.logo = typeInfo.logo;
          item.active = true;
          // 更新当前数据
          this.param.result.push(item);
          this.drawGroup.draggable(true);
        } else {
          // 显示必选的属性跟随栏目
          this.showAttrsTool = true;

          // 这是临时框的位置，属性框要在该基础上进一步操作
          let { tempX, tempY, tempW, tempH } = this.setLeftPos(item.id, true);
          // 去除滚动条的位置，因为是相对于视口的
          let pt = this.$refs.drawArea.scrollTop;
          tempY = tempY - pt;

          let maxTop = this.htmlHeight - 350;
          let top = tempY + 80 - tempH / 2;

          this.attrsToolStyle = {
            top: (top > maxTop ? maxTop : top) + "px",
            left: tempX + tempW + 20 + "px"
          };

          // 禁止拖拽
          this.drawGroup.draggable(false);

          // 禁止放大
          this.groupZoom.disableZoom();
        }

        this.activeItem = item;
      }

      this.shapeType = null;
      this.rightGoToBottom();
      // 将当前图形设置为选中
      this.$nextTick(() => {
        if (this.showTemp) {
          this.setTempPos(item.id);
          this.$refs.tempText.$el.querySelector("textarea").focus();
        }
      });
    },

    /**
     * 根据id选中
     * @param boolean true表示focus false表示不focus
     */
    setActiveById(id, boolean) {
      // 图形选中
      let hasShape = this.changeSelectShape(id);

      // 转写选中
      if (hasShape) {
        // 去除当前绘制状态
        this.drawStatus = false;
        this.currentDraw = null;

        // 选中
        this.param.result.forEach(item => {
          item.active = false;
          if (item.id == id) {
            item.active = true;
            this.activeItem = { ...item };
          }
        });

        // focus
        if (boolean) {
          this.$nextTick(() => {
            let $areaItem = this.$refs["areaItem" + id];
            if (
              $areaItem &&
              $areaItem[0] &&
              $areaItem[0].querySelector("textarea")
            ) {
              $areaItem[0].querySelector("textarea").focus();
            }
          });
        }
      }
    },

    /**
     * 获取当前点的信息
     */
    getPointer(e) {
      let scrollTop = this.$refs.drawArea.scrollTop,
        x = e.layerX || e.offsetX,
        y = (e.layerY || e.offsetY) + scrollTop,
        t = this.groupZoom.transform,
        rx = x - t.x,
        ry = y - t.y;

      this.getZoom();
      let zx = rx / this.param.zoom;
      let zy = ry / this.param.zoom;
      return {
        zx: zx, // 绝对位置
        zy: zy
      };
    },

    /**
     * 渲染已知数据的矩形
     */
    drawRectData(rectdata) {
      let { x, y, w, h, id, color, logo } = rectdata;
      // 绘制颜色
      let fillStyle = OcrSet.rect;
      fillStyle.color = color;
      let rect = this.drawGroup
        .rect(w, h)
        .move(x, y)
        .fill(fillStyle)
        .stroke(OcrSet.rectStroke)
        .attr({ id: id });

      // 将logo写入框框
      this.texts[id] = this.drawGroup.text(logo);
      this.changeTextsPos({
        id: id,
        region: "rect",
        x: rect.x(),
        y: rect.y(),
        w: rect.width()
      });

      if (!this.showAttr) {
        this.texts[id].addClass("datawood-hidden");
      }

      this.shapeBindEvent(rect);
    },

    /**
     * 绘制已知数据的多边形
     */
    drawPolygoData(data) {
      let { pointnum, points, id, color, logo } = data;
      // 对points进行转换
      let newPoints = points.split(";");
      newPoints.pop();
      points = [];
      newPoints.forEach((item, index) => {
        let items = item.split(",");
        items[0] = Number(items[0].substring(1));
        items[1] = Number(items[1].substring(0, items[1].indexOf(")")));
        points[index] = items;
      });

      // 颜色设置
      let fillStyle = OcrSet.polygo;
      fillStyle.color = color;
      let polygo = this.drawGroup
        .polygon(points)
        .fill(fillStyle)
        .stroke(OcrSet.rectStroke)
        .attr({ id: id });

      // 画logo
      this.texts[id] = this.drawGroup.text(logo);
      let textX = polygo.cx();
      let textY = polygo.cy();
      this.changeTextsPos({
        id: id,
        region: "area",
        cx: textX,
        cy: textY
      });

      // 如果不显示属性，则隐藏
      if (!this.showAttr) {
        this.texts[id].addClass("datawood-hidden");
      }
      this.shapeBindEvent(polygo);
    },

    /**
     * 对图形的事件绑定
     */
    shapeBindEvent(svgItem) {
      let that = this;

      if (!this.readonly) {
        // 大小随时改变
        svgItem.off("resizing").on("resizing", function() {
          that.changeSelectShapePos(this);
          if (that.showTemp) {
            that.setTempPos(this.id());
          }
        });

        // 大小改变,更新activeItem
        svgItem.off("resizedone").on("resizedone", function() {
          that.changeSelectShapePos(this);
          if (that.showTemp) {
            that.setTempPos(this.id());
          }
        });

        // 拖拽后的时候更新activeItem
        svgItem.off("dragmove").on("dragmove", function() {
          that.changeSelectShapePos(this);
          if (that.showTemp) {
            that.setTempPos(this.id());
          }
        });

        // 拖拽后,更新activeItem
        svgItem.off("dragend").on("dragend", function() {
          that.changeSelectShapePos(this);
          if (that.showTemp) {
            that.setTempPos(this.id());
          }
        });
      }

      // 点击事件
      svgItem.off("click").on("click", function(e) {
        e.stopPropagation();
        e.preventDefault();

        // 正在绘制和拖拽的时候不管用
        if (that.shapeType) {
          return;
        }

        let selectId = this.id();

        // 非批量选择情况下
        if (!that.batchKey && selectId === that.activeItem.id) {
          return;
        }

        // 更新当前的activeItem
        let selectItem = that.param.result.find(item => {
          if (item.id === selectId) {
            return item;
          }
        });

        that.areaItemClick(selectItem, true);
        that.setRightPos(selectId);
        if (that.showTemp) {
          that.setTempPos(selectId);
        }

        that.$nextTick(() => {
          if (that.showTemp) {
            that.$refs.tempText.$el.querySelector("textarea").focus();
          }
        });
      });
    },

    /**
     * 对选中的图形进行操作--左边
     */
    changeSelectShape(id) {
      if (this.showAttrsTool) {
        return;
      }

      let that = this;
      if (!id) {
        return false;
      }

      // 非批量下
      if (!this.batchKey) {
        // 销毁上一个
        if (this.selectShape) {
          this.selectShape.removeClass("svg-highlight");
          this.selectShape.draggable(false);
          // 取消选中
          this.selectShape
            .selectize(false, { deepSelect: true })
            .resize("stop");
        }

        // 激活当前选中
        this.selectShape = SVG.get(id).addClass("svg-highlight");
        if (!this.selectShape) {
          return false;
        }

        if (!this.readonly) {
          let that = this;
          // 当前图形可操作
          this.selectShape.selectize(OcrSet.lawSelectOpt).resize();
          this.shapeBindEvent(this.selectShape);
        }

        // 可拖拽点的设置
        this.$nextTick(() => {
          let points = SVG.select(".svg_select_points").members;
          let width = this.mainImage.width();

          if (width < 1000 || width > 2000) {
            points.forEach(item => {
              if (item.type == "circle") {
                item.addClass(
                  width > 2000 ? "svg-circle-big" : "svg-circle-small"
                );
              }
            });
          }
        });

        return true;
      } else {
        // 批量下样式改变
        let $svgDom = SVG.get(id);
        let hasHighlight = $svgDom.hasClass("svg-highlight");
        SVG.get(id)[hasHighlight ? "removeClass" : "addClass"]("svg-highlight");
      }
    },

    /**
     * 改变当前选中图形的位置和大小，更新数据
     */
    changeSelectShapePos(obj) {
      if (this.showAttrsTool) {
        this.$message.error("请先选择属性");
        return;
      }
      let { region, id } = this.activeItem;

      // 矩形
      if (region == "rect") {
        this.activeItem.x = obj.x();
        this.activeItem.y = obj.y();
        this.activeItem.w = obj.width();
        this.activeItem.h = obj.height();
      }
      // 多边形
      if (region == "area") {
        this.activeItem.points = obj.array().value.slice(0);
        this.activeItem.pointnum = this.activeItem.points.length;
      }

      // 修改当前item的texts
      this.changeTextsPos({
        id: id,
        region: region,
        x: obj.x(),
        y: obj.y(),
        w: obj.width(),
        cx: obj.cx(),
        cy: obj.cy()
      });

      // 同步数据值到result
      this.updateResult();
    },

    /**
     * 通过id更改text的位置
     * @param param 绘制说需要的参数
     */
    changeTextsPos(param) {
      let { region, id, x, y, cx, cy, w } = param;

      // 图片的大小不同的时候，字体大小也不同，暂时这么处理
      let mainWidth = this.mainImage.width();
      let size = 16,
        space = 10;

      if (mainWidth > 2000) {
        size = 24;
        space = 12;
      }

      if (mainWidth < 1000) {
        size = 10;
        space = 4;
      }
      this.texts[id].font({
        size: size
      });

      // 矩形
      if (region == "rect") {
        // 右上角的text位置跟随
        this.texts[id].cy(y + space);
        this.texts[id].cx(x + w - space);
      }
      // 多边形
      if (region == "area") {
        this.texts[id].cy(cy);
        this.texts[id].cx(cx);
      }
    },

    /**
     * 将最新的的数据写入到result中
     * @param item 如果item有值则写入，没有则取activeItem
     */
    updateResult(item) {
      let activeItem = item ? item : { ...this.activeItem };
      this.param.result.find((item, index) => {
        if (item.id === activeItem.id) {
          let newItem = Object.assign({}, item, activeItem);
          this.param.result.splice(index, 1, newItem);
        }
      });
    },

    /**
     * 更新当前的选中形状的样子
     * @param item 传入了item，否则就是activeItem
     */
    updateSelectShape(item) {
      let activeItem = item ? item : this.activeItem;
      let { id, logo, color, region } = activeItem;

      // 更改文字
      this.texts[id].text(logo);

      // 更改颜色
      let fillStyle = region == "rect" ? OcrSet.rect : OcrSet.polygo;
      fillStyle.color = color;
      let selectShape = item ? SVG.get(id) : this.selectShape;
      selectShape.fill(fillStyle);
    },

    /**
     * 点击形状
     * @param type 1，多边形，2，矩形
     */
    shapeClick(type) {
      if (this.readonly) {
        return;
      }

      // 创建一个新的item
      let newItem = this.createItem(type);
      this.activeItem = newItem;

      // 当前绘制图形标识
      this.shapeType = type;

      // 当前激活组件赋值
      this.changeSelectShape();
    },

    /**
     * 创建形状数据
     * @param type 1 多边形，2 矩形
     */
    createItem(type) {
      let obj = {
        id: new Date().getTime(),
        region: type == 1 ? "area" : "rect", // rect/area
        text: "", // 内容
        type: "" // 物理属性
      };

      // 物理属性的继承
      if (this.inheritAttr && this.activeAttrValue) {
        obj.type = this.activeAttrValue;
      }

      // 额外的参数
      if (type == 1) {
        obj.points = [];
        obj.pointnum = 0;
      } else {
        obj.w = "";
        obj.h = "";
        obj.x = "";
        obj.y = "";
      }

      return { ...obj };
    },

    /**
     * 区域内容点击
     * @param item 点击的item
     * @param boolean 是否手动触焦
     */
    areaItemClick(item, boolean) {
      if (this.showAttrsTool) {
        this.textareaBlur();
        return;
      }

      // 去除所有的focus;
      this.textareaBlur();

      // 批量操作中
      if (this.batchKey) {
        // 有则去除，无则加载
        if (this.batchItems[item.id]) {
          item.active = false;
          delete this.batchItems[item.id];
        } else {
          item.active = true; // 右边样式选中
          this.batchItems[item.id] = item; // 放置批量数据中
        }

        // 图形选择
        this.changeSelectShape(item.id);
      } else {
        // 当前处理数据
        this.activeItem = item;

        // 手动触焦
        if (boolean) {
          this.cancelBatchSattus();
        }

        this.setActiveById(item.id, boolean);

        let { id } = this.activeItem;

        // 当前处理SVG选中
        this.changeSelectShape(id);

        // 位置改变
        this.setLeftPos(id);
      }
    },

    /**
     * 判断图片和textarea的位置
     * 不能改变图片的大小，直接选取
     * 如果不在视图范围内，则移动位置
     * @param id 当前的图形id
     * @param istemp 是不是仅仅为了获取临时框的位置
     * @return 临时框的位置
     */
    setLeftPos(id, istemp) {
      // 当前的位置获取
      let { x, y, scaleX } = this.drawGroup.transform();

      // 选取的框框
      let activeShape = SVG.get(id);

      // 选取框的信息，相对于图片的是不变的
      let sx = activeShape.x() * scaleX;
      let sy = activeShape.y() * scaleX;
      let sw = activeShape.width() * scaleX;
      let sh = activeShape.height() * scaleX;

      // 如果有转写框，需要把转写框显示出来
      if (!istemp && this.showTemp) {
        sh = sh + 90;
      }

      // 图片的位置
      let px = x;
      let py = y;
      let pInfo = this.drawGroup.node.getBoundingClientRect();
      let pw = pInfo.width;
      let ph = pInfo.height;
      // 滚动条的位置
      let pt = this.$refs.drawArea.scrollTop;
      py = y - pt;

      // 视图的宽高
      let cw = this.$refs.drawArea.clientWidth;
      let ch = this.$refs.drawArea.clientHeight;

      // 记录临时框应该显示的位置
      let tempX = px + sx;
      let tempY = Math.abs(py) + sy + sh;

      // 脱离视线判断
      let x2 = x;
      let y2 = y;
      // 1-1、超出右边：图片向左边移动pos像素
      if (px >= 0 && px + sx + sw > cw) {
        let rpos1 = px + sx + sw - cw;
        x2 = x2 - rpos1;
      }
      // 1-2、图片放大超出左右边界
      if (px < 0) {
        let rpos2 = sx - Math.abs(px) + sw - cw;
        if (rpos2 > 0) {
          x2 = x2 - rpos2;
        }
        tempX = sx - Math.abs(px);
      }
      // 2、超出左边：图片向右移动pos
      if (px < 0) {
        let lpos = Math.abs(px) - sx;
        if (lpos > 0) {
          x2 = x2 + lpos;
        }
      }
      // 3、超出上边，图片向下移动
      if (py < 0) {
        tempY = sy - Math.abs(py) + sh;
        let tpos = Math.abs(py) - sy;
        if (tpos > 0) {
          y2 = y2 + tpos;
          tempY = sh - tpos;
        }
      }

      // 4-1、超出下边py>=0向上移动
      if (py >= 0 && py + sy + sh > ch) {
        let bpos1 = py + sy + sh - ch;
        y2 = y2 - bpos1;
      }
      // 4-2、超出下边py<0 向上移动
      if (py < 0) {
        let bpos2 = sy - Math.abs(py) + sh - ch;
        if (bpos2 > 0) {
          y2 = y2 - bpos2;
        }
      }

      // 更改图形的位置
      if (!istemp) {
        this.groupZoom.setPosition(x2, y2, scaleX);
        this.$nextTick(() => {
          // 位置改变了，临时框的位置也要改
          this.setTempPos(id);
        });
      } else {
        return {
          tempX: tempX,
          tempY: tempY + pt,
          tempW: sw,
          tempH: sh
        };
      }
    },

    /**
     * 设置右边的位置
     */
    setRightPos(id) {
      let domInfo = this.$refs["areaItem" + id][0].getBoundingClientRect();
      let { height, top } = domInfo;
      let $list = this.$refs.areaList;
      let listH = $list.clientHeight;
      if (top < 100) {
        $list.scrollTo(0, 0);
      }

      if (top > listH) {
        let scrollTop = $list.scrollTop;
        $list.scrollTo(0, top - listH + scrollTop);
      }
    },

    /**
     * 设置临时框的位置
     */
    setTempPos(id) {
      if (this.readonly || this.drawStatus) {
        return;
      }
      id = id ? id : this.activeItem.id;
      if (!id) {
        return;
      }
      let { tempX, tempY, tempW } = this.setLeftPos(id, true);
      this.tempTextStyle = {
        left: tempX + "px",
        top: tempY + 5 + "px"
      };
    },

    /**
     * 修改转写框
     */
    changeTempText(value) {
      this.activeItem.text = value;
      this.updateResult();
    },

    /**
     * 同步触发转写框的至
     */
    changeAreaText(value, id) {
      if (this.activeItem.id == id) {
        this.activeItem.text = value;
        this.updateResult();
      }
    },

    /**
     * 右边滚动到最下面，一般新增的时候触发
     */
    rightGoToBottom() {
      this.$nextTick(() => {
        let $list = this.$refs.areaList;
        let t = $list.childElementCount * 50;
        $list.scrollTo(0, t);
      });
    },

    /**
     * 所有的textarea失去焦点
     */
    textareaBlur() {
      if (this.$refs.areaList) {
        let textareas = this.$refs.areaList.querySelectorAll("textarea");
        if (textareas.length > 0) {
          for (var i = 0; i < textareas.length; i++) {
            textareas[i].blur();
          }
        }
      }
    },

    /**
     * 区域内容失去焦点
     */
    cancelSelected() {
      if (this.selectShape) {
        this.selectShape.removeClass("svg-highlight");
        this.selectShape.selectize(false, { deepSelect: true }).resize("stop");
        this.activeItem = {};
        this.selectShape = null;
      }

      // 去除所有的focus;
      this.textareaBlur();
    },

    /**
     * 取消复选状态
     */
    cancelBatchSattus() {
      // 右边
      this.param.result.forEach(item => {
        item.active = false;
      });

      // 左边
      for (var id in this.batchItems) {
        SVG.get(id).removeClass("svg-highlight");
      }

      // 状态
      this.batchEdit = false;
      this.batchItems = {};
    },

    /**
     * 不可点击区域点击
     */
    unWriteClick(item) {
      if (this.showAttrsTool) {
        return;
      }
      if (this.activeItem && item.id === this.activeItem.id) {
        // this.cancelSelected();
      } else {
        this.areaItemClick(item);
      }
    },

    /**
     * 加入错误字样
     */
    errorClick(e, item) {
      if (this.showAttrsTool) {
        this.$message.error("请先选择属性");
        return;
      }

      if (item) {
        item.text = item.text + "{{ERR}}";
        e.currentTarget.parentElement.querySelector("textarea").focus();
      } else {
        this.activeItem.text = this.activeItem.text + "{{ERR}}";
        this.updateResult();
      }
    },

    /**
     * 点击头部属性
     * 选择属性
     * 更改属性
     */
    attrClick(item) {
      if (this.showAttrsTool) {
        this.$message.error("请先选择属性");
        return;
      }

      // 复选改变
      if (this.batchEdit) {
        // 批量改变属性
        let { type, logo, color, writeable } = item;
        for (var i in this.batchItems) {
          // 文本修改
          let currentItem = this.batchItems[i];
          currentItem.type = type;
          currentItem.logo = logo;
          currentItem.color = color;
          currentItem.writeable = writeable;

          // 更新到数据中
          this.updateResult(currentItem);
          // 更新到图片中
          this.updateSelectShape(currentItem);
        }

        this.$nextTick(() => {
          this.textareaBlur();
        });
      } else {
        this.inheritAttr = true;
        this.attrToolClick(item);
      }
    },

    /**
     * 跟随属性点击
     * @param boolean 是不是点击跟随属性
     */
    attrToolClick(item, boolean) {
      let { type, logo, color, writeable } = item;

      // 头部属性值更改
      this.activeAttrValue = item.type;

      // 如果有当前激活
      if (this.activeItem && this.activeItem.id) {
        this.activeItem.type = type;
        this.activeItem.logo = logo;
        this.activeItem.color = color;
        this.activeItem.writeable = writeable;
        this.activeItem.active = true;

        // 更改数据
        this.updateResult();

        // 激活右侧
        this.setActiveById(this.activeItem.id, true);

        // 更新形状
        this.updateSelectShape();

        // 加入数据中
        if (boolean) {
          this.param.result.push({ ...this.activeItem });
        }

        // 边属性工具栏消失
        this.showAttrsTool = false;
        this.inheritAttr = true;

        // 允许拖拽和滚动了
        this.drawGroup.draggable(true);
        this.groupZoom.enableZoom();

        this.$nextTick(() => {
          if (this.showTemp) {
            this.$refs.tempText.$el.querySelector("textarea").focus();
          }
        });
      }
    },

    /**
     * 改变属性继承
     */
    inheritAttrChange() {
      if (this.inheritAttr) {
        this.activeAttrValue = this.activeAttrValue
          ? this.activeAttrValue
          : "handwrite";
      } else {
        this.activeAttrValue = "";
      }
    },

    /**
     * 显示属性切换
     */
    showAtrrChange() {
      for (var i in this.texts) {
        this.texts[i][this.showAttr ? "removeClass" : "addClass"](
          "datawood-hidden"
        );
      }
    },

    /**
     * 是否显示临时转写框
     */
    showTempChange(value) {
      if (value) {
        this.setTempPos();
      }
    },

    /**
     * 校验
     */
    valid() {
      if (this.showAttrsTool) {
        this.param.valid = false;
        this.param.validMsg = "请先添加属性";
        return;
      }
      if (this.param.bad) {
        return true;
      } else {
        // 必须有一个
        let results = this.param.result;
        if (results.length == 0) {
          this.param.valid = false;
          this.param.validMsg = "至少需要一个标记属性的绘图框";
          return;
        } else {
          // 必须都有转写
          let isAllMark = true;
          results.find(item => {
            if (item.writeable && !item.text) {
              isAllMark = false;
            }
          });

          if (!isAllMark) {
            this.param.valid = false;
            this.param.validMsg = "存在没有转写的绘图框";
            return;
          }
        }
      }
    },

    /**
     * 保存数据,只保存需要保存的数据
     */
    save() {
      // 将points转换成格式 "(122,141);(121,161);(917,170);(917,147);"
      let results = [...this.param.result];
      results.forEach((item, index) => {
        let points = item.points;
        if (points instanceof Array) {
          //标注的时候
          if (points && points.length > 0) {
            // 防止第一个点信息重复
            let p = [...item.points];
            if (
              p[0].toString() == p[1].toString() &&
              p.length == item.pointnum + 1
            ) {
              p.splice(0, 1);
            }

            let newPoints = "";
            p.forEach(unit => {
              newPoints += "(" + unit.toString() + ");";
            });
            item.points = newPoints;
          }
        }
        // 不可转写的text为空
        if (!item.writeable) {
          item.text = "";
        }

        // 删除无用的参数
        delete item.writeable;
        delete item.logo;
        delete item.color;
        delete item.active;
      });

      this.param.commitData = {
        result: results,
        bad: this.param.bad
      };
    },

    /**
     * 标为好数据
     */
    availableClick() {
      if (this.readonly || (this.mcType == 1 && !this.param.bad)) {
        return;
      }
      let nowStatus = this.param.bad;
      if (!nowStatus) {
        if (this.param.result.length > 0) {
          this.$confirm(
            "标记为坏数据后，已标注内容将会被清除，确认标记吗？",
            "",
            {
              lockScroll: false
            }
          )
            .then(() => {
              this.param.bad = true;
              this.param.result = [];
              this.clearDraw();
              this.drawSvg();
            })
            .catch(() => {});
        } else {
          this.param.bad = true;
        }
      } else {
        this.param.bad = false;
      }
    },

    /**
     * 根据浏览器的高度赋值高度，保证在可视范围内进行操作
     */
    getHeight() {
      let $body = document.documentElement
        ? document.documentElement
        : document.body;
      let bodyH = $body.clientHeight;
      let bodyW = $body.clientWidth;
      this.drawHeight = bodyH - 172 + "px";
      this.htmlHeight = bodyH;
      this.htmlWidth = bodyW;
    },

    /**
     * 上38下40键切换位置
     */
    jumpRightPos(keyCode) {
      let { id } = this.activeItem;
      let currentDom = this.$refs["areaItem" + id][0];
      this.textareaBlur();

      if (currentDom) {
        let newDom =
          keyCode == 40
            ? currentDom.nextElementSibling
            : currentDom.previousElementSibling;
        let activeId;

        // 如果有
        if (newDom) {
          activeId = newDom.id;
        } else {
          // 选择第一个40
          // 选择最后一个38
          let children = this.$refs.areaList.children;
          let length = children.length;

          if (keyCode == 40) {
            newDom = children[0];
          } else {
            newDom = children[length - 1];
          }

          activeId = newDom.id;
        }

        // 根据id选择
        this.setActiveById(activeId, false);
        this.setLeftPos(activeId);
        this.setRightPos(activeId);

        // 如果有隐藏，自动选择下一个
        if (newDom && [...newDom.classList].includes("datawood-hidden")) {
          this.jumpRightPos(keyCode);
        }
      }
    },

    /**
     * 设置快捷键--鼠标松开
     */
    setKeyUp(e) {
      let that = this;
      const keyCode = e.keyCode || e.which;

      // 下键40 上键38
      if ((keyCode == 40 || keyCode == 38) && this.activeItem) {
        e.preventDefault();
        this.jumpRightPos(keyCode);
      }

      if (this.readonly) {
        return;
      }

      // 绘制矩形ctrl
      if (keyCode == 17) {
        if (this.param.bad) {
          this.$message.error("坏数据不可标记");
          return;
        }
        if (this.showAttrsTool) {
          this.$message.error("请先选择属性");
          return;
        }
        // 取消复选状态
        this.cancelBatchSattus();

        if (this.shapeType == 2) {
          this.resetLine();
          this.shapeType = null;
          this.drawGroup.draggable(true);
        } else {
          this.shapeType = 2;
          this.drawGroup.draggable(false);
        }
      }

      // 取消绘制多边形alt
      if (keyCode == 18) {
        if (this.param.bad) {
          this.$message.error("坏数据不可标记");
          return;
        }
        if (this.showAttrsTool) {
          this.$message.error("请先选择属性");
          return;
        }

        // 取消复选状态
        this.cancelBatchSattus();

        if (this.shapeType == 1) {
          this.resetLine();
          this.shapeType = null;
        } else {
          this.shapeType = 1;
        }
      }

      // 取消激活状态
      if ((keyCode == 17 || keyCode == 18) && this.selectShape) {
        this.cancelSelected();
      }

      // 如果在文本框中则不可以使用快捷键
      var type = e.srcElement ? e.srcElement.type : e.target.type; // 看当前所处环境
      if (type === "text" || type === "textarea") {
        return;
      }

      // shift松开且没有点击
      if (keyCode == 16) {
        this.textareaBlur();

        // 标识没有在按shift键
        this.batchKey = false;

        // 标识当前是复选状态
        if (Object.keys(this.batchItems).length == 0) {
          this.batchEdit = false;
        }
      }

      // F键松开
      if (keyCode == 70 && this.selectShape) {
        this.selectShape.removeClass("select-shape-move");
        this.selectShape.draggable(false);
        this.drawGroup.draggable(true);
      }

      // 删除DEL
      if (keyCode == 68) {
        if (this.readonly) {
          return;
        }
        if (this.selectShape) {
          this.$confirm("是否删除当前选中的图形？", "", {
            lockScroll: false
          })
            .then(() => {
              this.param.result.find((item, index) => {
                if (item.id === this.activeItem.id) {
                  this.param.result.splice(index, 1);
                  this.activeItem = {};
                  this.selectShape
                    .selectize(false, { deepSelect: true })
                    .resize("stop");
                  this.selectShape.remove();
                  this.selectShape = null;

                  // 删除logo
                  this.texts[item.id].remove();
                  delete this.texts[item.id];
                }
              });
            })
            .catch(() => {});
        }
      }
    },

    /**
     * 设置快捷键--鼠标点击
     */
    setKeyDown(e) {
      const keyCode = e.keyCode || e.which;

      if (keyCode == 16 || keyCode == 38 || keyCode == 40 || keyCode == 112) {
        e.preventDefault();
      }

      // 如果在文本框中则不可以使用快捷键
      var type = e.srcElement ? e.srcElement.type : e.target.type; // 看当前所处环境
      if (type === "text" || type === "textarea") {
        // F1
        if (keyCode == 112) {
          this.errorClick();
        }
        return;
      }

      // shift批量修改
      if (keyCode == 16) {
        // 取消选中
        if (this.selectShape) {
          this.cancelSelected();
        }

        if (this.readonly) {
          return;
        }

        // 去除绘制
        this.resetLine();
        this.shapeType = null;

        // 可以批量标注
        this.batchEdit = true;

        // 按了shift
        this.batchKey = true;
      }

      // F键有选中，可拖拽
      if (keyCode == 70 && this.selectShape) {
        if (this.readonly) {
          return;
        }
        this.selectShape.addClass("select-shape-move");
        this.selectShape.draggable(true);
        this.drawGroup.draggable(false);
      }
    }
  },

  created() {
    let task = JSON.parse(window.sessionStorage.getItem("task"));
    // 1检查,0标注
    this.mcType = task.type;
    this.readonly = task.readonly;
    this.task = task;
  },

  mounted() {
    document.addEventListener("keyup", this.setKeyUp);
    document.addEventListener("keydown", this.setKeyDown);
    document.getElementsByTagName("html")[0].scrollTo(0, 100);

    // 区域高度
    this.getHeight();
    window.onresize = () => {
      this.getHeight();
    };

    // 右击取消
    window.oncontextmenu = function(e) {
      e.preventDefault();
    };

    //将方法绑定到window对象上，便于插件调用
    window["lawOcrSetTempData"] = () => {
      if (this.showTemp) {
        this.setTempPos();
      }
    };
  },

  // 路由离开前
  beforeRouteLeave(to, from, next) {
    document.removeEventListener("keydown", this.setKeyDown);
    document.removeEventListener("keyup", this.setKeyUp);
    next();
  },

  // 组件销毁
  destroyed() {
    window.lawOcrSetTempData = null;
  }
};
</script>

<style lang="less" scoped>
.lawocr-mark {
  .ocr-attrs {
    display: inline-block;
    span {
      position: relative;
      padding: 4px 6px;
      border-radius: 4px;
      font-size: 12px;
      margin: 0 6px;
      border: transparent 1px solid;
      cursor: pointer;
      &:hover {
        &::after {
          position: absolute;
          left: 0;
          top: 0;
          width: 100%;
          height: 100%;
          display: inline-block;
          content: "";
          background: #fff;
          opacity: 0.2;
        }
      }
      &.active {
        border: red 1px solid;
      }
    }
  }
  .ocr-answer {
    overflow: hidden;
    height: 434px;
    box-sizing: border-box;
    margin: -10px;
  }
  .draw-area,
  .draw-tools {
    position: relative;
    float: left;
    width: 80%;
    overflow: hidden;
    box-sizing: border-box;
    .help-tool {
      position: absolute;
      right: 0;
      top: 0;
      border-left: 1px solid #ececec;
      li {
        padding: 10px 0;
        border-bottom: 1px solid #ececec;
        background: #fff;
        width: 38px;
        font-size: 12px;
        cursor: pointer;
        text-align: center;
        .iconfont {
          margin-right: 0px;
          font-size: 16px;
        }
        span {
          display: block;
          margin-top: 5px;
        }

        &.active {
          background-color: #e0fdee;
        }
      }
    }
    .error-span {
      position: relative;
      top: 3px;
    }
  }
  .draw-tools {
    height: 100%;
    border-left: 1px solid #e8e8e8;
    width: 20%;
    box-sizing: border-box;
    .tools {
      overflow: hidden;
      dl {
        float: left;
        width: 24%;
        text-align: center;
        margin: 10px 13% 10px 13%;
        padding: 2px;
        box-sizing: border-box;
        cursor: pointer;
        dt {
          font-size: 30px;
          text-align: center;
        }
        &:last-child {
          position: relative;
          top: 3px;
          dd {
            margin-left: -8px;
          }
        }
        &.active {
          border-radius: 4px;
          background-color: #e8e8e8;
        }
      }
      .iconfont {
        color: #f9b9c4;
      }
      .icon-rect {
        font-size: 27px;
        color: #71f5ea;
      }
    }
    .tool-title {
      padding: 0 10px;
      text-align: left;
      font-weight: bold;
      background: #f5f5f5;
      line-height: 32px;
      clear: both;
    }
    .area {
      height: 100%;
      .area-list {
        height: 100%;
        overflow-y: auto;
        li {
          position: relative;
          margin-bottom: 4px;
          button {
            margin-top: 4px;
          }
          .un-write {
            width: 100%;
            background: #eef0f2;
            height: 40px;
            display: block;
            line-height: 40px;
            text-align: center;
            border: #e2e2e2 1px solid;
            margin: 5px 0;
            box-sizing: border-box;
            cursor: pointer;
            &.active {
              border: #b3d5f8 1px solid;
            }
            &.red-active {
              border: red 1px solid;
            }
          }
          .logo {
            position: absolute;
            right: 2px;
            top: 2px;
          }
        }
        .el-input {
          width: 80%;
        }
      }
    }

    .tags-attrs {
      padding: 0 10px;
      line-height: 30px;
      color: #999;
    }
    .tags-list {
      height: 90px;
      overflow-y: auto;
      li {
        display: inline-block;
        border-radius: 2px;
        border: 1px solid #eee;
        width: 29%;
        height: 30px;
        line-height: 30px;
        text-align: center;
        margin: 5px 0px 5px 5px;
        cursor: pointer;
        &.active {
          background-color: #e0fdee;
        }
      }
    }
  }
  .draw-area {
    height: 100%;
    overflow-y: auto;

    #canvas {
      width: 100%;
      height: inherit;
    }
    .screen-lables {
      position: absolute;
      right: 38px;
      top: 0;
      background: #fff;
      border: 1px solid #ececec;
      padding: 10px 5px 5px 10px;
      width: 218px;
      box-sizing: border-box;
      box-shadow: -1px 1px 2px rgba(0, 0, 0, 0.3);
      .overflow {
        display: inline-block;
        width: 60px;
        text-align: center;
        padding: 5px 0;
        border: 1px solid #ececec;
        margin: 0px 5px 5px 0;
        cursor: pointer;
        &.active {
          background-color: #e0fdee;
        }
      }
    }
  }
  .shape-tools {
    position: absolute;
    top: 70px;
    left: -2px;
    z-index: 10000;
    .iconfont {
      color: #f56c6c;
    }
  }
  .attrs-tool {
    position: absolute;
    width: 100px;
    left: 15px;
    top: 80px;
    border: #e8e8e8 1px solid;
    z-index: 999;
    li {
      cursor: pointer;
      display: inline-block;
      padding: 9px 14px;
      border: transparent 1px solid;
      border-radius: 2px;
      width: 100px;
      box-sizing: border-box;
      text-align: center;
      &:hover {
        border: 1px solid red;
      }
      &:first-child {
        cursor: text;
        font-weight: bold;
        background-color: #fff;
        &:hover {
          border: transparent 1px solid;
        }
      }
    }
  }
  .temp-text {
    position: absolute;
    width: 200px;
    left: 0px;
    top: 0px;
    textarea {
      border: red 1px solid;
    }
  }
}
</style>

<style lang="less">
.lawocr-mark {
  .law-button {
    margin-left: 10px;
    // float: left;
    // position: relative;
    // top: 6px;
    // &.el-button--small,
    // &.el-button--small.is-round {
    //   padding: 7px 15px;
    // }
  }
  .el-switch__core {
    width: 35px !important;
  }
  .area-list {
    .active {
      border: red 1px solid;
      box-sizing: border-box;
    }
  }

  .el-textarea__inner {
    font-family: "宋体" !important;
    padding: 5px;
  }
  .el-textarea__inner:focus {
    outline: 2px;
  }
  .svg_select_boundingRect {
    stroke-width: 1;
    stroke-dasharray: 3;
    stroke: rgb(254, 0, 255);
    stroke-width: 2;
    fill-opacity: 0.2;
    fill: rgb(54, 86, 191);
    pointer-events: none;
  }
  .svg_select_points {
    fill: #f56c6c;
    r: 6;
    opacity: 0;
    &:hover {
      opacity: 1;
    }
  }

  .svg-circle-big {
    r: 10;
  }

  .svg-circle-small {
    r: 3;
  }

  .svg_select_points_rot {
    opacity: 0;
  }

  .is-drag #ocrDrawGroup {
    cursor: move;
  }

  .is-point #ocrDrawGroup {
    // cursor: url("~assets/images/c1.png"), pointer !important;
    cursor: none !important;
  }

  .svg_select_boundingRect {
    stroke-opacity: 0;
  }

  .svg-highlight {
    stroke-opacity: 1;
    stroke-dasharray: 20, 20;
    stroke-dashoffset: 500;
    stroke-width: 2;
    animation: animation-dash 15s linear alternate infinite;
  }

  .select-shape-move {
    stroke: #9406ec;
  }

  @keyframes animation-dash {
    to {
      stroke-dashoffset: 0;
    }
  }

  .svg_select_points_lt {
    cursor: se-resize;
  }
  .svg_select_points_rt {
    cursor: ne-resize;
  }
  .svg_select_points_rb {
    cursor: nw-resize;
  }
  .svg_select_points_lb {
    cursor: ne-resize;
  }
  .svg_select_points_t {
    cursor: n-resize;
  }
  .svg_select_points_r {
    cursor: e-resize;
  }
  .svg_select_points_b {
    cursor: s-resize;
  }
  .svg_select_points_l {
    cursor: e-resize;
  }
}
</style>









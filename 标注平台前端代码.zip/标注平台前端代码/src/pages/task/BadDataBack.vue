<template>
    <div class="bad-data">
        <el-table
        size="small"
        :data="badDataList"
        align="center"
        height="600"
        v-loading="loading"
        element-loading-text="正在请求"
        >
            <el-table-column prop="taskTypeName" label="标注任务类型" width="200" :show-overflow-tooltip="true"></el-table-column>
            <el-table-column prop="lastModifiedDate" label="更新时间" width="200"></el-table-column>
            <el-table-column prop="lastModifiedBy" label="更新操作人" ></el-table-column>
            <el-table-column label="可标注数据" width="450">
                <template slot-scope="scope">
                    <span>{{scope.row.misjudgeBad}}</span>
                    <el-button type="primary" size="mini" class="btn-1" :disabled="scope.row.misjudgeBad==0" @click="openCreatTaskDialog(scope.row.taskTypeId)">创建新标注任务</el-button>
                    <el-button type="primary" size="mini" :disabled="scope.row.misjudgeBad==0" @click="downLoadMisBadData1(scope.row.taskTypeId)">下载</el-button> 
                    <el-button type="primary" size="mini" :disabled="scope.row.misjudgeBad==0" @click="clearMisBadData1(scope.row.taskTypeId)">清空</el-button>                 
            </template>
            </el-table-column>
            <el-table-column label="不可标注数据" width="450">
                <template slot-scope="scope">
                    <span>{{scope.row.bad}}</span>
                    <el-button type="primary" size="mini" class="btn-1" :disabled="scope.row.bad==0" @click="downLoadBadData1(scope.row.taskTypeId)">下载</el-button> 
                    <el-button type="primary" size="mini" :disabled="scope.row.bad==0" @click="clearBadData1(scope.row.taskTypeId)">清空</el-button> 
                </template>
            </el-table-column>   
       </el-table>
        <el-dialog title="数据下载" :visible.sync="downLoadVisible" width="400px">
            <p style="padding:10px 20px">下载数据</p>
            <el-checkbox v-model="checked" style="padding:5px 20px">下载数据后，清空数据池</el-checkbox>
            <span slot="footer" class="dialog-footer">
                <el-button @click="downLoadVisible = false" size="small">取 消</el-button>
                <el-button type="primary" @click="downLoadMisBadData()" v-if="!isBadData" size="small">确 定</el-button>
                <el-button type="primary" @click="downLoadBadData()" v-else size="small">确 定</el-button>
            </span>
        </el-dialog>

         <el-dialog title="清空数据池" :visible.sync="clearDataVisible" width="400px">
            <span>该操作将会清空数据池中储存的数据，请确认后操作。</span>
            <span slot="footer" class="dialog-footer">
                <el-button @click="clearDataVisible = false" size="small">取 消</el-button>
                <el-button type="primary" @click="clearMisBadData()" v-if="!isBadData" size="small">确 定</el-button>
                <el-button type="primary" @click="clearBadData()" v-else size="small">确 定</el-button>
            </span>
        </el-dialog>

        <el-dialog title="创建新标注任务" :visible.sync="creatTaskVisible" width="400px">
            <span>该操作将会清空数据池中储存的数据，请确认后操作。</span>
            <span slot="footer" class="dialog-footer">
                <el-button @click="creatTaskVisible = false" size="small">取 消</el-button>
                <el-button type="primary" size="small" @click="creatTask()">确 定</el-button>
            </span>
        </el-dialog>
    </div>
</template>
<script>
import { mapState, mapMutations } from "vuex";
export default {
  computed: {
    ...mapState(["appInfo"])
  },
  data() {
    return {
      loading: false,
      downLoadVisible: false,
      clearDataVisible: false,
      creatTaskVisible: false,
      isBadData: false,
      checked: false,
      taskTypeId: "",
      badDataList: []
    };
  },
  watch: {
    appInfo() {
      if (this.appInfo.id) {
        this.getBadDataList();
      }
    }
  },
  methods: {
    //打开新建任务窗口
    openCreatTaskDialog(taskTypeId) {
      this.taskTypeId = taskTypeId;
      this.creatTaskVisible = true;
    },

    //获取坏数据列表
    getBadDataList() {
      if (!this.appInfo.id) {
        return;
      }
      this.$api.task.getBadData({ id: this.appInfo.id }).then(res => {
        console.log(res);
        this.badDataList = res;
      });
    },

    //打开下载数据弹窗
    downLoadMisBadData1(taskTypeId) {
      this.taskTypeId = taskTypeId;
      this.downLoadVisible = true;
      this.isBadData = false;
    },

    //打开清空数据弹窗
    clearMisBadData1(taskTypeId) {
      this.taskTypeId = taskTypeId;
      this.clearDataVisible = true;
      this.isBadData = false;
    },

    //打开下载数据弹窗
    downLoadBadData1(taskTypeId) {
      this.taskTypeId = taskTypeId;
      this.downLoadVisible = true;
      this.isBadData = true;
    },

    //打开清空数据弹窗
    clearBadData1(taskTypeId) {
      this.taskTypeId = taskTypeId;
      this.clearDataVisible = true;
      this.isBadData = true;
    },

    //下载可标注数据
    downLoadMisBadData() {
      console.log("下载可标注数据");
      this.$api.task
        .downLoadMisBadData({ taskTypeId: this.taskTypeId })
        .then(res => {
          window.location.href =
            "base/datawood-processor/download/misjudge-bad-data/" + this.taskTypeId;
          if (this.checked) {
            this.clearMisBadData();
          }
          this.downLoadVisible = false;
        });
    },

    //清空可标注数据
    clearMisBadData() {
      console.log("清空可标注数据");
      this.$api.task
        .clearMisBadData({ taskTypeId: this.taskTypeId })
        .then(res => {
          this.getBadDataList();
          this.clearDataVisible = false;
        });
    },

    //下载不可标注数据
    downLoadBadData() {
      console.log("下载不可标注数据");
      this.$api.task
        .downLoadBadData({ taskTypeId: this.taskTypeId })
        .then(res => {
          window.location.href =
            "base/datawood-processor/download/bad-data/" + this.taskTypeId;
          if (this.checked) {
            this.clearBadData();
          }
          this.downLoadVisible = false;
        });
    },

    //清空不可标注数据
    clearBadData() {
      console.log("清空不可标注数据");
      this.$api.task.clearBadData({ taskTypeId: this.taskTypeId }).then(res => {
        this.getBadDataList();
        this.clearDataVisible = false;
      });
    },

    //创建新标注任务
    creatTask() {
      this.$router.push({
        name: "任务新建",
        params: { taskTypeId: this.taskTypeId, isBadDataCreate: true }
      });
    }
  },
  mounted() {
    this.getBadDataList();
  }
};
</script>
<style lang="less" scoped>
.bad-data {
  background-color: #fff;
  height: 700px;
  padding: 20px 20px;
  .btn-1 {
    margin-left: 40px;
  }
}
</style>



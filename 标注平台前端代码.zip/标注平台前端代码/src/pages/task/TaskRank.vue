<!--所有的用户工作量排名  -->
<template>
  <el-container class="user-work-count">
    <div class="appDetail">
      <div class="header">
        <span>{{appInfo.name}}</span>
        <el-button class="back-btn" size="small" @click="returnTask">返回首页</el-button>
      </div>
      <div class="footer">
        <span>
          <strong>创建人：</strong>
          {{appInfo.createdBy}}
        </span>
        <span class="font-margin">
          <strong>创建时间：</strong>
          {{appInfo.createdDate}}
        </span>
        <span class="font-margin">
          <strong>应用描述：</strong>
          {{appInfo.description}}
        </span>
      </div>
    </div>
    <el-header>
      <el-form size="small" :inline="true" @submit.native.prevent>
        <el-row class="wood-radio-group">
          <el-form-item label="标注类型：">
            <el-radio-group size="small" v-model="markType" @change="pageQuery(1)">
              <el-radio-button
                v-for="item of markTypes"
                :label="item.id"
                :key="item.id"
              >{{item.name}}</el-radio-button>
            </el-radio-group>
          </el-form-item>
        </el-row>
        <el-row class="wood-radio-group">
          <el-form-item label="提交时间：">
            <el-date-picker
              @change="pageQuery(1)"
              size="small"
              class="detail-date-picker"
              v-model="dateArr"
              type="daterange"
              range-separator="至"
              start-placeholder="开始日期"
              end-placeholder="结束日期"
              format="yyyy-MM-dd"
              value-format="yyyy-MM-dd"
            ></el-date-picker>
          </el-form-item>
        </el-row>
        <el-row class="wood-radio-group">
          <el-form-item>
            <el-input
              placeholder="搜索用户姓名"
              v-model="keyStr"
              :maxlength="30"
              clearable
              suffix-icon="el-icon-search"
              @keyup.enter.native="pageQuery(1)"
              @change="pageQuery(1)"
            ></el-input>
          </el-form-item>
          <export-list-data
            :exportData="exportData"
            :json_fields="json_fields"
            :name="name"
            class="export-data"
          ></export-list-data>
        </el-row>
        <div class="userCount">
          <dl>
            <dt class="mark">标注员</dt>
            <dd>
              <span class="font-primary-mark">{{count.mark}}</span>
            </dd>
          </dl>
          <dl>
            <dt class="check">检查员</dt>
            <dd>
              <span class="font-primary-check">{{count.check}}</span>
            </dd>
          </dl>
        </div>
      </el-form>
    </el-header>
    <el-main>
      <!-- tab页 -->
      <el-tabs v-model="taskType" @tab-click="handleClick(taskType)">
        <el-tab-pane label="标注排行" name="mark"></el-tab-pane>
        <el-tab-pane label="检查排行" name="check"></el-tab-pane>
      </el-tabs>

      <!--标注-->
      <el-table
        size="small"
        :data="userWorkData"
        align="center"
        height="452"
        v-if="taskType==='mark'"
        @sort-change="sortColumn"
      >
        <el-table-column
          type="index"
          :index="(index)=>{return (page - 1) * size + index + 1}"
          label="序号"
          min-width="50"
        ></el-table-column>
        <el-table-column prop="userId" label="用户账号" min-width="100" :show-overflow-tooltip="true"></el-table-column>
        <el-table-column prop="userName" label="用户姓名" min-width="120" :show-overflow-tooltip="true"></el-table-column>
        <el-table-column prop="current" label="当前任务量" :sortable="'custom'" min-width="140"></el-table-column>
        <el-table-column prop="currentComplete" label="已标注" :sortable="'custom'" min-width="140"></el-table-column>
        <el-table-column prop="commitCount" label="已提交" :sortable="'custom'" min-width="140"></el-table-column>
        <el-table-column prop="correct" label="合格率(%)" :sortable="'custom'" min-width="140"></el-table-column>
      </el-table>

      <!--检查-->
      <el-table
        size="small"
        :data="userWorkData"
        align="center"
        height="452"
        v-if="taskType==='check'"
        @sort-change="sortColumn"
      >
        <el-table-column type="index" label="序号" min-width="50"></el-table-column>
        <el-table-column prop="userId" label="用户账号" min-width="120" :show-overflow-tooltip="true"></el-table-column>
        <el-table-column prop="userName" label="用户姓名" min-width="140" :show-overflow-tooltip="true"></el-table-column>
        <el-table-column prop="current" label="当前任务量" :sortable="'custom'" min-width="140"></el-table-column>
        <el-table-column prop="currentComplete" label="已检查" :sortable="'custom'" min-width="140"></el-table-column>
        <el-table-column prop="commitCount" label="已提交" :sortable="'custom'" min-width="140"></el-table-column>
      </el-table>

      <!-- 分页 -->
      <el-pagination
        v-if="total > 10"
        @size-change="sizeChange"
        @current-change="pageChange"
        align="right"
        layout="total, sizes, prev, pager, next, jumper"
        :current-page="page"
        :page-sizes="[5, 10, 20, 40]"
        :page-size="size"
        :total="total"
        class="pager-wrapper"
      ></el-pagination>
    </el-main>
  </el-container>
</template>

<script>
import { mapState } from "vuex";
import ExportListData from "./ExportListData";

export default {
  data() {
    return {
      taskType: "mark",
      userWorkData: [],
      page: 1,
      size: 10,
      total: 0,
      keyStr: "",
      count: {
        mark: 0,
        check: 0
      },
      exportData: [],
      json_fields: {
        用户Id: "userId",
        用户名称: "userName",
        当前任务量: "current",
        已标注: "currentComplete",
        已提交: "commitCount",
        "合格率(%)": "correct"
      },
      name: "markRank.xls",
      markType: 0,
      markTypes: [
        {
          id: 0,
          name: "全部"
        }
      ],
      dateArr: []
    };
  },

  components: { ExportListData },

  computed: {
    ...mapState(["appInfo"])
  },

  watch: {
    appInfo() {
      if (this.appInfo.id) {
        this.pageQuery();
        this.userCount();
        this.queryTaskType();
      }
    }
  },

  methods: {
    //任务类型查询
    queryTaskType() {
      this.markTypes = [{ id: 0, name: "全部" }];
      if (!this.appInfo.id) {
        return;
      }

      this.$api.task.searchTaskType({ appId: this.appInfo.id }).then(res => {
        if (res === "") {
          return;
        }
        res.forEach(item => {
          this.markTypes.push({
            id: item.id,
            name: item.name
          });
        });
      });
    },

    sizeChange(size) {
      this.size = size;
      this.pageQuery(1);
    },

    pageChange(page) {
      this.page = page;
      this.pageQuery();
    },

    //分页查询
    pageQuery(resetPage) {
      if (resetPage == 1) {
        this.page = 1;
      }

      let param = {
        page: this.page,
        size: this.size,
        sort: "DESC",
        appId: this.appInfo.id,
        type: this.taskType === "mark" ? 0 : 1,
        property: "currentComplete",
        name: this.keyStr,
        from:
          this.dateArr && this.dateArr[0]
            ? new Date(this.dateArr[0]).getTime() - 28800000
            : null,
        to:
          this.dateArr && this.dateArr[1]
            ? new Date(this.dateArr[1]).getTime() - 28800000
            : null
      };
      if (this.markType !== 0) {
        param.taskTypeId = this.markType;
      }

      this.query(param);
    },

    //获取数据
    query(param) {
      this.$api.task.userWorkCount(param).then(res => {
        let { userWorkloadStats, total } = res;
        this.userWorkData = userWorkloadStats;
        this.total = total;

        //设置导出数据
        this.exportData = userWorkloadStats;
        // let copyParam = JSON.parse(JSON.stringify(param));
        // copyParam.page = 1;
        // copyParam.size = this.total;
        // this.getExportData(copyParam);
      });
    },

    //切换任务类型
    handleClick(type) {
      this.taskType = type;
      if (type === "check") {
        this.json_fields["已检查"] = 'currentComplete'
        delete this.json_fields["已标注"];
        delete this.json_fields["合格率(%)"];
        this.name = "checkRank.xls";
      } else {
        if (!this.json_fields.hasOwnProperty("合格率(%)")) {
          this.json_fields["合格率(%)"] = "";
          this.json_fields["已标注"] = 'currentComplete';
          delete this.json_fields["已检查"];
        }
        this.name = "markRank.xls";
      }
      this.pageQuery(1);
    },

    //返回首页
    returnTask() {
      this.$router.push({ path: "/task/index" });
    },

    // 表头的指定列排序
    sortColumn(column) {
      let { prop, order } = column;
      let param = {
        page: this.page,
        size: this.size,
        sort: order === "ascending" ? "ASC" : "DESC",
        appId: this.appInfo.id,
        type: this.taskType === "mark" ? 0 : 1,
        property: prop,
        name: this.keyStr,
        from:
          this.dateArr && this.dateArr[0]
            ? new Date(this.dateArr[0]).getTime() - 28800000
            : null,
        to:
          this.dateArr && this.dateArr[1]
            ? new Date(this.dateArr[1]).getTime() - 28800000
            : null
      };
      if (this.markType !== 0) {
        param.taskTypeId = this.markType;
      }
      this.query(param);
    },

    //用户统计
    userCount() {
      if (!this.appInfo.id) {
        return;
      }

      this.$api.task
        .userCount({
          orgId: this.appInfo.orgId,
          roleNames: "ROLE_DW_MARKER,ROLE_DW_CHECKER"
        })
        .then(res => {
          this.count.mark = res[0];
          this.count.check = res[1];
        });
    },

    //获取导出数据
    getExportData(param) {
      this.$api.task.userWorkCount(param).then(res => {
        let { userWorkloadStats } = res;
        this.exportData = userWorkloadStats;
      });
    }
  },

  watch: {},

  mounted() {
    this.pageQuery();
    this.queryTaskType();
    this.userCount();
  }
};
</script>
<style lang='less' scoped>
.user-work-count {
  .appDetail {
    position: relative;
    height: 80px !important;
    background: #fff;
    padding: 10px 25px;
    margin-bottom: 10px;
    .header {
      height: 50px !important;
      .el-button {
        right: 45px;
        position: absolute;
      }
      span {
        font-size: 19px;
        font-weight: bolder;
      }
    }
    .footer {
      height: 30px !important;
      .font-margin {
        margin-left: 40px;
      }
    }
  }
  .el-header {
    height: 160px !important;
    .wood-radio-group {
      padding-left: 5px;
    }
    .el-input {
      padding-left: 5px;
    }
    .export-data {
      display: inline-block;
      margin-top: 8px;
    }
    .userCount {
      position: absolute;
      top: 40px;
      right: 60px;
      dl {
        float: left;
        border-right: #eceef2 1px solid;
        text-align: center;
        font-size: 14px;
        &:nth-child(2) {
          border-right: 0;
        }
        dt {
          color: #909399;
          margin-bottom: 15px;
        }
        .mark {
          margin-right: 18px;
        }
        .check {
          margin-left: 18px;
        }
        dd {
          font-size: 30px;
          margin-right: 10px;
        }
        .font-primary-mark {
          color: #000;
          margin-right: 15px;
        }
        .font-primary-check {
          color: #000;
          margin-left: 15px;
        }
      }
    }
  }
  .el-main {
    padding: 5px 25px;
    margin-bottom: 16px;
  }
}
</style>

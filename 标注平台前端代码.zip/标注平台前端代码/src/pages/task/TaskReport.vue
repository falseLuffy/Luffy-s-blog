<template>
  <div id="taskReport" class="task-report">
    <div class="task-detail">
      <div class="task-text" v-if="taskReport">
        <strong>
          任务名：
          <span class="overflow" :title="taskReport.name">{{taskReport.name}}</span>
          <span class="font-primary">{{taskReport.statusDesc}}</span>
        </strong>
        <el-button
          type="primary"
          class="export-task-count"
          size="small"
          icon="el-icon-upload2"
          @click="exportTaskReport"
        >导出任务汇总</el-button>
        <ul>
          <li>
            <strong>任务类型：</strong>
            {{taskTypeName}}
          </li>
          <li>
            <strong>创建时间：</strong>
            {{taskReport.createDate}}
          </li>
          <li>
            <strong>结束时间：</strong>
            {{statisticsData.endDate}}
          </li>
          <li>
            <strong>创建人：</strong>
            {{taskReport.createdBy}}
          </li>
          <li>
            <strong>任务总量：</strong>
            {{taskReport.totalCount}}条
          </li>
          <li>
            <strong>批次数：</strong>
            {{statisticsData.batchCount}}
          </li>
          <li>
            <strong>正确率算法：</strong>
            {{checkDesc}}
          </li>
        </ul>
      </div>
      <div class="count">
        <dl style="flex-shrink:0">
          <dt class="check">任务耗时</dt>
          <dd>
            <span>{{day}}天</span>
          </dd>
        </dl>
        <dl>
          <dt class="check">提交标注数</dt>
          <dd>
            <span>{{statisticsData.total-statisticsData.misjudgeBad-statisticsData.bad}}</span>
          </dd>
        </dl>
        <dl>
          <dt class="check">提交检查数</dt>
          <dd>
            <span>{{statisticsData.checked}}</span>
          </dd>
        </dl>
        <dl>
          <dt class="check">检查率</dt>
          <dd>
            <span>{{getRate(statisticsData.checked,statisticsData.total-statisticsData.misjudgeBad-statisticsData.bad)}}</span>
          </dd>
        </dl>
        <dl>
          <dt class="check">综合正确率</dt>
          <dd>
            <span>{{statisticsData.correct}}%</span>
          </dd>
        </dl>
        <dl>
          <dt class="check">有效数据</dt>
          <dd>
            <span>{{statisticsData.total-statisticsData.misjudgeBad-statisticsData.bad}}</span>
          </dd>
        </dl>
        <dl>
          <dt class="check">可回收坏数据</dt>
          <dd>
            <span>{{statisticsData.misjudgeBad}}</span>
          </dd>
        </dl>
        <dl>
          <dt class="check">真实坏数据</dt>
          <dd>
            <span>{{statisticsData.bad}}</span>
          </dd>
        </dl>
        <dl>
          <dt class="check">坏数据比例</dt>
          <dd>
            <span>{{getRate(statisticsData.bad,statisticsData.total)}}</span>
          </dd>
        </dl>
      </div>
    </div>
    <div class="work-count">
      <p>
        <strong>工作量汇总</strong>
      </p>
      <div class="main">
        <el-form size="small" :inline="true" @submit.native.prevent>
          <el-form-item>
            <el-input
              placeholder="搜索用户姓名"
              v-model="keyStr"
              :maxlength="30"
              clearable
              @change="pageQuery(1)"
              suffix-icon="el-icon-search"
            ></el-input>
          </el-form-item>
        </el-form>

        <!--用户统计-->
        <div class="userCount">
          <dl>
            <dt class="mark">标注员</dt>
            <dd>
              <span class="font-primary-mark">{{statisticsData.markerCount}}</span>
            </dd>
          </dl>
          <dl>
            <dt class="check">检查员</dt>
            <dd>
              <span class="font-primary-check">{{statisticsData.checkerCount}}</span>
            </dd>
          </dl>
        </div>

        <!-- tab页 -->
        <el-tabs v-model="countType" @tab-click="pageQuery(1)">
          <el-tab-pane label="标注统计" name="mark"></el-tab-pane>
          <el-tab-pane label="检查统计" name="check"></el-tab-pane>
        </el-tabs>

        <!--标注-->
        <el-table
          size="small"
          :data="userWorkData"
          align="center"
          height="452"
          v-if="countType==='mark'"
        >
          <el-table-column
            type="index"
            :index="(index)=>{return (page - 1) * size + index + 1}"
            label="序号"
            min-width="50"
          ></el-table-column>
          <el-table-column prop="userId" label="用户账号" width="100" :show-overflow-tooltip="true"></el-table-column>
          <el-table-column
            prop="userName"
            label="用户姓名"
            min-width="120"
            :show-overflow-tooltip="true"
          ></el-table-column>
          <el-table-column prop="commitCount" label="标注量" min-width="140"></el-table-column>
          <el-table-column prop="correct" label="正确率（%）" min-width="140"></el-table-column>
          <el-table-column prop="misjudge" label="错判率（%）" min-width="140"></el-table-column>
        </el-table>

        <!--检查-->
        <el-table
          size="small"
          :data="userWorkData"
          align="center"
          height="452"
          v-if="countType==='check'"
        >
          <el-table-column type="index" label="序号" min-width="50"></el-table-column>
          <el-table-column prop="userId" label="用户账号" min-width="120" :show-overflow-tooltip="true"></el-table-column>
          <el-table-column
            prop="userName"
            label="用户姓名"
            min-width="140"
            :show-overflow-tooltip="true"
          ></el-table-column>
          <el-table-column prop="commitCount" label="提交检查" min-width="140"></el-table-column>
        </el-table>

        <!-- 分页 -->
        <el-pagination
          v-if="total > 10"
          @size-change="sizeChange"
          @current-change="pageChange"
          align="right"
          layout="total, sizes, prev, pager, next, jumper"
          :current-page="page"
          :page-sizes="[5, 10, 20, 40]"
          :page-size="size"
          :total="total"
          class="pager-wrapper"
        ></el-pagination>
      </div>
    </div>
  </div>
</template>
<script>
import { mapState, mapMutations } from "vuex";
import { getRate, formSubmit } from "assets/scripts/common";

export default {
  data() {
    return {
      id: "",
      keyStr: "",
      countType: "mark",
      size: 10,
      page: 1,
      total: 0,
      userWorkData: [],
      taskReport: {},
      statisticsData: {},
      getRate: getRate,
      day: "",
      taskTypeName: "",
      checkDesc: ""
    };
  },
  computed: {
    ...mapState(["appInfo"])
  },
  watch: {
    appInfo() {
      if (this.appInfo.id) {
        this.pageQuery(1);
      }
    }
  },
  methods: {
    ...mapMutations(["showLoading", "closeLoading"]),
    sizeChange(size) {
      this.size = size;
      this.pageQuery(1);
    },

    pageChange(page) {
      this.page = page;
      this.pageQuery(page);
    },
    handleClick(countType) {},

    //获取任务报告信息
    getTaskReport() {
      this.showLoading(true);
      this.$api.task.taskReport({ id: this.id }).then(res => {
        this.closeLoading(true);
        let { taskResp, statistics } = res;
        this.taskReport = taskResp;
        this.statisticsData = statistics;
        this.taskTypeName = this.taskReport.taskType.name;
        this.checkDesc = this.taskReport.checkBy.desc;
        let create = parseInt(
          (this.turnTimestamp(statistics.endDate) -
            this.turnTimestamp(taskResp.createDate)) /
            1000
        );
        this.day = (create / 86400).toFixed(3);
      });
    },

    //用户工作量统计
    pageQuery(resetPage) {
      if (resetPage == 1) {
        this.page = 1;
      }
      if (!this.appInfo.id) {
        return;
      }

      let param = {
        page: this.page,
        size: this.size,
        appId: this.appInfo.id,
        type: this.countType === "mark" ? 0 : 1,
        name: this.keyStr,
        taskId: this.id,
        property: "currentComplete",
        sort: "DESC"
      };

      this.$api.task.userWorkCount(param).then(res => {
        let { userWorkloadStats, total } = res;
        this.userWorkData = userWorkloadStats;
        this.total = total;
      });
    },

    //日期字符串转时间戳
    turnTimestamp(date) {
      date = date.substring(0, 19);
      date = date.replace(/-/g, "/");
      return new Date(date).getTime();
    },

    //通过提交表单下载文件
    exportTaskReport() {
      let param = {};
      formSubmit(
        `base/datawood-manager/api/task/export-report/${this.id}`,
        "taskReport",
        param
      );
    }
  },
  mounted() {
    // 获取任务id
    this.id = window.sessionStorage.getItem("id");
    this.getTaskReport();
    this.pageQuery(1);
  }
};
</script>
<style lang="less" scoped>
.task-report {
  .task-detail {
    position: relative;
    padding: 10px 20px;
    min-height: 230px;
    background: #fff;
    margin-bottom: 10px;
    overflow: auto;
    .export-task-count {
      position: absolute;
      top: 30px;
      right: 20px;
    }
    .task-text {
      float: left;
      width: 300px;
      box-sizing: border-box;
      font-size: 16px;
      .overflow {
        display: inline-block;
        max-width: 140px;
        position: relative;
        top: 3px;
      }
      .font-primary {
        font-size: 13px;
        font-weight: normal;
        margin-left: 5px;
        background-color: #35be57;
        color: #fff;
        padding: 3px 8px;
        border-radius: 5px;
      }
      ul {
        margin-top: 30px;
        li {
          height: 25px;
          font-size: 14px;
          line-height: 25px;
        }
      }
    }
    .count {
      position: absolute;
      top: 90px;
      left: 400px;
      display: flex;
      dl {
        flex-direction: column;
        display: flex;
        flex: 1;
        border-right: #eceef2 1px solid;
        text-align: center;
        font-size: 14px;
        &:nth-child(9) {
          border-right: 0;
        }
        dt {
          flex: 1;
          color: #909399;
          margin-bottom: 15px;
          margin-left: 10px;
          margin-right: 10px;
        }
        dd {
          font-size: 30px;
          margin-right: 10px;
          margin-left: 10px;
          span {
            color: #000;
          }
        }
      }
    }
  }
  .work-count {
    height: 550px;
    background: #fff;
    position: relative;
    p {
      width: 100px;
      padding: 30px 20px;
      font-size: 16px;
    }
    .main {
      padding-left: 20px;
      .el-button {
        margin-top: 5px;
      }
      .userCount {
        position: absolute;
        top: 70px;
        right: 30px;
        dl {
          float: left;
          border-right: #eceef2 1px solid;
          text-align: center;
          font-size: 14px;
          &:nth-child(2) {
            border-right: 0;
          }
          dt {
            color: #909399;
            margin-bottom: 15px;
          }
          .mark {
            margin-right: 18px;
          }
          .check {
            margin-left: 18px;
          }
          dd {
            font-size: 30px;
            margin-right: 10px;
          }
          .font-primary-mark {
            color: #000;
            margin-right: 15px;
          }
          .font-primary-check {
            color: #000;
            margin-left: 15px;
          }
        }
      }
    }
  }
}
</style>


<template>
  <mark-tpl
    class="address-mark"
    :appType="appType"
    :param="param"
    @query="query"
    @setQueryData="setQueryData"
    @valid="valid"
    @save="save"
  >
    <!-- 标题 -->
    <div class="address-title" slot="title">
      <span class="overflow">{{this.param.value}}</span>
      <template>
        <el-button
          type="danger"
          :disabled="mcType === 1"
          size="small"
          v-if="param.quality === -10"
          @click="availableClick"
        >坏数据
        </el-button>
        <el-button type="danger" size="small" class="btn-plain" v-else @click="availableClick">标为坏数据</el-button>
      </template>
    </div>

    <div slot="answer" class="address-answer">
      <!--标注区域-->
      <div class="mark-content">
        <div class="title">
          <div class="change" @mouseup="selection">
            <span
              v-for="item in getArea"
              :key="item.value"
              :data-type="item.key"
              :class="{type0:item.tag === 0,type1:item.tag === 1}"
              v-html="item.selected?item.selected:item.value"
            ></span>

            <ul class="type-list" v-show="selectList" @click="selectTag">
              <li>province</li>
              <li>city</li>
              <li>area</li>
              <li>town</li>
              <li>village</li>
              <li>road</li>
              <li>road_num</li>
              <li>poi</li>
              <li>取消</li>
            </ul>
          </div>
        </div>
        <div class="area-list">
          <el-table :show-header="false" :data="getArea" border style="width: 100%">
            <el-table-column prop="value" min-width="200"></el-table-column>
            <el-table-column prop="key" width="150">
              <template slot-scope="scope">
                <span v-if="scope.row.tag === 1">{{scope.row.key}}</span>
                <el-select
                  v-show="scope.row.value && scope.row.tag!==1"
                  v-model="scope.row.key"
                  placeholder="请选择"
                >
                  <el-option
                    v-for="item in options"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"
                  ></el-option>
                </el-select>
              </template>
            </el-table-column>
            <el-table-column prop="handle" width="65">
              <template slot-scope="scope" v-if="scope.row.tag !== 1 && scope.row.delete">
                <el-button
                  size="small"
                  type="text"
                  @click.native.prevent="deleteRow(scope, areaData)"
                >删除
                </el-button>
              </template>
            </el-table-column>
          </el-table>
        </div>
      </div>

      <!--地图区域-->
      <v-map :FsearchName="searchName" :Fkeyword="keyword" :Flocation="location"/>
    </div>
  </mark-tpl>
</template>

<script>
  import MarkTpl from "./MarkTpl";
  import {APPTYPE} from "assets/scripts/code";
  import {setMarkData, selectionText} from "assets/scripts/common";
  import VMap from "../components/Map";

  export default {
    name: "AddressMark",
    components: {
      MarkTpl,
      VMap
    },
    data() {
      return {
        tempTag: "",
        typeTag: "",
        initValue: "",
        provinceType: false,
        cityType: false,
        areaType: false,
        townType: false,
        villageType: false,
        roadType: false,
        roadNumType: false,
        poiType: false,
        area: [],
        flag: false,
        newTag: "",
        preSelectedText: "",
        errorTtile: "",
        editContent: {},
        poi: "",
        dictionary: "",
        selectedText: "",
        selectedTag: "",
        areaValue: {},
        selectList: false,
        areaData: [],
        options: [
          {
            id: 1,
            value: "province",
            label: "Province"
          },
          {
            id: 2,
            value: "city",
            label: "City"
          },
          {
            id: 3,
            value: "area",
            label: "Area"
          },
          {
            id: 4,
            value: "town",
            label: "Town"
          },
          {
            id: 5,
            value: "village",
            label: "Village"
          },
          {
            id: 6,
            value: "road",
            label: "Road"
          },
          {
            id: 7,
            value: "road_num",
            label: "RoadNum"
          },
          {
            id: 8,
            value: "poi",
            label: "Poi"
          }
        ],
        appType: APPTYPE.ADDRESS,
        mcType: "",
        task: null,
        readonly: false,
        loading: false,
        searchName: "",
        markTitle: "",
        location: "",
        keyword: "",
        normalShow: false,
        descShow: false,
        normalName: [],
        param: {
          name: "",
          url: "",
          quality: 0, // "0"好 "-10"坏
          bad: false, // "0"好 "1"坏
          result: {}
        }
      };
    },

    created() {
      let task = JSON.parse(window.sessionStorage.getItem("task"));
      // 1检查,0标注
      this.mcType = task.type;
      this.readonly = task.readonly;
      this.task = task;
    },

    computed: {
      getArea() {
        return this.areaData.sort((a, b) => {
          return a.number - b.number;
        });
      }
    },

    methods: {
      /**
       * 查询数据
       * @param param 请求参数
       * @param isCookie 是否是缓存
       */
      query(param, isCookie) {
        let id = param.userTaskItemId;
        delete param.dataId;
        this.$api.mark.getMarkFile(param).then(res => {
          res.userTaskItemId = id;
          if (isCookie) {
            setMarkData(id, res);
          } else {
            setMarkData(id, res);
            this.setQueryData(res);
          }
        });
      },

      /**
       * 请求数据后的内容处理
       * @param res 请求的数据
       */
      setQueryData(res) {
        // reset
        this.areaData = [];
        // 设置
        let addressData;
        let mcType = this.mcType;

        // 1）检查
        if (mcType === 1) {
          addressData = res.checkedData ? res.checkedData : res.markedData;
        } else if (res.markedData && mcType === 0) {
          // 2）标注
          addressData = res.markedData;
        } else if (!res.markedData) {
          // 3）没有标注
          addressData = res.data;
        }
        // 数据赋值
        this.param = {...this.param, ...res.data};

        // this.param.bad = addressData.bad ? addressData.bad : false;
        this.param.quality =
          addressData.quality === -10 ? addressData.quality : 0;

        this.param.sourcePath = res.sourcePath;
        this.param.result = addressData.result ? addressData.result : {};

        // init
        this.editContent = this.param.addressData;

        // 已经标注
        if (addressData.areaData) {
          this.areaData = addressData.areaData;
        } else {
          if (
            this.editContent.provinceTag &&
            this.editContent.provinceTag !== "2"
          ) {
            this.areaData.push({
              number: 0,
              delete: false,
              initValue: this.editContent.province,
              value: this.editContent.province,
              key: "province",
              tag: this.editContent.provinceTag
            });
          }
          if (this.editContent.cityTag && this.editContent.cityTag !== "2") {
            this.areaData.push({
              number: 1,
              delete: false,
              initValue: this.editContent.city,
              value: this.editContent.city,
              key: "city",
              tag: +this.editContent.cityTag
            });
          }
          if (this.editContent.adreaTag && this.editContent.adreaTag !== "2") {
            this.areaData.push({
              number: 2,
              delete: false,
              initValue: this.editContent.area,
              value: this.editContent.area,
              key: "area",
              tag: +this.editContent.adreaTag
            });
          }
          if (this.editContent.townTag && this.editContent.townTag !== "2") {
            this.areaData.push({
              number: 3,
              delete: false,
              initValue: this.editContent.town,
              value: this.editContent.town,
              key: "town",
              tag: +this.editContent.townTag
            });
          }
          if (
            this.editContent.villageTag &&
            this.editContent.villageTag !== "2"
          ) {
            this.areaData.push({
              number: 4,
              delete: false,
              initValue: this.editContent.village,
              value: this.editContent.village,
              key: "village",
              tag: +this.editContent.villageTag
            });
          }
          if (this.editContent.roadTag && this.editContent.roadTag !== "2") {
            this.areaData.push({
              number: 5,
              delete: false,
              initValue: this.editContent.road,
              value: this.editContent.road,
              key: "road",
              tag: +this.editContent.roadTag
            });
          }
          if (
            this.editContent.road_numTag &&
            this.editContent.road_numTag !== "2"
          ) {
            this.areaData.push({
              number: 6,
              delete: false,
              initValue: this.editContent.road_num,
              value: this.editContent.road_num,
              key: "road_num",
              tag: +this.editContent.road_numTag
            });
          }
          if (this.editContent.poiTag && this.editContent.poiTag !== "2") {
            this.areaData.push({
              number: 7,
              delete: false,
              initValue: this.editContent.poi,
              value: this.editContent.poi,
              key: "poi",
              tag: +this.editContent.poiTag
            });
          }
        }

        this.searchName = this.param.sourceAddress;
        this.keyword = this.param.sourceAddress;
        // this.location = this.param.province;

        // 获取数据后，才可以点击下一条，防止快速点击事件
        this.param.clicked = false;
        if (this.param.keycodetimer) {
          this.param.keycodetimer = null;
          clearTimeout(this.param.keycodetimer);
        }
      },

      // 模糊查询标准名
      _getBlurName(query) {
        const param = {
          locationLevel: this.typeTag,
          searchValue: query,
          page: 1,
          size: 10
        };
        this.$api.mark.getBlurName(param).then(res => {
          this.loading = false;
          let {content} = res;
          this.normalName = content;
        });
      },

      remoteMethod(query) {
        if (query !== "") {
          this.loading = true;
          this._getBlurName(query);
        } else {
          this.normalName = [];
        }
      },

      handleSearch() {
        this.keyword = this.searchName;
      },

      // 删除
      deleteRow(scope, rows) {
        const index = scope.$index;
        const name = scope.row.value;
        const selectedTag = scope.row.selected;
        const type = scope.row.type;
        const initType = scope.row.initType;
        const initValue = scope.row.initValue;

        // 标注还原的内容是属于哪个类别下的
        for (let item of this.getArea) {
          if (initType === item.key) {
            item.initValue = item.initValue.replace(selectedTag, name);
            item.value = item.initValue.replace(/<i[^>]*>[^<]*<\/i>/gi, "");
          }
        }

        rows.splice(index, 1);
      },

      // 文字选中
      selection(e) {
        // 选中的文字
        let text = selectionText();

        // 选中文字所属类型 data-type
        let type = e.target.dataset.type;
        this.tempTag = type ? type : this.tempTag;
        this.typeTag = this.tempTag;

        if (text) {
          this.selectedText = text;
          this.dictionary = text;
          this.searchName = text;
          this.selectList = true;
          this._getBlurName(text);
        }
      },

      selectTag(event) {
        const innerText = event.target.innerText;
        if (innerText === "取消") {
          this.selectList = false;
        } else {
          this.selectedTag = innerText;
          this.selectList = false;
          this.newTag = `<i>${this.selectedText}</i>`;
          // this.initValue = this.initValue.replace(this.selectedText, this.newTag)
          let initType = "";

          for (let item of this.areaData) {
            if (item.key === this.typeTag) {
              item.initValue = item.initValue ? item.initValue : item.value;
              item.initValue = item.initValue.replace(
                this.selectedText,
                this.newTag
              );
              item.value = item.value.replace(this.selectedText, "");
            }
          }

          let num = null;
          switch (this.selectedTag) {
            case "province":
              num = 0;
              break;
            case "city":
              num = 1;
              break;
            case "area":
              num = 2;
              break;
            case "town":
              num = 3;
              break;
            case "village":
              num = 4;
              break;
            case "road":
              num = 5;
              break;
            case "road_num":
              num = 6;
              break;
            case "poi":
              num = 7;
              break;
            default:
              break;
          }

          const item = {
            number: num,
            delete: true,
            initValue: this.initValue,
            initType: this.typeTag,
            selected: this.newTag,
            value: this.selectedText,
            key: this.selectedTag,
            tag: 0,
            type: `${this.selectedTag}Type`
          };

          this.areaData.push(item);
        }
      },

      //标准名中选择其它选项
      selectName(val) {
        val === "other" ? (this.descShow = true) : (this.descShow = false);
      },

      availableClick() {
        if (this.readonly || (this.mcType === 1 && !this.param.quality === -10)) {
          return;
        }
        let nowStatus = this.param.quality;
        if (nowStatus === 0) {
          if (this.param.result.length) {
            this.$confirm(
              "标记为坏数据后，已标注内容将会被清除，确认标记吗？",
              "",
              {
                lockScroll: false
              }
            )
              .then(() => {
                this.param.quality = -10;
                this.param.result = [];
              })
              .catch(() => {
              });
          } else {
            this.param.quality = -10;
          }
        } else {
          this.param.quality = 0;
        }
      },

      /**
       * 校验
       */
      valid() {
        return true;
      },

      /**
       * 保存数据,只保存需要保存的数据
       */
      save() {
        let map = new Map();
        let obj = {};
        this.areaData.forEach(item => {
          if (map.has(item.key)) {
            let value = map.get(item.key);
            map.set(item.key, `${value},${item.value}`);
          } else {
            map.set(item.key, item.value);
          }
        });

        for (let [k, v] of map) {
          obj[k] = v;
        }

        this.param.commitData = {
          // editContent: this.editContent,
          result: obj,
          areaData: this.areaData,
          quality: this.param.quality
        };
      }
    }
  };
</script>

<style lang="less" scoped>
  .address-mark {
    .address-title {
      display: flex;
      align-items: center;

      .overflow {
        display: inline-block;
        max-width: 400px;
        margin: 0 15px;
      }
    }

    .address-answer {
      display: flex;

      .mark-content {
        flex: 1;
        margin-right: 10px;

        .title {
          display: flex;
          flex-wrap: wrap;
          font-size: 16px;
          background: #eaf6ff;
          padding: 20px;
          border-radius: 2px;
          line-height: 1.5;
        }

        .area-list {
          margin-top: 30px;
        }

        .change {
          position: relative;
          display: flex;
          flex-wrap: wrap;

          span {
            margin: 0 2px;
          }

          .type1 {
            user-select: none;
          }

          .type0 {
            color: #db384c;
            margin: 0 2px 2px;
          }

          .type0 /deep/ i {
            display: inline-block;
            user-select: none;
            background: #db384c;
            color: #fff;
            border-radius: 2px;
            padding: 2px 6px;
          }
        }

        .type-list {
          position: absolute;
          z-index: 99;
          right: 4px;
          top: 30px;
          padding: 10px 0;
          color: #fff;
          font-size: 14px;
          margin: 5px 0;
          background-color: #fff;
          border: 1px solid #ebeef5;
          border-radius: 4px;
          box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);

          li {
            list-style: none;
            line-height: 36px;
            padding: 0 20px;
            margin: 0;
            font-size: 14px;
            color: #606266;
            cursor: pointer;
            outline: none;

            &:hover {
              background-color: #ecf5ff;
              color: #66b1ff;
            }
          }
        }

        .poi {
          .error {
            color: #3a8ee6;
          }
        }
      }

      .map-content {
        position: relative;
        width: 530px;
        height: 400px;

        .tag-select {
          position: absolute;
          z-index: 2999;
          background: rgba(0, 0, 0, 0.1);
          width: 100%;
          left: 0;
          top: 0;
        }

        .input-search {
          position: absolute;
          z-index: 2800;
          width: 200px;
          left: 10px;
          top: 50px;
        }

        .map {
          width: 530px;
          height: 400px;
        }
      }
    }
  }
</style>

import md5 from 'js-md5'
import {
  Base64
} from 'js-base64'
import {
  asyncRouterMap,
  router
} from "@/router"
import store from '@/store'
import Cookies from "js-cookie"

// 获取随机的值
function rdNum(n) {
  var rnd = "";
  for (var i = 0; i < n; i++) {
    rnd += Math.floor(Math.random() * 10);
  }
  return rnd;
}

//获取headers的值
export function createHeader(token, isformdata) {
  var contentType = isformdata ? 'multipart/form-data' : 'application/json';
  if (!token && Cookies.get('accessToken')) {
    token = Cookies.get('accessToken')
  }
  return {
    'Content-Type': contentType,
    'time': new Date().getTime(),
    'salt': rdNum(6),
    'Authorization': token ? `Bearer ${token}` : ''
  }
}

//密码加密
export function encodePwd(pwd) {
  return Base64.encode(md5(pwd))
}

//表单检验
export const formValid = {
  // 特殊字符
  specialKeyValidator: (rule, value, callback) => {
    let pattern = new RegExp("[`~!@#$^&%*()=|{}':;',\\[\\].<>/?~！@#￥……&*（）——|{}【】‘；：”“'。，、？]")
    if (pattern.test(value) || /\s+/g.test(value)) {
      callback(new Error('只能输入纯文本，不可输入特殊字符包括空格和换行'))
    } else {
      callback();
    }
  },
  // 空格
  passwordValidator: (rule, value, callback) => {
    if (/[\u4e00-\u9fa5]/.test(value) || /\s+/g.test(value)) {
      callback(new Error('不能输入中文或者空格'))
    } else {
      callback();
    }
  },
  nullValidator: (rule, value, callback) => {
    if (value.replace(/(^\s*)|(\s*$)/g, "") == "") {
      callback(new Error('不能为空或只有空格'))
    } else {
      callback();
    }
  },
  numberValidator: (rule, value, callback) => {
    value = Number(value);
    if (value == 0 || value > 100) {
      callback(new Error('值必须大于0且小于100'))
    } else {
      callback()
    }
  },
  accountValidator: (rule, value, callback) => {
    if (!/^[A-Za-z0-9_-]*$/g.test(value)) {
      callback(new Error('请输入字母或数字,下划线,连接符'))
    } else {
      callback()
    }
  }
}

//获取动态路由map
export function setRouterMap(user) {
  user = (typeof user === "string") ?
    JSON.parse(user) :
    user;
  let routers = [];
  asyncRouterMap.forEach(function (item) {
    if (item.meta && item.meta.role[0] === user.role) {
      routers.push(item);
    }
  });

  //更改储存的在store的路由map
  store.commit('setRouters', routers);
  if (!store.state.user.role) {
    store.commit('setUserInfo', user);
  }

  router.addRoutes(routers);
  return routers;
}

function padLeftZero(str) {
  return ('00' + str).substr(str.length);
}

//通过率(保留2位小数)
export function getRate(val, total) {
  val = val ? val : 0;
  total = total ? total : 0;
  if (val === 0 || total === 0) {
    return "0%"
  };

  let rate = ((val / total) * 100).toString();
  if (rate.indexOf('.') > -1) {
    rate = Number(rate).toFixed(2)
  }
  return rate + '%';
}

// 控制左边侧边栏的显示
export function setNavVisible(type, boolean) {
  const leftDom = document.querySelector(".left-slider"),
    mainDom = document.querySelector(".main-container"),
    copyDom = document.querySelector(".copyright"),
    iconDom = document.getElementById("datawoodControlNav");

  // 隐藏图标
  if (iconDom) {
    iconDom.classList[boolean ? 'add' : 'remove']('icon-hide');
  }

  if (leftDom) {
    leftDom.classList[type == "hidden" ? 'add' : 'remove']('left-hidden')
  }
  if (mainDom) {
    mainDom.classList[type == "hidden" ? 'add' : 'remove']('width-100')
  }
  if (copyDom) {
    copyDom.classList[type == "hidden" ? 'add' : 'remove']('width-100')
  }

}

/**
 * 设置缓存数据
 * @param {Number} index 
 * @param {Object} res 
 */
export function setMarkData(index, res) {
  let markDatas = sessionStorage.markDatas ? JSON.parse(sessionStorage.markDatas) : {};
  markDatas[index] = res;
  sessionStorage.setItem("markDatas", JSON.stringify(markDatas));
}

/**
 * 获取缓存数据
 */
export function getMarkData() {
  if (sessionStorage.markDatas) {
    return JSON.parse(sessionStorage.markDatas)
  } else {
    return null;
  }
}

/**
 * 删除缓存数据
 * @param {Number} index 
 */
export function delMarkData(index) {
  let markDatas = sessionStorage.markDatas;
  if (markDatas) {
    markDatas = JSON.parse(sessionStorage.markDatas);
    if (markDatas[index]) {
      delete markDatas[index]
    };
    sessionStorage.setItem("markDatas", JSON.stringify(markDatas));
  }
}

/**
 * 获取周
 * @param {*} AddWeekCount  0当前周，1下周
 */
export function getWeekStartAndEnd(AddWeekCount) {
  var startStop = new Array();
  var millisecond = 1000 * 60 * 60 * 24;
  var currentDate = new Date();
  currentDate = new Date(currentDate.getTime() + (millisecond * 7 * AddWeekCount));

  var week = currentDate.getDay();
  var month = currentDate.getDate();
  var minusDay = week != 0 ? week - 1 : 6;
  var currentWeekFirstDay = new Date(currentDate.getTime() - (millisecond * minusDay));
  var currentWeekLastDay = new Date(currentWeekFirstDay.getTime() + (millisecond * 6));
  startStop.push(currentWeekFirstDay);
  startStop.push(currentWeekLastDay);
  return startStop;
}

/** 
 * 获得相对当月AddMonthCount个月的起止日期 
 * AddMonthCount为0 代表当月 为-1代表上一个月  为1代表下一个月 以此类推
 * ***/
export function getMonthStartAndEnd(AddMonthCount) {
  var startStop = new Array();
  var currentDate = new Date();
  var month = currentDate.getMonth() + AddMonthCount;
  if (month < 0) {
    var n = parseInt((-month) / 12);
    month += n * 12;
    currentDate.setFullYear(currentDate.getFullYear() - n);
  }
  currentDate = new Date(currentDate.setMonth(month));
  var currentMonth = currentDate.getMonth();
  var currentYear = currentDate.getFullYear();
  var currentMonthFirstDay = new Date(currentYear, currentMonth, 1);
  var currentMonthLastDay = new Date(currentYear, currentMonth + 1, 0);
  startStop.push(currentMonthFirstDay);
  startStop.push(currentMonthLastDay);
  return startStop;
}

/**
 * 检查密码强度
 * @param {} sValue 
 */
export function checkStrong(sValue) {
  var modes = 0;
  //正则表达式验证符合要求的
  if (sValue.length < 1) return "";
  if (/\d/.test(sValue)) modes++; //数字
  if (/[a-z]/.test(sValue)) modes++; //小写
  if (/[A-Z]/.test(sValue)) modes++; //大写  
  if (/\W/.test(sValue)) modes++; //特殊字符

  //逻辑处理
  switch (modes) {
    case 1:
      return "密码强度 低";
      break;
    case 2:
      return "密码强度 中";
      break;
    case 3:
    case 4:
      return sValue.length < 8 ? "密码强度 中" : "密码强度 高"
      break;
  }
  return modes;
}

/**
 * 获取当前用户应用信息
 */
export function getAppInfo() {
  let info = window.localStorage.getItem("userAppInfo") ? JSON.parse(window.localStorage.getItem("userAppInfo")) : null;
  return info;
}

/**
 * 设置当前用户应用信息
 */
export function setAppInfo(newApp) {
  let allInfos = getAppInfo();
  let myId = newApp.userId;
  // 如果有则替换
  if (allInfos) {
    allInfos[myId] = newApp;
    window.localStorage.setItem(
      "userAppInfo", JSON.stringify(allInfos)
    );
  } else {
    let obj = {};
    obj[myId] = newApp;

    window.localStorage.setItem(
      "userAppInfo",
      JSON.stringify(obj)
    );
  }
}

/**
 * 通过表单提交的方式下载
 * @param param 请求的参数
 * @param url 请求的URL
 */
export function formSubmit(url,exportParent, param) {  
  var $form = document.getElementById("exportForm");
  if (!$form) {
    $form = document.createElement("form");
    $form.setAttribute("id", "exportForm");
    $form.setAttribute("method", param ? "post" : "get");
    $form.setAttribute("target", "");
    $form.style.display = "none";
    document.getElementById(exportParent).appendChild($form);
  }

  $form.setAttribute("action", url);
  if (param) {
    while($form.firstChild) {
      $form.removeChild($form.firstChild)
    }
    let token = Cookies.get("accessToken");
    param.access_token = token;
    for (var obj in param) {
      var input = document.createElement("input");
      input.type = "hidden";
      input.name = obj;
      input.value = param[obj];
      $form.appendChild(input);
    };
  }
  $form.submit();
}

/**
 * 鼠标左键选中文字
 * **/
export const selectionText = ()=> {
  let selectionObj = null,
    rangeObj = null,
    selectedText = '',
    selectedHtml = '';
    if(window.getSelection()){
      selectionObj = window.getSelection()
      selectedText = selectionObj.toString()
      // rangeObj = selectionObj.getRangeAt(0)
      // let docFragment = rangeObj.cloneContents()
      // let tempDiv = document.createElement("div");
      // tempDiv.appendChild(docFragment);
      // selectedHtml = tempDiv.innerHTML;
    }else if(document.selection){
      selectionObj = document.selection;
      rangeObj = selectionObj.createRange();
      selectedText = rangeObj.text;
      selectedHtml = rangeObj.htmlText;
    }
    return selectedText
}

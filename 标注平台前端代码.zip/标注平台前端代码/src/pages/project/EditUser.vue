<template>
  <section class="dialog">
    <el-form style="width: 100%" :model="userForm" :rules="rules" ref="userForm" label-width="110px" labelPosition="right" size="small" >
      <el-form-item label="用户账号:">
        <el-input name="account" :disabled="isReadonly" :value="userObj.account"></el-input>
      </el-form-item>
      <el-form-item label="用户名称:">
        <el-input name="name" :disabled="isReadonly" :value="userObj.name"></el-input>
      </el-form-item> 
      <el-form-item label="公司:">
        <el-input name="account" :disabled="isReadonly" :value="userObj.applicationName"></el-input>
      </el-form-item>
      <el-form-item prop="des_info" label="描述:">
        <el-input type="textarea" :autosize="{ minRows: 2, maxRows: 4 }" :maxlength="255" name="desc" v-model="userForm.des_info" placeholder="请输入描述"></el-input>
      </el-form-item>
      <el-form-item label="管理员密码:" prop="adminPwd">
        <el-input name="adminPwd" type="password" v-model="userForm.adminPwd" :maxlength="30" placeholder="请输入"></el-input>
      </el-form-item>
    </el-form>
    <div slot="footer" align="right" class="section-footer">
      <el-button size="small" @click="hide">取消</el-button>
      <el-button type="primary" size="small" @click="editUser">确定</el-button>
    </div>
  </section>
</template>

<script>
export default {
  name: "NewUser",

  props: {
    userObj: Object
  },
  data() {
    return {
      isReadonly: true,
      userForm: {
        uid: "",
        des_info: "",
        adminPwd: ""
      },
      rules: {
        adminPwd: { required: true, message: "请输入密码", trigger: "blur" }
      }
    };
  },
  methods: {
    // 编辑
    editUser() {
      this.$refs.userForm.validate(valid => {
        if (valid) {
          this.$api.user.editUser(this.userForm).then(() => {
            this.hide();
            this.resetForm();
            this.$message.success("编辑成功");
          }).catch(() => {});
        }
      });
    },

    // 重置
    resetForm() {
      this.$refs.userForm.resetFields();
      this.$refs.userForm.clearValidate();
    },

    // 隐藏
    hide() {
      this.$emit("hide", this.userForm.des_info);
    },

    // 初始化
    init() {
      Object.assign(this.userForm, {
        uid: this.userObj.uid,
        des_info: this.userObj.desc
      });
    }
  },
  mounted() {
    this.init();
  }
};
</script>

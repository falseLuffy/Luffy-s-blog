<!-- 侧边导航栏 -->
<template>
  <ul class="detail-sub-nav">
    <li v-for="item of navData" :class="{active:navActive==item.id}" @click="navClick(item)" :key="item.id">{{item.name}}</li>
  </ul>
</template>

<script>
/**
 * id: 指向的id
 * name: 显示名称
 */
export default {
  props: ["navData"],
  data() {
    return {
      navActive: "",
      scrollFlag: false
    };
  },

  methods: {
    /**
     * 点击导航
     */
    navClick(item) {
      this.navActive = item.id;
      document.documentElement.scrollTo(0, item.top);
    },

    /**
     * 滚动事件
     */
    scrollEvt() {
      if (this.scrollFlag) {
        return;
      }
      setTimeout(() => {
        this.scrollFlag = false;
        let $html = document.documentElement
          ? document.documentElement
          : document.body;
        let scrollTop = $html.scrollTop;
        let scrollHeight = $html.scrollHeight;
        let clientHeight = $html.clientHeight;

        // 最顶部
        if (scrollTop == 0) {
          this.navActive = this.navData[0].id;
          return;
        }
        // 最底部
        if (scrollHeight - clientHeight == scrollTop) {
          let len = this.navData.length;
          this.navActive = this.navData[len - 1].id;
          return;
        }
        this.navData.find(item => {
          if (item.top <= scrollTop && item.bottom >= scrollTop) {
            this.navActive = item.id;
            return true;
          }
        });
      }, 50);
    }
  },
  mounted() {
    window.addEventListener("scroll", this.scrollEvt);
    this.navActive = this.navData[0].id;
    this.navData.forEach(item => {
      let $dom = document.getElementById(item.id);
      let { top, bottom } = $dom.getBoundingClientRect();
      item.top = top;
      item.bottom = bottom;
    });
  },
  destroyed() {
    window.removeEventListener("scroll", this.scrollEvt);
  }
};
</script>
<style lang='less' scoped>
.detail-sub-nav {
  position: fixed;
  right: 0;
  top: 40%;
  z-index: 99;
  li {
    font-size: 12px;
    cursor: pointer;
    line-height: 40px;
    &:hover {
      color: #409eff;
    }
    a {
      color: inherit;
    }
    &.active {
      position: relative;
      color: #409eff;
      &:after,
      &::before {
        display: block;
        width: 16px;
        height: 16px;
        background-color: #409eff;
        position: absolute;
        left: -21px;
        top: 12px;
        content: "";
        border-radius: 8px;
      }
      &:after {
        width: 8px;
        height: 8px;
        background-color: #fff;
        left: -17px;
        top: 16px;
      }
    }
  }
  &:before {
    width: 2px;
    height: 160px;
    background-color: #e2e5ed;
    content: "";
    display: inline-block;
    position: absolute;
    left: -14px;
  }
}
</style>
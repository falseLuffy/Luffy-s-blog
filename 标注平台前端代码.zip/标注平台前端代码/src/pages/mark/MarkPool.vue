<template>
  <el-container class="task-pool">
    <el-header class="task-info">
      <el-form :inline="true" @submit.native.prevent>
        <el-row class="wood-radio-group">
          <el-form-item label="标注类型：">
            <el-radio-group size="small" v-model="markType" @change="query(1)">
              <el-radio-button
                v-for="item of taskTypes"
                :label="item.id"
                :key="item.id"
              >{{item.name}}</el-radio-button>
            </el-radio-group>
          </el-form-item>
        </el-row>
        <el-row class="wood-radio-group">
          <el-form-item label="参与状态：">
            <el-radio-group size="small" v-model="markStatus" @change="query(1)">
              <el-radio-button
                v-for="item of statusTypes"
                :label="item.id"
                :key="item.id"
              >{{item.name}}</el-radio-button>
            </el-radio-group>
          </el-form-item>
        </el-row>

        <!--任务搜索-->
        <el-form-item class="task-query">
          <el-input
            size="small"
            v-model="taskName"
            placeholder="搜索任务名称"
            :maxlength="30"
            clearable
            suffix-icon="el-icon-search"
            @keyup.enter.native="query(1)"
            @change="query(1)"
          ></el-input>
        </el-form-item>
      </el-form>
    </el-header>

    <el-main class="task-list">
      <!--任务列表-->
      <el-table
        :data="taskList"
        class="task"
        v-loading="loading"
        element-loading-text="正在请求"
      >
        <el-table-column label width="300">
          <template slot-scope="scope">
            <ul>
              <li>
                <i class="iconfont icon-fiveStar" v-if="scope.row.joined"></i>
                <strong class="task-name">{{scope.row.name}}</strong>
              </li>
              <li class="li-type">标注类型:{{scope.row.taskTypeName}}</li>
              <li class="li-type">任务数:{{scope.row.count}}</li>
            </ul>
          </template>
        </el-table-column>
        <el-table-column label min-width="100">
          <template slot-scope="scope">
            <ul>
              <li></li>
              <li class="li-type">开始时间</li>
              <li class="li-type">{{scope.row.createDate}}</li>
            </ul>
          </template>
        </el-table-column>
        <el-table-column label min-width="100">
          <template slot-scope="scope">
            <ul>
              <li></li>
              <li class="li-type">创建人</li>
              <li class="li-type">{{scope.row.createBy}}</li>
            </ul>
          </template>
        </el-table-column>
        <el-table-column label width="140">
          <template>
            <ul>
              <li></li>
              <li class="li-type">标注领取进度</li>
              <li class="li-type">检查领取进度</li>
            </ul>
          </template>
        </el-table-column>
        <el-table-column label width="220">
          <template slot-scope="scope">
            <ul>
              <li></li>
              <li class="li-type">
                <el-progress
                  :percentage="scope.row.count==0?0:parseFloat(getRate(scope.row.markAssignedNum,scope.row.count))"
                ></el-progress>
              </li>
              <li class="li-type">
                <el-progress
                  :percentage="scope.row.count==0?0:parseFloat(getRate(scope.row.checkAssignedNum,scope.row.count))"
                ></el-progress>
              </li>
            </ul>
          </template>
        </el-table-column>

        <el-table-column label min-width="80">
          <template slot-scope="scope">
            <ul>
              <li></li>
              <li class="li-type">
                <el-button
                  type="primary"
                  size="mini"
                  @click="joinMark(scope.row)"
                  :disabled="!scope.row.receiveMark || !authMark"
                >参与标注</el-button>
              </li>
              <li class="li-type">
                <el-button
                  type="primary"
                  size="mini"
                  @click="joinCheck(scope.row)"
                  :disabled="!scope.row.receiveCheck || !authCheck"
                >参与检查</el-button>
              </li>
            </ul>
          </template>
        </el-table-column>
      </el-table>
      <!-- 分页 -->
      <el-pagination
        size="small"
        v-if="total > 5"
        @size-change="sizeChange"
        @current-change="pageChange"
        align="right"
        layout="total, sizes, prev, pager, next, jumper"
        :current-page="page"
        :page-sizes="[5, 10, 20, 40]"
        :page-size="size"
        :total="total"
      ></el-pagination>
    </el-main>

    <!--领取标注任务弹窗-->
    <el-dialog title="领取标注任务" :visible.sync="openMarkDialog" width="400px" class="mark-dialog">
      <span class="title">
        <strong>领取数量</strong>
      </span>
      <el-input-number
        v-model="taskNum"
        controls-position="right"
        :min="1"
        :max="maxTaskNum"
        v-if="openMarkDialog"
        size="small"
      ></el-input-number>
      <span class="max-num">最大领取量：{{maxTaskNum}}</span>
      <span slot="footer" class="dialog-footer">
        <el-button @click="closeMarkDialog" size="small">取 消</el-button>
        <el-button type="primary" @click="sureReceiveMark" size="small">确 定</el-button>
      </span>
    </el-dialog>

    <!--领取检查任务弹窗-->
    <el-dialog title="领取检查任务" :visible.sync="openCheckDialog" width="1000px" class="check-dialog">
      <receive-check-task
        v-if="openCheckDialog"
        :id="taskId"
        @closeCheckDialog="closeCheckDialog"
        @query="query"
      ></receive-check-task>
    </el-dialog>
  </el-container>
</template>
<script>
import ReceiveCheckTask from "./ReceiveCheckTask";
import { mapState, mapMutations } from "vuex";
import { getRate } from "assets/scripts/common";
export default {
  components: {
    ReceiveCheckTask
  },
  computed: {
    ...mapState(["appInfo","user"])
  },
  data() {
    return {
      authMark: false,
      authCheck: false,
      //任务类型
      taskTypes: [{ id: 0, name: "全部" }],
      markType: 0,
      //参与状态
      statusTypes: [
        { id: 1, name: "全部" },
        { id: 2, name: "我参与的" },
        { id: 3, name: "未参与的" }
      ],
      markStatus: 1,
      //搜索任务名称
      taskName: "",

      taskList: [],

      openMarkDialog: false,
      openCheckDialog: false,
      //领取任务数目
      taskNum: 0,
      //最大领取数目
      maxTaskNum: 0,
      page: 1,
      size: 5,
      total: 0,
      loading: false,
      taskId: "",
      getRate: getRate
    };
  },
  methods: {
    ...mapMutations(["showLoading", "closeLoading"]),
    query(resetPage) {
      if (resetPage == 1) {
        this.page = 1;
      }

      if (!this.appInfo.id) {
        return;
      }
      this.loading = true;

      let param = {
        appId: this.appInfo.id,
        page: this.page,
        size: this.size,
        name: this.taskName,
        sort: "createdDate,DESC"
      };
      if (this.markType !== 0) {
        param.taskTypeId = this.markType;
      }
      if (this.markStatus !== 1) {
        param.joined = this.markStatus == 2 ? true : false;
      }
      this.$api.mark
        .receiveTaskList(param)
        .then(res => {
          let { content, totalElements } = res;
          this.taskList = content;
          this.total = totalElements;
          this.loading = false;
        })
        .catch(() => {
          this.loading = false;
        });
    },

    //参与标注
    joinMark(row) {
      this.taskId = row.id;
      this.maxTaskNum = Math.min(
        row.count - row.markAssignedNum,
        row.maxApplyCount
      );
      this.openMarkDialog = true;
    },

    //确认参与标注
    sureReceiveMark() {
      this.showLoading(true);
      this.$api.mark
        .receiveMark({
          taskId: this.taskId,
          count: this.taskNum
        })
        .then(res => {
          this.openMarkDialog = false;
          this.query();
          this.$message.success("标注任务领取成功！");
          this.closeLoading(true);
        })
        .catch(() => {
          this.$message.error("标注任务领取失败！");
          this.closeLoading(true);
        });
    },

    //参与检查
    joinCheck(row) {
      this.taskId = row.id;
      this.openCheckDialog = true;
    },

    //关闭参与标注弹窗
    closeMarkDialog() {
      this.openMarkDialog = false;
    },

    //关闭参与检查弹窗
    closeCheckDialog() {
      this.openCheckDialog = false;
    },

    // taskDetail(row) {
    //   window.sessionStorage.setItem("canGetTaskInfo", JSON.stringify(row));
    //   this.$router.push({ path: "/mark/taskDetail" });
    // },

    sizeChange(size) {
      this.size = size;
      this.query(1);
    },

    pageChange(page) {
      this.page = page;
      this.query();
    },

    //任务类型查询
    queryTaskType() {
      this.taskTypes = [{ id: 0, name: "全部" }];
      if (!this.appInfo.id) {
        return;
      }

      this.$api.task.searchTaskType({ appId: this.appInfo.id }).then(res => {
        res.forEach(item => {
          this.taskTypes.push({
            id: item.id,
            name: item.name
          });
        });
      });
    }
  },
  watch: {
    appInfo() {
      if (this.appInfo.id) {
        this.query(1);
        this.queryTaskType();
      }
    }
  },
  created() {
    this.query(1);
    this.queryTaskType();
     let appName = this.appInfo.name;
     let deputies = JSON.parse(localStorage.deputies);
     let roleList = [];
     deputies.map(item=>{
       if(item.name === appName) {
          roleList.push(item.role)
       } 
     })
    if(roleList.includes('ROLE_DW_MARKER')){
      this.authMark = true
    }
    if(roleList.includes('ROLE_DW_CHECKER')) {
      this.authCheck = true
    }
  }
};
</script>

<style lang="less" scoped>
.task-pool {
  .task-info {
    background-color: #fff;
    height: 100px !important;
    position: relative;
    .task-query {
      position: absolute;
      right: 10px;
      top: 65px;
    }
  }
  .task-list {
    background-color: #fff;
    margin-bottom: 50px;
    .task {
      ul {
        height: 90px;
        li {
          height: 30px;
          line-height: 30px;
          .el-progress {
            line-height: 30px;
          }
          .el-progress.el-progress--line {
            width: 200px;
          }
        }
        .li-type {
          color: #6d6b6b;
        }
      }
    }
  }
  .mark-dialog {
    .title {
      margin-left: 15px;
      margin-right: 5px;
    }
    .max-num {
      margin-left: 15px;
      color: #ccc;
    }
  }
  .check-dialog {
    .el-button.el-button--primary.el-button--small {
      margin-right: 30px;
    }
  }
}
</style>

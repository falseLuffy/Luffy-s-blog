<template>
  <el-container class="choose-checker">
    <el-header class="dialog-header">
      <el-form
        :inline="true"
        :model="queryForm"
        ref="queryForm"
        @submit.native.prevent
        size="small"
      >
        <el-form-item label prop="name">
          <el-input
            v-model="queryForm.value"
            clearable
            :maxlength="30"
            autofocus
            placeholder="请输入检查员名称"
            suffix-icon="el-icon-search"
            @keyup.enter.native="query(1)"
            @change="query(1)"
          ></el-input>
        </el-form-item>
      </el-form>
    </el-header>
    <el-main class="dialog-main">
      <el-table
        size="small"
        ref="checkerTable"
        :data="userData"
        @selection-change="selectChecker"
        @row-click="rowClick"
        align="center"
        border
        height="352"
        v-loading="loading"
        element-loading-text="正在请求"
      >
        <el-table-column type="selection" width="50"></el-table-column>
        <el-table-column label="检查员" :show-overflow-tooltip="true">
          <template slot-scope="scope">
            <span>{{scope.row.name}}（{{scope.row.userId}}）</span>
          </template>
        </el-table-column>
      </el-table>
      <el-pagination
        v-if="total > 10"
        @size-change="sizeChange"
        @current-change="pageChange"
        align="right"
        :current-page="queryForm.page"
        :page-sizes="[10, 20, 50, 100]"
        :page-size="queryForm.size"
        layout="total, sizes, prev, pager, next"
        :total="total"
      ></el-pagination>
    </el-main>
    <el-footer>
      <div align="right">
        <el-button type="primary" size="small" @click="confirm">确定</el-button>
        <el-button size="small" @click="hide">取消</el-button>
      </div>
    </el-footer>
  </el-container>
</template>

<script>
import { mapState, mapMutations } from "vuex";
export default {
  name: "chooseChecker",
  props: ["ids", "accept", "markerIds"],
  data() {
    return {
      loading: false,
      total: 0,
      userData: [],
      queryForm: {
        value: "",
        page: 1,
        size: 10,
        orgId: ""
      },
      distribute: []
    };
  },
  computed: {
    ...mapState(["appInfo"])
  },
  methods: {
    ...mapMutations(["showLoading", "closeLoading"]),
    //分页
    sizeChange(size) {
      this.queryForm.size = size;
      this.query(1);
    },
    pageChange(page) {
      this.queryForm.page = page;
      this.query();
    },

    // 查询
    query(resetPage) {
      if (resetPage == 1) {
        this.queryForm.page = 1;
      }

      this.queryForm.orgId = this.appInfo.orgId;

      this.loading = true;
      this.$api.task
        .checkList(this.queryForm)
        .then(res => {
          this.loading = false;
          let { content, totalElements } = res;
          this.userData = content;
          this.total = totalElements;
          this.updateUserData();
        })
        .catch(() => {
          this.loading = false;
        });
    },

    //确定
    confirm() {
      let len = this.distribute.length;

      if (!len) {
        this.$message.warning("请选择检查人员");
        return;
      }

      if (len > 1) {
        this.$message.warning("只能选一个检查员");
        return;
      }

      let warning = "";
      if (this.markerIds && this.markerIds.includes(this.distribute[0].userId)) {
        warning = "且检查员和标注员有重复";
      }

   
      this.$confirm(
        this.accept
          ? `检查员分配后将不可修改${warning}，确认复检任务吗？`
          : `检查员分配后将不可修改${warning}，确认提交分配吗？`,
        "",
        { lockScroll: false }
      )
        .then(_ => {
          // 复检
          if (this.accept) {
            this.$emit("selected", this.distribute);
          } else {
            // 仅分配检查员
            this.showLoading();
            this.$api.task
              .distributeChecker({
                userId: this.distribute[0].userId,
                ids: this.ids.join(",")
              })
              .then(res => {
                this.closeLoading();
                this.$message.success("检查员分配成功");
                this.$emit("selected", this.distribute);
              })
              .catch(() => {
                this.closeLoading();
              });
          }
        })
        .catch(() => {});
    },

    //选择检查员
    selectChecker(val) {
      if (val.length === 2) {
        delete val[1].clicked;
        this.$refs.checkerTable.toggleRowSelection(val[1]);
        this.$message.warning("只能选一个检查员");
        return;
      }
      this.distribute = val;
    },

    // 点击行toggle复选框
    rowClick(row) {
      row.clicked = !row.clicked;
      this.$refs.checkerTable.toggleRowSelection(row, row.clicked);
    },

    //隐藏
    hide() {
      this.$emit("hide");
    }
  },

  mounted() {
    this.query();
  }
};
</script>

<style rel="stylesheet/less" lang="less">
.el-dialog__body {
  padding: 10px;
}
.choose-checker.el-container {
  .el-header.dialog-header {
    height: 40px !important;
    padding: 0 15px;
  }
  .el-main.dialog-main {
    margin-top: 0;
    padding: 15px;
    min-height: 100px !important;
    margin-bottom: 0;
    .el-table td {
      padding: 3px 0 !important;
    }
    .el-pagination {
      min-height: 30px !important;
    }
    .el-table__empty-block {
      min-height: 168px;
    }
  }
  .el-table__header {
    thead {
      .el-checkbox {
        display: none;
      }
    }
  }
  td {
    cursor: pointer;
  }
}
</style>

// 项目相关接口
import {
  $get,
  $post,
  $put,
  $delete
} from '../http'

//人员查询
const getUserSearch = data => {
  return $get('/base/usercenter/api/users/search', data)
};

//新增人员
const addUser = data => {
  return $post('/base/usercenter/api/users', data)
};

//重置密码
const resetPwd = data => {
  let login = data.login;
  delete data.login;
  return $post('/base/usercenter/api/users/change-password/' + login, data)
}

//获取个人兼职列表
const getDeputiesList = data => {
  return $get('/base/usercenter/api/userdeputies/user', data)
}

// 应用配置-应用管理员获取
const getAppUserList = data => {
  return $get('/base/usercenter/api/userdeputies', data)
}

// 应用配置-应用管理员添加/删除
const actionAppUserList = data => {
  return $post('/base/datawood-manager/api/application/updateAdmin', data)
}

// 应用配置-应添加新应用管理员
const addNewAppUser = data => {
  return $get('/base/usercenter/api/users/search', data)
}

// 应用配置-新建应用
const createApp = data => {
  return $post('/base/datawood-manager/api/application/new', data, true)
}

// 应用配置-应用列表
const appList = data => {
  return $get('/base/datawood-manager/api/application/list', data)
}

// 应用配置-应用详情
const getAppDetail = data => {
  let id = data.id;
  return $get(`/base/datawood-manager/api/application/${id}`, {})
}

// 应用配置-更改详情
const changeAppDetail = data => {
  return $post("/base/datawood-manager/api/application/updateConfig", data, true)
}

// 任务类型-列表
const taskTypesList = data => {
  return $get('/base/datawood-manager/api/task-types', data)
}

// 任务类型-新增/编辑
const addTaskType = data => {
  if (data.id) {
    return $put('/base/datawood-manager/api/task-types', data)
  } else {
    return $post('/base/datawood-manager/api/task-types', data)
  }
}

// 任务类型-详情
const taskTypeDetail = data => {
  let id = data.id;
  return $get(`/base/datawood-manager/api/task-types/${id}`, {})
}

// 任务类型-删除
const delTaskType = data => {
  let id = data.id;
  return $delete(`/base/datawood-manager/api/task-types/${id}`, {})
}

// 应用-删除
const delApp = data => {
  let id = data.id;
  return $delete(`/base/datawood-manager/api/application/${id}`, {})
}

//批量导入用户
const importUsers = data => {
  return $post('/base/usercenter/api/users/import', data, true)
}

//新建处理器
const createProcessor = data => {
  return $post('/base/datawood-manager/api/processors', data);
}

//获取处理器列表
const getProcessorList = data => {
  return $get('/base/datawood-manager/api/processors', data);
}

//编辑处理器
const updateProcessor = data => {
  return $put('/base/datawood-manager/api/processors', data);
}

//新建过程
const createProcess = data => {
  return $post('/base/datawood-manager/api/processes', data);
}

//编辑过程
const updateProcess = data => {
  return $put('/base/datawood-manager/api/processes', data);
}

//获取过程列表
const getProcessList = data => {
  return $get('/base/datawood-manager/api/processes', data);
}

//删除处理器
const delProcessor = data => {
  let id = data.id;
  delete data.id;
  return $delete(`/base/datawood-manager/api/processors/${id}`, data);
}

//删除过程
const delProcess = data => {
  let id = data.id;
  delete data.id;
  return $delete(`/base/datawood-manager/api/processes/${id}`, data);
}

//获取单个处理器内容
const getProcessorDetail = data => {
  let id = data.id;
  delete data.id;
  return $get(`/base/datawood-manager/api/processors/${id}`, data);
}

//获取单个过程内容
const getProcessDetail = data => {
  let id = data.id;
  delete data.id;
  return $get(`/base/datawood-manager/api/processes/${id}`, data);
}

//获取应用下的处理器列表
const getAppProcessor = data =>{
  let id = data.appId;
  delete data.appId;
  return $get(`/base/datawood-manager/api/application/getProcessors/${id}`, data);
}

//更新应用下的处理器配置
const updateAppProcessor = data =>{
  return $post('/base/datawood-manager/api/application/updateProcessorInfo', data);
}

export default {
  getUserSearch,
  addUser,
  resetPwd,
  getDeputiesList,
  getAppUserList,
  actionAppUserList,
  addNewAppUser,
  createApp,
  appList,
  getAppDetail,
  changeAppDetail,
  taskTypesList,
  addTaskType,
  taskTypeDetail,
  delTaskType,
  delApp,
  importUsers,
  createProcessor,
  updateProcessor,
  createProcess,
  updateProcess,
  delProcessor,
  delProcess,
  getProcessorList,
  getProcessList,
  getProcessDetail,
  getAppProcessor,
  updateAppProcessor,
  getProcessorDetail
}
<template>
  <el-container class="task-detail">
    <!-- 内容 -->
    <el-main>
      <!-- 搜索 -->
      <el-form size="small" :inline="true" :model="queryForm" ref="queryForm" class="query-form">
        <el-form-item label="用户名称：" prop="name">
          <el-input
            name="name"
            v-model="queryForm.name"
            placeholder="请输入用户名称"
            :maxlength="30"
            clearable
            @keyup.enter.native="query(1)"
          ></el-input>
        </el-form-item>
        <el-form-item label="日期:" prop="date">
          <el-date-picker
            v-model="queryForm.date"
            type="daterange"
            range-separator="至"
            start-placeholder="开始日期"
            end-placeholder="结束日期"
            format="yyyy-MM-dd"
            value-format="yyyy-MM-dd"
          ></el-date-picker>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" icon="el-icon-search" @click="query(taskType,1)" style>查询</el-button>
        </el-form-item>
      </el-form>

      <!-- tab页 -->
      <el-tabs v-model="taskType" @tab-click="query(taskType,1)">
        <el-tab-pane label="标注统计" name="mark"></el-tab-pane>
        <el-tab-pane label="检查统计" name="check"></el-tab-pane>
      </el-tabs>

      <!-- 标注表格 -->
      <el-table size="small" ref="markForm" :data="markData" align="center" v-show="isMarkShow">
        <el-table-column
          type="index"
          label="序号"
          width="80"
          :index="(index)=>{return (currentPage - 1) * pageSize + index + 1}"
        ></el-table-column>
        <el-table-column prop="account" label="标注员账号"></el-table-column>
        <el-table-column prop="name" label="标注员名称"></el-table-column>
        <el-table-column label="已标注 / 当前任务量" align="center">
          <template slot-scope="scope">{{scope.row.markedNum}} / {{scope.row.totalNum}}</template>
        </el-table-column>
        <el-table-column prop="commitNum" label="已提交" align="center"></el-table-column>
        <el-table-column label="正确数 / 已检查" align="center" v-if="user.proName=='媒资平台'">
          <template slot-scope="scope">{{scope.row.correctNum}} / {{scope.row.checkedNum}}</template>
        </el-table-column>

        <el-table-column prop="checkedNum" label="已检查" align="center" v-if="user.proName=='语义标注'"></el-table-column>
      </el-table>

      <!-- 检查表格 -->
      <el-table size="small" ref="checkForm" :data="checkData" align="center" v-show="!isMarkShow">
        <el-table-column
          type="index"
          label="序号"
          width="80"
          :index="(index)=>{return (currentPage - 1) * pageSize + index + 1}"
        ></el-table-column>
        <el-table-column prop="account" label="检查员账号"></el-table-column>
        <el-table-column prop="name" label="检查员名称"></el-table-column>
        <el-table-column label="已检查 / 当前任务量" align="center">
          <template slot-scope="scope">{{scope.row.checkedWorkload}} / {{scope.row.currentWorkload}}</template>
        </el-table-column>
        <el-table-column prop="completedWorkload" label="已提交" align="center"></el-table-column>
      </el-table>

      <el-pagination
        v-if="total>10"
        @size-change="sizeChange"
        @current-change="pageChange"
        align="right"
        :current-page="currentPage"
        :page-sizes="[10, 20, 50, 100]"
        :page-size="pageSize"
        layout="total, sizes, prev, pager, next, jumper"
        :total="total"
      ></el-pagination>
    </el-main>
  </el-container>
</template>

<script>
import { mapState } from "vuex";
export default {
  data() {
    return {
      markData: [],
      checkData: [],
      isMarkShow: true,
      currentPage: 1,
      pageSize: 10,
      taskType: "mark",
      total: 0,
      queryForm: {
        name: "",
        date: []
      }
    };
  },
  computed: {
    ...mapState(["user"])
  },
  methods: {
    //分页
    sizeChange(size) {
      this.pageSize = size;
      this.query(this.taskType, 1);
    },
    pageChange(page) {
      this.currentPage = page;
      this.query(this.taskType);
    },

    // 查询
    query(taskType, page) {
      if (page) {
        this.currentPage = page;
      }

      let date = this.queryForm.date,
        fromTime = date ? date[0] : "",
        toTime = date ? date[1] : "";
      let param = {
        page: this.currentPage,
        pageSize: this.pageSize,
        name: this.queryForm.name,
        projectId: this.user.projectId,
        fromTime: fromTime ? new Date(fromTime).getTime() - 28800000 : "",
        toTime: toTime ? new Date(toTime).getTime() - 28800000 : ""
      };

      // 标注任务
      if (taskType === "mark") {
        this.isMarkShow = true;
        this.$api.task
          .getMarkDetail(param)
          .then(data => {
            this.total = data.total;
            this.markData = data.list;
          })
          .catch(() => {});
      }

      // 检查任务
      if (taskType === "check") {
        this.isMarkShow = false;
        this.$api.task
          .getCheckDetail(param)
          .then(data => {
            this.total = data.total;
            this.checkData = data.list;
          })
          .catch(() => {});
      }
    }
  },
  mounted() {
    this.query("mark", 1);
  }
};
</script>

<style rel="stylesheet/less" lang="less">
.el-container.task-detail {
  background: #f6f6f6;
  .el-header {
    background: #fff;
  }

  .el-main {
    margin-top: 10px;
    background: #fff;
    padding-top: 20px;
  }
}
</style>








<!-- 音频分层标注 -->
<template>
  <mark-tpl
    class="layer-mark"
    :appType="appType"
    :keysList="keysList"
    :param="param"
    @query="query"
    @setQueryData="setQueryData"
    @valid="valid"
    @save="save"
  >
    <div slot="answer">
      <div class="layer-title">
        <span class="overflow" :title="param.wav_file">{{param.wav_file}}</span>
        <template>
          <el-button
            :disabled="edit === 1"
            size="small"
            type="danger"
            v-if="param.quality === -10"
            @click="availableClick">不可用
          </el-button>
          <el-button
            :disabled="edit === 1"
            size="small"
            type="danger"
            class="btn-plain"
            v-else
            @click="availableClick"
          >标为不可用
          </el-button>

          <div class="labelType" v-if="param.quality === -10 && type === 9">
            <el-select :disabled="edit === 1" v-model="labelType" clearable placeholder="请选择">
              <el-option
                v-for="item in LabelOptions"
                :key="item.id"
                :label="item.label"
                :value="item.value">
              </el-option>
            </el-select>
          </div>

        </template>

      </div>
      <!-- 音频 -->
      <mark-audio
        v-if="audio"
        :audio="audio"
        :leavemusic="leavemusic"
        @ready="audioReady">
      </mark-audio>
      <!-- 表单 -->
      <el-form :model="param" ref="markForm" :rules="rules" :disabled="edit === 1">
        <el-form-item prop="label1">
          <el-input
            size="small"
            placeholder="请输入标签"
            :rows="2"
            v-model="param.label1"
            :readonly="this.readonly"
            :maxlength="200"
          >
            <template slot="prepend">标签1</template>
          </el-input>
        </el-form-item>
        <el-form-item prop="label2">
          <el-input
            size="small"
            placeholder="请输入标签"
            :rows="2"
            v-model="param.label2"
            :readonly="this.readonly"
            :maxlength="200"
          >
            <template slot="prepend">标签2</template>
          </el-input>
        </el-form-item>
        <el-form-item prop="label3">
          <el-input
            size="small"
            placeholder="请输入标签"
            :rows="2"
            v-model="param.label3"
            :readonly="this.readonly"
            :maxlength="200"
          >
            <template slot="prepend">标签3</template>
          </el-input>
        </el-form-item>
      </el-form>
    </div>
  </mark-tpl>
</template>

<script>
  import MarkTpl from "./MarkTpl";
  import MarkAudio from "@/pages/common/LargeAudio";
  import {APPTYPE} from "assets/scripts/code";
  import {formValid, setMarkData} from "assets/scripts/common";

  export default {
    name: "layerMark",
    components: {
      MarkTpl,
      MarkAudio
    },

    data() {
      return {
        edit: 0,
        LabelOptions: [],
        labelType: '',
        keysList: [
          {
            name: "功能说明",
            key: "快捷键"
          },
          {
            name: "播放切换",
            key: "Q"
          },
          {
            name: "保存并下一条",
            key: "空格"
          }
        ],
        type: APPTYPE.YP2,
        appType: APPTYPE.YP,
        mcType: "",
        readonly: false,
        wavesurfer: null,
        param: {
          quality: 0, // "0"好 "-10"坏
          bad: false,
          label1: "",
          label2: "",
          label3: ""
        },
        audio: null,
        rules: {
          // label1: [
          //   { validator: formValid.specialKeyValidator, trigger: "change" }
          // ],
          // label2: [
          //   { validator: formValid.specialKeyValidator, trigger: "change" }
          // ],
          // label3: [
          //   { validator: formValid.specialKeyValidator, trigger: "change" }
          // ]
        },
        showSuccess: false,
        showError: false,
        leavemusic: false
      };
    },
    methods: {
      /**
       * 查询数据
       * @param param 请求参数
       * @param isCookie 是否是缓存
       */
      query(param, isCookie) {
        let id = param.userTaskItemId;
        let dataId = param.dataId;
        delete param.dataId;

        this.$api.mark
          .getMarkFile(param)
          .then(res => {
            res.userTaskItemId = id;
            res.dataId = dataId;
            if (isCookie) {
              setMarkData(id, res);
            } else {
              setMarkData(id, res);
              this.setQueryData(res);
            }
          })
          .catch(() => {
          });
      },

      /**
       * 请求数据后的内容处理
       * @param res 请求的数据
       */
      setQueryData(res) {
        let layerData;
        this.param = this.getResetData();

        let mcType = this.mcType;

        // 1）检查
        if (mcType === 1) {
          layerData = res.checkedData ? res.checkedData : res.markedData;
        } else if (res.markedData && mcType === 0) {
          // 2）标注
          layerData = res.markedData;
        } else if (!res.markedData) {
          // 3）没有标注
          layerData = res.data;
        }

        this.param = Object.assign({}, this.param, layerData);
        this.progress = true;
        this.labelType = this.param.labelType;
        this.param.quality = layerData.quality === -10 ? layerData.quality : 0;

        //音频加载
        this.audio = `${res.sourcePath}${res.data.wav_file}`;

        // 获取数据后，才可以点击下一条，防止快速点击事件
        this.param.clicked = false;
        if (this.param.keycodetimer) {
          this.param.keycodetimer = null;
          clearTimeout(this.param.keycodetimer);
        }
      },

      /**
       * 校验
       */
      valid() {
        return true;
      },

      /**
       * 保存数据
       */
      save() {
        this.param.xmin = 0;
        this.param.xmax = this.duration;
        if (this.type === 9) {
          this.param.labelType = this.labelType
        }
        return true;
      },

      // 坏数据标签字典
      getDict() {
        this.$api.task.getDictTree({dictId: 5, level: 1}).then(res => {
          this.LabelOptions = res[0].children
        })
      },

      /**
       * 重置数据
       */
      getResetData() {
        return {
          bad: false,
          quality: 0, // "0"好 "-10"坏
          label1: "",
          label2: "",
          label3: "",
          wav_file: ""
        };
      },

      /**
       * 文件可用点击
       */
      availableClick() {
        // 只读，检查员不可以改好数据
        if (this.readonly || (this.mcType === 1 && !this.param.quality === -10)) {
          return;
        }
        let nowStatus = this.param.quality;
        if (nowStatus === 0) {
          this.param.quality = -10;
        } else {
          this.param.quality = 0;
        }
        // this.param.quality = -10;
        // this.param.bad = !this.param.bad;
      },

      /**
       * 点击正确/错误按钮
       * @param num 1正确，2错误
       */
      check(num) {
        this.param.checkResult = num;
        this.showResult();
      },

      /**
       * 最大秒赋值
       */
      audioReady(duration, wavesurfer) {
        this.duration = duration;
        this.wavesurfer = wavesurfer;
      },

      /**
       * 组件离开前
       */
      leave() {
        if (this.wavesurfer) {
          this.leavemusic = !this.leavemusic;
        }
      }
    },
    created() {
      let task = JSON.parse(window.sessionStorage.getItem("task"));

      // 1检查,0标注
      this.mcType = task.type;
      if (this.mcType === 1) {
        // 0检查可修改，1检查不能修改
        this.edit = task.checkWithRevision;
      }
      this.readonly = task.readonly;
      this.task = task;
      this.getDict()
    },

    /**
     * 离开前操作，暂停播放音乐
     */
    beforeRouteLeave(to, from, next) {
      this.leave();
      this.$nextTick(() => {
        next();
      });
    }
  };
</script>
<style lang="less" scoped>
  .layer-mark {
    .layer-title {
      .overflow {
        display: inline-block;
        max-width: 60%;
        margin-right: 10px;
        line-height: 22px;
        position: relative;
        top: 5px;
      }
    }

    .labelType {
      display: inline-block
    }
  }
</style>









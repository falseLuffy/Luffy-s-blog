<template>
  <div class="mark-tpl" :class="{'check-tpl':mcType===1}">
    <!-- 头部 -->
    <div class="review-header">
      <div class="left-attr">
        <span class="task-name overflow" :title="taskName">
          <template v-if="appType !== APPTYPE.LAW">{{taskName}}</template>
          <template v-else>
            <span class="num-tip" @click="navClick">
              <i class="iconfont icon-numlist"></i>
              {{currentNum}}/{{totalCount}}
            </span>
          </template>

          <slot name="subtitle"></slot>
        </span>

        <!-- 快捷键 -->
        <template v-if="!readonly">
          <el-tooltip
            size="small"
            placement="bottom"
            effect="light"
            v-if="keysList && keysList.length > 0"
          >
            <ul slot="content" class="mark-keys-content">
              <li v-for="(item,index) of keysList" :key="item.key" :class="{'is-strong':index===0}">
                <span class="first-item">{{item.name}}</span>
                <span>{{item.key}}</span>
              </li>
            </ul>
            <span class="mark-keys">
              <i class="iconfont icon-keys"></i>快捷键
            </span>
          </el-tooltip>
          <el-tooltip size="small" placement="bottom" effect="light" v-else>
            <ul slot="content" class="mark-keys-content">
              <li class="is-strong">
                <span class="first-item">功能说明</span>
                <span>快捷键</span>
              </li>
              <li>
                <span class="first-item">保存并下一条</span>
                <span>空格</span>
              </li>
            </ul>
            <span class="mark-keys">
              <i class="iconfont icon-keys"></i>快捷键
            </span>
          </el-tooltip>
        </template>
        <!-- 题目插槽 -->
        <slot name="title"></slot>
      </div>

      <!-- 右侧操作按钮 -->
      <div class="btn-wrapper">
        <slot name="butterSlot"></slot>

        <template v-if="mcType === 1 && !readonly && checkByUser">
          <el-button size="small" type="primary" @click="check(true)">正确</el-button>
          <el-button size="small" type="primary" @click="check(false)">错误</el-button>
        </template>
        <el-button size="small" v-if="!readonly" type="success" @click="prevAnswer">上一条</el-button>
        <el-button
          size="small"
          v-if="!readonly"
          type="success"
          @click="nextAnswer"
          v-text="nextBtnName"
        ></el-button>
        <!-- 跳标 -->
        <el-button
          size="small"
          type="warning"
          @click="jumpAnswer"
          v-if="(appType === APPTYPE.CV || appType === APPTYPE.LAW) && mcType === 0 && !readonly"
        >跳过标注
        </el-button>
        <template v-if="readonly && appType === APPTYPE.LAW">
          <el-button size="small" type="success" @click="prevAnswer" v-if="currentNum>1">上一条</el-button>
          <el-button
            size="small"
            type="success"
            @click="nextAnswer"
            v-if="currentNum!==totalCount"
          >下一条
          </el-button>
        </template>
        <el-button class="back-btn" type="danger" @click="prevStep">退出{{title}}</el-button>
      </div>
    </div>
    <!-- 内容 -->
    <el-main>
      <div :class="['main-left',{'main-left2':appType === APPTYPE.LAW}]" v-show="leftShow">
        <div class="review-progress">
          <el-pagination
            layout="total,prev, next"
            small
            :pageSize="50"
            :total="totalCount"
            @prev-click="prevPage"
            @next-click="nextPage"
            :current-page="currentPage"
          ></el-pagination>
          <span class="total-page">总 {{totalPages}} 页</span>
        </div>
        <!-- 数字板 -->
        <ul class="review-num" v-if="numList.length">
          <li
            :key="item.id"
            v-for="(item,index) in numList"
            :class="{
              active:(currentPage-1)*50+(index + 1)===currentNum,
              done:item.quality === 0 && (item.status===2 || item.status===4) ,
              wrong:item.quality === 20,
              right:item.quality=== 10,
              bad: item.quality=== -10,
              nobad: item.quality===-11
            }"
            @click="numClick((currentPage-1)*50+(index + 1),true)"
            :title="(currentPage-1)*50+(index + 1)"
          >{{(currentPage-1)*50+(index + 1)}}
          </li>
        </ul>
        <!-- 数字板导航 -->
        <!-- <div class="nav-bar" @click="navClick">
          <i class="iconfont icon-close" v-if="leftShow"></i>
          <i class="iconfont icon-open" v-else></i>
        </div>-->
      </div>

      <div :class="['main-right',{'main-right2':appType === APPTYPE.LAW},{'robot':!checkByUser}]">
        <section class="review-answer">
          <template v-if="mcType === 1 && checkByUser">
            <i class="iconfont icon-success" v-show="showSuccess"></i>
            <i class="iconfont icon-error" v-show="showError"></i>
          </template>
          <!-- 答案插槽 -->
          <slot name="answer"></slot>
        </section>
      </div>
    </el-main>
  </div>
</template>

<script>
  import {mapMutations} from "vuex";
  import {APPTYPE} from "assets/scripts/code";
  import {
    setNavVisible,
    getMarkData,
    setMarkData,
    delMarkData
  } from "assets/scripts/common";

  export default {
    name: "MarkTpl",
    props: {
      keysList: Array, // 快捷键显示
      appType: Number, // 当前的应用，用于特殊的业务需求
      param: Object // 表示标注/检查数据
    },

    data() {
      return {
        leftShow: this.appType !== APPTYPE.LAW, // 左边面板是否显示
        isApp: false, // 是不是应用管理员
        loading: false,
        totalPages: 1,
        APPTYPE: APPTYPE,
        showSuccess: false,
        showError: false,
        isBadFlag: false,
        notBadFlag: false,
        mcType: "",
        jump: false, // 跳标
        temp: false, // 暂存
        numList: [], // 数字题板
        currentNum: 0, // 当前选中
        doneCount: 0, // 已经检查
        currentPage: 0, // 当前页
        totalCount: "", // 题目总数
        markAll: false, // 是否标注完成
        readonly: false, // 表示只读
        taskType: "", // 当前任务类型
        nextBtnName: "保存并下一条",
        nextData: null, // 下一条数据,
        checkByUser: true
      };
    },

    methods: {
      ...mapMutations(["setNavShow", "showLoading", "closeLoading"]),
      /**
       * 导航控制
       */
      navClick() {
        this.leftShow = !this.leftShow;
      },

      /**
       * 离开页面
       */
      leavePage() {
        document.removeEventListener("keyup", this.setKeyUpEvt);
        if (this.isApp) {
          let taskType = sessionStorage.getItem("taskType");
          this.$router.push({
            name: "任务详情",
            params: {taskType: taskType}
          });
        } else {
          let taskQuery = sessionStorage.getItem("taskQuery");
          this.$router.push({
            name: "我的任务",
            params: {taskQuery: taskQuery}
          });
        }
      },

      /**
       * 返回主页
       */
      prevStep() {
        if (this.readonly) {
          this.leavePage();
        } else {
          this.$confirm(
            "此操作将离开该页面,请确认数据已保存,确定离开吗?",
            "提示",
            {
              confirmButtonText: "确定",
              cancelButtonText: "取消",
              type: "info",
              lockScroll: false
            }
          )
            .then(() => {
              this.leavePage();
            })
            .catch(() => {
            });
        }
      },

      /**
       * 获取点击数的信息
       */
      getNumInfo(num) {
        let index = num - (this.currentPage - 1) * 50 - 1;
        let id = this.numList[index] ? this.numList[index].id : "";
        let dataId = this.numList[index] ? this.numList[index].dataId : "";

        return {
          index: index,
          id: id,
          dataId: dataId
        };
      },

      /**
       * 显示左侧数字分页,并缓存上一页和下一页的数据
       * @param pageNum 页数
       * @param boolean 表示翻页求取数据，第一条
       */
      queryPage(pageNum, boolean) {
        let param = {
          page: pageNum,
          size: 50,
          userTaskId: this.userTaskId
        };

        sessionStorage.setItem("markDatas", "{}");

        this.$api.mark
          .getPage(param)
          .then(res => {
            let {lastIndex, userTaskItems} = res;
            let {content, pageable, totalPages, totalElements} = userTaskItems;

            // 当前页赋值
            this.currentPage = pageable.pageNumber + 1;

            // 数字表赋值
            this.numList = content;

            // 总页数赋值
            this.totalPages = totalPages;

            // 第一次请求
            if (pageNum == -1) {
              // 当前请求数字
              this.currentNum = lastIndex;
              this.totalCount = totalElements;

              // 请求上次操作的下一条
              let {id, index, dataId} = this.getNumInfo(this.currentNum);
              this.query({userTaskItemId: id, dataId: dataId}, true);
            }

            // 翻页请求
            if (boolean) {
              let {id, index, dataId} = this.getNumInfo(this.currentNum);
              this.query({userTaskItemId: id, dataId: dataId}, true);
            }
          })
          .catch(() => {
            this.loading = false;
          });
      },

      /**
       * 上一页数字表
       */
      prevPage() {
        let {index, id} = this.getNumInfo(this.currentNum);
        this.otherPageIndex = index;
        this.otherPageId = id;
        this.queryPage(this.currentPage - 1);
      },

      /**
       * 下一页数字表
       */
      nextPage() {
        let {index, id} = this.getNumInfo(this.currentNum);
        this.otherPageIndex = index;
        this.otherPageId = id;
        this.queryPage(this.currentPage + 1);
      },

      /**
       * 查询数据
       * @param param 请求所需参数
       * @param boolean 是否是第一次请求，true是，false否
       */
      query(param, boolean) {
        // 设置缓存字段
        if (boolean) {
          sessionStorage.setItem("markDatas", "{}");
        }

        let markDatas = getMarkData();

        // 获取下一条数据信息
        let nextInfo = {
          index: "",
          id: "",
          dataId: ""
        };
        if (this.totalCount >= this.currentNum + 1) {
          nextInfo = this.getNumInfo(this.currentNum + 1);
        }

        // 1、有当前条
        if (markDatas && markDatas[param.userTaskItemId]) {
          // 执行当条
          this.$emit("setQueryData", markDatas[param.userTaskItemId]);

          // 缓存下条数据
          let nextId = nextInfo.id;
          let nextDataId = nextInfo.dataId;
          if (nextId && !markDatas[nextId]) {
            this.$emit(
              "query",
              {userTaskItemId: nextId, dataId: nextDataId},
              true
            );
          }
        } else {
          // 2、无当前条
          if (markDatas && !markDatas[param.userTaskItemId]) {
            // 请求当条
            this.$emit("query", param);

            // 缓存下条数据
            let nextId = nextInfo.id;
            let nextDataId = nextInfo.dataId;
            if (nextId && !markDatas[nextId]) {
              this.$emit(
                "query",
                {userTaskItemId: nextId, dataId: nextDataId},
                true
              );
            }
          } else {
            this.$emit("query", param);
          }
        }

        // 显示当前的检查状态
        let currentNum = this.currentNum;
        let {id, index} = this.getNumInfo(currentNum);

        if (this.mcType == 1) {
          let status = this.numList[index].quality;
          this.showError = false;
          this.showSuccess = false;
          if (status == 20 || status == -10 || status === -11) {
            this.showError = true;
          }
          if (status == 10) {
            this.showSuccess = true;
          }
        }

        // 判断是否已经全部标注完了
        if ((currentNum === this.totalCount && boolean) || this.totalCount == 1) {
          this.nextBtnName = `完成${this.title}`;
          this.markAll = true;
        }
      },

      /**
       * 上一条答案
       */
      prevAnswer() {
        // 翻页情况
        let currentPageSmallest = (this.currentPage - 1) * 50 + 1; //当前页最小值

        // 第一条不让翻
        if (this.currentNum === 1) {
          this.$message.error("上一条无数据！");
          this.cancelLimit();
          return;
        }

        // 如果下条数据，超过本页最大值则调到下一页
        if (currentPageSmallest > this.currentNum - 1) {
          this.queryPage(this.currentPage - 1);
        }

        //查看上一条
        this.numClick(this.currentNum - 1);
      },

      /**
       * 跳标给提示
       */
      jumpAnswer() {
        this.$confirm("跳标不会保存任何修改的数据，确认跳标吗？", "", {
          lockScroll: false
        })
          .then(() => {
            this.nextAnswer(true);
          })
          .catch(() => {
          });
      },

      /**
       * 下一条答案
       * @param isJump 表示是否跳标
       */
      nextAnswer(isJump) {
        // 防止不停的点击
        if (this.param.clicked) {
          this.$message.info("数据尚未请求完成，请稍后点击");
          return;
        }
        this.param.clicked = true;

        //改变doneCount的值
        const isLastItem = this.currentNum === this.doneCount + 1;
        if (isLastItem && !this.markAll) {
          this.doneCount++;
        }

        // 跳标设置
        this.jump = isJump === true;
        this.numClick(
          this.currentNum === this.totalCount
            ? this.totalCount
            : this.currentNum + 1,
          true
        );
      },

      /**
       * 取消限制
       */
      cancelLimit() {
        var that = this;
        that.param.clicked = false;
        that.param.valid = true;
        that.param.validMsg = "";
        if (that.param.keycodetimer) {
          that.param.keycodetimer = null;
          clearTimeout(that.param.keycodetimer);
        }
      },

      /**
       * 点击左边数字板的数字，显示对应的题目
       * @param num 点击的数字
       * @param next 是否点了下一条按钮
       */
      numClick(num, next) {
        // 如果是音频标注，正在加载音频的时候禁止保存
        if (this.appType === APPTYPE.YP || this.appType === APPTYPE.CN) {
          let audioProgress = window.sessionStorage.getItem("audioProgress");
          if (audioProgress) {
            this.$message.warning("请等音频加载完再操作");
            this.cancelLimit();
            return;
          }
        }

        // 跳过的不保存
        if (!this.jump) {
          if (!this.readonly) {
            // 点自己无效
            if (num === this.currentNum && num !== this.totalCount) {
              this.cancelLimit();
              return;
            }

            // 跳题检测无效
            let {index, id} = this.getNumInfo(num);
            if (id && num > 1) {
              let status = this.numList[index].status;
              // 看一下上一个是否被标注
              let lastIndex = this.getNumInfo(num - 1).index,
                lastStatus = this.numList[lastIndex].status;
              if (
                num >= this.currentNum + 2 &&
                status === 0 &&
                lastStatus === 0
              ) {
                this.$message.warning("不可跳题" + this.title);
                this.cancelLimit();
                return;
              }
            }

            // 检查判断
            if (this.mcType === 1 && !this.showSuccess && !this.showError) {
              if (!next) {
                this.tempData(num);
                this.cancelLimit();
                return;
              } else {
                if (this.checkByUser) {
                  this.$message.warning("请先判断正确性");
                  this.cancelLimit();
                  return;
                } else {
                  this.cancelLimit();
                }
              }
            }

            // 各类型分别校验
            this.param.valid = true;
            this.$emit("valid");

            // 校验不通过
            if (!this.param.valid) {
              if (!next) {
                this.tempData(num);
                this.cancelLimit();
                return;
              } else {
                this.$message.error(this.param.validMsg);
                this.cancelLimit();
                return;
              }
            }

            // 按钮名称更改
            if (num !== this.totalCount) {
              this.nextBtnName = "保存并下一条";
            }
          } else {
            //点自己无效
            if (num === this.currentNum) {
              this.cancelLimit();
              return;
            }
            // 这里是音频标注的查看为了清除regions
            if (this.appType === APPTYPE.YP) {
              this.$emit("valid");
            }
          }
        }

        // 只读和跳标，不保存
        if (this.readonly || this.jump) {
          this.queryNextEnd(num);
        } else {
          this.queryNext(num);
        }
      },

      /**
       * 如果不是点击【保存并下一条】，校验通过就保存，不通过则不保存
       */
      tempData(num) {
        // 暂存数据
        this.temp = true;

        // 按钮名称更改
        if (num != this.totalCount) {
          this.nextBtnName = "保存并下一条";
        }
        // 显示下一条结果
        this.queryNextEnd(num);
      },

      /**
       * 保存当条且检查下一条
       * @param num 点击的数字
       */
      queryNext(num) {
        // 获取保存数据，更改this.param的值
        this.$emit("save");

        // 删除操作数据
        delete this.param.clicked;
        delete this.param.valid;
        delete this.param.validMsg;
        delete this.param.keycodetimer;

        let {id, index} = this.getNumInfo(this.currentNum);
        // 跳页点击情况
        if (
          !id &&
          Math.ceil(this.currentNum / 50) !== this.currentPage &&
          this.otherPageId
        ) {
          id = this.otherPageId;
          index = this.otherPageIndex;
        }
        let req = {
          userTaskItemId: id,
          data: this.param.commitData ? this.param.commitData : this.param
        };

        // 坏数据
        req.quality = this.param.quality === -10 ? -10 : 0;
        if (req.quality === -10) {
          this.isBadFlag = true;
        }
        //  req.quality = this.param.quality=== -10 ? -10 : 0;
        // if (this.param.quality === -10) {
        //   this.isBadFlag = true;
        // }

        // 检查数据
        if (this.mcType === 1) {
          let status = this.numList[index].quality;
          if (status === 20 || this.showError) {
            req.quality = 20;
          }
          if (status === 10 || this.showSuccess) {
            req.quality = 10;
          }

          //坏数据
          if(status === -10 && this.showSuccess){ // 选择正确标签
            req.quality = -10
          }
          if(status === -10 && this.showError){ // 选择错误标签
            req.quality = -11
          }


          /**
           * 非坏数据判断
           * pass true
           */
          if (req.bad) {
            this.notBadFlag = !req.pass;

            //todo
            if (!this.checkByUser) {
              req.misjudgeBad = false;
            } else {
              req.misjudgeBad = !req.pass;
              delete req.pass;
            }
          }
          // 检查员不传外层quality
          // delete req.quality;
        }
        if (req.userTaskItemId) {
          // 常规标注和检查保存
          this.showLoading();
          this.$api.mark
            .saveMarkFile(req)
            .then(res => {
              this.closeLoading();
              //删除当前条的缓存数据
              delMarkData(id);
              this.queryNextEnd(num);
            })
            .catch(() => {
              this.closeLoading();
            });
        }
      },

      /**
       * 保存后的处理操作
       * @param num 保存的条目
       */
      queryNextEnd(num) {
        if (this.nextBtnName === `完成${this.title}` && !this.readonly) {
          this.doneCount = this.totalCount;
          this.cancelLimit();
          this.lastClick = true;
          this.queryPage(this.currentPage);

          this.$confirm(`${this.title}成功`)
            .then(_ => {
              this.$confirm(
                "此操作将离开该页面,请确认数据已保存,确定离开吗?",
                "提示",
                {
                  confirmButtonText: "确定",
                  cancelButtonText: "取消",
                  type: "info"
                }
              )
                .then(() => {
                  //改变当前currentNum
                  this.currentNum = num;
                  this.lastClick = false;
                  this.leavePage();
                })
                .catch(() => {
                  this.lastClick = false;
                });
            })
            .catch(() => {
              this.currentNum = num;
              this.lastClick = false;
            });
        } else {
          // 点击完成设置
          this.numClickDone(num);

          if (!this.readonly) {
            //如果是最后一条则改文本
            this.nextBtnName =
              num === this.totalCount ? `完成${this.title}` : "保存并下一条";
          }
        }
      },

      /**
       * 点击数字后，左右界面更改
       * @param num 点击的数字
       */
      numClickDone(num) {
        // 当前数字颜色更改
        let current = this.getNumInfo(this.currentNum);

        if (!this.jump && current.id && !this.temp && !this.readonly) {
          let status = this.numList[current.index].quality;
          if (status !== 10 && status !== 20) {
            this.numList[current.index].quality = 2;
          }
          // 坏数据
          if (this.isBadFlag) {
            this.numList[current.index].quality = -10; // 坏
            this.isBadFlag = false;
          }

          // 检查员+非坏数据判断
          if (this.mcType == 1 && this.notBadFlag) {
            this.numList[current.index].quality = -11; // 非坏
            this.notBadFlag = false;
          }
        }

        //改变当前currentNum
        this.currentNum = num;
        let {id, dataId} = this.getNumInfo(num);

        // 额外的事件
        if (this.appType == APPTYPE.YP) {
          this.$emit("extraEvt");
        }

        if (id) {
          // 渲染右边下一条任务
          const param = {
            userTaskItemId: id,
            dataId: dataId
          };
          this.query(param);
        } else {
          //如果下条数据，超过本页最大值则跳到下一页
          let currentPageBigest = this.currentPage * 50;
          if (currentPageBigest < this.currentNum) {
            this.queryPage(this.currentPage + 1, true);
          }

          // 如果上条数据
          let currentPageSmallest = (this.currentPage - 1) * 50 + 1; //当前页最小值
          if (currentPageSmallest > this.currentNum) {
            this.queryPage(this.currentPage - 1, true);
          }
        }

        // 暂存标识符
        this.temp = false;
      },

      /**
       * 快捷键设置
       */
      setKeyCode() {
        let that = this;
        // 阻止默认空格事件
        document.addEventListener("keydown", e => {
          const keyCode = e.keyCode || e.which;
          if (keyCode === 32) {
            e.preventDefault();
            e.stopPropagation();
          }
        });
        document.onkeyup = that.debounce(that.setKeyUpEvt, 600);
      },

      // 防抖
      debounce(fn, wait) {
        let timer = null;
        return function () {
          let args = arguments;
          let _this = this;
          clearTimeout(timer);
          timer = setTimeout(() => {
            fn.apply(_this, args);
          }, wait);
        };
      },
      /**
       * 点击空格--保存
       */
      setKeyUpEvt(e) {
        const that = this;
        const keyCode = e.keyCode || e.which;
        // 如果在文本框中则不可以使用快捷键
        var type = e.srcElement ? e.srcElement.type : e.target.type; // 看当前所处环境
        if (type === "text" || type === "textarea") {
          return;
        }

        if (keyCode === 32 && !this.lastClick) {
          // 如果当前页面出现dialog则取消
          if (document.getElementsByClassName("v-modal").length > 0) {
            e.preventDefault();
            return;
          }

          e.preventDefault();
          if (that.param.keycodetimer) {
            return;
          }
          that.param.keycodetimer = that.nextAnswer();
        }
      },

      /**
       * 检查设置值
       */
      check(boolean) {
        this.showSuccess = false;
        this.showError = false;
        let {index} = this.getNumInfo(this.currentNum);
        if (boolean === true) {
          this.showSuccess = true;
          let currentStatus = this.numList[index].quality;
          if (currentStatus !== -10 && currentStatus !== -11) {
            this.numList[index].quality = 10;
          }
        }

        if (boolean === false) {
          this.showError = true;
          let currentStatus = this.numList[index].quality;
          if (currentStatus !== -10 && currentStatus !== -11) {
            this.numList[index].quality = 20;
          }
        }
      }
    },

    created() {
      let task = JSON.parse(sessionStorage.getItem("task"));
      // 任务信息获取
      this.mcType = task.type; // 任务类型，0标注 1检查
      this.readonly = task.readonly; // 只读
      this.totalCount = task.count; // 任务总数
      this.taskName = task.name; // 任务名称
      this.userTaskId = task.userTaskId; // 用户任务ID
      this.doneCount = task.completeCount; // 完成数
      this.isApp = task.isApp;
      this.checkByUser = task.checkByUser;

      if (this.mcType === 0) {
        this.title = "标注";
        if (task.status === -1) {
          this.totalCount = task.count - task.passCount;
          this.doneCount = task.completeCount - task.passCount;
        }
      } else if (this.mcType === 1) {
        this.title = "检查";
      }

      if (this.readonly) {
        this.title = "";
      }

      // 初次请求
      this.queryPage(-1);

      // 快捷键设置
      this.setKeyCode();

      // 清理缓存
      sessionStorage.removeItem("markDatas");

      // 隐藏左侧菜单
      this.$nextTick(() => {
        setNavVisible("hidden", true);
        this.setNavShow(false);
      });
    }
  };
</script>

<style rel="stylesheet/less" lang="less" scoped>
  ul,
  li {
    padding: 0;
    margin: 0;
    list-style: none;
  }

  .mark-tpl {
    position: relative;
    background: #f6f6f6;

    .review-header {
      button {
        margin-top: 6px;
        float: right;
        padding: 7px 13px;
      }
    }

    .el-main {
      margin-top: 10px;
      background: #fff;
      padding: 10px 15px;
      box-sizing: border-box;

      .main-left,
      .main-right {
        float: left;
        box-sizing: border-box;
      }
    }
  }

  .review-header {
    padding: 10px 15px;
    background: #fff;
    overflow: hidden;
    display: flex;

    .left-attr {
      flex: 1;
      display: flex;
      align-items: center;
    }

    .task-name {
      font-size: 14px;
      font-weight: bold;
      display: inline-block;
      max-width: 200px;
      margin-right: 10px;

      .num-tip {
        font-weight: normal;
        cursor: pointer;

        .icon-numlist {
          font-size: 16px;
          margin: 0;
        }
      }
    }

    .mark-keys {
      cursor: pointer;
      margin-left: 10px;

      .icon-keys {
        position: relative;
        top: 4px;
        left: 5px;
      }
    }

    .btn-wrapper {
      width: 340px;
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      justify-content: flex-end;

      .el-button {
        float: left;
      }
    }
  }

  .main-left {
    position: relative;
    width: 18%;
    min-height: 431px;
    padding: 10px;
    background: #f9f7f7;
    margin-bottom: 40px;

    .review-progress {
      .total-page {
        float: right;
        line-height: 35px;
        color: #606266;
        margin-right: 5px;
      }

      .el-pagination {
        display: block;
        min-height: 20px !important;
        margin-top: 5px;
        margin-bottom: 5px;
        float: right;
      }
    }

    .review-keys {
      text-align: center;
      padding-top: 10px;

      li {
        position: relative;
        padding-bottom: 30px;

        button {
          padding: 5px;
          border-radius: 2px;
        }

        &:first-child:after,
        &:nth-child(2):after {
          font-size: 22px;
          color: #ff9800;
          content: "\2193";
          position: absolute;
          left: 49%;
          top: 26px;
        }
      }
    }

    .review-num {
      clear: both;
      overflow: hidden;
      padding: 10px;
      padding-top: 0;
      box-sizing: border-box;

      li {
        list-style: none;
        border: 1px solid #b1b6bf;
        cursor: pointer;
        color: #000;
        float: left;
        margin: 2px;
        width: calc(~"(100% - 56px) / 10");
        height: 32px;
        text-align: center;
        line-height: 32px;
        border-radius: 2px;
        font-size: 12px;
        text-overflow: ellipsis;
        overflow: hidden;

        &:first-child,
        &:nth-child(10n + 1) {
          margin-left: 0;
        }

        &:nth-child(10n) {
          margin-right: 0;
        }

        &.done {
          background: #a9a9a9;
          color: #fff;
          border-color: #a9a9a9;
        }

        &.wrong {
          background: #f56c6c;
          color: #fff;
          border-color: #f56c6c;
        }

        &.right {
          background: #67c23a;
          color: #fff;
          border-color: #67c23a;
        }

        &.jump {
          background: #e6a23c;
          color: #fff;
          border-color: #e6a23c;
        }

        &:hover,
        &.active {
          background: #409eff;
          color: #fff;
          border-color: #409eff;
        }

        &.bad,
        &.nobad {
          position: relative;

          &::before {
            position: absolute;
            content: "坏";
            display: inline-block;
            top: -8px;
            right: -7px;
            color: #fff;
            width: 20px;
            height: 20px;
            background-color: #e6a23c;
            line-height: 29px;
            font-size: 12px;
            text-align: left;
            padding-left: 2px;
          }
        }

        &.nobad::before {
          content: "非坏";
          width: 32px;
          top: -8.5px;
        }
      }
    }

    .review-num {
      li {
        width: calc(~"(100% - 28px) / 5");

        &:nth-child(10n + 1) {
          margin-left: 2px;
        }

        &:nth-child(10n) {
          margin-right: 2px;
        }

        &:nth-child(5n + 1) {
          margin-left: 0;
        }

        &:nth-child(5n) {
          margin-right: 0;
        }
      }
    }

    .nav-bar {
      position: absolute;
      text-align: center;
      line-height: 20px;
      left: 5px;
      top: 5px;
      color: grey;
      cursor: pointer;
      width: 20px;
      height: 20px;
      border: #bab7b7 1px solid;
      border-radius: 5px;

      .iconfont {
        font-size: 18px;
        margin: 0;
      }
    }
  }

  .main-left2 {
    position: absolute;
    top: 70px;
    left: 0px;
    border: #e2dcdc 1px solid;
    min-height: 446px;
    z-index: 2021;
  }

  .main-right {
    margin-left: 10px;
    width: calc(~"82% - 10px");

    .review-answer {
      padding: 10px;
      margin-bottom: 50px;
      overflow: hidden;
    }
  }

  .main-right2 {
    width: 100%;
    margin-left: 0;
  }

  .review-answer {
    padding: 10px 0px;
    border-radius: 2px;
    border: 1px solid #e8e8e8;
    font-size: 14px;
    min-height: 360px;
    margin-bottom: 60px;
  }

  .info-btn {
    max-width: 200px;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .check-tpl {
    .main-right {
      &::before {
        content: "";
        position: absolute;
        right: 40px;
        top: 109px;
        font-size: 16px;
      }

      &::after {
        position: absolute;
        right: 15px;
        top: 99px;
        width: 0;
        height: 0;
        content: "";
        border-color: rgba(64, 158, 255, 0.3) rgba(64, 158, 255, 0.3) transparent transparent;
        border-width: 36px;
        border-style: solid;
      }

      .icon-success,
      .icon-error {
        position: absolute;
        right: 14px;
        top: 102px;
        z-index: 99;
        font-size: 25px;
        color: #67c23a;
      }

      .icon-error {
        color: #f56c6c;
      }
    }

    .robot {
      &:after {
        content: "";
        display: none;
      }
    }

    .check-btn {
      position: absolute;
      right: 293px;
      top: 10px;

      .el-button {
        padding: 7px 18px;
        margin-left: 10px;
      }
    }

    .review-answer {
      margin-top: 25px;
    }
  }

  .mark-keys-content {
    border-bottom: #666 1px solid;

    li {
      border: #666 1px solid;
      border-bottom: none;

      span {
        display: inline-block;
        padding: 5px;
      }

      span.first-item {
        width: 80px;
        border-right: #666 1px solid;
      }

      &.is-strong span {
        font-weight: bolder;
      }
    }
  }
</style>



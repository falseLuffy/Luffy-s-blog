<template>
  <section class="new-process">
    <!--过程基本信息-->
    <el-form
      label-position="right"
      label-width="100px"
      :model="processInfo"
      :rules="rules"
      ref="processInfo"
      size="small"
    >
      <el-form-item label="过程名称" prop="name" placeholder="请输入过程的名称">
        <el-input v-model="processInfo.name" size="small"></el-input>
      </el-form-item>
      <el-form-item label="过程描述" prop="desc">
        <el-input type="textarea" placeholder="请输入过程的简单描述" v-model="processInfo.desc" size="small"></el-input>
      </el-form-item>
      <el-form-item label="引擎类型">
        <el-radio-group v-model="type" size="small">
          <el-radio :label="1">默认引擎</el-radio>
          <!-- <el-radio :label="3">代码片段</el-radio>
          <el-radio :label="6">Restful接口</el-radio>
          <el-radio :label="9">linux可执行</el-radio>-->
        </el-radio-group>
      </el-form-item>
      <!-- <el-form-item label="语言">
        <el-radio-group v-model="processInfo.language" size="small">
          <el-radio :label="3">JavaScript</el-radio>
          <el-radio :label="6">Python</el-radio>
          <el-radio :label="9">Java</el-radio>
        </el-radio-group>
      </el-form-item>
      <el-form-item label="方式">
        <el-radio-group v-model="processInfo.way" size="small">
          <el-radio :label="3">代码</el-radio>
          <el-radio :label="6">文件上传</el-radio>
        </el-radio-group>
      </el-form-item>-->
    </el-form>
    <!--代码块-->
    <codemirror v-model="processInfo.content" :options="cmOptions" class="code"></codemirror>
    <!-- 操作按钮 -->
    <div class="dialog-footer">
      <el-button type="primary" size="small" @click="updateProcess" v-if="isEdit">确 定</el-button>
      <el-button type="primary" size="small" @click="createProcess" v-else>确 定</el-button>
      <el-button @click="cancel" size="small">取 消</el-button>
    </div>
  </section>
</template>
<script>
import { codemirror } from "vue-codemirror";
require("codemirror/mode/python/python.js");
require("codemirror/mode/javascript/javascript.js");
require("codemirror/mode/clike/clike.js");
require("codemirror/mode/shell/shell.js");
require("codemirror/theme/blackboard.css");
require("codemirror/keymap/vim.js");
require("codemirror/keymap/sublime.js");
require("codemirror/keymap/emacs.js");
require("codemirror/addon/hint/show-hint.css");
require("codemirror/addon/hint/show-hint.js");
require("codemirror/addon/hint/javascript-hint.js");
export default {
  components: {
    codemirror
  },
  props:["processorId","processeDetail","isEdit"],
  data() {
    return {
      processInfo: {
        name: "",
        desc: "",
        // language: 3,
        // way: 3,
        content: ""
      },
      type: 1,
      cmOptions: {
        tabSize: 4,
        mode: "text/javascript",
        // mode:"text/x-java",
        // mode:"text/x-sh",
        theme: "blackboard",
        lineNumbers: true,
        line: true,
        extraKeys: { Ctrl: "autocomplete" }
      },
      rules: {
        name: [{ required: true, message: "请输入处理器名称", trigger: "blur" }]
      }
    };
  },
  methods: {
    cancel() {
      this.$emit("cancel");
    },

    //新建处理过程
    createProcess() {
      this.$refs.processInfo.validate(valid => {
        this.processInfo.processorId = this.processorId;
        this.processInfo.engineType = "DEFAULTENGINE";
        if (valid) {
          this.$api.project.createProcess(this.processInfo).then(res => {
            this.$emit("query");
            this.cancel();
          });
        }
      });
    },

    //更新处理过程
    updateProcess(){
       this.$refs.processInfo.validate(valid => {
        this.processInfo.processorId = this.processorId;
        this.processInfo.id = this.processeDetail.id;
        this.processInfo.engineType = "DEFAULTENGINE";
        if (valid) {
          this.$api.project.updateProcess(this.processInfo).then(res => {
            this.$emit("query");
            this.cancel();
          });
        }
      });
    }
  },

  mounted(){
    if(this.processeDetail){
      this.processInfo = this.processeDetail;
    }
  }
};
</script>
<style lang="less">
.new-process {
  .el-input__inner {
    width: 300px;
  }
  .el-textarea__inner {
    width: 300px;
    height: 60px;
  }
  .CodeMirror {
    height: 250px;
    width: 580px;
    margin-left: 40px;
  }
  .dialog-footer {
    margin-top: 10px;
    margin-left: 330px;
  }
  .el-form-item--mini.el-form-item,
  .el-form-item--small.el-form-item {
    margin-bottom: 15px;
  }
}
</style>

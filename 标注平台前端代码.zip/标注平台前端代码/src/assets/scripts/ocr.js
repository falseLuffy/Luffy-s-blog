// 用于ocr的各种配置项
export default {
  // 图片的边框
  imageBorder: {
    color: "#f00",
    width: 3,
    linecap: "round",
    dasharray: "20,10,5,5,5,10",
    linejoin: "miter"
  },
  // 图片指示线
  imageLine: {
    width: 1,
    color: "#f00",
    dasharray: "5, 5"
  },
  // 选择框
  selectOpt: {
    rotationPoint: false,
    deepSelect: true
  },
  lawSelectOpt: {
    rotationPoint: false,
    deepSelect: true,
    points:['lt','rt','lb','rb']
  },
  // 放大缩小参数
  zoomOpt: {
    zoom: [0.05, 10]
  },
  zoomOpt2: {
    zoomEnabled: true,
    maxZoom: 3,
    minZoom: 0.1
  },
  // 中间图片的id
  groupId: {
    id: "ocrDrawGroup"
  },
  // 正在绘制的矩形
  rect: {
    color: '#abcdef',
    opacity: 0.6
  },
  // 多边形样式
  polygo: {
    color: "#3656bf",
    opacity: 0.2
  },
  // 矩形边框
  rectStroke: {
    color: "#f56c6c",
    width: 1,
    linecap: "round",
    linejoin: "miter",
    opacity: 0.4
  },
  // 快捷键说明
  keys: [{
      name: "功能说明",
      key: "快捷键"
    },
    {
      name: "多边形",
      key: "Z"
    },
    {
      name: "矩形",
      key: "A"
    },

    {
      name: "筛选",
      key: "S"
    },
    {
      name: "拖拽",
      key: "X"
    },
    {
      name: "删除",
      key: "Delete"
    },
    {
      name: "保存并下一条",
      key: "空格"
    }
  ],

  lawkeys:[{
    name: "功能说明",
    key: "快捷键"
  },
  {
    name: "多边形",
    key: "ALT"
  },
  {
    name: "矩形",
    key: "CTRL"
  },
  {
    name: "删除",
    key: "D"
  },{
    name: "复选",
    key: "长按SHIFT+鼠标左击"
  },
  {
    name: "区域拖动",
    key: "长按F+鼠标左击"
  },
  {
    name: "保存并下一条",
    key: "空格"
  }],
  drawHeight: "434px",
  areaHeight: "134px",
  attrsList: [{
    label: "手写(H)",
    type: "handwrite",
    writeable: true,
    color: "#ffecf6",
    logo: "H"
  }, {
    label: "印刷(M)",
    type: "machineprint",
    writeable: true,
    color: "#d1d1ff",
    logo: "M"
  }, {
    label: "签章(S)",
    type: "seal",
    writeable: false,
    color: "#ccffff",
    logo: "S"
  }, {
    label: "指印(F)",
    type: "fingerprint",
    writeable: false,
    color: "#cccccc",
    logo: "F"
  }, {
    label: "插图(P)",
    type: "graphics",
    writeable: false,
    color: "#ffeed1",
    logo: "P"
  }, {
    label: "标题(T)",
    type: "title",
    writeable: true,
    color: "#cce5cc",
    logo: "T"
  }],

  arrtsInfo: {
    handwrite: {
      label: "手写(H)",
      type: "handwrite",
      writeable: true,
      color: "#ffecf6",
      logo: "H"
    },
    machineprint: {
      label: "印刷(M)",
      type: "machineprint",
      writeable: true,
      color: "#d1d1ff",
      logo: "M"
    },
    fingerprint:{
      label: "指印(F)",
      type: "fingerprint",
      writeable: false,
      color: "#cccccc",
      logo: "F"
    },
    seal: {
      label: "签章(S)",
      type: "seal",
      writeable: false,
      color: "#ccffff",
      logo: "S"
    },
    graphics: {
      label: "插图(P)",
      type: "graphics",
      writeable: false,
      color: "#ffeed1",
      logo: "P"
    },
    title: {
      label: "标题(T)",
      type: "title",
      writeable: true,
      color: "#cce5cc",
      logo: "T"
    }
  }
}

<!-- 导出 -->
<template>
  <div id="exportList" class="export-list">
    <el-header>
      <div class="export-btns">
        <el-button
          size="small"
          type="success"
          icon="el-icon-sold-out"
          @click="showExportDialog()"
        >导出完成数据</el-button>
        <el-button size="small" type="success" icon="el-icon-refresh" @click="query()">刷新列表</el-button>
      </div>

      <!-- 搜索 -->
      <el-form size="small" :inline="true" ref="queryForm" class="query-form">
        <el-row>
          <el-col :span="13">
            <el-form-item label="创建时间：">
              <el-date-picker
                v-model="createDate"
                type="daterange"
                range-separator="至"
                start-placeholder="开始日期"
                end-placeholder="结束日期"
                format="yyyy-MM-dd"
                value-format="yyyy-MM-dd"
              ></el-date-picker>
            </el-form-item>
          </el-col>
          <el-col :span="9">
            <el-form-item label="导出状态：">
              <el-select v-model="status">
                <el-option
                  v-for="(item) of exportStatusData"
                  :label="item.label"
                  :value="item.value"
                  :key="item.value"
                ></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="2">
            <el-form-item>
              <el-button type="primary" icon="el-icon-search" @click="query(1)">查询</el-button>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </el-header>
    <el-container>
      <!-- 导出列表 -->
      <el-table
        size="small"
        :data="exportData"
        align="center"
        height="380"
        v-loading="loading"
        element-loading-text="正在请求"
      >
        <el-table-column
          type="index"
          label="序号"
          width="50"
          :index="(index)=>{return (page - 1) * size + index + 1}"
        ></el-table-column>
        <el-table-column prop="createdDate" label="导出时间" :formatter="dateFormat" width="140"></el-table-column>
        <el-table-column prop="count" label="导出条数"></el-table-column>
        <el-table-column prop="name" label="文件名" width="150" :show-overflow-tooltip="true"></el-table-column>
        <el-table-column prop="statusDesc" label="导出状态"></el-table-column>
        <el-table-column prop="typeName" label="文件类型"></el-table-column>
        <el-table-column label="操作">
          <template slot-scope="scope">
            <el-button
              size="mini"
              @click="download(scope.row)"
              v-if="!scope.row.immediate && scope.row.status == 1"
            >下载</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-container>

    <!-- 分页 -->
    <el-pagination
      v-if="total > 10"
      @size-change="sizeChange"
      @current-change="pageChange"
      align="right"
      layout="total, sizes, prev, pager, next, jumper"
      :current-page="page"
      :page-sizes="[5, 10, 20, 40]"
      :page-size="size"
      :total="total"
      class="pager-wrapper"
    ></el-pagination>

    <el-dialog
      class="show-export"
      width="400px"
      top="10%"
      title="导出信息确认"
      :modal="false"
      :visible.sync="showExport"
      :lock-scroll="false"
    >
      <el-row>
        <el-form size="small" label-width="150px">
          <el-form-item label="是否立即下载">
            <el-radio-group v-model="immediate">
              <el-radio :label="true">是</el-radio>
              <el-radio :label="false">否</el-radio>
            </el-radio-group>
          </el-form-item>
          <el-form-item label="导出文件类型选择">
            <el-radio-group v-model="type">
              <el-radio :label="0">标注结果</el-radio>
              <el-radio :label="1" v-if="showCheck">检查结果</el-radio>
            </el-radio-group>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="exportList()">确定导出</el-button>
          </el-form-item>
        </el-form>
      </el-row>
    </el-dialog>
    <div class="v-modal" tabindex="0" style="z-index:1" v-if="showExport"></div>
  </div>
</template>

<script>
import { mapMutations } from "vuex";
import { formSubmit } from "assets/scripts/common";

export default {
  props: ["id"],
  data() {
    return {
      loading: false,
      page: 1,
      size: 10,
      total: 0,
      exportData: [],
      createDate: [],
      exportStatusData: [
        { value: "", label: "全部" },
        { value: "1", label: "已导出" },
        { value: "0", label: "导出中" },
        { value: "-1", label: "失败" }
      ],
      modalIndex: 0,
      status: "",
      showExport: false,
      showCheck: true,
      immediate: true,
      type: 0 // 0检查后，1标注后
    };
  },

  methods: {
    ...mapMutations(["showLoading", "closeLoading"]),
    //分页
    sizeChange(size) {
      this.size = size;
      this.query();
    },

    pageChange(page) {
      this.page = page;
      this.query();
    },

    /**
     * 查询
     */
    query(resetPage) {
      if (resetPage === 1) {
        this.page = 1;
      }
      this.loading = true;
      let createDate = this.createDate,
        startDate = createDate ? createDate[0] : "",
        endDate = createDate ? createDate[1] : "";

      let param = {
        sort: "createdDate,DESC",
        taskId: this.id,
        status: this.status,
        page: this.page,
        size: this.size,
        startDate: startDate ? new Date(startDate).getTime() - 28800000 : "",
        endDate: endDate ? new Date(endDate).getTime() - 28800000 : ""
      };

      this.$api.task
        .getExportList(param)
        .then(res => {
          this.loading = false;
          let { content, totalElements } = res;
          this.exportData = content;
          this.total = totalElements;
        })
        .catch(() => {
          this.loading = false;
        });
    },

    /**
     * 导出信息确认
     */
    showExportDialog() {
      this.showExport = true;
    },

    /**
     * 导出
     */
    exportList() {
      let param = {
        taskId: this.id,
        immediate: this.immediate,
        type: this.type
      };
 
      if (this.immediate) {
        this.$api.task.validateExport(param).then(res => {
          formSubmit(
            "base/datawood-processor/api/tasks/export",
            "exportList",
            param
          );
          this.showExport = false;
          this.$confirm(
            "操作成功，请等待文件下载，刷新列表可以查看导出记录！",
            "",
            {
              showCancelButton: false
            }
          );
        },error=>{
          this.showExport = false;
        });
      } else {
        this.showLoading();
        this.$api.task
          .exportTask(param)
          .then(data => {
            this.closeLoading();
            this.$message.success("导出成功");
            this.showExport = false;
            this.query();
          })
          .catch(() => {
            this.closeLoading();
          });
      }
    },

    /**
     * 下载
     * @param item 列表任务信息
     */
    download(item) {
      formSubmit(`base/datawood-processor/download/export/${item.id}`, "exportList");
      this.$message.success("操作成功");
    },

    /**
     * 时间格式化
     */
    dateFormat(row, column) {
      let time = row[column.property];
      if (time === undefined) {
        return "";
      }
      return this.$moment(time).format("YYYY-MM-DD HH:mm:ss");
    }
  },
  created() {
    let task = window.sessionStorage.getItem("taskInfo");
    // 不检查，没有检查结果选项
    if (task && JSON.parse(task) && JSON.parse(task).whetherCheck.code == 40) {
      this.showCheck = false;
    }
    this.query();
  }
};
</script>
<style lang="less" scoped>
.export-btns {
  margin-bottom: 10px;
}
</style>

<style lang='less'>
.export-list {
  .pager-wrapper {
    min-height: 30px !important;
    margin-top: 10px;
  }

  .el-container {
    clear: both;
  }

  .el-table--small td,
  .el-table--small th {
    padding: 5px 0;
  }
}
</style>

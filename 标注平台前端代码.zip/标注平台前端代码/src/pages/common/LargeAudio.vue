<!-- 音频组件 -->
<template>
  <div class="mark-largeaudio">
    <!-- 音频 -->
    <div
      v-show="progress"
      class="mark-progress"
      v-loading="progress"
      element-loading-background="rgba(0, 0, 0, 1)"
      :style="{width:wrapperWidth}"
    ></div>
    <div ref="onewaveform" class="onewave-form" v-if="segNumbers == 1"></div>
    <div class="wave-wrapper" id="waveWrapper" ref="waveWrapper" v-else>
      <div
        class="wave-container"
        :title="cursorTitle"
        :style="{width: waveContainerWidth=='100%'?'100%':waveContainerWidth+'px'}"
        @click="containerClick($event)"
      >
        <div
          id="waveform"
          ref="waveform"
          class="wave-form"
          :style="{width: waveFormWidth=='100%'?'100%':waveFormWidth+'px',left: waveFormLeft+'px'}"
          @click.stop
        ></div>
        <!-- 自定义指示线 -->
        <div class="wave-cursor" v-show="cursorShow" :style="{left: cursorLeft}"></div>
      </div>
    </div>

    <!-- 音频控制按钮 -->
    <div class="audio-group">
      <el-button
        type="primary"
        @click="play"
        size="small"
        :class="{'loop': (activeRegion && activeRegion.id)}"
      >
        <i :class="['iconfont',{'icon-run':runIcon,'icon-pause':!runIcon}]"></i>
        <span>{{playText}}</span>
      </el-button>
      <el-button type="warning" @click="stop" size="small">
        <i class="iconfont icon-stop"></i>重置
      </el-button>

      <div class="volume">
        <div class="volume-content">
          <i class="iconfont icon-voice"></i>
          <el-slider v-model="volume" @change="setVolume"></el-slider>
        </div>
      </div>

      <div class="time-show">
        <span class="time-text">时间：</span>
        <span class="font-primary current-time">{{currentTime}}秒</span>
        <span class="time-text">时长：</span>
        <span class="duration-time">{{duration}}秒</span>
      </div>
    </div>
  </div>
</template>

<script>
require("assets/scripts/large-wavesurfer.min.js");

export default {
  props: ["audio", "leavemusic", "region", "regionRead"],
  data() {
    return {
      color1: "rgba(254, 240, 240, 0.5)", // 已选
      color3: "rgba(230, 189, 189, 0.8)", // 选中
      duration: 0,
      currentTime: 0,
      progress: true,
      percent: 0,
      wavesurfer: null,
      volume: 50,
      playText: "播放",
      activeRegion:null,
      runIcon: true,
      results: null,
      wrapperWidth: "100%",
      waveContainerWidth: "100%",
      waveFormWidth: "100%",
      waveFormScroll: 0,
      waveFormLeft: 0,
      cursorShow: false,
      fromFinish: false,
      fromSeek: false,
      clickWrapperPos: 0,
      cursorLeft: 0,
      cursorTitle: "",
      audioInfo: {},
      rangeBit: 0,
      rangeSecond: 100,
      lastSegTime: 0, // 理想状态下的描述
      segNumbers: 0, // 段的总数
      blobPools: {}, // 请求过的blob
      currentSeg: null //正在播放的段
    };
  },

  watch: {
    // 控制音频源
    audio() {
      this.reset();
      this.audioPlay();
    },

    // 离开页面，停止音频播放
    leavemusic() {
      if (this.leavemusic) {
        this.wavesurfer.destroy();
        document.removeEventListener("keyup", this.setKeys);
      }
    }
  },

  methods: {
    reset() {
      this.clearPools();

      this.duration = 0;
      this.currentTime = 0;
      this.progress = true;
      this.percent = 0;
      this.playText = "播放";
      this.runIcon = true;

      // 大音频参数
      this.clickWrapperPos = 0;
      this.audioInfo = {};
      this.segNumbers = 0;
      this.waveContainerWidth = "100%";
      this.waveFormWidth = "100%";
      this.waveFormScroll = 0;
      this.waveFormLeft = 0;
      this.cursorShow = false;
      this.cursorLeft = 0;
      this.cursorTitle = "";
      this.blobPools = {}; // 请求过的blob
      this.currentSeg = null;
      this.lastSegTime = 0;
    },

    /**
     * 音频初始化
     */
    audioPlay() {
      let that = this;
      if(that.wavesurfer){
        that.wavesurfer.stop()
      }
      
      // 获取音频信息
      that.$api.mark.getAudioInfo({path: that.audio}).then(res => {
          if (!res) {
            return;
          }
          // 音频信息存储
          that.audioInfo = res;

          // 音频时长
          that.duration = parseInt(res.duration / 1000000);

          // 如果音频的长度大于500s分段请求,每段100s
          // 1分钟的字节数[平均] = 比特率(bps) * 时长(s)  /  8
          that.rangeBit =
            that.duration > 500
              ? (that.audioInfo.bitrate * that.rangeSecond) / 8
              : that.audioInfo.size;

          // 总段数
          that.segNumbers = Math.ceil(that.audioInfo.size / that.rangeBit);

          // 段数大于1
          if (that.segNumbers > 1) {
            // 最后一段的秒数记录
            that.lastSegTime =
              that.duration - (that.segNumbers - 1) * that.rangeSecond;
            if (that.lastSegTime < 0) {
              that.segNumbers--;
              that.lastSegTime =
                that.duration - (that.segNumbers - 1) * that.rangeSecond;
            }

            // 容器宽
            that.wrapperWidth = Math.floor(
              that.$refs.waveWrapper.clientWidth - 1
            );

            // 音频宽
            let dWidth = Math.round(that.duration * 20);
            that.waveContainerWidth =
              that.wrapperWidth > dWidth ? that.wrapperWidth : dWidth;

            // waveform的宽度，防止音频过短，渲染不完
            let maxWidth = document
              .getElementById("waveform")
              .getBoundingClientRect().width;
            that.waveFormWidth =
              that.wrapperWidth > maxWidth ? that.wrapperWidth : maxWidth;
          }

          // 创建wavesurfer
          if (!that.wavesurfer) {
            that.$nextTick(() => {
              that.wavesurfer = WaveSurfer.create({
                container:
                  that.$refs[that.segNumbers > 1 ? "waveform" : "onewaveform"],
                waveColor: "#368666", //波纹
                progressColor: "#6d9e8b",
                hideScrollbar: that.segNumbers > 1 ? true : false,
                cursorColor: "#fff",
                height: 80,
                responsive: true,
                scrollParent: true,
                maxCanvasWidth: 50000
              });
            });
          }

          // 第一次获取音频片段
          that.getAudioSeg(1, false, true);
        })
        .catch(() => {});
    },

    /**
     * 根据时间显示字节
     */
    getBitBySecond(s) {
      return (this.audioInfo.bitrate * s) / 8;
    },

    /**
     * 获取音频片段
     * @param segNumber 加载第几段
     * @param justCache 仅仅缓存 true 仅缓存不加载
     * @param initLoad 初始加载
     */
    getAudioSeg(segNumber, justCache, initLoad) {
      let that = this;
      let xhr = new XMLHttpRequest();
      let reqUrl = location.origin;
      xhr.open(
        "GET",
        `${reqUrl}/base/storage/api/audio/${this.audioInfo.code}`,
        true
      );
      xhr.responseType = "arraybuffer";

      let startBit = this.rangeBit * (segNumber - 1);
      let endBit = this.rangeBit * segNumber;
      xhr.setRequestHeader("Range", `bytes=${startBit}-${endBit}`);

      xhr.onload = function() {
        if (this.status === 206 || this.status === 304) {
          let type = xhr.getResponseHeader("Content-Type");
          let blob = new Blob([this.response], { type: type });

          // 加入缓存中
          that.blobPools[segNumber] = {
            url: URL.createObjectURL(blob)
          };

          // 第一次加载第一段
          if (initLoad) {
            that.wavesurfer.load(that.blobPools[segNumber].url);
            that.currentSeg = 1;
            // 音频事件绑定
            that.wavesurferEvt();
          } else if (!justCache) {
            that.currentSeg = segNumber;
            that.wavesurfer.load(that.blobPools[segNumber].url);
          }

          // 滚动条的位置随着加载的位置移动
          if (!justCache && that.segNumbers > 1) {
            that.setScrollPos(segNumber);
          }
        }
      };

      xhr.onerror = function() {
        that.$message.error("音频加载失败，请重试");
        that.progress = false;
      };
      xhr.send();
    },

    /**
     * 根据段设置容器的位置，保证波纹在可见区域
     * @param segNumber 请求段
     */
    setScrollPos(segNumber) {
      let n = segNumber ? segNumber : this.currentSeg;
      let segNumbers = this.segNumbers;

      let end = this.blobPools[n - 1] && this.blobPools[n - 1].endPos;
      // 最后一段
      if (n === segNumbers && this.blobPools[n] && this.blobPools[n].startPos) {
        end = this.blobPools[n].startPos;
      }

      this.waveFormScroll = end ? end : (n - 1) * this.wrapperWidth;
      this.waveFormLeft = this.waveFormScroll;
      this.$refs.waveWrapper.scrollLeft = this.waveFormScroll;
    },

    /**
     * 绑定的wavesurfer事件
     */
    wavesurferEvt() {
      let that = this;
      // 加载时候
      this.wavesurfer.on("loading", percents => {
        that.percent = percents;
        window.sessionStorage.setItem("audioProgress", true);
      });

      // 加载成功
      this.wavesurfer.on("ready", () => {
        let d = that.wavesurfer.getDuration();
        let currentSeg = that.currentSeg;
        let segNumbers = that.segNumbers;

        if (segNumbers > 1) {
          // 这里是一个hack，因为有时候会存在buffer解析不对的情况，不应该超过20s的误差
          let parSecond =
            currentSeg < segNumbers ? that.rangeSecond : that.lastSegTime;
          let differSecond = Math.abs(parSecond - d);
          if (differSecond > 20) {
            that.progress = true;
            that.getAudioSeg(that.currentSeg);
            return;
          }
          // wave的宽度
          let canvasWidth = that.$refs.waveform.querySelector("canvas").width;
          if (canvasWidth) {
            that.waveFormWidth = canvasWidth;
          }
        } else {
          that.duration = parseInt(d);
        }

        that.progress = false;
        window.sessionStorage.removeItem("audioProgress");
        that.$emit("ready", that.duration, that.wavesurfer);

        // 记录当断的位置
        let pools = that.blobPools;

        // 第一段
        if (currentSeg == 1) {
          pools[currentSeg].startPos = 0;
          pools[currentSeg].endPos = that.waveFormWidth;
          // 预加载第二段
          if (segNumbers > 1) {
            that.getAudioSeg(2, true);
          }
        } else if (currentSeg == that.segNumbers) {
          // 最后一段
          pools[currentSeg].startPos =
            that.waveContainerWidth - that.waveFormWidth;
          pools[currentSeg].endPos = that.waveContainerWidth;
          that.setScrollPos();
        } else {
          // 其他段
          that.getAudioSeg(currentSeg + 1, true);
          if (pools[currentSeg - 1] && pools[currentSeg - 1].endPos) {
            pools[currentSeg].startPos = pools[currentSeg - 1].endPos;
            pools[currentSeg].endPos =
              pools[currentSeg].startPos + that.waveFormWidth;
          }
        }

        // 自动播放来的
        if (that.fromFinish) {
          that.fromFinish = false;
          that.play();
        }

        // 点击来的
        if (that.fromSeek) {
          that.cursorShow = false;
          let leftTime = parseFloat(that.waveFormScroll) / 20;
          let moveTime = Math.abs(that.currentTime - leftTime);
          that.wavesurfer.skip(moveTime);

          // 指针的位置移动到当时指的clickWrapperPos位置上，体验更好，这里不能改变波纹的位置，需要改变滚动条的位置
          that.$nextTick(() => {
            let movePos = moveTime * 20;
            let disPos = that.clickWrapperPos - movePos;
            // 左-
            // 右+
            let scrollLeft = that.$refs.waveWrapper.scrollLeft;
            if (disPos > 0) {
              that.$refs.waveWrapper.scrollLeft = scrollLeft - disPos;
            } else {
              that.$refs.waveWrapper.scrollLeft = scrollLeft + Math.abs(disPos);
            }
            that.fromSeek = false;
            that.clickWrapperPos = 0;
          });
        }
      });

      // 播放中
      this.wavesurfer.on("audioprocess", res => {
        // 多段的情况下
        if (that.segNumbers > 1) {
          // 表示的是前面实际播放的
          let leftTime = that.waveFormScroll
            ? parseFloat(that.waveFormScroll) / 20
            : 0;

          // 当前实际的时间
          that.currentTime = parseInt(res + leftTime);

          // wave移动的距离
          let moveDis = Math.round(res * 20);

          // 滚动条的实际位置
          let scrollLeft = that.$refs.waveWrapper.scrollLeft;
          let waveFormLeft = that.waveFormLeft;
          let waveFormWidth = that.waveFormWidth; //wave
          let wrapperWidth = that.wrapperWidth;

          // 第一段的时候 moveDis - scrollLeft;
          // 第二段 waveFormLeft-scrollLeft+moveDis
          let actualDis;
          if (waveFormLeft == 0) {
            actualDis = moveDis - scrollLeft;
          } else {
            actualDis = waveFormLeft - scrollLeft + moveDis;
          }

          // 大于位置
          if (actualDis === wrapperWidth) {
            let dis =
              moveDis >= wrapperWidth
                ? waveFormWidth - moveDis
                : wrapperWidth - moveDis;
            that.$refs.waveWrapper.scrollLeft = scrollLeft + dis;
          }
        } else {
          that.currentTime = parseInt(that.wavesurfer.getCurrentTime());
        }
      });

      // 结束播放
      this.wavesurfer.on("finish", () => {
        that.setPause();

        let segNumbers = that.segNumbers;
        let currentSeg = that.currentSeg;
        if (segNumbers > 1) {
          if (segNumbers == currentSeg) {
            that.currentTime = that.duration;
          } else {
            // 不是最后一段，就加载下一段，然后继续播放
            let nextSeg = currentSeg + 1;
            that.progress = true;
            // 有缓存数据
            if (that.blobPools[nextSeg]) {
              // 加载缓存数据
              that.wavesurfer.load(that.blobPools[nextSeg].url);

              // 更改当前的播放段数
              that.currentSeg = nextSeg;
              that.setScrollPos();
            } else {
              that.getAudioSeg(nextSeg);
            }
            that.fromFinish = true;
          }
        }
      });

      // seek
      this.wavesurfer.on("seek", pos => {
        this.cursorShow = false;
        let res = that.wavesurfer.getCurrentTime();
        let leftTime = parseFloat(that.waveFormScroll) / 20;
        that.currentTime = parseInt(res + leftTime);
      });

      // 加载失败
      this.wavesurfer.on("error", () => {
        this.progress = false;
        window.sessionStorage.removeItem("audioProgress");
      });
    },

    // /**
    //  * 鼠标触发事件TODO
    //  */
    // containerOver(e) {
    //   this.cursorShow = true;
    // },
    // containerMove(e) {
    //   // 白色指示线的显示位置
    //   let offsetX = e.offsetX;
    //   this.cursorLeft = offsetX + "px";

    //   // 获取当前时间节点
    //   this.cursorTitle = parseInt(offsetX / 20);
    // },
    // containerOut(e) {
    //   this.cursorShow = false;
    //   this.cursorTitle = "";
    // },

    /**
     * 随机点击容器
     * @param e 点击的容器e
     */
    containerClick(e) {
      if (this.segNumbers == 1 || this.progress) {
        return;
      }
      // 点击的位置记录
      let layerX = e.layerX;

      // 记录当前鼠标点击的绝对位置
      let scrollLeft = this.$refs.waveWrapper.scrollLeft;
      this.clickWrapperPos = layerX - scrollLeft;

      // 获取点击的时间点
      let currentTime = parseInt(layerX / 20);

      // 获取字节所在
      let { size, duration, bitrate } = this.audioInfo;
      let currentBit = (bitrate * currentTime) / 8;
      let seg = Math.ceil(currentBit / this.rangeBit);

      // 因为音乐的动态性，所以请求的段数会存在误差，这个时候更改请求的段数
      if (seg == this.currentSeg) {
        // let currentMinTime = 60 * (this.currentSeg-1);
        // let currentMaxTime = 60 * this.currentSeg;
        let average = (120 * this.currentSeg - this.rangeSecond) / 2;
        seg = currentTime > average ? seg + 1 : seg - 1;
      }

      // 暂不支持跨段请求
      if (Math.abs(seg - this.currentSeg) > 1) {
        this.$confirm(
          `长音频未缓存状态下仅支持前后跨越${this.rangeSecond}秒的跨段请求`,
          "",
          {
            lockScroll: false
          }
        );
      } else {
        this.currentTime = currentTime;

        // 有缓存数据
        this.progress = true;
        if (this.blobPools[seg]) {
          // 加载缓存数据
          this.wavesurfer.load(this.blobPools[seg].url);

          // 更改当前的播放段数
          this.currentSeg = seg;
          this.setScrollPos();
        } else {
          this.getAudioSeg(seg);
        }

        this.fromSeek = true;
      }
    },

    /**
     * 获取当前的字节
     */
    getNowBit(time) {
      let { bitrate } = this.audioInfo;
      return bitrate * time * 128;
    },

    /**
     * 设置暂停
     * @param boolean true 表示仅仅改文字
     */
    setPause(type) {
      this.wavesurfer.pause();
      this.runIcon = true;
      this.playText = "播放";
    },

    /**
     * 设置播放
     */
    setPlay() {
      this.wavesurfer.play();
      this.runIcon = false;
      this.playText = "暂停";
    },

    /**
     * 播放/暂停切换
     */
    play() {
      if (this.progress) {
        this.$message.warning("请等音频加载完再操作");
        return;
      }
      if (this.playText === "播放") {
        if (this.currentTime == this.duration) {
          this.wavesurfer.stop();
        }
        this.setPlay();
      } else {
        this.setPause();
      }
    },

    /**
     * 停止播放
     */
    stop() {
      if (this.progress) {
        this.$message.warning("请等音频加载完再操作");
        return;
      }
      this.wavesurfer.stop();
      this.runIcon = true;
      this.playText = "播放";

      if (this.segNumbers > 1) {
        this.setScrollPos();
      }
    },

    /**
     * 设置音量
     * @param value 音量大小
     */
    setVolume(value) {
      this.volume = value;
      this.wavesurfer.setVolume(value / 100);
    },

    /**
     * 快捷键设置
     */
    setKeys(e) {
      let that = this;
      const keyCode = e.keyCode || e.which;

      // 如果在文本框中则不可以使用快捷键
      var type = e.srcElement ? e.srcElement.type : e.target.type; // 看当前所处环境

      if (type === "text" || type === "textarea") {
        return;
      }

      if (document.getElementsByClassName("v-modal").length > 0) {
        e.preventDefault();
        return;
      }

      // 点击Q键
      if (keyCode === 81) {
        e.preventDefault();
        this.play();
      }
    },

    /**
     * 清除缓存
     */
    clearPools() {
      for (var i in this.blobPools) {
        window.URL.revokeObjectURL(this.blobPools[i]);
      }
      this.blobPools = {};
    }
  },

  created() {
    this.$nextTick(() => {
      this.audioPlay();
      document.addEventListener("keyup", this.setKeys);
    });
  },

  destroyed() {
    this.clearPools();
  }
};
</script>
<style rel="stylesheet/less"  lang="less" scoped>
.mark-largeaudio {
  position: relative;
  .wave-wrapper {
    height: 80px;
    overflow-x: auto;
    overflow-y: hidden;
    position: relative;
    box-sizing: border-box;
    margin: 10px auto 0;
    .wave-container {
      position: absolute;
      top: 0;
      left: 0;
      height: 80px;
      background: #000;
      box-sizing: border-box;
      cursor: pointer;
      &::after {
        position: absolute;
        content: "";
        width: 100%;
        height: 1px;
        background: #368666;
        display: inline-block;
        top: 50%;
        left: 1px;
        z-index: 9;
      }
      .wave-cursor {
        position: absolute;
        content: "";
        width: 1px;
        height: 80px;
        background: #368666;
        display: inline-block;
        top: 0;
        left: 0;
        z-index: 2000;
      }
    }
  }
  .onewave-form {
    width: 100%;
    height: 80px;
    position: relative;
    background: #000;

    background-repeat: no-repeat;
    background-size: 100% 100%;
    margin: 20px auto 10px;
    .el-progress {
      position: absolute;
      top: 32px;
      left: 0;
      width: 100%;
      color: #fff;
    }
  }
  .wave-form {
    height: 80px;
    position: absolute;
    background: #000;
    background-repeat: no-repeat;
    background-size: 100% 100%;
    z-index: 10;
    .el-progress {
      position: absolute;
      top: 32px;
      left: 0;
      width: 100%;
      color: #fff;
    }
  }
  .audio-group {
    margin-bottom: 20px;
    button {
      padding: 6px 10px 6px 25px;
      position: relative;
      &.loop {
        background-color: #3ae33f;
        border-color: #3ae33f;
      }
      .iconfont {
        position: absolute;
        top: 4px;
        left: 7px;
        font-size: 16px;
      }
    }
    .volume {
      display: inline-block;
      width: 100px;
      vertical-align: middle;
      margin-left: 30px;
      position: relative;
      .iconfont.icon-voice {
        position: absolute;
        left: -25px;
        top: 10px;
        color: #585757;
      }
    }
    .time-show {
      float: right;
      line-height: 38px;
      .time-text {
        display: inline-block;
        width: 42px;
      }
      .current-time,
      .duration-time {
        margin-right: 15px;
        font-size: 16px;
        font-weight: bold;
      }
      .current-time {
        display: inline-block;
        margin-right: 0px;
        width: 75px;
      }
    }
  }
  .mark-progress {
    position: absolute !important;
    left: 0;
    right: 0;
    top: 0;
    height: 70px;
    z-index: 999;
  }
}
</style>

<style lang="less" scoped>
.volume .el-slider__button {
  width: 12px;
  height: 12px;
}
.el-radio + .el-radio {
  margin-left: 15px;
}
.mark-region-end {
  position: relative;
  background-color: rgba(254, 255, 255, 0.4) !important;
}
.wavesurfer-region {
  cursor: pointer;
  &::before,
  &::after {
    width: 6px;
    height: 6px;
    border-radius: 5px;
    background-color: blue;
    position: absolute;
    content: "";
    display: inline-block;
    bottom: 0;
    z-index: 9999;
  }
  &::before {
    left: -3px;
  }
  &::after {
    background-color: red;
    right: -3px;
  }
}
.mark-region-select {
  background-color: rgba(230, 189, 189, 0.7) !important;
}
</style>

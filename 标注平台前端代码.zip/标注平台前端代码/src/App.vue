<template>
  <div id="app" class="main-mark">
    <div class="loading home-loading" v-loading="loading" 
         element-loading-text="正在请求..." 
         element-loading-spinner="el-icon-loading" 
         element-loading-background="rgba(0, 0, 0, 0.8)">
    </div>
    <router-view/>
  </div>
</template>

<script>
import { mapState } from "vuex"
export default {
  name: "App",
  computed: {
    ...mapState(["loading"])
  }
};
</script>

<style lang="less">
.loading.el-loading-parent--relative {
  position: inherit!important;
}
.home-loading .el-loading-mask{
  position: fixed;
  z-index: 5000;
}
</style>




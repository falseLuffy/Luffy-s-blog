// 主要用于别名的定义
export const APICODE = {
  '10001': "输入的手机号或验证码错误",
  '10002': "输入的用户名或密码错误",
  '10003': "必须输入验证码",
  '10004': "输入的验证码无效",
  '10005': "验证码过期",
  '10006': "验证码发送间隔过短,一分钟内只能发送一次",
  '10007': "验证码类型不支持",
  '10010': "未输入手机号",
  '10011': "手机号码格式不正确",
  '10012': "邮箱格式错误",
  '10013': "手机号已被注册",
  '10014': "手机未注册",
  '10020': "登录名已经被占用",
  '10021': "邮箱已经被占用",
  '10022': "密码长度必须在8-100之间",
  '10023': '用户不存在',
  '10024': '应用管理员无权操作其他应用用户',
  '10025': '用户被锁定',
  '10026': '用户已注销',
  '10027': '用户已删除',
  '10028': '用户未使用邮箱激活',
  '10040': '簇群不存在',
  '10041': '内置簇群，不能删除',
  '10042': '内置簇群，不能修改',
  '10100': "角色不存在",
  '10200': "角色不存在",
  '10300': "兼职存在，重复添加",
  '10301': "兼职不存在",
  'DW-13000': '请求头必须包含所有认证参数，包含X-AppId,X-AppKey,X-Timestamp,X-Sign',
  'DW-13001': '应用ID不存在',
  'DW-13002': '签名认证失败',
  'DW-13003': '时间格式错误',
  'DW-13004': '签名过期',
  'DW-13005': '任务未完成，无法获取结果',
  'DW-11000': '任务类型不存在',
  'DW-14000': '任务不存在',
  'DW-14002': '创建任务时，任务名称不能重复',
  'DW-17000': '路径已经被占用'
}

// app应用-用于有特殊需求的
export const APPTYPE = {
  CV: 1, // CV标注，显示跳标按钮
  OCR: 2, // OCR标注，显示快捷键面板
  YP: 3, // 音频标注，音频加载的时候，不可以点快捷保存
  RULE: 4, // 知识点标注，用于跳标
  CN: 5, // 中文标注
  EN: 6, // 英文标注
  LAW: 7, // 政法OCR标注
  ADDRESS: 8, //地址标注,
  YP2:9 //音频标注 智能服务
}

// datawood的用户中文
export const roleName = {
  'ROLE_USER': '普通用户',
  'ROLE_DW_APPADMIN': '应用管理员',
  'ROLE_DW_SUPERADMIN': '超级管理员'
}

// datawood的用户英文
export const datawoodRole = {
  user: 'ROLE_USER',
  marker: "ROLE_DW_MARKER",
  checker: "ROLE_DW_CHECKER",
  appAdmin: 'ROLE_DW_APPADMIN',
  superAdmin: 'ROLE_DW_SUPERADMIN'
}

export const APPID = "ec2642bb5add4127bc8a7d08a85fd45b";


// 英文标注的替换音
export const enDataList = [{
    label: "1",
    options: [{
      value: "aa",
      label: "aa"
    }, {
      value: "ay",
      label: "ay"
    }, {
      value: "eh",
      label: "eh"
    }, {
      value: "ir",
      label: "ir"
    }, {
      value: "ng",
      label: "ng"
    }, {
      value: "sh",
      label: "sh"
    }, {
      value: "uw",
      label: "uw"
    }]
  },
  {
    label: "2",
    options: [{
        value: "ae",
        label: "ae"
      },
      {
        value: "b",
        label: "b"
      },
      {
        value: "er",
        label: "er"
      },
      {
        value: "iy",
        label: "iy"
      },
      {
        value: "oo",
        label: "oo"
      },
      {
        value: "t",
        label: "t"
      },
      {
        value: "v",
        label: "v"
      },
    ]
  },
  {
    label: "3",
    options: [{
        value: "ah",
        label: "ah"
      },
      {
        value: "ch",
        label: "ch"
      },
      {
        value: "ey",
        label: "ey"
      },
      {
        value: "jh",
        label: "jh"
      },
      {
        value: "ow",
        label: "ow"
      },
      {
        value: "th",
        label: "th"
      },
      {
        value: "w",
        label: "w"
      }
    ]
  },
  {
    label: "4",
    options: [{
        value: "ao",
        label: "ao"
      },
      {
        value: "d",
        label: "d"
      },
      {
        value: "f",
        label: "f"
      },
      {
        value: "k",
        label: "k"
      },
      {
        value: "oy",
        label: "oy"
      },
      {
        value: "tr",
        label: "tr"
      },
      {
        value: "y",
        label: "y"
      }
    ]
  },
  {
    label: "5",
    options: [{
        value: "ar",
        label: "ar"
      },
      {
        value: "dh",
        label: "dh"
      },
      {
        value: "g",
        label: "g"
      },
      {
        value: "l(L)",
        label: "l(L)"
      },
      {
        value: "p",
        label: "p"
      },
      {
        value: "ts",
        label: "ts"
      },
      {
        value: "z",
        label: "z"
      }
    ]
  },
  {
    label: "6",
    options: [{
        value: "aw",
        label: "aw"
      },
      {
        value: "dr",
        label: "dr"
      },
      {
        value: "hh",
        label: "hh"
      },
      {
        value: "m",
        label: "m"
      },
      {
        value: "r",
        label: "r"
      },
      {
        value: "uh",
        label: "uh"
      },
      {
        value: "zh",
        label: "zh"
      }
    ]
  },
  {
    label: "7",
    options: [{
        value: "ax",
        label: "ax"
      },
      {
        value: "dz",
        label: "dz"
      },
      {
        value: "ih",
        label: "ih"
      },
      {
        value: "n",
        label: "n"
      },
      {
        value: "s",
        label: "s"
      },
      {
        value: "ur",
        label: "ur"
      },
      {
        value: "fill",
        label: "fill"
      }
    ]
  }
]


export default {
  APICODE,
  APPTYPE,
  roleName,
  datawoodRole,
  APPID,
  enDataList
}

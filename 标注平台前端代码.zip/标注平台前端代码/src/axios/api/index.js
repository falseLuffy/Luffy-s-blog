import user from './user'
import project from './project'
import task from './task'
import mark from './mark'
export default {
  user,
  project,
  task,
  mark
}

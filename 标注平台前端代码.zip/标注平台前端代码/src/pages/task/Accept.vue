<template>
  <el-container class="task-accept">
    <!-- 头部按钮 -->
    <el-header height="5%">
      <el-button class="back-btn" size="small" @click="cancel">返回</el-button>
    </el-header>
    <!-- 主体内容 -->
    <el-main>
      <!-- 筛选条件 -->
      <el-row class="accept-form">
        <div class="form-btns">
          <!-- 验收 -->
          <el-button type="primary" @click="batchCheck" v-if="checkCode==41" size="small">
            <i class="iconfont icon-rysh"></i>批量复检
          </el-button>
          <el-button type="success" @click="batchAccept" size="small">
            <i class="iconfont icon-yes"></i>批量验收
          </el-button>
        </div>
      </el-row>

      <!-- 数据验收 -->
      <div id="accept" class="accept-grid">
        <el-table
          size="small"
          :data="acceptData"
          align="center"
          @selection-change="changeAcceptFun"
          border
          height="430"
          v-loading="loading"
          element-loading-text="正在请求"
        >
          <el-table-column type="selection" width="50"></el-table-column>
          <el-table-column
            type="index"
            label="序号"
            width="50"
            :index="(index)=>{return (page - 1) * size + index + 1}"
          ></el-table-column>
          <el-table-column prop="checkerName" width="90" label="检查员" :show-overflow-tooltip="true"></el-table-column>
          <el-table-column prop="markerName" width="90" label="标注员" :show-overflow-tooltip="true"></el-table-column>
          <el-table-column prop="count" width="70" label="任务总数"></el-table-column>
          <el-table-column prop="checkRound" width="70" label="检查轮数" v-if="checkCode==41"></el-table-column>
          <el-table-column prop="checkRate"  width="110" label="有效数据检查率" v-if="checkCode==41"></el-table-column>
          <el-table-column label="合格率" width="60" v-if="checkCode==41">
            <template slot-scope="scope">
              <span>{{scope.row.accuracy}}%</span>
              <!-- <span v-text="getRate(scope.row.passCount,scope.row.count)"></span> -->
            </template>
          </el-table-column>
          <el-table-column prop="badCount" width="80" label="坏数据数"></el-table-column>
          <el-table-column prop="misjudgeBadCount" width="90" label="错判数据数"></el-table-column>
          <el-table-column prop="commitDate" label="提交时间" :formatter="dateFormat" width="140"></el-table-column>
          <el-table-column label="操作">
            <template slot-scope="scope">
              <el-button
                size="mini"
                type="primary"
                @click="singleCheck(scope.row.userTaskId,scope.row.markerId)"
                v-if="checkCode==41"
              >复检</el-button>
              <el-button size="mini" type="primary" @click="singleAccept(scope.row.userTaskId)">验收</el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>

      <!-- 分页 -->
      <el-pagination
        v-if="total > 10"
        @size-change="sizeChange"
        @current-change="pageChange"
        align="right"
        layout="total, sizes, prev, pager, next, jumper"
        :current-page="page"
        :page-sizes="[5, 10, 20, 40]"
        :page-size="size"
        :total="total"
        class="pager-wrapper"
      ></el-pagination>
    </el-main>

    <!-- 选择检查员 -->
    <el-dialog
      width="680px"
      top="2%"
      title="选择复检检查员"
      :visible.sync="showChecker"
      :lock-scroll="false"
    >
      <choose-checker
        v-if="showChecker"
        @selected="selectChecker"
        @hide="hideChecker"
        :ids="checkIds"
        :markerIds="markerIds"
        :accept="true"
      ></choose-checker>
    </el-dialog>
  </el-container>
</template>
}
<script>
import { mapMutations } from "vuex";
import { getRate } from "assets/scripts/common";
import ChooseChecker from "./ChooseChecker";
export default {
  components: { ChooseChecker },
  data() {
    return {
      getRate: getRate,
      id: null,
      loading: false,
      page: 1,
      size: 10,
      total: 0,
      acceptData: [],
      acceptSelectArr: [],
      checkIds: [], // 选择的检查任务id
      markerIds: [], // 选中的标注员的用户id
      showChecker: false,
      checkCode: null
    };
  },
  methods: {
    ...mapMutations(["showLoading", "closeLoading"]),
    //返回
    cancel() {
      this.$router.push({ path: "/task/list" });
    },

    //分页
    sizeChange(size) {
      this.size = size;
      this.query(1);
    },
    pageChange(page) {
      this.page = page;
      this.query();
    },

    // 获取验收数据
    query(page) {
      if (page) {
        this.page = 1;
      }
      let param = {
        id: this.id,
        page: this.page,
        size: this.size
      };

      this.$api.task
        .acceptList(param)
        .then(res => {
          this.loading = false;
          this.acceptData = res.content;
          this.acceptData.forEach(item => {
            item.checkRate = item.checkRate ? item.checkRate + "%" : "0%";
          });
          this.total = res.totalElements;
        })
        .catch(() => {
          this.loading = false;
        });
    },

    // 选择的条目
    changeAcceptFun(val) {
      this.acceptSelectArr = val;
    },

    // 选择检查员后再执行复检操作
    selectChecker(user) {
      this.showChecker = false;

      // 复检
      this.showLoading();
      this.$api.task
        .reCheckTask({
          ids: this.checkIds,
          userId: user[0].userId
        })
        .then(res => {
          this.closeLoading();
          this.query(1);
          this.$message.success("复检成功");
        })
        .catch(() => {});
    },

    // 单个检查
    singleCheck(userTaskId, markerId) {
      this.checkIds = [userTaskId];
      this.markerIds = [markerId];

      this.showChecker = true;
    },

    // 批量检查
    batchCheck() {
      let len = this.acceptSelectArr.length;
      if (!len) {
        this.$message.warning("请至少选择一条数据");
        return;
      }
      this.checkIds = [];
      this.markerIds = [];

      this.acceptSelectArr.forEach(item => {
        this.checkIds.push(item.userTaskId);
        this.markerIds.push(item.markerId);
      });
      this.showChecker = true;
    },

    // 单个验收
    singleAccept(userTaskId) {
      this.$confirm("确认验收该任务吗？", "", { lockScroll: false })
        .then(() => {
          this.acceptTask([userTaskId]);
        })
        .catch(() => {});
    },

    // 批量验收
    batchAccept() {
      let len = this.acceptSelectArr.length;
      if (!len) {
        this.$message.warning("请至少选择一条数据");
        return;
      }
      this.$confirm("确认批量验收任务吗？", "", { lockScroll: false })
        .then(() => {
          let ids = [];
          this.acceptSelectArr.forEach(item => {
            ids.push(item.userTaskId);
          });
          this.acceptTask(ids);
        })
        .catch(() => {});
    },

    // 验收任务
    acceptTask(ids) {
      this.showLoading();
      this.$api.task
        .acceptTask({
          ids: ids
        })
        .then(res => {
          this.closeLoading();
          this.query(1);
          this.$message.success("验收成功");
        })
        .catch(() => {
          this.closeLoading();
        });
    },

    // 隐藏检查员分配
    hideChecker() {
      this.showChecker = false;
    },

    // 时间格式化
    dateFormat(row, column) {
      let time = row[column.property];
      if (time === undefined || !time) {
        return "";
      }
      return this.$moment(time).format("YYYY-MM-DD HH:mm");
    }
  },
  created() {
    this.taskInfo = JSON.parse(window.sessionStorage.getItem("taskInfo"));
    this.id = this.taskInfo.id;
    this.checkCode = this.taskInfo.whetherCheck.code;
    // this.id = this.$route.params.taskId;
    // this.checkCode = this.$route.params.checkCode;
    this.query();
  }
};
</script>

<style rel="stylesheet/less" lang="less">
.el-container.task-accept {
  background: #f6f6f6;
  .el-header {
    background: #fff;
    padding: 10px 15px;
  }

  .el-main {
    font-size: 14px;
    background: #fff;
    padding: 15px;
    min-height: 460px;
    margin-top: 10px;

    .form-btns {
      float: right;
      button {
        padding: 8px 6px;
        margin-left: 10px;
      }

      .iconfont {
        font-size: 14px;
      }
    }
    .accept-grid {
      padding: 10px 0px;
      margin-bottom: 30px;
      .el-row {
        margin: 10px 0 20px 0;
      }
      .el-table__empty-block {
        min-height: 270px;
      }
      .el-table--small td,
      .el-table--small th {
        padding: 7px 0;
      }
    }

    .el-table th {
      background: #f5f7fa;
    }
  }

  .font-primary {
    font-weight: bold;
  }
}
</style>










<template>
  <div class="export-list">
    <download-excel :data="exportData" :fields="json_fields" :name="name">
      <span>导出列表</span>
    </download-excel>
  </div>
</template>
<script>
export default {
  props: ["exportData", "json_fields", "name"]
};
</script>
<style lang="less" scoped>
.export-list {
  span {
    display: inline-block;
    line-height: 12px;
    color: #fff;
    background-color: #409eff;
    padding: 6px 8px;
    border-radius: 4px;
    &:hover {
      cursor: pointer;
    }
  }
}
</style>


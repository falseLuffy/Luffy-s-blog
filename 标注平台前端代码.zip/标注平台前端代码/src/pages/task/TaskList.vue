<template>
  <el-container class="task-list">
    <el-header height="10%">
      <!-- 一级查询条件 -->
      <el-form
        size="small"
        :inline="true"
        label-width="85px"
        :model="queryForm"
        ref="queryForm"
        class="query-form"
        @submit.native.prevent
        v-show="queryFormShow"
      >
        <el-row class="header-row">
          <el-form-item label="标注类型：" prop="taskType">
            <el-radio-group v-model="queryForm.taskType" @change="query(1)">
              <el-radio-button
                v-for="item of taskTypes"
                :label="item.id"
                :key="item.id"
              >{{item.name}}</el-radio-button>
            </el-radio-group>
          </el-form-item>
        </el-row>
        <el-row class="header-row">
          <el-form-item label="选择时间：" prop="taskTime">
            <el-date-picker
              @change="query(1)"
              v-model="queryForm.taskTime"
              type="daterange"
              range-separator="至"
              start-placeholder="开始日期"
              end-placeholder="结束日期"
              format="yyyy-MM-dd"
              value-format="yyyy-MM-dd"
            ></el-date-picker>
          </el-form-item>
        </el-row>

        <!-- <el-form-item label="数据筛选：" prop="data1">
          <el-select v-model="queryForm.data1"></el-select>
        </el-form-item>
        <el-form-item label prop="data2">
          <el-input type="number" v-model="queryForm.data2" :precision="0" placeholder="最小值"></el-input>
        </el-form-item>
        <el-form-item label prop="data3">
          <el-input type="number" v-model="queryForm.data3" :precision="0" placeholder="最大值"></el-input>
        </el-form-item>

        <el-form-item>
          <el-button type="primary" icon="el-icon-search" @click="query(1)">查询</el-button>
        </el-form-item>-->
        <el-tooltip content="收起" placement="top">
          <i class="iconfont icon-up" @click="queryFormShowEvt(false)"></i>
        </el-tooltip>
      </el-form>

      <div v-show="!queryFormShow" class="query-form-close">高级查询
        <el-tooltip content="展开" placement="top">
          <i class="iconfont icon-down" @click="queryFormShowEvt(true)"></i>
        </el-tooltip>
      </div>
    </el-header>
    <el-main>
      <div class="list-name">任务列表</div>
      <!-- 二级查询条件 -->
      <el-form
        size="small"
        :inline="true"
        label-width="20px"
        :model="queryForm2"
        ref="queryForm2"
        @submit.native.prevent
      >
        <!--列表导出-->
        <export-list-data
          :exportData="exportData"
          :json_fields="json_fields"
          :name="name"
          class="export-data"
        ></export-list-data>

        <el-row style="float:right;margin-top:20px;">
          <el-form-item prop="status">
            <el-radio-group v-model="queryForm2.status" @change="query(1)">
              <el-radio-button label>全部</el-radio-button>
              <el-radio-button label="1">未开始</el-radio-button>
              <el-radio-button label="2">进行中</el-radio-button>
              <el-radio-button label="3">待归档</el-radio-button>
              <el-radio-button label="4">已完成</el-radio-button>
            </el-radio-group>
          </el-form-item>
          <el-form-item prop="name">
            <el-input
              v-model="queryForm2.name"
              placeholder="搜索任务名称"
              clearable
              suffix-icon="el-icon-search"
              @keyup.enter.native="query(1)"
              @change="query(1)"
            ></el-input>
          </el-form-item>
        </el-row>
        <el-row class="task-add">
          <el-button type @click="openNew">
            <i class="iconfont icon-add"></i>添加新任务
          </el-button>
        </el-row>
      </el-form>

      <!-- 列表 -->
      <el-table
        size="small"
        :data="taskData"
        align="center"
        height="460"
        v-loading="loading"
        element-loading-text="正在请求"
      >
        <el-table-column
          type="index"
          label="序号"
          width="50"
          :index="(index)=>{return (page - 1) * size + index + 1}"
        ></el-table-column>
        <el-table-column label="任务名称" width="120" :show-overflow-tooltip="true">
          <template slot-scope="scope">
            <strong class="hover-title" @click="titleDetail(scope.row)">{{scope.row.name}}</strong>
          </template>
        </el-table-column>
        <el-table-column prop="createDate" label="开始时间" width="140" :formatter="dateFormat"></el-table-column>
        <el-table-column prop="totalCount" label="任务量"></el-table-column>
        <el-table-column prop="markAssignedNum" label="已分配标注"></el-table-column>
        <el-table-column label="标注进度" width="120">
          <template slot-scope="scope">
            <span>
              {{scope.row.markCompleted ? scope.row.markCompleted : 0}}(
              <span
                v-text="getRate(scope.row.markCompleted,scope.row.markAssignedNum)"
              ></span>
              )
            </span>
          </template>
        </el-table-column>
        <el-table-column prop="checkAssignedNum" label="已分配检查"></el-table-column>
        <el-table-column label="检查进度" width="100">
          <template slot-scope="scope">
            <span v-if="scope.row.whetherCheck.code == 41">
              {{scope.row.checkCompletedNum ? scope.row.checkCompletedNum : 0}}(
              <span
                v-text="getRate(scope.row.checkCompletedNum,scope.row.checkAssignedNum)"
              ></span>
              )
            </span>
            <span v-else></span>
          </template>
        </el-table-column>
        <el-table-column prop="acceptedNum" label="已验收"></el-table-column>
        <el-table-column prop="statusDesc" label="状态"></el-table-column>
        <el-table-column label="操作" width="150">
          <template slot-scope="scope">
            <el-button
              type="primary"
              size="mini"
              @click="openDispense(scope.row)"
              v-if="scope.row.status === 1 || scope.row.status === 2 "
            >分配</el-button>
            <el-button
              type="primary"
              size="mini"
              @click="archive(scope.row.id)"
              v-if="scope.row.status === 3"
            >归档</el-button>
            <el-button
              type="primary"
              size="mini"
              @click="taskReport(scope.row.id)"
              v-if="scope.row.status === 4"
            >报告</el-button>
            <el-dropdown size="mini">
              <el-button type="primary" size="mini" class="more-btn">
                更多
                <i class="el-icon-arrow-down el-icon--right"></i>
              </el-button>
              <el-dropdown-menu slot="dropdown">
                <el-dropdown-item @click.native="titleDetail(scope.row)">详情</el-dropdown-item>
                <el-dropdown-item @click.native="exportTask(scope.row)">导出</el-dropdown-item>
                <el-dropdown-item
                  @click.native="checkConfig(scope.row)"
                  v-if="scope.row.status !== 4"
                >配置</el-dropdown-item>
                <el-dropdown-item
                  @click.native="acceptTask(scope.row)"
                  v-if="scope.row.status !== 4"
                >验收</el-dropdown-item>
                <el-dropdown-item
                  @click.native="addMoreTask(scope.row.id)"
                  v-if="scope.row.status !== 4"
                >继续添加</el-dropdown-item>
                <el-dropdown-item @click.native="delTask(scope.row.id)">移除</el-dropdown-item>
              </el-dropdown-menu>
            </el-dropdown>
          </template>
        </el-table-column>
      </el-table>

      <!-- 分页 -->
      <el-pagination
        v-if="total > 10"
        @size-change="sizeChange"
        @current-change="pageChange"
        align="right"
        layout="total, sizes, prev, pager, next, jumper"
        :current-page="page"
        :page-sizes="[5, 10, 20, 40]"
        :page-size="size"
        :total="total"
        class="pager-wrapper"
      ></el-pagination>
    </el-main>

    <!-- 导出列表 -->
    <el-dialog width="910px" top="2%" :visible.sync="showExport" class="task-export">
      <export-list v-if="showExport" :id="id"></export-list>
    </el-dialog>

    <!-- 继续添加 -->
    <el-dialog
      width="560px"
      :visible.sync="showAdd"
      class="goOn-add"
      title="批次上传"
      :lock-scroll="false"
    >
      <div>
        <el-form size="small" :rules="rules" ref="addTask" :model="addTask">
          <!-- 批次备注 -->
          <el-form-item label="批次备注">
            <el-input
              type="textarea"
              rows="3"
              placeholder="请输入任务的简单描述"
              v-model="addTask.description"
              style="width:410px"
            ></el-input>
          </el-form-item>

          <!-- 文件上传方式选择 -->
          <el-form-item label="上传方式">
            <el-radio-group v-model="addTask.uploadMethod" @change="uploadMethodChange">
              <el-radio label="11">输入地址</el-radio>
              <el-radio label="10">文件上传</el-radio>
            </el-radio-group>
          </el-form-item>

          <!-- 文件上传：点击 -->
          <el-form-item label-width="0px" class="upload-item" v-if="uploadShow">
            <span class="label-required">导入文件</span>
            <div class="upload-wrapper">
              <i class="iconfont icon-upload"></i>
              <input
                type="file"
                @change="upload"
                accept=".csv, application/x-rar, application/zip, text/plain, application/json"
              >
              <span class="upload-name" v-text="fileName"></span>
            </div>
            <div class="upload-error" v-show="fileEmptyInfo">请上传文件</div>
          </el-form-item>

          <!-- 文件上传：地址 -->
          <el-form-item prop="filePath" label="文件地址" v-if="urlShow">
            <el-input v-model="addTask.filePath" placeholder="请输入上传地址"></el-input>
            <a v-if="pathUrl" :href="pathUrl" target="_blank">文件上传地址</a>
          </el-form-item>
        </el-form>

        <!-- 操作按钮 -->
        <el-button size="small" type="primary" @click="submit('addTask')" class="submit">确 定</el-button>
        <el-button size="small" @click="cancel">返 回</el-button>
      </div>
    </el-dialog>

    <!--查看配置-->
    <el-dialog
      :width="width"
      title="任务配置"
      :visible.sync="showConfig"
      class="task-config"
      :lock-scroll="false"
    >
      <check-config :data="configData" v-if="showConfig" @cancle="closeConfig" @query="query"></check-config>
    </el-dialog>

    <el-dialog
      class="datawood-del"
      width="400px"
      title="删除提示"
      :visible.sync="showDel"
      :lock-scroll="false"
    >
      <div class="del-danger">移除任务后，该任务下的所有子任务都将被移除，请问确认移除吗？</div>
      <el-button type="primary" @click="sureDel()" size="small">确认</el-button>
    </el-dialog>
  </el-container>
</template>
}
<script>
import { mapState, mapMutations } from "vuex";
import { getRate } from "assets/scripts/common";
import ExportList from "./ExportList";
import CheckConfig from "./CheckConfig";
import ExportListData from "./ExportListData";

export default {
  name: "Task",
  computed: {
    ...mapState(["user", "appInfo"])
  },
  components: {
    ExportList,
    CheckConfig,
    ExportListData
  },
  data() {
    return {
      showDel: false,
      loading: false,
      taskAddLoading: false,
      getRate: getRate,
      queryFormShow: false,
      queryForm: {
        taskType: 0,
        taskTime: []
      },
      queryForm2: {
        status: "",
        name: ""
      },
      showExport: false,
      showConfig: false,
      showAdd: false,
      canClose: false,
      fileShow: false,
      taskId: "",
      name: "",
      uploadStatus: null,
      page: 1,
      size: 10,
      total: 0,
      sort: "createdDate,DESC",
      value: "",
      taskData: [],
      // 移除
      showDel: false,
      delTid: "",

      //添加
      addTask: {
        taskId: "",
        description: "",
        uploadMethod: "11",
        filePath: "",
        file: null
      },
      pathUrl: "",
      uploadShow: false,
      urlShow: true,
      fileName: "请选择文件",
      fileEmptyInfo: false,
      rules: {
        filePath: [
          { required: true, message: "请输入文件地址", trigger: "blur" }
        ]
      },
      configData: {},
      width: "",
      isOne: false,

      //列表导出
      exportData: [],
      json_fields: {
        任务名称: "name",
        开始时间: "createDate",
        任务量: "totalCount",
        已分配标注: "markAssignedNum",
        标注进度: {
          callback: value => {
            let completedNum = value.markCompleted ? value.markCompleted : 0;
            let assignedNum = value.markAssignedNum;
            return `${completedNum}(${getRate(completedNum, assignedNum)})`;
          }
        },
        已分配检查: {
          field: "checkAssignedNum",
          callback: value => {
            return value ? value : 0;
          }
        },
        检查进度: {
          callback: value => {
            if (value.whetherCheck.code === 41) {
              let completedNum = value.checkCompletedNum ? value.checkCompletedNum: 0;
              let assignedNum = value.checkAssignedNum;
              return `${completedNum}(${getRate(completedNum, assignedNum)})`;
            } else {
              return "";
            }
          }
        },
        已验收: "acceptedNum",
        状态: "statusDesc"
      },
      name: "taskList.xls",

      taskTypes: [
        {
          id: 0,
          name: "全部"
        }
      ]
    };
  },
  methods: {
    ...mapMutations(["showLoading", "closeLoading"]),

    //显示高级查询
    queryFormShowEvt(boolean) {
      this.queryFormShow = boolean;
    },

    // 详情
    titleDetail(row) {
      window.sessionStorage.setItem("taskInfo", JSON.stringify(row));
      this.$router.push({ path: "/task/taskDetail" });
    },

    // 验收
    acceptTask(row) {
      let id = row.id;
      let checkCode = row.whetherCheck.code;
      window.sessionStorage.setItem("taskInfo", JSON.stringify(row));
      this.$router.push({
        name: "任务验收",
        params: { taskId: id, checkCode: checkCode }
      });
    },

    //任务报告
    taskReport(id) {
      window.sessionStorage.setItem("id", id);
      this.$router.push({ path: "/task/taskReport" });
    },

    checkConfig(row) {
      this.configData = row;
      if (this.configData.status === 1) {
        this.width = "700px";
      } else {
        this.width = "400px";
      }
      this.showConfig = true;
    },

    //分页
    sizeChange(size) {
      this.size = size;
      this.query(1);
    },
    pageChange(page) {
      this.page = page;
      this.query();
    },

    //列表获取
    query(resetPage) {
      if (resetPage === 1) {
        this.page = 1;
      }

      if (!this.appInfo.id) {
        return;
      }

      this.loading = true;
      let taskTime = this.queryForm.taskTime;
      let param = {
        appId: this.appInfo.id,
        page: this.page,
        size: this.size,
        sort: this.sort,
        name: this.queryForm2.name,
        status: this.queryForm2.status,
        startDate:
          taskTime && taskTime[0]
            ? new Date(taskTime[0]).getTime() - 28800000
            : null,
        endDate:
          taskTime && taskTime[1]
            ? new Date(taskTime[1]).getTime() + 28800000*2
            : null
      };
      if (this.queryForm.taskType !== 0) {
        param.taskTypeId = this.queryForm.taskType;
      }

      //深拷贝请求参数
      let copyParam = JSON.parse(JSON.stringify(param));

      this.$api.task.getTaskList(param).then(data => {
          this.loading = false;
          data.content.forEach(item => {
            if (!item.markAssignedNum) {
              item.markAssignedNum = 0;
            }
            if (!item.checkAssignedNum) {
              item.checkAssignedNum = 0;
            }
          });
          this.taskData = data.content;
          if (this.taskData.length === 1) {
            this.isOne = true;
          } else {
            this.isOne = false;
          }
          this.total = data.totalElements;

          //获取全部导出数据
          this.exportData = data.content;
          // copyParam.page = 1;
          // copyParam.size = this.total;
          // this.exportTaskListData(copyParam);
        })
        .catch(() => {
          this.loading = false;
        });
    },

    //新建
    openNew() {
      this.$router.push({ path: "/task/create" });
    },

    //分配
    openDispense(row) {
      if (
        row.markAssignedNum >= row.totalCount &&
        row.checkAssignedNum >= row.totalCount
      ) {
        this.$message.warning("该任务不可分配");
      } else {
        window.sessionStorage.setItem("taskInfo", JSON.stringify(row));
        this.$router.push({ path: "/task/dispense" });
      }
    },

    //打回
    taskBackByTid(row) {
      let param = { tid: row.id };
      this.$api.task
        .TaskBackByTid(param)
        .then(data => {
          this.$alert("打回成功。", "提示信息", {
            confirmButtonText: "确定",
            callback: action => {
              this.query(1);
            }
          });
        })
        .catch(() => {});
    },

    // 归档
    archive(id) {
      this.$confirm("确认将此任务归档吗？", "", { lockScroll: false })
        .then(() => {
          this.$api.task
            .archiveTask({
              taskId: id
            })
            .then(() => {
              this.$message.success("归档成功");
              this.query(1);
            })
            .catch(() => {});
        })
        .catch(() => {});
    },

    //导出
    exportTask(row) {
      this.showExport = true;
      window.sessionStorage.setItem("taskInfo", JSON.stringify(row));
      this.id = row.id;
    },

    //继续上传
    addMoreTask(id) {
      this.addTask.taskId = id;
      //数据置空、默认上传url
      this.addTask.description = "";
      this.addTask.filePath = "";
      this.addTask.uploadMethod = "11";
      this.addTask.file = null;
      this.uploadShow = false;
      this.urlShow = true;
      this.fileEmptyInfo = false;
      this.fileName = "请选择文件";
      this.showAdd = true;
    },

    //提交任务
    submit(name) {
      this.$refs[name].validate(valid => {
        if (this.uploadShow && !this.addTask.file) {
          this.fileEmptyInfo = true;
          this.fileName = "请选择文件";
          return;
        } else {
          this.fileEmptyInfo = false;
        }
        if (valid) {
          let param = Object.assign(this.addTask);
          let formData = new FormData();
          for (var i in param) {
            formData.append(i, param[i]);
          }
          this.showLoading();
          //分批上傳
          this.$api.task
            .batchTask(formData)
            .then(
              data => {
                this.closeLoading();
                this.showAdd = false;
                this.query();
                this.$message.success("任务批次添加成功");
              },
              error => {
                this.closeLoading();
                this.showAdd = false;
                this.$message.error("任务批次添加失败");
              }
            )
            .catch(() => {});
        }
      });
    },

    //返回首页
    cancel() {
      this.showAdd = false;
    },

    //上传方式切换
    uploadMethodChange(val) {
      if (val === "10") {
        this.uploadShow = true;
        this.urlShow = false;
        this.fileEmptyInfo = this.addTask.file ? false : this.fileEmptyInfo;
        if (!this.fileEmptyInfo) {
          this.fileName = "请选择文件";
        }
      } else {
        this.uploadShow = false;
        this.urlShow = true;
        this.fileEmptyInfo = false;
        this.fileName = "请选择文件";
        this.addTask.file = null;
      }
    },

    //上传文件
    upload(event) {
      const file = event.target.files[0];
      this.fileName = file.name;
      this.fileEmptyInfo = false;
      this.addTask.file = file;
    },

    //获取文件访问的baseurl
    getBaseUrl() {
      this.$api.task.getStorageUrl({}).then(res => {
        this.pathUrl = res;
      });
    },

    //移除
    delTask(tid) {
      this.delTid = tid;
      this.showDel = true;
    },

    /**
     * 确认移除
     */
    sureDel() {
      if (this.isOne && this.page !== 1) {
        this.page = this.page - 1;
      }
      this.$api.task
        .delTask({ id: this.delTid })
        .then(() => {
          this.$message.success("任务移除成功");
          this.query();
          this.closeDel();
        })
        .catch(() => {});
    },

    /**
     * 关闭移除弹窗
     */
    closeDel() {
      this.showDel = false;
    },

    // 时间格式化
    dateFormat(row, column) {
      let time = row[column.property];
      if (!time) {
        return "";
      }
      return this.$moment(time).format("YYYY-MM-DD HH:mm:ss");
    },

    closeConfig() {
      this.showConfig = false;
    },

    //导出任务列表
    exportTaskListData(param) {
      this.$api.task.getTaskList(param).then(res => {
        let { content } = res;
        this.exportData = content;
      });
    },

    //任务类型查询
    queryTaskType() {
      this.taskTypes = [{ id: 0, name: "全部" }];
      if (!this.appInfo.id) {
        return;
      }

      this.$api.task.searchTaskType({ appId: this.appInfo.id }).then(res => {
        if (res === "") {
          return;
        }
        res.forEach(item => {
          this.taskTypes.push({
            id: item.id,
            name: item.name
          });
        });
      });
    }
  },

  watch: {
    appInfo() {
      if (this.appInfo.id) {
        this.query(1);
        this.queryTaskType();
      }
    }
  },

  mounted() {
    this.query(1);
    this.queryTaskType();
    this.getBaseUrl();
  }
};
</script>

<style rel="stylesheet/less" lang="less">
.task-list {
  background: #f6f6f6;
  padding-bottom: 20px;
  .el-header {
    background: #ffffff;
    position: relative;
    padding: 10px 25px 0px 25px;
    margin-bottom: 20px;
    .header-row {
      border-bottom: 1px #f0eded dashed;
      margin-bottom: 10px;
    }
    .query-form {
      position: relative;
    }
    .icon-up,
    .icon-down {
      font-size: 30px;
      color: #92969f;
      position: absolute;
      top: 0;
      right: 0;
      cursor: pointer;
      &:hover {
        color: #66b1ff;
      }
    }
    .query-form-close {
      position: relative;
      line-height: 40px;
      top: -3px;
      .icon-down {
        font-size: 24px;
      }
    }
  }

  .el-main {
    height: 700px;
    background: #ffffff;
    padding: 0px 15px;
    .export-data {
      float: right;
      margin-top: 26px;
    }
    .list-name {
      float: left;
      margin-top: 20px;
      margin-left: 10px;
    }
    .task-add {
      clear: both;
      margin-bottom: 10px;
      text-align: center;
      button {
        padding: 10px 0;
        border-style: dashed;
        width: 100%;
        margin: 0 auto;
        border-radius: 4px;
        font-size: 14px;
      }
      .icon-add {
        font-size: 16px;
      }
    }
    .hover-title {
      cursor: pointer;
      color: #409eff;
      &:hover {
        color: darken(#409eff, 20%);
      }
    }
    .el-pagination {
      margin-top: 40px;
    }
  }
}
.key-str {
  width: 25%;
  margin-left: 65%;
}
.el-header {
  position: relative;
  padding: 20px 25px 0 25px;
  .icon-add {
    font-size: 14px;
  }
  .task-add {
    position: absolute;
    right: 24px;
    top: 20px;
  }
}
.el-button--mini,
.el-button--mini.is-round {
  padding: 5px 10px;
}
.el-table__empty-block {
  min-height: 250px;
}
.task-del {
  .del-danger {
    line-height: 28px;
    text-indent: 20px;
    font-weight: bold;
  }
  button {
    margin-left: 280px;
  }
  .del-psw {
    margin: 10px 0;
    label {
      line-height: 28px;
      font-weight: bold;
    }
  }
}
.goOn-add {
  a {
    margin-left: 80px;
  }
  .el-input {
    width: 400px;
  }
  .upload-wrapper {
    input {
      width: 41px;
      height: 32px;
      z-index: 100;
      position: absolute;
      opacity: 0;
      cursor: pointer;
      line-height: 32px;
      overflow: hidden;
    }
    .icon-upload {
      font-size: 30px;
      position: absolute;
      color: #6ea5de;
      cursor: pointer;
      z-index: 99;
    }
    .upload-name {
      padding-left: 50px;
    }
  }
  .upload-item {
    .label-required {
      display: inline-block;
      text-align: right;
      float: left;
      font-size: 14px;
      color: #606266;
      line-height: 40px;
      padding: 0 34px 0 0;
      box-sizing: border-box;
      width: 100px;
      &::before {
        content: "*";
        color: #f56c6c;
        margin-right: 4px;
      }
    }
    .el-form-item__error {
      display: none;
    }
  }
  .upload-error {
    color: #f56c6c;
    font-size: 12px;
  }
  .el-form-item__error {
    margin-left: 80px;
  }
  .submit {
    margin-left: 180px;
  }
}
</style>

<style lang="less">
.task-list {
  .el-header {
    .el-form-item {
      margin-bottom: 10px;
    }
  }
  .el-button-group .el-button + .el-button {
    padding-bottom: 4px;
    border-left: 1px solid #dcdfe6;
  }
  .task-export {
    .el-dialog__body {
      padding-top: 10px;
    }
  }

  .task-del {
    .el-dialog__title {
      color: #f56c6c;
      font-weight: bold;
    }
  }

  .more-btn {
    padding: 4.5px 10px;
  }

  .task-config {
    .el-dialog__body {
      padding: 10px 30px;
      color: #606266;
      font-size: 16px;
    }
  }
}
</style>











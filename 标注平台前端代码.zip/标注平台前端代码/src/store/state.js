let loading = false; //全局loading
let user = { //用户信息
  appId: "",
  role: "",
  authorities: [],
  cnName: "",
  login: ""
};
// let deputies = []; //应用权限
let accessToken = "";
let routers = []; //权限路由
let appInfo = {};
let containerAlive = true; //主体路由显示
let navShow = true // 左侧导航显示

export default {
  // deputies,
  loading,
  user,
  routers,
  accessToken,
  containerAlive,
  appInfo,
  navShow
}

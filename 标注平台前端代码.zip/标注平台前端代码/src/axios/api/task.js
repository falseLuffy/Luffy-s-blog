// 任务相关接口
import {
  $get,
  $post,
  $put,
  concatPageInfo,
  $delete
} from '../http';

// 任务列表
const getTaskList = data => {
  let param = concatPageInfo(data, 'base/datawood-manager/api/task/list')
  return $get(param.url, param.data)
};

// 文件上传
const createTask = data => {
  return $post('base/datawood-manager/api/task/new', data, true)
};

//分批上传
const batchTask = data => {
  return $post('base/datawood-manager/api/task-batch/new', data, true)
};

// 分配判断
const distributeJudge = data => {
  return $get('base/datawood-manager/api/task/checkReady', data)
};

// 分配标注员
const distributeMarker = data => {
  return $post('base/datawood-manager/api/distribute/marker', data)
};

// 分配检查员
const distributeChecker = data => {
  return $get('base/datawood-manager/api/distribute/inspector', data)
};

// 标注员任务列表
const distributeMarkList = data => {
  return $get('base/datawood-manager/api/distribute/marker/list', data)
};

// 检查列表
const distributeCheckList = data => {
  return $get('base/datawood-manager/api/distribute/inspector/list', data)
};

// 数据导出
const getExportList = data => {
  return $get('base/datawood-manager/api/task-exports', data)
};

// 导出数据
const exportTask = data => {
  return $get('base/datawood-processor/api/tasks/export', data)
};

// 分配-搜索标注员
const markerList = data => {
  return $get('base/datawood-manager/api/marker/list', data)
};

// 分配-搜索检查员导出数据
const checkList = data => {
  return $get('base/datawood-manager/api/inspector/list', data)
};

// 验收列表
const acceptList = data => {
  return $get('base/datawood-manager/api/user-tasks/wait-accept', data)
};

// 验收用户任务
const acceptTask = data => {
  return $post('base/datawood-manager/api/user-tasks/accept', data)
};

// 验收用户任务
const reCheckTask = data => {
  return $post('base/datawood-manager/api/user-tasks/unaccept', data)
};

// 获取当前用户详细信息
const getMyInfos = data => {
  return $get('base/datawood-manager/api/user-infos/me', {})
}

// 任务详情--标注详情
const detailMark = data => {
  return $get('base/datawood-manager/api/user-tasks/marker', data)
}

// 任务详情--检查详情
const detailCheck = data => {
  return $get('base/datawood-manager/api/user-tasks/inspector', data)
}

// 任务详情--回收
const detailWithdraw = data => {
  return $post('base/datawood-manager/api/user-tasks/withdraw', data)
}

// 任务详情--批次上传列表
const detailBatch = data => {
  return $get('base/datawood-manager/api/task-batch/list', data)
}

// 任务详情--统计
const detailStatistic = data => {
  return $post('base/datawood-manager/api/task/statistic', data)
}

// 任务信息获取
const getTaskBaseInfo = data => {
  let id = data.id;
  delete data.id;
  return $get(`base/datawood-manager/api/task/${id}`, data)
}

// 任务删除
const delTask = data => {
  let id = data.id;
  return $delete(`base/datawood-manager/api/task/${id}`, data)
}

//更新任务配置
const updateConfig = data => {
  return $post('base/datawood-manager/api/task/updateConfig', data, true)
}

// 任务归档
const archiveTask = data => {
  return $get('base/datawood-manager/api/task/archive', data)
}

// 任务下载
const downloadTask = data => {
  let id = data.id;
  return $get(`base/datawood-processor/api/export/download/${id}`, data)
}

//任务统计
const appStatistic = data => {
  let id = data.id;
  return $get(`base/datawood-manager/api/application/statistic/${id}`)
}

//任务类型查询
const searchTaskType = data => {
  return $get(`base/datawood-manager/api/task-types`, data)
}

//应用用户工作量统计
const userWorkCount = data => {
  return $get(`base/datawood-manager/api/user-infos/workload`, data);
}

// 新建时判断名字是否重复
const judgeName = data => {
  return $post('base/datawood-manager/api/task/name-existed', data)
}

//部门兼职统计
const userCount = data => {
  return $get('base/usercenter/api/userdeputies/count', data)
}

// 获取字典列表
const dictList = data => {
  let param = concatPageInfo(data, 'base/datawood-manager/api/dictionaries')
  return $get(param.url, param.data)
}

// 获取字典树
const getDictTree = data => {
  return $get('base/datawood-manager/api/dictionary/tree', data)
}

// 删除节点
const delDictNode = data => {
  let id = data.id;
  return $delete(`base/datawood-manager/api/dictionary-node/${id}`, data)
}

// 编辑节点
const editDictNode = data => {
  return $post(`base/datawood-manager/api/dictionary-node`, data)
}

// 新增节点
const addDictNode = data => {
  return $post(`/base/datawood-manager/api/dictionary-node/new`, data)
}

// 导入字典
const importDict = data => {
  return $post(`base/datawood-manager/api/dictionary/import-excel`, data, true)
}

//获取坏数据列表
const getBadData = data => {
  let id = data.id;
  return $get(`base/datawood-manager/api/application/getBadData/${id}`, data)
}

//下载坏数据
const downLoadBadData = data => {
  let taskTypeId = data.taskTypeId;
  return $get(`base/datawood-processor/downloadbad-data/${taskTypeId}`, data)
}

//下载非坏数据
const downLoadMisBadData = data => {
  let taskTypeId = data.taskTypeId;
  return $get(`base/datawood-processor/download/misjudge-bad-data/${taskTypeId}`, data)
}

//清空坏数据
const clearBadData = data => {
  let taskTypeId = data.taskTypeId;
  return $get(`base/datawood-processor/api/clear-bad/${taskTypeId}`, data)
}

//清空非坏数据
const clearMisBadData = data => {
  let taskTypeId = data.taskTypeId;
  return $get(`base/datawood-processor/api/clear-misjudge-bad/${taskTypeId}`, data)
}

//获取用户任务列表
const getUserTaskList = data => {
  return $get('base/datawood-manager/api/user-tasks', data)
}

//工作量汇总
const workloadStatistic = data => {
  return $get('base/datawood-manager/api/user-info/workload-statistic', data)
}

//任务报告
const taskReport = data => {
  let id = data.id;
  delete data.id;
  return $get(`base/datawood-manager/api/task/report/${id}`, data)
}

//获取文件上传地址
const getStorageUrl = data => {
  return $get('base/datawood-manager/api/server/storage-url');
}

//导出任务报告
const exportTaskReport = data => {
  let id = data.id;
  delete data.id;
  return $get(`base/datawood-manager/api/task/export-report/${id}`, data);
}

//导出列表验证
const validateExport = data => {
  return $get('base/datawood-processor/api/tasks/validate-export', data);
}

export default {
  getTaskList,
  createTask,
  batchTask,
  distributeJudge,
  distributeMarker,
  distributeChecker,
  distributeMarkList,
  distributeCheckList,
  getExportList,
  exportTask,
  markerList,
  checkList,
  acceptList,
  acceptTask,
  reCheckTask,
  getMyInfos,
  detailMark,
  detailCheck,
  detailWithdraw,
  detailBatch,
  updateConfig,
  delTask,
  getTaskBaseInfo,
  detailStatistic,
  archiveTask,
  downloadTask,
  appStatistic,
  searchTaskType,
  userWorkCount,
  judgeName,
  userCount,
  dictList,
  getDictTree,
  delDictNode,
  editDictNode,
  addDictNode,
  importDict,
  getBadData,
  downLoadBadData,
  downLoadMisBadData,
  clearBadData,
  clearMisBadData,
  getUserTaskList,
  workloadStatistic,
  taskReport,
  getStorageUrl,
  exportTaskReport,
  validateExport
}

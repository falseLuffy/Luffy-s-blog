<template>
  <div>
    <mark-tpl
      class="cn-mark"
      :appType="appType"
      :param="param"
      :keysList="keysList"
      @query="query"
      @setQueryData="setQueryData"
      @valid="valid"
      @save="save"
    >
      <div slot="answer">
        <div>
          {{param.wav_file}}
          <template>
            <el-button
              size="small"
              type="danger"
              v-if="!param.valid_flag"
              @click="availableClick"
            >不可用</el-button>
            <el-button
              size="small"
              type="danger"
              class="btn-plain"
              v-else
              @click="availableClick"
            >标为不可用</el-button>
          </template>
        </div>
        <!-- 音频 -->
        <div id="waveform" ref="waveform" class="wave-form">
          <el-progress :percentage="percent" :stroke-width="8" v-if="progress"></el-progress>
        </div>
        <!-- 音频控制按钮 -->
        <div class="audio-group">
          <el-button size="small" type="primary" @click="play">
            <i :class="['iconfont',{'icon-run':runIcon,'icon-pause':!runIcon}]"></i>
            <span>{{playText}}</span>
          </el-button>
          <el-button size="small" type="warning" @click="stop">
            <i class="iconfont icon-stop"></i>重置
          </el-button>

          <div class="volume">
            <div class="volume-content">
              <i class="iconfont icon-voice"></i>
              <el-slider v-model="volume" @change="setVolume"></el-slider>
            </div>
          </div>
        </div>

        <!-- 设置面板 -->
        <div class="content">
          <div class="main-content">
            <!-- 展示面板 -->
            <div class="main">
              <div class="sents" v-for="(item,index) in param.sents" :key="index">
                <span
                  ref="words"
                  class="word"
                  v-for="(unit,idx) in item.words"
                  :key="idx"
                  @click.prevent="markWord(index,idx,unit,unit.word_beg_pos,unit.word_end_pos,$event)"
                  :class="{
                erhua:unit.is_erhua,
                active:wordIndex === `${index}-${idx}`,
                error:errIndex[`${index}-${idx}`] || unit.error ,
                defect:defect[`${index}-${idx}`] || unit.defect,
                done:markDone[`${index}-${idx}`] || unit.done || unit.is_biaozhu == 1,
                'is-biaozhu': unit.is_biaozhu == 2
                }"
                >{{unit.content}}</span>
              </div>
            </div>
          </div>
          <!-- 设置面板 -->
          <div class="side">
            <dl>
              <dt>对照</dt>
              <dd>
                <span
                  class="name"
                  :title="`${dzContent}(${dzPY})`"
                  v-show="dzPY"
                >{{dzContent}}( {{dzPY}} )</span>
              </dd>
            </dl>

            <dl>
              <dt>声母</dt>
              <dd>
                <el-radio-group v-model="sm" @change="smChange">
                  <el-radio size="small" label="smD" :disabled="disabled">缺陷</el-radio>
                  <el-radio size="small" label="smE" :disabled="disabled">错误</el-radio>
                </el-radio-group>
                <div v-show="sm === 'smE'" class="label">
                  <span>标注：</span>
                  <el-select size="small" v-model="smValue" clearable :disabled="disabled">
                    <el-option
                      v-for="item in smList"
                      :value="item.value"
                      :key="item.value"
                    >{{ item.label }}</el-option>
                  </el-select>
                </div>
              </dd>
            </dl>

            <dl>
              <dt>韵母</dt>
              <dd>
                <el-radio-group v-model="ym" @change="ymChange">
                  <el-radio size="small" label="ymD" :disabled="disabled">缺陷</el-radio>
                  <el-radio size="small" label="ymE" :disabled="disabled">错误</el-radio>
                </el-radio-group>
                <div v-show="ym === 'ymE'" class="label">
                  <span>标注：</span>
                  <el-select size="small" v-model="ymValue" clearable :disabled="disabled">
                    <el-option
                      v-for="item in ymList"
                      :value="item.value"
                      :key="item.value"
                    >{{ item.label }}</el-option>
                  </el-select>
                </div>
              </dd>
            </dl>

            <dl>
              <dt>声调</dt>
              <dd>
                <el-radio-group v-model="sd" @change="sdChange">
                  <el-radio size="small" label="sdD" :disabled="disabled">缺陷</el-radio>
                  <el-radio size="small" label="sdE" :disabled="disabled">错误</el-radio>
                </el-radio-group>
                <div v-show="sd === 'sdE'" class="label">
                  <span>标注：</span>
                  <el-select size="small" v-model="sdValue" clearable :disabled="disabled">
                    <el-option
                      v-for="item in sdList"
                      :value="item.value"
                      :key="item.value"
                    >{{ item.label }}</el-option>
                  </el-select>
                </div>
              </dd>
            </dl>

            <dl>
              <dt>轻声</dt>
              <dd>
                <el-radio-group v-model="qs" @change="errorChange">
                  <el-radio size="small" label="qsD" :disabled="disabled">缺陷</el-radio>
                  <el-radio size="small" label="qsE" :disabled="disabled">错误</el-radio>
                </el-radio-group>
              </dd>
            </dl>

            <dl>
              <dt>儿化</dt>
              <dd>
                <el-radio-group v-model="eh" @change="errorChange">
                  <el-radio size="small" label="ehD" :disabled="disabled">缺陷</el-radio>
                  <el-radio size="small" label="ehE" :disabled="disabled">错误</el-radio>
                </el-radio-group>
              </dd>
            </dl>

            <dl class="zcl">
              <dt>错增漏</dt>
              <dd>
                <el-radio-group v-model="numbers" class="numbers" @change="numbersChange">
                  <el-radio size="small" label="loZ" :disabled="disabled">漏读</el-radio>
                  <el-radio size="small" label="zeZ" :disabled="disabled">增读</el-radio>
                  <el-input-number
                    size="small"
                    :disabled="disabled"
                    class="zd-number"
                    :precision="0"
                    v-show="numbers === 'zeZ'"
                    :max="100"
                    :min="0"
                    v-model="zeCount"
                  ></el-input-number>
                </el-radio-group>

                <div class="error">
                  <el-checkbox
                    size="small"
                    v-model="error"
                    :disabled="disabled"
                    @change="errorChange"
                  >错误</el-checkbox>
                </div>
              </dd>
            </dl>

            <!-- grade -->
            <div class="grade">
              <el-button
                size="small"
                type="warning"
                icon="android-refresh"
                @click="reset"
                v-if="!readonly"
              >重置</el-button>&emsp;
              <el-button
                size="small"
                type="primary"
                icon="happy"
                v-if="cnMarkType === 'sentence'"
                @click="gradeModal"
              >句篇评分</el-button>
            </div>
          </div>
        </div>
      </div>
    </mark-tpl>
    <el-dialog title="句篇整体评分" :visible.sync="grade" top="5%" center width="520px">
      <dl class="modal-list">
        <dt>总体评分：</dt>
        <dd class="center">
          <span class="label">系统性缺陷：</span>
          <el-select size="small" v-model="xtscore" style="width:86px" :disabled="readonly">
            <el-option
              v-for="item in scoreList"
              :value="item.value"
              :key="item.value"
            >{{ item.label }}</el-option>
          </el-select>

          <span class="label">语调偏误：</span>
          <el-select size="small" v-model="ytscore" style="width:86px" :disabled="readonly">
            <el-option
              v-for="item in scoreList"
              :value="item.value"
              :key="item.value"
            >{{ item.label }}</el-option>
          </el-select>

          <br>
          <br>

          <span class="label">停连不当：</span>
          <el-select size="small" v-model="tlscore" style="width:86px" :disabled="readonly">
            <el-option
              v-for="item in scoreList"
              :value="item.value"
              :key="item.value"
            >{{ item.label }}</el-option>
          </el-select>

          <span class="label">朗读不流畅：</span>
          <el-select size="small" v-model="ldscore" style="width:86px" :disabled="readonly">
            <el-option
              v-for="item in scoreList"
              :value="item.value"
              :key="item.value"
            >{{ item.label }}</el-option>
          </el-select>

          <br>
          <br>

          <span class="label">句篇总分：</span>
          <el-input-number
            size="small"
            :disabled="readonly"
            placeholder="输入分数(0-100)"
            :max="100"
            :min="0"
            v-model="param.total_score"
            :precision="0"
          ></el-input-number>（ 总分：100 ）
        </dd>
      </dl>

      <dl class="modal-list">
        <dt>其它：</dt>
        <dd>
          <el-checkbox-group size="small" v-model="qt" :disabled="disabled">
            <el-checkbox label="0">停连不当</el-checkbox>
            <el-checkbox label="1">回读</el-checkbox>
            <el-checkbox label="2">语调偏误</el-checkbox>
          </el-checkbox-group>
        </dd>
      </dl>

      <dl class="modal-list">
        <dt>评分参考：</dt>
        <dd>
          <p>
            <span>缺陷：</span>
            <em>{{defectCount}}</em>处
          </p>
          <p>
            <span>错误：</span>
            <em>{{errCount}}</em>处
          </p>
          <p>
            <span>漏读：</span>
            <em>{{losCount}}</em>处
          </p>
          <p>
            <span>增读：</span>
            <em>{{zesCount}}</em>处
          </p>
        </dd>
      </dl>
      <div slot="footer" class="dialog-footer">
        <el-button size="small" @click="grade = false">取 消</el-button>
        <el-button size="small" type="primary" @click="sureScore(false)">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import MarkTpl from "./MarkTpl";
import WaveSurfer from "wavesurfer.js";
import { APPTYPE } from "assets/scripts/code";
import { setMarkData } from "assets/scripts/common";
export default {
  name: "CnMark",
  components: {
    MarkTpl
  },
  data() {
    return {
      keysList: [
        {
          name: "功能说明",
          key: "快捷键"
        },
        {
          name: "播放切换",
          key: "Q"
        },
        {
          name: "保存并下一条",
          key: "空格"
        }
      ],
      appType: APPTYPE.CN,
      mcType: "",
      cnMarkType: "",

      task: null,
      readonly: false,
      progress: true,
      percent: 0,
      wavesurfer: {},
      volume: 50,
      wordIndex: "",
      errIndex: {},
      defect: {},
      markDone: {},
      disabled: true,
      sent: {},
      sm: "",
      smValue: "",
      smList: [
        {
          value: "b",
          label: "b"
        },
        {
          value: "p",
          label: "p"
        },
        {
          value: "m",
          label: "m"
        },
        {
          value: "f",
          label: "f"
        },
        {
          value: "d",
          label: "d"
        },
        {
          value: "t",
          label: "t"
        },
        {
          value: "n",
          label: "n"
        },
        {
          value: "l",
          label: "l"
        },
        {
          value: "g",
          label: "g"
        },
        {
          value: "k",
          label: "k"
        },
        {
          value: "h",
          label: "h"
        },
        {
          value: "j",
          label: "j"
        },
        {
          value: "q",
          label: "q"
        },
        {
          value: "x",
          label: "x"
        },
        {
          value: "zh",
          label: "zh"
        },
        {
          value: "ch",
          label: "ch"
        },
        {
          value: "sh",
          label: "sh"
        },
        {
          value: "r",
          label: "r"
        },
        {
          value: "z",
          label: "z"
        },
        {
          value: "c",
          label: "c"
        },
        {
          value: "s",
          label: "s"
        },
        {
          value: "零声母",
          label: "零声母"
        },
        {
          value: "没有声母",
          label: "没有声母"
        }
      ],
      ym: "",
      ymValue: "",
      ymList: [
        {
          value: "a",
          label: "a"
        },
        {
          value: "o",
          label: "o"
        },
        {
          value: "e",
          label: "e"
        },
        {
          value: "i",
          label: "i"
        },
        {
          value: "u",
          label: "u"
        },
        {
          value: "ü",
          label: "ü"
        },
        {
          value: "-i前",
          label: "-i前"
        },
        {
          value: "-i后",
          label: "-i后"
        },
        {
          value: "er",
          label: "er"
        },
        {
          value: "ai",
          label: "ai"
        },
        {
          value: "ei",
          label: "ei"
        },
        {
          value: "ui",
          label: "ui"
        },
        {
          value: "ao",
          label: "ao"
        },
        {
          value: "ou",
          label: "ou"
        },
        {
          value: "iu",
          label: "iu"
        },
        {
          value: "ia",
          label: "ia"
        },
        {
          value: "ie",
          label: "ie"
        },
        {
          value: "ua",
          label: "ua"
        },
        {
          value: "uo",
          label: "uo"
        },
        {
          value: "üe",
          label: "üe"
        },
        {
          value: "iao",
          label: "iao"
        },
        {
          value: "iou",
          label: "iou"
        },
        {
          value: "uai",
          label: "uai"
        },
        {
          value: "uei",
          label: "uei"
        },
        {
          value: "an",
          label: "an"
        },
        {
          value: "en",
          label: "en"
        },
        {
          value: "in",
          label: "in"
        },
        {
          value: "un",
          label: "un"
        },
        {
          value: "ün",
          label: "ün"
        },
        {
          value: "ian",
          label: "ian"
        },
        {
          value: "uan",
          label: "uan"
        },
        {
          value: "uen",
          label: "uen"
        },
        {
          value: "üan",
          label: "üan"
        },
        {
          value: "ang",
          label: "ang"
        },
        {
          value: "eng",
          label: "eng"
        },
        {
          value: "ing",
          label: "ing"
        },
        {
          value: "ong",
          label: "ong"
        },
        {
          value: "iang",
          label: "iang"
        },
        {
          value: "uang",
          label: "uang"
        },
        {
          value: "ueng",
          label: "ueng"
        },
        {
          value: "iong",
          label: "iong"
        },
        {
          value: "儿化",
          label: "儿化"
        }
      ],
      sd: "",
      sdValue: "",
      sdList: [
        {
          value: "0",
          label: "0"
        },
        {
          value: "1",
          label: "1"
        },
        {
          value: "2",
          label: "2"
        },
        {
          value: "3",
          label: "3"
        },
        {
          value: "4",
          label: "4"
        }
      ],
      qs: "",
      eh: "",
      numbers: "",
      zeCount: 0,
      louOldCount: 0,
      zeOldCount: 0,
      error: false,
      param: {
        content: "",
        read_type: "",
        valid_flag: true,
        wav_file: "",
        sentenceScore: {},
        sents: [],
        total_score: 0
      },
      playText: "播放",
      runIcon: true,
      once: true,
      grade: false,
      qt: [],
      xtscore: "",
      ytscore: "",
      tlscore: "",
      ldscore: "",
      scoreList: [
        {
          value: "0",
          label: "0"
        },
        {
          value: "1",
          label: "1"
        },
        {
          value: "2",
          label: "2"
        },
        {
          value: "3",
          label: "3"
        },
        {
          value: "4",
          label: "4"
        },
        {
          value: "5",
          label: "5"
        }
      ],
      dzPY: "",
      dzContent: "",
      losCount: 0,
      zesCount: 0,
      defectCount: 0,
      errCount: 0,
      $element: null,
      checkerEdit: false //检查员是否修改
    };
  },
  methods: {
    /**
     * 查询数据
     * @param param 请求参数
     * @param isCookie 是否是缓存
     */
    query(param, isCookie) {
      let id = param.userTaskItemId;
      let dataId = param.dataId;
      delete param.dataId;

      this.$api.mark
        .getMarkFile(param)
        .then(res => {
          res.userTaskItemId = id;
          res.dataId = dataId;
          if (isCookie) {
            setMarkData(id, res);
          } else {
            setMarkData(id, res);
            this.setQueryData(res);
          }
        })
        .catch(() => {});
    },

    /**
     * 请求数据后的内容处理
     * @param res 请求的数据
     */
    setQueryData(res) {
      // 数据重置
      this.reset();
      this.runIcon = true;
      this.playText = "播放";
      this.dzContent = "";
      this.dzPY = "";
      this.errIndex = {};
      this.defect = {};
      this.markDone = {};
      this.disabled = true;
      this.wordIndex = "";
      this.louOldCount = 0;
      this.zeOldCount = 0;

      let mcType = this.mcType;
      let cnData;

      // 1）检查
      if (mcType == 1) {
        cnData = res.checkedData ? res.checkedData : res.markedData;
      } else if (res.markedData && mcType == 0) {
        // 2）标注
        cnData = res.markedData;
      } else if (!res.markedData) {
        // 3）没有标注
        cnData = res.data;
      }
      this.param = cnData;

      // 数据处理,为了让数据初始化的时候根据数据正确的显示错误和缺陷等信息
      this.param.sents = this.setSents(this.param.sents, true);
      this.progress = true;

      //音频加载
      let reqUrl = location.origin;
      let audio = `${reqUrl}/base/datawood-processor/download/source/${res.dataId}`;
      this.wavesurfer.load(audio);

      // 句篇显示
      if (this.cnMarkType === "sentence") {
        let sentenceScore = this.param.sentenceScore;

        if (
          JSON.stringify(sentenceScore) !== "{}" &&
          sentenceScore !== undefined
        ) {
          this.showSentenceScore(sentenceScore);
        } else {
          this.sureScore(true);
        }

        this.param.total_score = this.param.total_score
          ? this.param.total_score
          : 0;
      }

      // 获取数据后，才可以点击下一条，防止快速点击事件
      this.param.clicked = false;
      if (this.param.keycodetimer) {
        this.param.keycodetimer = null;
        clearTimeout(this.param.keycodetimer);
      }
    },

    // 遍历sents，设置/获取值,isget为true表示为了获取
    setSents(sents, isget) {
      if (!isget) {
        this.losCount = 0;
        this.zesCount = 0;
      }
      sents.forEach(item => {
        item.words.forEach(unit => {
          // 默认
          unit.error = false;
          unit.defect = false;

          let sm = unit.phone_info[0].errs[0].err_type,
            ym = unit.phone_info[1].errs[0].err_type,
            sd = unit.phone_info[1].errs[1].err_type,
            qs = unit.errs[0].qingsheng_err,
            eh = unit.errs[0].erhua_err,
            numbers = unit.errs[0].err_type,
            error = unit.errs[0].is_err;

          // 错误标识
          if (
            sm === "smE" ||
            ym === "ymE" ||
            sd === "sdE" ||
            eh === "ehE" ||
            qs === "qsE" ||
            numbers === "loZ" ||
            error
          ) {
            unit.error = true;
          }

          // 缺陷标识
          if (
            sm === "smD" ||
            ym === "ymD" ||
            sd === "sdD" ||
            eh === "ehD" ||
            numbers === "zeZ" ||
            qs === "qsD"
          ) {
            unit.defect = true;
          }

          if (!isget) {
            // 错/漏读计数
            if (numbers === "loZ") {
              this.losCount += 1;
            } else if (numbers === "zeZ") {
              this.zesCount += Number(unit.errs[0].insert_count || 0);
            }
          }
        });
      });

      if (isget) {
        return sents;
      } else {
        // 判断当前是否选中loudu
        var currentLouCount = 0;

        // 当前选中漏读
        if (this.numbers === "loZ") {
          this.zeCount = 0;
          currentLouCount = 1;
        }

        // 漏读
        this.zesCount = this.zesCount - this.zeOldCount + this.zeCount;
        this.losCount = this.losCount - this.louOldCount + currentLouCount;
      }
    },

    // 中文标注--句篇评分获取
    showSentenceScore(sentenceScore) {
      for (var i in sentenceScore) {
        this[i] =
          sentenceScore[i] === undefined
            ? i === "qt"
              ? []
              : 0
            : sentenceScore[i];
      }
    },

    // 中文标注--句篇总体评分
    gradeModal() {
      this.grade = true;

      // 错误和缺陷计数
      let nums = this.$refs.words;
      let errorArr = [];
      let defectArr = [];
      nums.forEach(value => {
        if (value.className.includes("error")) {
          errorArr.push("errors");
        } else if (value.className.includes("defect")) {
          defectArr.push("defect");
        }
      });

      this.defectCount = defectArr.length;
      this.errCount = errorArr.length;

      //漏读/增读数量
      this.setSents(this.param.sents);
    },

    // 中文标注--句篇评分
    // isClear表示需要清除值
    sureScore(isClear) {
      const sentenceScore = {
        qt: (this.qt = isClear ? [] : this.qt),
        xtscore: (this.xtscore = isClear ? "" : this.xtscore),
        ytscore: (this.ytscore = isClear ? "" : this.ytscore),
        tlscore: (this.tlscore = isClear ? "" : this.tlscore),
        ldscore: (this.ldscore = isClear ? "" : this.ldscore),
        losCount: (this.losCount = isClear ? "" : this.losCount),
        zesCount: (this.zesCount = isClear ? "" : this.zesCount),
        defectCount: (this.defectCount = isClear ? "" : this.defectCount),
        errCount: (this.errCount = isClear ? "" : this.errCount)
      };

      this.param.sentenceScore = sentenceScore;
      this.grade = false;
    },

    /**
     * 文件可用点击
     */
    availableClick() {
      // 只读，检查员不可以改好数据
      if (this.readonly || (this.mcType == 1 && this.param.valid_flag)) {
        return;
      }

      this.param.valid_flag = !this.param.valid_flag;
    },

    // 音频初始化
    audioPlay() {
      let wavesurfer = WaveSurfer.create({
        container: this.$refs.waveform,
        waveColor: "#368666",
        progressColor: "#6d9e8b",
        cursorColor: "#fff",
        height: 64,
        responsive: true,
        scrollParent: true
      });
      this.wavesurfer = wavesurfer;

      // 加载
      wavesurfer.on("loading", percents => {
        this.percent = percents;
        window.sessionStorage.setItem("audioProgress", true);
      });

      // 加载成功
      wavesurfer.on("ready", () => {
        this.progress = false;
        window.sessionStorage.removeItem("audioProgress");
        this.duration = parseInt(this.wavesurfer.getDuration());
      });

      // 播放中
      this.wavesurfer.on("audioprocess", () => {
        this.currentTime = parseInt(this.wavesurfer.getCurrentTime());
        if (this.currentTime === this.duration) {
          this.runIcon = true;
          this.playText = "播放";
        }
      });

      // 加载失败
      this.wavesurfer.on("error", () => {
        this.progress = false;
        window.sessionStorage.removeItem("audioProgress");
      });
    },

    // 播放
    play() {
      if (this.progress) {
        this.$message.warning("请等音频加载完再操作");
        return;
      }

      if (this.playText === "播放") {
        this.wavesurfer.play();
        this.runIcon = false;
        this.playText = "暂停";
      } else {
        this.wavesurfer.pause();
        this.runIcon = true;
        this.playText = "播放";
      }
    },

    // 停止
    stop() {
      if (this.progress) {
        this.$message.warning("请等音频加载完再操作");
        return;
      }
      this.wavesurfer.stop();
    },

    // 设置音量
    setVolume(value) {
      this.volume = value;
      this.wavesurfer.setVolume(value / 100);
    },

    // 选中标注文字
    markWord(index, idx, sent, beg, end, $event) {
      if (this.progress) {
        this.$message.warning("请等音频加载完再操作");
        return;
      }

      if (sent.is_biaozhu == 2) {
        return;
      }

      // 储存当前dom
      this.$element = $event.target;

      // 是否第一次点击
      if (this.once) {
        this.once = false;
      } else {
        this.save();
      }

      // 表示当前的字的唯一性标识
      this.wordIndex = `${index}-${idx}`;

      // 浅拷贝
      this.sent = sent;

      //对照
      this.dzContent = sent.content;
      this.dzPY = sent.pinyin;

      // 声母
      this.sm = sent.phone_info[0].errs[0].err_type;
      this.smValue = sent.phone_info[0].errs[0].replace;

      // 韵母
      this.ym = sent.phone_info[1].errs[0].err_type;
      this.ymValue = sent.phone_info[1].errs[0].replace;

      // 声调
      this.sd = sent.phone_info[1].errs[1].err_type;
      this.sdValue = sent.phone_info[1].errs[1].replace;

      // 轻声
      this.qs = sent.errs[0].qingsheng_err;

      // 儿化
      this.eh = sent.errs[0].erhua_err;

      // 错读\lou读
      this.numbers = sent.errs[0].err_type;
      // 是否是漏读
      this.louOldCount = this.numbers === "loZ" ? 1 : 0;
      if (this.numbers === "zeZ") {
        this.zeCount = Number(sent.errs[0].insert_count || 0);
      } else {
        this.zeCount = 0;
      }

      this.zeOldCount = this.zeCount;

      // 错误
      this.error = sent.errs[0].is_err;
      this.setError();

      // 去除只读
      this.disabled = false;

      // 音频读音
      this.wavesurfer.play(
        parseFloat((beg * 10) / 1000),
        parseFloat((end * 10) / 1000)
      );

      this.runIcon = true;
      this.playText = "播放";

      if (this.readonly) {
        this.disabled = true;
      }
    },

    //重置标注面板
    reset() {
      if (this.disabled && !this.readonly) {
        return;
      }
      this.sm = "";
      this.ym = "";
      this.sd = "";
      this.qs = "";
      this.eh = "";
      this.smValue = "";
      this.ymValue = "";
      this.sdValue = "";
      this.numbers = "";
      this.zeCount = 0;
      this.error = false;
      this.errIndex[this.wordIndex] && delete this.errIndex[this.wordIndex];
      this.defect[this.wordIndex] && delete this.defect[this.wordIndex];

      // 去除对应的样式,便于及时计数
      if (this.$element) {
        this.$element.className = this.$element.className.replace("error", "");
        this.$element.className = this.$element.className.replace("defect", "");
      }
    },

    // 保存标注内容
    save() {
      this.param.bad = !this.param.valid_flag;

      if (!this.wordIndex) {
        return;
      }
      // 标识已标注
      this.markDone[this.wordIndex] = true;
      this.sent.done = true;

      // 错误/缺陷标识
      this.setError();

      // 错增漏
      let count = "";
      this.numbers === "loZ" ? (count = 1) : (count = this.zeCount);

      const word_errs = {
        erhua_err: this.eh,
        qingsheng_err: this.qs,
        err_type: this.numbers,
        insert_count: count,
        is_err: this.error
      };

      const phone_info_errs = {
        err_type: this.sm,
        replace: this.smValue
      };

      const phone_info_ymerrs = [
        {
          err_type: this.ym,
          replace: this.ymValue
        },
        {
          err_type: this.sd,
          replace: this.sdValue
        }
      ];

      this.sent.errs[0] = word_errs;
      this.sent.phone_info[0].errs[0] = phone_info_errs;
      this.sent.phone_info[1].errs = phone_info_ymerrs;
      this.sent.is_erhua =
        this.eh === "ehD" || this.eh === "ehE" ? true : false;
    },

    // 错误和缺陷赋值
    setError() {
      if (!this.wordIndex) {
        return;
      }
      // 默认
      this.errIndex[this.wordIndex] = false;
      this.sent.error = false;
      this.defect[this.wordIndex] = false;
      this.sent.defect = false;

      // 错误标识
      if (
        this.sm === "smE" ||
        this.ym === "ymE" ||
        this.sd === "sdE" ||
        this.eh === "ehE" ||
        this.qs === "qsE" ||
        this.numbers === "loZ" ||
        this.error
      ) {
        this.errIndex[this.wordIndex] = true;
        this.sent.error = true;

        if (this.$element && !this.$element.className.includes("error")) {
          this.$element.className = this.$element.className + " error";
        }
      }

      // 缺陷标识
      if (
        this.sm === "smD" ||
        this.ym === "ymD" ||
        this.sd === "sdD" ||
        this.eh === "ehD" ||
        this.qs === "qsD" ||
        this.numbers === "zeZ"
      ) {
        this.defect[this.wordIndex] = true;
        this.sent.defect = true;

        if (this.$element && !this.$element.className.includes("defect")) {
          this.$element.className = this.$element.className + " defect";
        }
      }
    },

    // 声母切换
    smChange() {
      if (this.sm === "smD") {
        this.smValue = "";
      }
      this.setError();
    },

    // 韵母切换
    ymChange() {
      if (this.ym === "ymD") {
        this.ymValue = "";
      }
      this.setError();
    },

    // 声调切换
    sdChange() {
      if (this.sd === "sdD") {
        this.sdValue = "";
      }
      this.setError();
    },

    // 漏读/增读切换
    numbersChange() {
      this.zeCount = 0;
      this.setError();
    },

    // 轻声,儿化,错误切换
    errorChange() {
      this.setError();
    },

    /**
     * 快捷键设置
     */
    setKeyCode() {
      const type = this.type,
        that = this;

      // 阻止默认空格事件
      document.addEventListener("keydown", e => {
        const keyCode = e.keyCode || e.which;
        if (keyCode === 32) {
          e.preventDefault();
        }
      });
      document.addEventListener("keyup", that.setKeyUpEvt);
    },

    /**
     * 校验
     */
    valid() {
      return true;
    },

    /**
     * 点击空格控制音乐
     */
    setKeyUpEvt(e) {
      const that = this;
      const keyCode = e.keyCode || e.which;
      if (keyCode === 81) {
        e.preventDefault();
        that.play();
      }
    }
  },

  created() {
    var task = JSON.parse(window.sessionStorage.getItem("task"));
    // 1检查,0标注
    this.mcType = task.type;
    this.readonly = task.readonly;

    // 获取当前标注类型
    this.cnMarkType = this.$route.params.id;

    this.$nextTick(() => {
      this.audioPlay();
      this.setKeyCode();
    });
  },

  /**
   * 离开前操作，暂停播放音乐
   */
  beforeRouteLeave(to, from, next) {
    this.wavesurfer.pause();
    this.runIcon = true;
    this.playText = "播放";
    document.removeEventListener("keyup", this.setKeyUpEvt);
    next();
  }
};
</script>

<style lang="less" scoped>
.wave-form {
  width: 100%;
  position: relative;
  background: #000;
  margin: 20px auto 10px;
  .el-progress {
    position: absolute;
    top: 20px;
    left: 0;
    width: 100%;
    color: #fff;
  }
}
.audio-group {
  button {
    padding: 6px 10px 6px 25px;
    position: relative;
    .iconfont {
      position: absolute;
      top: 4px;
      left: 7px;
      font-size: 16px;
    }
  }
  .volume {
    display: inline-block;
    width: 100px;
    vertical-align: middle;
    margin-left: 30px;
    position: relative;
    .iconfont.icon-voice {
      position: absolute;
      left: -25px;
      top: 10px;
      color: #585757;
    }
  }
}
.content {
  margin: 20px auto;
  overflow: hidden;
  .main-content {
    position: relative;
    float: left;
    width: 57%;
    padding-bottom: 10px;
    border-radius: 2px;
    background: #f3f4f5;
    height: 440px;
    overflow-y: auto;
    box-sizing: border-box;
  }
  .main {
    width: 100%;
    background-size: 40px 40px;
    margin: 14px auto;

    .sents {
      display: inline-block;
      margin: 0 5px;
      box-shadow: 1px 1px 5px #dadada;
      border-radius: 4px;
      background: #fff;
      margin-bottom: 10px;
      .word {
        display: inline-block;
        font-size: 16px;
        width: 30px;
        height: 30px;
        text-align: center;
        line-height: 30px;
        color: #333;
        cursor: pointer;
        &:active {
          color: #555;
        }
      }

      .done {
        color: #999;
      }
      .defect {
        color: rgb(243, 19, 243);
      }
      .error {
        color: #ed3f14;
      }
      .erhua {
        font-weight: 700;
        font-style: oblique;
      }
      .active {
        color: #409eff;
        font-weight: bold;
      }
      .is-biaozhu {
        color: #eae5e5;
        cursor: not-allowed;
      }
    }
  }
  .side {
    float: right;
    width: calc(~"43% - 10px");
    background: #f3f4f5;
    color: #333;
    height: 440px;
    border-radius: 2px;
    dl {
      border-bottom: 1px solid #d8d8d8;
      height: 47px;
      line-height: 47px;
      &.zcl {
        height: auto;
        line-height: normal;
        dd {
          padding: 10px;
        }
      }
    }
    dt {
      display: inline-block;
      width: 80px;
      text-align: center;
      font-size: 14px;
    }
    dd {
      display: inline-block;
      border-left: 1px solid #d8d8d8;
      padding: 0 10px 0 10px;
      .name {
        display: inline-block;
        text-align: center;
        width: 100px;
        margin-right: 20px;
        font-size: 14px;
        text-overflow: ellipsis;
        overflow: hidden;
        white-space: nowrap;
        position: relative;
        top: 7px;
        line-height: 22px;
      }
      .label {
        display: inline-block;
        margin-left: 2px;
        .el-select {
          width: 75px;
        }
        .el-input__inner {
          padding: 0 3px;
        }
      }
      span {
        font-size: 14px;
      }
      button {
        padding: 5px 15px;
      }
      .zd-number {
        width: 75px;
        height: 26px;
        margin-left: 10px;
      }
    }
    .grade {
      text-align: center;
      margin-top: 20px;
      padding-bottom: 20px;
    }
  }
}

.modal-list {
  margin-bottom: 40px;
  dt {
    display: inline-block;
    width: 75px;
    font-size: 14px;
    vertical-align: top;
  }
  dd {
    display: inline-block;
    .label {
      display: inline-block;
      width: 85px;
      margin-left: 10px;
    }
    p {
      margin-bottom: 10px;
    }
    em {
      font-style: normal;
      color: red;
    }
    &.center {
      position: relative;
      top: -8px;
      left: -11px;
    }
  }
}
</style>

<style lang="less" scoped>
.cn-mark wave {
  overflow: hidden !important;
}
.volume .el-slider__button {
  width: 12px;
  height: 12px;
}
// .el-radio + .el-radio {
//   margin-left: 15px;
// }

.numbers {
  .el-radio {
    margin-bottom: 5px;
  }
  .el-input-number__decrease,
  .el-input-number__increase {
    display: none;
  }
}

.side .el-input__inner {
  padding: 0 2px;
  height: 26px;
  line-height: 26px;
}

.el-radio__input.is-disabled + span.el-radio__label {
  color: #7a7c7f;
}

.zd-number .el-input--small .el-input__inner {
  padding: 0 5px;
}
</style>




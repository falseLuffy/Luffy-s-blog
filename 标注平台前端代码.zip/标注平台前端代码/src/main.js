import Vue from 'vue'
import ElementUI from 'element-ui'
import App from './App'
import {router} from './router'
import store from './store'
import moment from "moment"
import VueMomentJS from "vue-momentjs"
import api from './axios'
import VeBar from 'v-charts/lib/bar.common'
import VueCodemirror from 'vue-codemirror'
import JsonExcel from 'vue-json-excel'
import BaiduMap from 'vue-baidu-map'

import 'element-ui/lib/theme-chalk/index.css'
import 'assets/font/iconfont.css'
import 'assets/styles/base.css'
import 'codemirror/lib/codemirror.css'

Vue.use(ElementUI, {
  size: 'small',
  zIndex: 3000
})
Vue.use(BaiduMap, {
  ak: 'w4POp2AmwnCd35rKPWSYX3NdWuG6Dq0h'
})
Vue.use(VueMomentJS, moment)
Vue.component(VeBar.name, VeBar)
Vue.use(api)
Vue.use(VueCodemirror)
Vue.component('downloadExcel', JsonExcel)

Vue.config.productionTip = false;

new Vue({
  el: '#app',
  components: {
    App
  },
  template: '<App/>',
  router,
  store,
})

<template>
  <div class="app-wrapper">
    <!-- 侧边栏 -->
    <nav-items></nav-items>

    <!-- 内容栏 -->
    <div class="main-container">
      <top-item></top-item>
      <div class="app-main">
        <section class="app-main-content">
          <router-view v-if="containerAlive"></router-view>
        </section>
      </div>
      <!-- 底部 -->
      <div class="copyright">版权所有 @科大讯飞股份有限公司</div>
    </div>
  </div>
</template>
<script>
import { mapState } from "vuex";
import NavItems from "./Nav";
import TopItem from "./Top";

export default {
  name: "Layout",
  components: {
    NavItems,
    TopItem
  },
  computed: {
    ...mapState(["containerAlive"]),
    key() {
      return this.$route.name !== undefined
        ? this.$route.name + new Date()
        : this.$route + new Date();
    }
  }
};
</script>
<style rel="stylesheet/less" lang="less" scoped>
.app-wrapper {
  position: relative;
  width: 100%;
  height: 100%;

  .main-container {
    float: left;
    width: calc(100% - 205px);
    height: calc(100% - 50px);
    margin-left: 5px;
  }
  .current-local {
    position: relative;
    box-sizing: border-box;
    height: 50px;
    float: left;
    min-width: 50%;
    .icon-place {
      position: absolute;
      font-size: 22px;
      color: #606266;
      top: 10px;
      left: 30px;
    }
    .app-levelbar {
      &:before {
        display: inline-block;
        content: "当前位置：";
        position: absolute;
        left: 60px;
        color: #606266;
      }
      &.el-breadcrumb {
        display: inline-block;
        font-size: 14px;
        line-height: 50px;
        position: relative;
        min-width: 30%;
        margin-top: -2px;
        height: 50px;
        padding-left: 130px;
        .no-redirect {
          color: #606266;
          cursor: text;
        }
      }
    }
  }

  .app-main {
    height: calc(~"100% - 45px");
    background: #f6f6f6;
  }

  .app-main-content {
    padding-top: 10px;
    background: #f6f6f6;
  }

  .copyright {
    position: fixed;
    bottom: 0;
    text-align: center;
    width: calc(100% - 180px);
    height: 50px;
    line-height: 50px;
    font-size: 12px;
    background: #f8f8f8;
    color: #838383;
    z-index: 1001;
  }
}
.fade-enter,
.fade-leave-to {
  opacity: 0;
}

.fade-enter-active,
.fade-leave-active {
  transition: all 0.5s;
}
</style>

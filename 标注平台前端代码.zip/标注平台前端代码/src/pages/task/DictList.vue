<template>
  <el-container class="dict-list">
    <el-main>
      <div class="dict-list-title">字典列表</div>
      <!-- 列表 -->
      <ul class="dict-content" v-loading="loading" element-loading-text="正在请求">
        <li v-for="(item,index) in dictData" v-if="dictData && dictData.length > 0" :key="index">
          <el-row>
            <el-col :span="24">
              <strong class="ellipsis">{{item.name}}</strong>
              <span
                class="dict-label"
                v-if="item.label && item.label.length > 0"
                v-for="(unit,index) of item.label"
                :key="index"
                :style="{backgroundColor:unit.color}"
              >{{unit.text}}</span>
            </el-col>
          </el-row>
          <!-- 状态显示 -->
          <el-row class="main-font">
            <el-col :span="8">简介：{{item.description}}</el-col>
            <el-col :span="6">
              <dl>
                <dt>创建人</dt>
                <dd>{{item.createdBy}}</dd>
              </dl>
            </el-col>
            <el-col :span="6">
              <dl>
                <dt>更新时间</dt>
                <dd>{{dateFormat(item.updateDate)}}</dd>
              </dl>
            </el-col>
            <el-col :span="4">
              <el-button type="primary" size="mini" @click="editDict(item)">编辑</el-button>
            </el-col>
          </el-row>
        </li>
        <!-- 无数据 -->
        <div class="dict-content-empty" v-show="contentEmpty"></div>
      </ul>
      <!-- 分页 -->
      <el-pagination
        v-if="total > 10"
        @size-change="sizeChange"
        @current-change="pageChange"
        align="right"
        layout="total, sizes, prev, pager, next, jumper"
        :current-page="page"
        :page-sizes="[5, 10, 20, 40]"
        :page-size="size"
        :total="total"
        class="pager-wrapper"
      ></el-pagination>
    </el-main>

    <el-dialog width="910px" top="2%" :visible.sync="editDictShow"></el-dialog>
  </el-container>
</template>
}
<script>
import { mapState } from "vuex";
export default {
  name: "DictList",
  computed: {
    ...mapState(["appInfo"])
  },
  watch: {
    appInfo() {
      if (this.appInfo.id) {
        this.query(1);
      }
    }
  },
  data() {
    return {
      contentEmpty: true,
      page: 1,
      size: 10,
      total: 0,
      value: "",
      dictData: [],
      editDictShow: false,
      loading: false,
      buttonColors: [
        "#409EFF",
        "#67c23a",
        "#909399",
        "#e6a23c",
        "#f56c6c",
        "#9422e8"
      ]
    };
  },
  methods: {
    //分页
    sizeChange(size) {
      this.size = size;
      this.query(1);
    },
    pageChange(page) {
      this.page = page;
      this.query();
    },

    // 列表获取
    query(resetPage) {
      if (resetPage == 1) {
        this.page = 1;
      }
      if (!this.appInfo.id) {
        return;
      }
      let param = {
        appId: this.appInfo.id,
        page: this.page,
        size: this.size
      };

      this.loading = true;
      this.$api.task
        .dictList(param)
        .then(res => {
          this.loading = false;
          let { content, totalElements } = res;
          this.total = totalElements;
          this.dictData = content;

          if (content.length > 0) {
            //  标签的数据处理
            this.dictData.forEach((item, index) => {
              let labels = item.label.split(",");
              let lastArr = [];
              labels.forEach((unit, order) => {
                let i;
                i = order > 5 ? order % 5 : order;
                lastArr.push({
                  text: labels[order],
                  color: this.buttonColors[i]
                });
              });

              item.label = lastArr;
            });

            this.contentEmpty = false;
          } else {
            this.contentEmpty = true;
          }
        })
        .catch(() => {
          this.loading = false;
        });
    },

    // 字典编辑
    editDict(row) {
      window.sessionStorage.setItem("editInfo", JSON.stringify(row));
      this.$router.push({ path: "/task/editDict" });
    },

    //日期格式化
    dateFormat(time) {
      if (!time) {
        return "";
      }
      return this.$moment(time).format("YYYY-MM-DD HH:mm");
    }
  },

  mounted() {
    this.query(1);
  }
};
</script>

<style rel="stylesheet/less" lang="less">
.dict-list {
  padding-bottom: 20px;
  .el-container .el-main {
    padding: 0px 15px;
  }

  .dict-content {
    padding: 0;
    margin-bottom: 35px;
    li {
      list-style: none;
      padding: 20px 0px;
      border-bottom: #ddd 1px dashed;
      .el-row {
        padding: 4px 0;
        font-size: 12px;
        strong {
          max-width: 300px;
          font-size: 14px;
          position: relative;
          top: 4px;
          margin-right: 10px;
        }
        .dict-label {
          color: #fff;
          padding: 3px 8px;
          text-align: center;
          border-radius: 3px;
          margin-right: 8px;
        }
      }
      .main-font {
        margin-top: 20px;
        .el-col-2 {
          text-align: center;
        }
        dd {
          margin-top: 10px;
        }
      }
      .el-icon-edit-outline {
        font-size: 18px;
        position: relative;
        left: -5px;
        &:hover {
          color: #4baffe;
        }
      }
    }
    .dict-content-empty {
      font-size: 14px;
      height: 400px;
      text-align: center;
      position: relative;
      &:before {
        display: inline-block;
        width: 110px;
        height: 90px;
        background-image: url("~@/assets/images/nodata.png");
        background-size: cover;
        content: "";
        position: absolute;
        left: 50%;
        top: 50%;
      }
      &:after {
        content: "暂无数据";
        position: absolute;
        left: calc(50% + 28px);
        top: calc(50% + 100px);
        color: #909399;
      }
    }
  }

  .dict-list-title {
    font-weight: bold;
    margin: 20px 0;
  }
}
.el-button--mini,
.el-button--mini.is-round {
  padding: 5px 10px;
}
.el-table__empty-block {
  min-height: 250px;
}
</style>











<template>
  <el-container class="get-check-task">
    <!-- 用户列表 -->
    <el-main>
      <div class="user-table">
        <el-table
          size="small"
          class="table1"
          ref="userTable"
          :data="markUserData"
          @selection-change="changeUserFun"
          @row-click="rowClick"
          align="center"
          border
          height="370"
          v-loading="loading"
          element-loading-text="正在请求"
        >
          <el-table-column type="selection" width="50" :selectable="userSelected"></el-table-column>
          <el-table-column type="index" label="序号" min-width="50"></el-table-column>
          <el-table-column label="标注员" :show-overflow-tooltip="true" width="180">
            <template slot-scope="scope">
              <span
                class="font-grey"
                v-if="scope.row.selected"
              >{{scope.row.markerName}}（{{scope.row.markerId}}）</span>
              <span v-else>{{scope.row.markerName}}（{{scope.row.markerId}}）</span>
            </template>
          </el-table-column>
          <el-table-column label="提交时间" width="140" :formatter="dateFormat">
            <template slot-scope="scope">
              <span class="font-grey" v-if="scope.row.selected">{{scope.row.commitDate}}</span>
              <span v-else>{{scope.row.commitDate}}</span>
            </template>
          </el-table-column>
          <el-table-column label="数据数量" width="72">
            <template slot-scope="scope">
              <span class="font-grey" v-if="scope.row.selected">{{scope.row.totalCount}}</span>
              <span v-else>{{scope.row.totalCount}}</span>
            </template>
          </el-table-column>
        </el-table>
        <el-pagination
          size="small"
          @current-change="pageChange"
          align="left"
          :current-page="page"
          :page-size="size"
          layout="total, prev, pager, next"
          :total="total"
        ></el-pagination>
      </div>

      <!-- 已选列表 -->
      <el-table
        size="small"
        class="dis-table"
        :data="distribute"
        align="center"
        border
        height="362"
      >
        <el-table-column label="已选检查任务" :show-overflow-tooltip="true">
          <template slot-scope="scope">
            <span>{{scope.row.markerName}}（{{scope.row.markerId}}）</span>
            <span class="task-num">{{scope.row.totalCount}}</span>
            <i class="iconfont icon-del" title="移除" @click="removeDistribute(scope.row)"></i>
          </template>
        </el-table-column>
      </el-table>
    </el-main>
    <div class="count">
      <span>
        共
        <strong>{{distribute.length}}</strong>个子任务,共
        <strong>{{totalDataNum}}</strong>条数据
      </span>
    </div>
    <el-footer>
      <div align="right">
        <el-button size="small" @click="cancle">取 消</el-button>
        <el-button size="small" type="primary" @click="submitReceive">确 定</el-button>
      </div>
    </el-footer>
  </el-container>
</template>
<script>
import { mapMutations } from "vuex";
export default {
  props: ["id"],
  data() {
    return {
      //标注员列表
      markUserData: [],
      //已选列表
      distribute: [],
      loading: false,
      page: 1,
      size: 8,
      total: 0,
      totalDataNum: 0
    };
  },

  methods: {
    ...mapMutations(["showLoading", "closeLoading"]),
    sizeChange(size) {
      this.size = size;
      this.query(1);
    },

    pageChange(page) {
      this.page = page;
      this.query(page);
    },

    query(resetPage) {
      if (resetPage == 1) {
        this.page = 1;
      }
      this.loading = true;
      this.$api.mark
        .receiveCheckUserList({
          taskId: this.id,
          page: this.page,
          size: this.size
        })
        .then(res => {
          let { content, totalElements } = res;
          this.markUserData = content;
          this.total = totalElements;
          this.updateUserData();
          this.loading = false;
        })
        .catch(() => {
          this.loading = false;
        });
    },

    // 时间格式化
    dateFormat(row, column) {
      let time = row[column.property];
      if (!time) {
        return "";
      }
      return this.$moment(time).format("YYYY-MM-DD HH:mm:ss");
    },

    // 选中用户：选中后的用户列表禁用，分配列表加入，如果没有则直接添加，有则不动
    changeUserFun(user, row) {
      if (!this.distribute.length) {
        this.distribute = JSON.parse(JSON.stringify(user));
      }
      this.markUserData.forEach(item => {
        user.find(unit => {
          if (unit.id === item.id) {
            this.$set(item, "selected", true);
            if (this.distribute.length > 0) {
              let hasUser = false;
              this.distribute.find(dis => {
                if (dis.id === unit.id) {
                  hasUser = true;
                }
              });
              if (!hasUser) {
                this.distribute.push(JSON.parse(JSON.stringify(item)));
              }
            }
          }
        });
      });
      this.computedTotalNum();
    },

    // 点击行toggle复选框
    rowClick(row) {
      this.$refs.userTable.toggleRowSelection(row, true);
    },

    // 用户选中
    userSelected(row) {
      if (row.selected) {
        return false;
      } else {
        return true;
      }
    },

    // 根据候选更新标注员
    updateUserData() {
      this.markUserData.forEach(item => {
        if (this.distribute.length > 0) {
          //如果item.id在distribute里，则禁用，否则开放
          let findFlag = false;
          this.distribute.find(unit => {
            if (unit.id === item.id) {
              this.$set(item, "selected", true);
              findFlag = true;
            }
          });

          if (!findFlag) {
            this.$set(item, "selected", false);
            this.$refs.userTable.toggleRowSelection(item, false);
          }
        } else {
          this.$set(item, "selected", false);
          this.$refs.userTable.toggleRowSelection(item, false);
        }
      });
      this.computedTotalNum();
    },

    // 移除用户
    removeDistribute(row) {
      // 移除distribute中的数据
      this.distribute = this.distribute.filter(item => {
        return item.id !== row.id;
      });

      this.updateUserData();
    },

    cancle() {
      this.$emit("closeCheckDialog");
    },

    submitReceive() {
      this.showLoading(true);
      let ids = [];
      this.distribute.forEach(item => {
        ids.push(item.id);
      });
      this.$api.mark
        .receiveCheck({
          ids: ids
        })
        .then(res => {
          this.$emit("query");
          this.$emit("closeCheckDialog");
          this.$message.success("检查任务领取成功！");
          this.closeLoading(true);
        })
        .catch(() => {
          this.$message.error("检查任务领取失败！");
          this.closeLoading(true);
        });
    },

    computedTotalNum() {
      this.totalDataNum = 0;
      this.distribute.forEach(item => {
        this.totalDataNum = this.totalDataNum + item.totalCount;
      });
    }
  },

  created() {
    this.query(1);
  }
};
</script>
<style lang="less" scoped>
.get-check-task {
  .user-table,
  .dis-table {
    float: left;
    width: 40%;
  }
  .user-table {
    width: 53%;
    margin-right: 7%;
    .el-table__row {
      cursor: pointer;
    }
    .el-pagination {
      min-height: 0px !important;
      margin-top: 0px;
    }
  }
  .dis-table {
    .icon-del {
      color: #7e8287;
      position: absolute;
      right: 10px;
      top: 9px;
      font-size: 15px;
      cursor: pointer;
    }
    .el-table .cell {
      line-height: 26px;
    }
    .task-num {
      position: absolute;
      right: 160px;
    }
  }
  .count {
    position: absolute;
    top: 78%;
    right: 45px;
  }
}
</style>


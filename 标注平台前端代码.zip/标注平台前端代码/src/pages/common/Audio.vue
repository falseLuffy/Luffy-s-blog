<!-- 音频组件 -->
<template>
  <div class="mark-audio">
    <!-- 音频 :style="{backgroundImage:`url(${vedioBg})`}"-->
    <div id="waveform" ref="waveform" class="wave-form">
      <el-progress :percentage="percent" :stroke-width="8" v-if="progress"></el-progress>
    </div>
    <!-- 音频控制按钮 -->
    <div class="audio-group">
      <el-button
        type="primary"
        @click="play"
        size="small"
        :class="{'loop': (activeRegion && activeRegion.id)}"
      >
        <i :class="['iconfont',{'icon-run':runIcon,'icon-pause':!runIcon}]"></i>
        <span>{{playText}}</span>
      </el-button>
      <el-button type="warning" @click="stop" size="small">
        <i class="iconfont icon-stop"></i>重置
      </el-button>

      <div class="volume">
        <div class="volume-content">
          <i class="iconfont icon-voice"></i>
          <el-slider v-model="volume" @change="setVolume"></el-slider>
        </div>
      </div>

      <div class="time-show">
        <span class="time-text">时间：</span>
        <span class="font-primary current-time">{{currentTime}}秒</span>
        <span class="time-text">时长：</span>
        <span class="duration-time">{{duration}}秒</span>
      </div>
    </div>
  </div>
</template>

<script>
import WaveSurfer from "wavesurfer.js/dist/wavesurfer.js";
import RegionsPlugin from "wavesurfer.js/dist/plugin/wavesurfer.regions.min.js";
import Cookies from "js-cookie";

export default {
  props: ["audio", "leavemusic", "region", "regionRead"],
  data() {
    return {
      color1: "rgba(254, 240, 240, 0.5)", // 已选
      color3: "rgba(230, 189, 189, 0.8)", // 选中
      duration: 0,
      currentTime: 0,
      progress: true,
      percent: 0,
      wavesurfer: null,
      waveRegionBind: false,
      regionArray: {}, // 最终绘制的区域图形
      activeRegion: null, // 当前正在编辑的
      newRegion: false, // 是否手动更新
      volume: 50,
      playText: "播放",
      runIcon: true,
      results: null,
      autoPause: false,
      vedioBg: ""
    };
  },

  components: {},

  watch: {
    // 控制音频源
    audio() {
      this.reset();
      this.audioPlay();
    },

    // 离开页面，停止音频播放
    leavemusic() {
      if (this.leavemusic) {
        this.setPause();
        document.removeEventListener("keyup", this.setKeys);
      }
    }
  },

  methods: {
    reset() {
      this.duration = 0;
      this.currentTime = 0;
      this.progress = true;
      this.percent = 0;
      this.playText = "播放";
      this.runIcon = true;
      this.activeRegion = null;
    },

    /**
     * 获取当前时间
     */
    getCurrentTime(num) {
      if (num) {
        return Number(this.wavesurfer.getCurrentTime().toFixed(num));
      } else {
        return Number(this.wavesurfer.getCurrentTime().toFixed(2));
      }
    },

    /**
     * 音频初始化
     */
    audioPlay() {
      let that = this;
      if (!this.wavesurfer) {
        this.wavesurfer = WaveSurfer.create({
          container: this.$refs.waveform,
          waveColor: "#368666",
          progressColor: "#6d9e8b",
          cursorColor: "#fff",
          height: 80,
          responsive: true,
          scrollParent: true,
          // backend: "MediaElement",
          // partialRender: true, // 部分加载
          plugins: [RegionsPlugin.create()]
        });
      }

      this.wavesurfer.load(this.audio, null, "metadata");

      // this.wavesurfer.load(
      //   this.audio,
      //   [0.0218, 0.0183, 0.0165, 0.0198, 0.2137, 0.2888],
      //   "metadata"
      // );

      // 加载时候
      this.wavesurfer.on("loading", percents => {
        this.percent = percents;
        window.sessionStorage.setItem("audioProgress", true);
      });

      // 加载成功
      this.wavesurfer.on("ready", () => {
        this.progress = false;
        window.sessionStorage.removeItem("audioProgress");
        this.duration = Number(this.wavesurfer.getDuration().toFixed(3));
        this.$emit("ready", this.duration, this.wavesurfer);

        // 区域渲染
        if (this.region) {
          this.clearRegion();

          // 绘制区域
          if (this.results) {
            this.results.forEach(item => {
              this.addOneRegion(item);
            });
            this.results = null;
          }

          if (!this.regionRead) {
            // 设置成可拖动区域
            this.wavesurfer.enableDragSelection({
              color: this.color3
            });

            // 创建新的region回调
            this.wavesurfer.on("region-created", () => {
              if (!that.runIcon) {
                that.play();
              }
              that.newRegion = true;
            });

            // 创建区域成功后
            this.wavesurfer.on("region-update-end", res => {
              that.wavesurfer.pause();

              // 如果是新创建的，则移除旧的
              if (that.activeRegion && that.activeRegion.id && that.newRegion) {
                if (this.regionArray[that.activeRegion.id]) {
                  that.cancelActiveRegion();
                } else {
                  that.activeRegion.remove();
                }
                that.activeRegion = null;
              }
              // 当前激活
              that.newRegion = false;
              that.activeRegion = res;

              // 更新输入区数据
              that.$emit("setActiveRegion", { ...res });

              // 指针移动
              that.wavesurfer.seekTo(res.start / that.duration);
            });
          }

          // 双击区域
          this.wavesurfer.on("region-dblclick", res => {
            if (!that.runIcon) {
              that.play();
            }

            // 获取当前激活组件的id
            let activeId =
              this.activeRegion && this.activeRegion.id
                ? this.activeRegion.id
                : null;

            // 获取当前组件
            this.changeActiveRegion(res.id, activeId === res.id ? true : false);
          });
        }

        // this.vedioBg = "/static/seg.png";

        // 播放中
        this.wavesurfer.on("audioprocess", () => {
          this.currentTime = this.getCurrentTime();
        });

        // 结束播放
        this.wavesurfer.on("finish", () => {
          this.setPause();
        });

        // 暂停播放
        this.wavesurfer.on("pause", () => {
          if (this.activeRegion && this.activeRegion.id) {
            // 自动停的，继续播放
            if (this.autoPause) {
              this.activeRegion.play();
            } else {
              this.runIcon = true;
              this.playText = "播放";
              // 指针移动
              this.wavesurfer.seekTo(this.activeRegion.start / this.duration);
            }
          }
        });

        // seek
        this.wavesurfer.on("seek", pos => {
          let currentTime = pos * that.wavesurfer.getDuration();
          that.currentTime = Number(currentTime.toFixed(2));
        });
      });

      // 加载失败
      this.wavesurfer.on("error", () => {
        this.progress = false;
        window.sessionStorage.removeItem("audioProgress");
      });
    },

    /**
     * 取消上个激活，恢复位置
     */
    cancelActiveRegion() {
      let that = this;
      let activeId =
        this.activeRegion && this.activeRegion.id ? this.activeRegion.id : null;

      // 取消当前激活,，恢复原样
      if (activeId) {
        if (that.regionArray[activeId]) {
          // 获取列表中的数据，始终显示列表保存的数据，防止修改后不保存导致位置偏差
          this.$emit("getListData", activeId);
        } else {
          that.activeRegion.remove();
        }
      }

      // 编辑区域清空
      this.$emit("setActiveRegion", {
        start: 0,
        end: 0,
        text: ""
      });
      this.activeRegion = null;
    },

    /**
     * 从外部更新对应id的区域
     */
    updateIdRegion(res) {
      if (res) {
        let { regionId, text, xmin, xmax } = res;
        this.regionArray[regionId].update({
          color: this.color1,
          drag: false,
          start: xmin,
          end: xmax
        });
        this.regionArray[regionId].text = text;
      }
    },

    /**
     * 外部更新激活active区域
     */
    updateActiveRegion(res) {
      let { xmin, xmax, text } = res;
      let id = new Date().getTime();

      if (!this.activeRegion) {
        if (xmax > xmin) {
          this.activeRegion = this.wavesurfer.addRegion({
            id: id,
            start: xmin,
            end: xmax,
            loop: false,
            drag: true,
            resize: true,
            color: this.color3
          });

          this.newRegion = false;

          // 更新输入区数据start, end, text, id
          this.$emit("setActiveRegion", {
            start: xmin,
            end: xmax,
            text: text,
            id: id
          });

          // 指针移动
          this.wavesurfer.seekTo(xmin / this.duration);
        }
      } else {
        this.activeRegion.update({
          start: xmin,
          end: xmax
        });
      }
    },

    /**
     * 切换激活组件
     * @id 要激活的组件
     * @isSelf 激活组件是不是自己
     */
    changeActiveRegion(id, isSelf) {
      let that = this;

      // 取消当前激活
      that.cancelActiveRegion();

      // 重置激活
      if (that.regionArray[id]) {
        that.regionArray[id].update({
          color: isSelf ? that.color1 : that.color3,
          drag: this.regionRead ? false : true,
          resize: this.regionRead ? false : true
        });
      }

      if (!isSelf) {
        // 编辑区域同步显示
        that.$emit("setActiveRegion", { ...that.regionArray[id] });
        that.activeRegion = that.regionArray[id];
      } else {
        // 取消当前激活组件
        that.cancelActiveRegion();
      }
    },

    /**
     * 获取结果并设置结果
     */
    getResults(results) {
      results.forEach((item, index) => {
        item.regionId = (index + 1) * new Date().getTime();
      });
      this.results = [...results];
      return results;
    },

    /**
     * 生成一个region
     * item.xmin, item.xmax, item.regionId,item.text
     */
    addOneRegion(item) {
      let { xmin, xmax, regionId, text } = item;
      var rId = regionId ? regionId : new Date().getTime();

      let waveRegion = this.wavesurfer.addRegion({
        id: rId,
        start: xmin,
        end: xmax,
        loop: false,
        drag: true,
        resize: true,
        color: this.color1
      });

      waveRegion.text = text;
      this.regionArray[rId] = waveRegion;

      this.regionArray[rId].update({
        drag: false,
        resize: false
      });
    },

    /**
     * 清除所有的region
     */
    clearRegion() {
      // 清空有的音频
      this.wavesurfer.unAll();
      this.wavesurfer.disableDragSelection();
      this.wavesurfer.clearRegions();
      this.activeRegion = null;
      this.regionArray = {};

      this.vedioBg = "";
    },

    /**
     * 插入下一段修改区域情况
     */
    appendRegionToData(text) {
      let that = this;
      if (this.activeRegion) {
        // 停止播放
        if (!this.runIcon) {
          this.play();
        }

        // 禁止拖拽
        this.activeRegion.update({
          resize: false,
          drag: false,
          color: that.color1
        });

        let { id, element } = this.activeRegion;
        this.activeRegion.text = text;

        // 将绘制的区域放到数组中
        this.regionArray[id] = this.activeRegion;

        // 去除当前激活组件
        this.activeRegion = null;

        return id;
      }
    },

    /**
     * 删除绘制的标注图形
     */
    removeRegion(id) {
      if (id) {
        if (this.regionArray[id]) {
          this.regionArray[id].remove();
          if (
            this.activeRegion &&
            this.activeRegion.id &&
            id === this.activeRegion.id
          ) {
            this.cancelActiveRegion();
          }
        } else {
          this.activeRegion.remove();
          this.cancelActiveRegion();
        }
      }
    },

    /**
     * 设置暂停
     * @param boolean true 表示仅仅改文字
     */
    setPause(type) {
      this.autoPause = false; // 表示是不是自动暂停

      this.wavesurfer.pause();
      this.runIcon = true;
      this.playText = "播放";
    },

    /**
     * 设置播放
     */
    setPlay() {
      // 循环播放选中区域
      if (this.activeRegion && this.activeRegion.id) {
        this.autoPause = true;

        this.activeRegion.play();
      } else {
        this.wavesurfer.play();
      }

      this.runIcon = false;
      this.playText = "暂停";
    },

    /**
     * 播放/暂停切换
     */
    play() {
      if (this.progress) {
        this.$message.warning("请等音频加载完再操作");
        return;
      }
      if (this.playText === "播放") {
        if (this.currentTime == this.duration) {
          this.wavesurfer.stop();
        }
        this.setPlay();
      } else {
        this.setPause();
      }
    },

    /**
     * 停止播放
     */
    stop() {
      if (this.progress) {
        this.$message.warning("请等音频加载完再操作");
        return;
      }
      if (this.activeRegion && this.activeRegion.id) {
        this.autoPause = false;
      }
      this.wavesurfer.stop();
      this.runIcon = true;
      this.playText = "播放";
    },

    /**
     * 设置音量
     * @param value 音量大小
     */
    setVolume(value) {
      this.volume = value;
      this.wavesurfer.setVolume(value / 100);
    },

    /**
     * 快捷键设置
     */
    setKeys(e) {
      let that = this;
      const keyCode = e.keyCode || e.which;

      // 如果在文本框中则不可以使用快捷键
      var type = e.srcElement ? e.srcElement.type : e.target.type; // 看当前所处环境

      if (type === "text" || type === "textarea") {
        return;
      }

      if (document.getElementsByClassName("v-modal").length > 0) {
        // this.$message.error("请关闭弹窗后再操作");
        e.preventDefault();
        return;
      }

      // 点击Q键
      if (keyCode === 81) {
        e.preventDefault();
        this.play();
      }

      // 点击delete键
      if (
        keyCode == 46 &&
        this.activeRegion &&
        this.activeRegion.id &&
        !this.regionRead
      ) {
        this.$emit("deleteRow", this.activeRegion.id);
      }
    }
  },

  created() {
    this.$nextTick(() => {
      this.audioPlay();
      document.addEventListener("keyup", this.setKeys);
    });
  }
};
</script>
<style rel="stylesheet/less"  lang="less" scoped>
.wave-form {
  width: 100%;
  height: 80px;
  position: relative;
  background: #000;

  background-repeat: no-repeat;
  background-size: 100% 100%;
  margin: 20px auto 10px;
  .el-progress {
    position: absolute;
    top: 32px;
    left: 0;
    width: 100%;
    color: #fff;
  }
}
.audio-group {
  margin-bottom: 20px;
  button {
    padding: 6px 10px 6px 25px;
    position: relative;
    &.loop {
      background-color: #3ae33f;
      border-color: #3ae33f;
    }
    .iconfont {
      position: absolute;
      top: 4px;
      left: 7px;
      font-size: 16px;
    }
  }
  .volume {
    display: inline-block;
    width: 100px;
    vertical-align: middle;
    margin-left: 30px;
    position: relative;
    .iconfont.icon-voice {
      position: absolute;
      left: -25px;
      top: 10px;
      color: #585757;
    }
  }
  .time-show {
    float: right;
    line-height: 38px;
    .time-text {
      display: inline-block;
      width: 42px;
    }
    .current-time,
    .duration-time {
      margin-right: 15px;
      font-size: 16px;
      font-weight: bold;
    }
    .current-time {
      display: inline-block;
      margin-right: 0px;
      width: 75px;
    }
  }
}
</style>

<style lang="less" scoped>
.volume .el-slider__button {
  width: 12px;
  height: 12px;
}
.el-radio + .el-radio {
  margin-left: 15px;
}
.mark-region-end {
  position: relative;
  background-color: rgba(254, 255, 255, 0.4) !important;
}
.wavesurfer-region {
  cursor: pointer;
  &::before,
  &::after {
    width: 6px;
    height: 6px;
    border-radius: 5px;
    background-color: blue;
    position: absolute;
    content: "";
    display: inline-block;
    bottom: 0;
    z-index: 9999;
  }
  &::before {
    left: -3px;
  }
  &::after {
    background-color: red;
    right: -3px;
  }
}
.mark-region-select {
  background-color: rgba(230, 189, 189, 0.7) !important;
}
</style>

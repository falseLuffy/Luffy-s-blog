<template>
  <el-container>
    <!-- 按钮 -->
    <el-header height="5%">
      <el-button class="back-btn" size="small" @click="prevStep">返回</el-button>
    </el-header>

    <el-main>
      <!-- 任务信息 -->
      <div class="proj-info">
        <div class="proj-text">
          <el-button
            size="small"
            type="primary"
            icon="el-icon-edit"
            @click="editInfo"
            v-if="!infoEdit"
          >编辑配置</el-button>
          <el-button size="small" type="success" icon="el-icon-check" @click="editInfo" v-else>确认编辑</el-button>

          <el-button
            size="small"
            icon="el-icon-edit"
            @click="editInfo(1)"
            v-if="infoEdit"
            style="margin-right:10px"
          >取消编辑</el-button>
          <strong>{{name}}</strong>
          <ul>
            <li>
              <span>创建人：</span>
              {{createdBy}}
            </li>
            <li>
              <span>创建时间：</span>
              {{createdDate}}
            </li>
            <li>
              <span>应用简介：</span>
              {{description}}
            </li>
            <li>
              <span>KEY：</span>
              {{appKey}}
            </li>
            <li>
              <span>Secret：</span>
              {{appSecret}}
            </li>
          </ul>

          <ul>
            <li>
              <span>任务权限：</span>
              <template v-if="infoEdit">
                <el-radio-group v-model="projInfo.openLevel" size="small">
                  <el-radio :label="20">公开任务</el-radio>
                  <el-radio :label="21">私有任务</el-radio>
                </el-radio-group>
              </template>
              <span class="task-unset" v-else>{{projInfoName.openLevel}}</span>
              <span class="task-tip" v-if="projInfo.openLevel=='21' && infoEdit">（私有任务只能被管理员分配）</span>
            </li>

            <li
              v-if="(projInfo.openLevel=='20' && infoEdit) || (projInfoName.openLevel!=='未配置' && !infoEdit)"
            >
              <span>最大可领取数：</span>
              <el-input-number
                size="small"
                v-if="infoEdit"
                :precision="0"
                :min="0"
                placeholder="最大可领取数"
                v-model="projInfo.maxApplyNumber"
              ></el-input-number>
              <span class="task-unset" v-else>{{projInfo.maxApplyNumber}}</span>
            </li>

            <li>
              <span>标注方式：</span>
              <template v-if="infoEdit">
                <el-radio-group v-model="projInfo.markMethod" size="small">
                  <el-radio :label="30">单次标注</el-radio>
                  <el-radio :label="31">多次标注</el-radio>
                </el-radio-group>
              </template>
              <span class="task-unset" v-else>{{projInfoName.markMethod}}</span>
            </li>

            <li
              v-if="(projInfo.markMethod=='31' && infoEdit) || (projInfoName.markMethod!=='未配置' && !infoEdit)"
            >
              <span>标注次数：</span>
              <el-input-number
                size="small"
                v-if="infoEdit"
                :min="1"
                :precision="0"
                placeholder="标注次数"
                v-model="projInfo.markRound"
              ></el-input-number>
              <span class="task-unset" v-else>{{projInfo.markRound}}</span>
            </li>

            <li>
              <span>是否检查：</span>
              <template v-if="infoEdit">
                <el-radio-group v-model="projInfo.whetherCheck" size="small">
                  <el-radio :label="41">是</el-radio>
                  <el-radio :label="40">否</el-radio>
                </el-radio-group>
              </template>
              <span class="task-unset" v-else>{{projInfoName.whetherCheck}}</span>
            </li>

            <li
              v-if="(projInfo.whetherCheck=='41' && infoEdit) || (projInfoName.whetherCheck!=='未配置' && projInfoName.whetherCheck!=='不检查' && !infoEdit)"
            >
              <span>检查比例(%)：</span>
              <template v-if="infoEdit">
                <el-input-number
                  size="small"
                  :precision="0"
                  :max="100"
                  :min="0"
                  placeholder="检查比例"
                  v-model="projInfo.checkRate"
                ></el-input-number>
                <span class="task-tip">（检查员可以领取不低于此比例的检查任务）</span>
              </template>
              <span class="task-unset" v-else>{{projInfo.checkRate}}</span>
            </li>

            <li>
              <span>打回方式:</span>
              <template v-if="infoEdit">
                <el-radio-group v-model="projInfo.rejectBy" @change="rejectByChange">
                  <el-radio :label="70">手动打回</el-radio>
                  <el-radio :label="71">自动打回</el-radio>
                </el-radio-group>
              </template>
              <span class="task-unset" v-else>{{projInfoName.rejectBy}}</span>
            </li>

            <li v-if="projInfo.rejectBy === 71 && infoEdit">
              <span>合格阈值：</span>
              <template>
                <el-input-number
                  size="small"
                  :precision="0"
                  :max="100"
                  :min="1"
                  placeholder="合格阈值"
                  v-model="projInfo.passRateThreshold"
                ></el-input-number>
              </template>
            </li>

            <li v-if="!infoEdit && projInfo.rejectBy === 71">
              <span>合格阈值：</span>
              <span class="task-unset">{{projInfo.passRateThreshold}}</span>
            </li>
            <li>
              <span>正确率统计：</span>
              <template v-if="infoEdit">
                <el-radio-group v-model="projInfo.checkBy" size="small">
                  <el-radio :label="50">检查员统计</el-radio>
                  <el-radio :label="51">机器统计</el-radio>
                </el-radio-group>
              </template>
              <span class="task-unset" v-else>{{projInfoName.checkBy}}</span>
              <span class="task-tip" v-if="projInfo.checkBy == '50'&& infoEdit">（检查员的检查结果计算正确率）</span>
              <span class="task-tip" v-if="projInfo.checkBy == '51'&& infoEdit">（机器的检查结果计算正确率）</span>
            </li>

            <li>
              <span>坏数据检查:</span>
              <template v-if="infoEdit">
                <el-radio-group v-model="projInfo.badDataProcess">
                  <el-radio :label="80">检查</el-radio>
                  <el-radio :label="81">不检查</el-radio>
                  <span class="task-tip" v-if="projInfo.badDataProcess === 80">（坏数据需要检查员核对）</span>
                  <span class="task-tip" v-if="projInfo.badDataProcess === 81">（坏数据不需要检查员核对）</span>
                </el-radio-group>
              </template>
              <span class="task-unset" v-else>{{projInfoName.badDataProcess}}</span>
            </li>

            <li>
              <span>机器质检：</span>
              <template v-if="infoEdit">
                <el-radio-group v-model="projInfo.checkByMachine" size="small">
                  <el-radio :label="60">是</el-radio>
                  <el-radio :label="61">否</el-radio>
                </el-radio-group>
              </template>
              <span class="task-unset" v-else>{{projInfoName.checkByMachine}}</span>
            </li>

            <li v-if="projInfo.checkByMachine=='60'">
              <span>质检结果：</span>
              <el-radio-group
                v-if="infoEdit"
                v-model="projInfo.machineCheckType"
                class="robot-result"
                size="small"
              >
                <el-row>
                  <el-radio :label="62">机器质检标注员结果</el-radio>
                </el-row>
                <el-row>
                  <el-radio :label="63">机器质检检查员结果</el-radio>
                </el-row>
                <el-row>
                  <el-radio :label="64">机器质检标注员和检查员结果</el-radio>
                </el-row>
              </el-radio-group>
              <span class="task-unset" v-else style="width:200px">{{projInfoName.machineCheckType}}</span>
            </li>
          </ul>
        </div>

        <!-- 应用管理员 -->
        <div class="proj-user">
          <strong>应用管理员</strong>
          <el-table
            :data="userData"
            align="center"
            height="450"
            v-loading="userloading"
            element-loading-text="正在请求"
            size="small"
          >
            <el-table-column prop="login" label="账号"></el-table-column>
            <el-table-column label="应用管理员姓名" width="150px" :show-overflow-tooltip="true">
              <template slot-scope="scope">
                <span v-if="!scope.row.edit">{{scope.row.cnName}}</span>
                <el-select
                  size="small"
                  v-else
                  v-model="scope.row.cnName"
                  filterable
                  placeholder="请选择"
                  @change="selectUser(scope.row.cnName)"
                  @visible-change="openUser($event)"
                >
                  <el-option
                    v-for="item in useroptions"
                    :key="item.id"
                    :label="item.cnName"
                    :value="item.id"
                  ></el-option>
                </el-select>
              </template>
            </el-table-column>
            <el-table-column label="操作">
              <template slot-scope="scope">
                <el-button size="mini" type="primary" @click.native="userDel(scope.row)">移除</el-button>
              </template>
            </el-table-column>
          </el-table>

          <el-button size="small" class="add-user" @click="userAdd">
            <i class="iconfont icon-add"></i>添加新应用管理员
          </el-button>
        </div>
      </div>

      <!-- 应用高级配置 -->
      <div class="datawood-table">
        <div class="datawood-name" style="float:none">应用高级配置</div>

        <el-tabs v-model="setType" @tab-click="setHandleClick">
          <el-tab-pane label="预处理器配置" name="PRE"></el-tab-pane>
          <el-tab-pane label="分析处理器配置" name="ANALYSIS"></el-tab-pane>
          <el-tab-pane label="导出处理器配置" name="EXPORT"></el-tab-pane>
        </el-tabs>

        <el-table
          :data="setData"
          align="center"
          height="450"
          v-loading="setloading"
          element-loading-text="正在请求"
          size="small"
        >
          <el-table-column
            type="index"
            label="序号"
            width="50"
            :index="(index)=>{return (setpage - 1) * setsize + index + 1}"
          ></el-table-column>
          <el-table-column prop="name" label="处理器名称"></el-table-column>
          <el-table-column prop="desc" label="处理器描述" min-width="180" :show-overflow-tooltip="true"></el-table-column>
          <el-table-column label="操作">
            <template slot-scope="scope">
              <el-button size="mini" type="primary" @click.native="setDel(scope.row.id)">移除</el-button>
            </template>
          </el-table-column>
        </el-table>

        <el-row class="datawood-add">
          <el-button @click="setAdd()" size="small">
            <i class="iconfont icon-add"></i>添加新处理器
          </el-button>
        </el-row>

        <el-pagination
          @size-change="setsizeChange"
          @current-change="setpageChange"
          :current-page="setpage"
          :page-size="setsize"
          :total="settotal"
          v-show="settotal > 10"
          align="right"
          :page-sizes="[10, 20, 50, 100]"
          layout="total, sizes, prev, pager, next, jumper"
        ></el-pagination>
      </div>

      <!-- 新增处理器 -->
      <el-dialog
        title="处理器列表"
        center
        :visible.sync="setAddDialog"
        width="700px"
        :lock-scroll="false"
      >
        <el-table
          :data="setAddData"
          @selection-change="setAddChange"
          v-loading="setAddloading"
          element-loading-text="正在请求"
          height="300"
          size="small"
        >
          <el-table-column type="selection" width="55"></el-table-column>
          <el-table-column property="name" label="处理器名称"></el-table-column>
          <el-table-column property="desc" label="功能描述"></el-table-column>
          <el-table-column property="typeDesc" label="处理器类型"></el-table-column>
        </el-table>
        <div slot="footer" align="center" class="dialog-footer">
          <el-button size="small" @click="setCancel()">取 消</el-button>
          <el-button size="small" type="primary" @click="setSure()">确 定</el-button>
        </div>
      </el-dialog>

      <!-- 标注任务类型 -->
      <div class="datawood-table">
        <div class="datawood-name">任务类型标注</div>
        <el-row class="datawood-add">
          <el-button @click="typeAdd()" size="small">
            <i class="iconfont icon-add"></i>添加新任务类型
          </el-button>
        </el-row>
        <el-table
          :data="typeData"
          align="center"
          height="450"
          v-loading="typeloading"
          element-loading-text="正在请求"
          size="small"
        >
          <el-table-column type="index" label="序号" width="50"></el-table-column>
          <el-table-column prop="name" label="任务类型"></el-table-column>
          <el-table-column prop="createdDate" label="创建时间" :formatter="dateFormat"></el-table-column>
          <el-table-column
            prop="description"
            label="任务简述"
            min-width="180"
            :show-overflow-tooltip="true"
          ></el-table-column>
          <el-table-column label="操作">
            <template slot-scope="scope">
              <el-button size="mini" type="primary" @click.native="typeEdit(scope.row)">编辑</el-button>
              <el-button size="mini" type="primary" @click.native="typeDel(scope.row.id)">移除</el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>
    </el-main>

    <!-- 新增标注类型弹窗 -->
    <el-dialog
      :title="typeTitle"
      center
      :visible.sync="typeAddDialog"
      width="500px"
      :lock-scroll="false"
    >
      <el-form :model="typeForm" :rules="typeRules" label-width="120px" ref="typeform" size="small">
        <el-form-item prop="name" label="标注类型名称">
          <el-input v-model="typeForm.name" placeholder="请输入标注类型名称" :maxlength="30"></el-input>
        </el-form-item>
        <el-form-item prop="description" label="标注类型描述">
          <el-input
            type="textarea"
            :rows="4"
            maxlength="250"
            v-model="typeForm.description"
            placeholder="请输入标注类型描述"
          ></el-input>
        </el-form-item>
        <el-form-item prop="type" label="标注页面">
          <el-radio v-model="typeForm.type" label="route">内部路由</el-radio>
          <el-radio v-model="typeForm.type" label="url">外部链接</el-radio>
        </el-form-item>
        <el-form-item prop="typeUrl">
          <el-input v-model="typeForm.typeUrl" placeholder="请输入地址"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" align="center" class="dialog-footer">
        <el-button size="small" @click="typeCancel()">取 消</el-button>
        <el-button size="small" type="primary" @click="typeSure()">确 定</el-button>
      </div>
    </el-dialog>
  </el-container>
</template>

<script>
import { mapMutations } from "vuex";
import { APPID } from "assets/scripts/code";
export default {
  name: "EditProj",

  data() {
    return {
      infoEdit: false,
      name: "",
      appId: "",
      orgId: "",
      createdBy: "",
      description: "",
      createdDate: "",
      appKey: "",
      appSecret: "",
      projInfo: {
        openLevel: "",
        maxApplyNumber: 100,
        markMethod: "",
        markRound: "",
        whetherCheck: "",
        checkRate: 100,
        checkBy: "",
        checkByMachine: "",
        machineCheckType: "",
        rejectBy: "",
        passRateThreshold: 100,
        badDataProcess: ""
      },

      projInfoName: {
        openLevel: "未配置",
        markMethod: "未配置",
        whetherCheck: "未配置",
        checkBy: "未配置",
        checkByMachine: "未配置",
        machineCheckType: "未配置",
        badDataProcess: "未配置",
        rejectBy: "未配置"
      },
      // 用户列表
      userData: [],
      useroptions: [],
      userAddFlag: false, // 是否允许再添加
      userloading: false,

      // 应用列表
      setData: [],
      setloading: false,
      setType: "PRE",
      setpage: 1,
      setsize: 10,
      settotal: 0,
      setAddDialog: false,
      allAppProcessor: {},
      processorIds: [],
      oriProcessorIds: [],

      // 应用新增列表
      setAddData: [],
      setAddloading: false,
      addpage: 1,
      addsize: 10,
      addtotal: 0,

      // 类型列表
      typeEditId: "",
      typeTitle: "",
      typeData: [],
      typeAddDialog: false,
      typeloading: false,

      typeForm: {
        name: "",
        description: "",
        type: "route",
        typeUrl: ""
      },
      typeRules: {
        name: [
          { required: true, message: "请输入标注类型名称", trigger: "blur" }
        ],
        description: [
          { required: true, message: "请输入标注类型描述", trigger: "blur" }
        ],
        typeUrl: [{ required: true, message: "请输入地址", trigger: "blur" }]
      },
      top: 0
    };
  },

  methods: {
    ...mapMutations(["showLoading", "closeLoading"]),
    // 返回
    prevStep() {
      this.$router.push({ path: "/project/index" });
    },

    // 第一次加载所有
    queryAll() {
      // this.showLoading();
      this.detailQuery();
      this.userQuery();
      this.typeQuery();
      this.setQuery();
    },

    // 获取详情
    detailQuery() {
      this.$api.project
        .getAppDetail({
          id: this.appId
        })
        .then(res => {
          this.closeLoading();
          let {
            name,
            description,
            createdBy,
            createdDate,
            appId,
            secret
          } = res;
          this.createdBy = createdBy;
          this.name = name;
          this.description = description;
          this.createdDate = this.$moment(createdDate).format(
            "YYYY-MM-DD HH:mm"
          );
          this.appKey = appId;
          this.appSecret = secret;

          // 配置信息
          this.updateInfo(res);
        })
        .catch(() => {});
    },

    // 更新值
    updateInfo(res) {
      let {
        openLevel,
        maxApplyNumber,
        markMethod,
        markRound,
        whetherCheck,
        checkRate,
        checkBy,
        checkByMachine,
        machineCheckType,
        rejectBy,
        passRateThreshold,
        badDataProcess
      } = res;

      this.$nextTick(() => {
        // 值
        this.projInfo.openLevel = openLevel.code;
        this.projInfo.maxApplyNumber = maxApplyNumber ? maxApplyNumber : 0;
        this.projInfo.markMethod = markMethod.code;
        this.projInfo.markRound = markRound;
        this.projInfo.whetherCheck = whetherCheck.code;
        this.projInfo.checkRate = checkRate ? checkRate : 0;
        this.projInfo.checkBy = checkBy.code;
        this.projInfo.checkByMachine = checkByMachine.code;
        this.projInfo.machineCheckType = machineCheckType.code;
        this.projInfo.badDataProcess = badDataProcess.code;
        this.projInfo.rejectBy = rejectBy.code;
        this.projInfo.passRateThreshold = passRateThreshold
          ? passRateThreshold
          : 0;

        // 文本显示
        this.projInfoName.openLevel = openLevel.desc
          ? openLevel.desc
          : "未配置";
        this.projInfoName.markMethod = markMethod.desc
          ? markMethod.desc
          : "未配置";
        this.projInfoName.whetherCheck = whetherCheck.desc
          ? whetherCheck.desc
          : "未配置";
        this.projInfoName.checkBy = checkBy.desc ? checkBy.desc : "未配置";
        this.projInfoName.checkByMachine = checkByMachine.desc
          ? checkByMachine.desc
          : "未配置";
        this.projInfoName.machineCheckType = machineCheckType.desc
          ? machineCheckType.desc
          : "未配置";
        this.projInfoName.badDataProcess = badDataProcess.desc
          ? badDataProcess.desc
          : "未配置";
        this.projInfoName.rejectBy = rejectBy.desc ? rejectBy.desc : "未配置";
      });
    },

    // 1编辑配置
    editInfo(flag) {
      if (flag == 1) {
        this.infoEdit = !this.infoEdit;
        return;
      }

      //保存结果
      if (this.infoEdit) {
        this.$confirm("确认保存设置吗？", "", { lockScroll: false })
          .then(res => {
            let formData = new FormData();
            for (var i in this.projInfo) {
              if (this.projInfo[i]) {
                formData.append(i, this.projInfo[i]);
              }
            }
            formData.append("appId", this.appId);
            this.$api.project
              .changeAppDetail(formData)
              .then(res => {
                this.updateInfo(res);
                this.$message.success("修改成功");
                this.infoEdit = !this.infoEdit;
              })
              .catch(() => {});
          })
          .catch(() => {});
      } else {
        this.infoEdit = !this.infoEdit;
      }
    },

    // 2人员列表展示
    userQuery() {
      this.userloading = true;

      let param = {
        orgId: this.orgId,
        roleName: "ROLE_DW_APPADMIN",
        page: 0,
        size: 100
      };

      this.$api.project
        .getAppUserList(param)
        .then(res => {
          this.userloading = false;
          this.userData = [];
          if (res.content.length > 0) {
            res.content.forEach(item => {
              let obj = {
                id: item.user.id,
                login: item.user.login,
                cnName: item.user.cnName
              };

              this.userData.push(obj);
            });
          }
        })
        .catch(() => {
          this.userloading = false;
        });
    },

    // 2人员移除
    userDel(row) {
      // 删除新增栏
      if (!row.login) {
        let len = this.userData.length;
        this.userData.splice(len - 1, 1);
        this.userAddFlag = false;
        return;
      }

      // 删除数据
      this.$confirm("确定移除该应用管理员吗？", "", { lockScroll: false })
        .then(() => {
          let param = {
            appId: this.appId,
            action: "delete",
            userId: row.login,
            userName: row.cnName
          };

          this.showLoading();
          this.$api.project
            .actionAppUserList(param)
            .then(res => {
              this.closeLoading();
              this.userQuery();
              this.$message.success("移除成功");
            })
            .catch(() => {});
        })
        .catch(() => {});
    },

    // 2人员新增可选的栏目
    userAdd() {
      if (this.userAddFlag) {
        return;
      }
      this.userAddFlag = true;
      this.userData.push({
        edit: true
      });
    },

    // 2人员确定选择添加
    selectUser(userId) {
      let selectItem = this.useroptions.find(item => {
        return item.id == userId;
      });

      let param = {
        appId: this.appId,
        action: "add",
        userId: selectItem.login,
        userName: selectItem.cnName
      };

      this.showLoading();
      this.$api.project
        .actionAppUserList(param)
        .then(res => {
          this.closeLoading();
          this.userQuery();
          this.$message.success("添加成功");
          this.userAddFlag = false;
        })
        .catch(() => {});
    },

    /**
     * 打开列表
     */
    openUser(callback) {
      if (callback) {
        let param = {
          roleName: "ROLE_DW_APPADMIN",
          appId: APPID,
          value: "",
          page: 0,
          size: 200,
          sort: ""
        };
        this.$api.project
          .addNewAppUser(param)
          .then(res => {
            let { content } = res;
            this.useroptions = [];
            if (content && content.length > 0) {
              content.forEach(item => {
                let obj = {
                  id: item.id,
                  login: item.login,
                  cnName: item.cnName
                };

                let hasRole = this.userData.findIndex(unit => {
                  return unit.id === item.id;
                });

                if (hasRole == -1) {
                  this.useroptions.push(obj);
                }
              });
            }
          })
          .catch(() => {});
      }
    },

    // 3应用设置分页
    setsizeChange(size) {
      this.setsize = size;
      this.setQuery();
    },
    setpageChange(page) {
      this.setpage = page;
      this.setQuery();
    },

    /**
     * 3应用设置列表获取
     * @param page 页数
     * @param type 类型
     * @param boolean 是否需要滚动界面
     */
    setQuery(page, type, boolean) {
      if (page) {
        this.setpage = page;
      }

      if (type) {
        this.setType = type;
      }

      this.setloading = true;
      this.$api.project.getAppProcessor({ appId: this.appId }).then(res => {
        this.setloading = false;
        let { appProcessors } = res;

        let arrayAppProcessors = [];
        let map = new Map();
        appProcessors.forEach(item => {
          if (item.type == "PRE") {
            map.set("PRE", item.processorDTOS);
          }
          if (item.type == "ANALYSIS") {
            map.set("ANALYSIS", item.processorDTOS);
          }
          if (item.type == "EXPORT") {
            map.set("EXPORT", item.processorDTOS);
          }

          //合并所有处理器
          arrayAppProcessors = [...arrayAppProcessors, ...item.processorDTOS];
        });

        let currType = type ? this.setType : "PRE";
        this.allAppProcessor = map;
        this.setData = this.allAppProcessor.get(currType);

        //更新后数据后，指控重新赋值
        this.oriProcessorIds=[];
        //提取所有处理器Id
        arrayAppProcessors.forEach(item => {
          this.oriProcessorIds.push(item.id);
        });

        if (boolean) {
          this.setCancel();
        }
      });
    },

    // 3应用配置tab点击
    setHandleClick() {
      this.setData = this.allAppProcessor.get(this.setType);
    },

    // 3新增处理器
    setAdd() {
      //获取所有处理器列表
      this.setAddloading = true;
      this.$api.project
        .getProcessorList({ sort: "createdDate,DESC" })
        .then(res => {
          this.setAddDialog = true;
          this.setAddloading = false;
          let { content } = res;
          this.setAddData = content;
        });
    },

    // 3取消处理器
    setCancel() {
      this.setAddDialog = false;
    },

    // 3确定处理器
    setSure() {
      this.setAddloading = true;

      //合并所有的处理器并去重
      let allIds =  Array.from(new Set([...this.processorIds,...this.oriProcessorIds]));

      this.$api.project
        .updateAppProcessor({
          appId: this.appId,
          processorIds: allIds
        })
        .then(res => {
          this.setAddloading = false;
          this.setAddDialog = false;
          this.setType = "PRE";
          this.setQuery();
          this.$message.success("处理器添加成功!");
        });
    },

    //3删除处理器
    setDel(id) {
      //从所有处理器id中移除
      this.oriProcessorIds.find(oriId => {
        if (oriId == id) {
          let index = this.oriProcessorIds.indexOf(oriId);
          this.oriProcessorIds.splice(index, 1);
        }
      });

      //更新应用处理器
      this.$api.project
        .updateAppProcessor({
          appId: this.appId,
          processorIds: this.oriProcessorIds
        })
        .then(res => {
          this.setQuery(1, this.setType);
        });
    },

    //3选择处理器
    setAddChange(val) {
      this.processorIds = [];
      if (val.length > 0) {
        val.forEach(item => {
          this.processorIds.push(item.id);
        });
      }
    },

    // 4标注任务,boolean表示清空弹窗的值
    typeQuery(page, boolean) {
      if (page) {
        this.typepage = page;
      }

      this.typeloading = true;
      this.$api.project
        .taskTypesList({
          appId: this.appId
        })
        .then(res => {
          this.typeloading = false;
          this.typeData = res;
        })
        .catch(() => {
          this.typeloading = false;
        });
    },

    // 4标注任务新增
    typeAdd() {
      this.typeAddDialog = true;
      this.typeEditId = "";
      this.typeTitle = "创建标注类型";
      this.typeForm.description = "";
      this.typeForm.name = "";
      this.typeForm.type = "route";
      this.typeForm.typeUrl = "";
    },

    // 4标注任务删除
    typeDel(id) {
      // 删除数据
      this.$confirm("确定移除该任务类型吗？", "", { lockScroll: false })
        .then(() => {
          this.$api.project
            .delTaskType({
              id: id
            })
            .then(res => {
              this.typeQuery();
              this.$message.success("移除成功");
            })
            .catch(() => {});
        })
        .catch(() => {});
    },

    // 4标注任务编辑
    typeEdit(row) {
      this.typeAdd();
      let { description, name, useUri, internalUri, externalUri, id } = row;
      this.typeTitle = "编辑标注类型";
      this.typeEditId = id;
      this.typeForm.description = description;
      this.typeForm.name = name;
      this.typeForm.type = useUri;
      this.typeForm.typeUrl = useUri == "route" ? internalUri : externalUri;
    },

    // 4标注任务弹窗取消
    typeCancel() {
      this.typeAddDialog = false;
      this.$refs.typeform.resetFields();
      this.$refs.typeform.clearValidate();
    },

    // 4标注任务弹窗确认
    typeSure() {
      this.$refs.typeform.validate(valid => {
        if (!valid) {
          return;
        }

        let param = JSON.parse(JSON.stringify(this.typeForm));
        if (param.type == "route") {
          param.route = param.typeUrl;
        } else {
          param.url = param.typeUrl;
        }

        delete param.typeUrl;
        param.applicationId = this.appId;
        param.id = this.typeEditId ? this.typeEditId : "";
        this.showLoading();
        // 新增或者编辑
        this.$api.project
          .addTaskType(param)
          .then(res => {
            this.closeLoading();
            this.typeAddDialog = false;
            // 添加到列表中
            this.typeQuery(1, true);
          })
          .catch(() => {});
      });
    },

    // 时间格式化
    dateFormat(row, column) {
      let time = row[column.property];
      if (time === undefined || !time) {
        return "";
      }
      return this.$moment(time).format("YYYY-MM-DD HH:mm:ss");
    }
  },

  mounted() {
    let appInfo = JSON.parse(window.sessionStorage.getItem("appInfo"));
    this.appId = appInfo.id;
    this.orgId = appInfo.orgId;

    // 滚动条滚至最顶
    document.getElementsByTagName("html")[0].scrollTo(0, 0);
    this.queryAll();
  }
};
</script>

<style rel="stylesheet/less" lang="less" scoped>
.el-container {
  background: #f6f6f6;
  .el-header {
    background: #fff;
    padding: 10px 15px;
    margin-bottom: 10px;
    .back-btn {
      margin-left: 10px;
    }
  }
  .proj-info {
    overflow: hidden;
    margin-bottom: 10px;
    .detail-btns {
      position: absolute;
      right: 10px;
    }
    .proj-text,
    .proj-user {
      height: 700px;
      background: #fff;
      padding: 20px 25px;
      float: left;
      width: 60%;
      box-sizing: border-box;
      margin-right: 10px;
    }
    .proj-text {
      font-size: 16px;
      min-height: 450px;
      button {
        float: right;
      }
      strong {
        min-width: 100px;
        display: inline-block;
        text-align: right;
      }
      ul {
        margin-top: 15px;
        li {
          font-size: 14px;
          line-height: 34px;
        }
        span {
          display: inline-block;
          width: 100px;
          text-align: right;
        }
        .task-tip {
          width: 300px;
          text-align: left;
        }
        .task-unset {
          text-align: left;
        }
      }
      .robot-result {
        .el-row {
          line-height: 22px;
        }
      }
    }
    .proj-user {
      width: ~"calc(40% - 10px)";
      margin-right: 0px;
      .add-user {
        padding: 10px 0;
        border-style: dashed;
        width: 100%;
        margin: 0 auto;
        margin-top: 10px;
        border-radius: 4px;
        font-size: 14px;
        .icon-add {
          font-size: 16px;
        }
      }
    }
  }

  .el-main {
    background: #f6f6f6;
    padding: 0;
  }
}
</style>

<style lang="less">
.detail-btns .el-button-group .el-button--primary:last-child {
  line-height: 0;
}
.detail-bars {
  .bar-item {
    margin-bottom: 20px;
    margin-left: 10px;
    display: inline-block;
    width: 50%;
  }
}
</style>
















<!-- 用户任务列表 -->
<template>
  <el-container class="mymark-list">
    <!-- 头部信息 -->
    <el-header>
      <div class="mask-info">
        <dl>
          <dt>我的待办</dt>
          <dd>
            <span class="font-primary">{{todo}}</span>
          </dd>
        </dl>
        <dl>
          <dt>被打回</dt>
          <dd>
            <span class="font-danger">{{back}}</span>
          </dd>
        </dl>
        <dl>
          <dt>今日提交</dt>
          <dd>
            <span class="font-success">{{todayCommit}}</span>
          </dd>
        </dl>
      </div>
    </el-header>
    <!-- 主体信息 -->
    <el-main>
      <!-- tab页 -->
      <el-tabs v-model="completed" @tab-click="query(1,completed)">
        <el-tab-pane label="未完成" name="undo"></el-tab-pane>
        <el-tab-pane label="已完成" name="done"></el-tab-pane>
      </el-tabs>

      <!-- 搜索表单 -->
      <el-form :inline="true" :model="queryForm" ref="queryForm" @submit.native.prevent>
        <el-row class="wood-radio-group">
          <el-form-item label="标注类型：">
            <el-radio-group v-model="queryForm.typeId" @change="query(1)" size="small">
              <el-radio-button
                v-for="item of taskTypes"
                :label="item.id"
                :key="item.id"
              >{{item.name}}
              </el-radio-button>
            </el-radio-group>
          </el-form-item>

          <el-form-item style="float:right">
            <el-input
              size="small"
              name="name"
              v-model="queryForm.name"
              :maxlength="30"
              placeholder="搜索任务名称"
              clearable
              suffix-icon="el-icon-search"
              @keyup.enter.native="query(1)"
              @change="query(1)"
            ></el-input>
          </el-form-item>
        </el-row>

        <el-row class="wood-radio-group">
          <el-form-item label="任务类型：">
            <el-radio-group v-model="queryForm.type" @change="query(1,true)" size="small">
              <el-radio-button label="0">标注任务</el-radio-button>
              <el-radio-button label="1">检查任务</el-radio-button>
            </el-radio-group>
          </el-form-item>
        </el-row>

        <el-row class="wood-radio-group">
          <el-form-item label="任务状态：">
            <el-radio-group v-model="queryForm.status" @change="query(1)" size="small">
              <el-radio-button label>全部</el-radio-button>
              <template v-if="completed === 'undo'">
                <template v-if="queryForm.type == 0">
                  <el-radio-button label="-1">被打回</el-radio-button>
                  <el-radio-button label="0">待标注</el-radio-button>
                  <el-radio-button label="1">标注中</el-radio-button>
                </template>
                <!-- 检查任务 -->
                <template v-else>
                  <el-radio-button label="3">待检查</el-radio-button>
                  <el-radio-button label="4">检查中</el-radio-button>
                </template>
              </template>

              <template v-if="completed === 'done'">
                <template v-if="queryForm.type == 0">
                  <el-radio-button label="2" size="small">标注已提交</el-radio-button>
                </template>
                <!-- 检查任务 -->
                <template v-else>
                  <el-radio-button label="5" size="small">检查已提交</el-radio-button>
                </template>
                <el-radio-button label="7" size="small">已验收</el-radio-button>
              </template>
            </el-radio-group>
          </el-form-item>
        </el-row>
      </el-form>

      <!-- 未完成列表 -->
      <el-table
        class="user-table"
        size="small"
        key="undoTable"
        :data="unDoData"
        align="center"
        v-if="completed === 'undo'"
        v-loading="loading"
        element-loading-text="正在请求"
      >
        <el-table-column
          type="index"
          label="序号"
          width="80"
          :index="(index)=>{return (page - 1) * size + index + 1}"
        ></el-table-column>
        <el-table-column prop="name" label="任务名称" width="120" :show-overflow-tooltip="true"></el-table-column>
        <el-table-column prop="markType" label="标注类型" width="100" :show-overflow-tooltip="true"></el-table-column>
        <el-table-column prop="typeDesc" label="任务类型"></el-table-column>
        <el-table-column prop="count2" label="数据数量"></el-table-column>
        <!-- <el-table-column prop="bad" label="坏数据数量" v-if="queryForm.type == 1"></el-table-column> -->
        <el-table-column label="合格率" v-if="queryForm.type===1">
          <template slot-scope="scope">
            <span
              v-if="scope.row.checkByUser">{{(scope.row.accuracy*100).toFixed(2)}}%</span>
            <span v-else>---</span>

          </template>
        </el-table-column>
        <!-- <el-table-column label="坏数据错判率" width="95" v-if="queryForm.type==1">
          <template slot-scope="scope">
            <span v-text="parseFloat(getRate(scope.row.misjudgeBadCount,scope.row.count2))"></span>%
          </template>
        </el-table-column> -->
        <el-table-column :label="queryForm.type===0?'标注进度':'检查进度'" width="140">
          <template slot-scope="scope">
            <el-progress
              size="small"
              :percentage="parseFloat(getRate(scope.row.completeCount2,scope.row.count2))"
            ></el-progress>
          </template>
        </el-table-column>
        <el-table-column prop="createDate" label="开始时间" width="135" :formatter="dateFormat"></el-table-column>
        <el-table-column prop="statusDesc" label="任务状态"></el-table-column>

        <el-table-column label="操作" width="200">
          <template slot-scope="scope">
            <el-button
              type="primary"
              size="mini"
              v-if="queryForm.type == 0"
              @click="mark(scope.row)"
            >标注
            </el-button>
            <el-button type="primary" size="mini" v-else @click="check(scope.row)">检查</el-button>
            <el-button type="primary" size="mini" @click="commitTask(scope.row)">提交</el-button>

            <el-button
              v-if="queryForm.type === 1 && scope.row.rejectByUser"
              type="primary"
              size="mini"
              @click="rejectTask(scope.row)"
            >打回
            </el-button>
          </template>
        </el-table-column>
      </el-table>

      <!-- 已完成列表 -->
      <el-table
        class="user-table"
        size="small"
        key="doneTable"
        :data="doneData"
        align="center"
        v-if="completed === 'done'"
        v-loading="loading"
        element-loading-text="正在请求"
      >
        <el-table-column
          type="index"
          label="序号"
          width="80"
          :index="(index)=>{return (page - 1) * size + index + 1}"
        ></el-table-column>
        <el-table-column prop="name" label="任务名称" width="140" :show-overflow-tooltip="true"></el-table-column>
        <el-table-column prop="markType" label="标注类型" width="100" :show-overflow-tooltip="true"></el-table-column>
        <el-table-column prop="typeDesc" label="任务类型"></el-table-column>
        <el-table-column prop="count" label="数据数量"></el-table-column>
        <el-table-column prop="bad" label="坏数据数量"></el-table-column>
        <el-table-column label="合格率">
          <template slot-scope="scope">
            <span>{{(scope.row.accuracy*100).toFixed(2)}}%</span>
          </template>

          <!-- <template slot-scope="scope">
            <span
              v-text="parseFloat(getRate(scope.row.passCount,scope.row.checkCount))"
              v-if="queryForm.type == 0"
            ></span>
            <span v-text="parseFloat(getRate(scope.row.passCount,scope.row.effectiveCount))" v-else></span>%
          </template> -->
        </el-table-column>
        <el-table-column label="坏数据判错率" width="95" v-if="queryForm.type == 1">
          <template slot-scope="scope">
            <span v-text="parseFloat(getRate(scope.row.misjudgeBadCount,scope.row.count))"></span>%
          </template>
        </el-table-column>
        <el-table-column prop="commitDate" label="提交时间" width="140" :formatter="dateFormat"></el-table-column>
        <el-table-column prop="statusDesc" label="任务状态"></el-table-column>
        <el-table-column label="操作" width="140">
          <template slot-scope="scope">
            <el-button v-if="scope.row.taskStatus != 4" type="primary" size="mini" @click="mark(scope.row,true)">查看
            </el-button>
          </template>
        </el-table-column>
      </el-table>

      <el-pagination
        size="small"
        v-if="total > 10"
        @size-change="sizeChange"
        @current-change="pageChange"
        align="right"
        :current-page="page"
        :page-sizes="[10, 20, 50, 100]"
        :page-size="size"
        layout="total, sizes, prev, pager, next, jumper"
        :total="total"
      ></el-pagination>
    </el-main>

    <!-- 选择检查比例弹窗 -->
    <el-dialog
      size="small"
      title="检查任务信息"
      :visible.sync="manualRejectDialog"
      width="600px"
      :lock-scroll="false"
      class="manual-reject"
    >
      <el-row>
        <div class="title">
          <strong>数据数量</strong>
        </div>
        <ul>
          <li>
            <div>总数据</div>
            <div class="data-num">{{markSum.totalCount}}</div>
          </li>
          <li>
            <div>有效标注</div>
            <div class="data-num">{{markSum.totalCount-markSum.badCount}}</div>
          </li>
          <li>
            <div>坏数据</div>
            <div class="data-num">{{markSum.badCount}}</div>
          </li>
          <li>
            <div>坏数据检查</div>
            <div class="data-num">{{markSum.checkBad?"是":"否"}}</div>
          </li>
        </ul>
      </el-row>

      <el-row>
        <div class="title">
          <strong>检查数据范围</strong>
        </div>
        <ul>
          <li>
            <div>未被抽查数据</div>
            <!-- if rejectbyuser false currentSampleRange  -->
            <div class="data-num" v-if="markSum.rejectByUser">
              {{markSum.currentSampleRange-markSum.checked+markSum.passed}}
            </div>
            <div class="data-num" v-else>{{markSum.currentSampleRange}}</div>

          </li>
          <li>
            <div>已检查通过数据</div>
            <div class="data-num">{{markSum.passed}}</div>
          </li>
          <li>
            <div>已检查未通过数据</div>
            <div class="data-num">{{markSum.checked-markSum.passed}}</div>
          </li>
          <li>
            <div>待检查数据</div>
            <div class="data-num">{{markSum.currentSampleRange}}</div>
          </li>
        </ul>
      </el-row>

      <el-row v-if="!markSum.rejectByUser">
        <div class="title">
          <strong>合格率阈值</strong>
        </div>
        <div style="height:20px;line-height:20px;margin-bottom:10px;">
          <span>
            该检查任务为自动触发打回的任务，您需要完成所有抽检数据的检查才可提交，本次检查任务的最低合格率要求为
            <span
              style="color:red"
            >{{markSum.passRateThreshold}}%</span>
          </span>
        </div>
      </el-row>

      <el-row class="check-ratio" v-if="manualRejectDialog">
        <div class="title">
          <strong>检查比例</strong>
        </div>
        <el-radio-group v-model="checkedType">
          <el-radio :label="2">最低检查比例（{{defCheckRate}}%）</el-radio>
          <el-radio :label="1">自定义检查比例</el-radio>
          <span class="ratio-num">
            <el-input-number
              v-model="ratioData"
              size="small"
              v-if="checkedType==1"
              :max="100"
              :min="defCheckRate+1"
            ></el-input-number>
          </span>
        </el-radio-group>
      </el-row>

      <div slot="footer" align="center" class="dialog-footer">
        <el-button size="small" type="primary" @click="checkSure()">开始检查</el-button>
        <el-button size="small" @click="closeCheck()">取 消</el-button>
      </div>
    </el-dialog>
  </el-container>
</template>

<script>
  import {mapState, mapMutations} from "vuex";
  import {setNavVisible, getRate} from "assets/scripts/common";

  export default {
    name: "Mark",
    computed: {
      ...mapState(["user", "appInfo"])
    },
    data() {
      return {
        loading: false,
        getRate: getRate,
        markProgress: 0,
        completed: "undo",
        taskTypes: [
          {
            id: "",
            name: "全部"
          }
        ],
        unDoData: [],
        doneData: [],
        page: 1,
        size: 10,
        total: "",
        todo: "",
        back: "",
        todayCommit: 0,
        queryForm: {
          name: "",
          userId: "",
          type: 0,
          status: "",
          typeId: ""
        },
        checkRow: null,
        checkRate: 0,

        manualRejectDialog: false,
        checkedType: 2,
        ratioData: "",
        markSum: {},
        defCheckRate: ""
      };
    },
    methods: {
      ...mapMutations(["setNavShow"]),
      // 获取标注类型
      getTaskTypes() {
        let allType = {
          id: "",
          name: "全部"
        };

        this.$api.project
          .taskTypesList({
            appId: this.appInfo.id
          })
          .then(res => {
            if (res && res.length > 0) {
              res.unshift(allType);
              this.taskTypes = res;
            } else {
              this.taskTypes = [allType];
            }
          })
          .catch(() => {
            this.taskTypes = [allType];
          });
      },

      //分页
      sizeChange(size) {
        this.size = size;
        this.query(1);
      },

      pageChange(page) {
        this.page = page;
        this.query();
      },

      // 查询
      query(resetPage, completed) {
        this.loading = true;

        if (resetPage) {
          this.page = resetPage;
        }

        if (completed) {
          this.queryForm.status = "";
        }

        this.queryForm.userId = this.user.login;
        this.queryForm.completed = this.completed === "done" ? true : false;
        this.queryForm.page = this.page;
        this.queryForm.size = this.size;
        this.queryForm.applicationId = this.appInfo.id;
        this.$api.mark.getMarkList(this.queryForm).then(res => {
          // 关闭loading
          this.loading = false;
          this.unDoData = [];
          this.doneData = [];

          // 数据展示
          let {content, totalElements} = res;
          if (this.completed === "done") {
            this.doneData = content;
          } else {
            content.forEach(item => {
              if (item.status == -1) {
                // item.completeCount2 = item.completeCount - item.passCount;
                // item.count2 = item.count - item.passCount;
                item.completeCount2 =
                  item.completeCount + item.reMark - item.count;
                item.count2 = item.reMark;
              } else {
                item.completeCount2 = item.completeCount;
                item.count2 = item.count;
              }
            });
            this.unDoData = content;
          }
          this.total = totalElements;
        })
          .catch(() => {
            this.loading = false;
          });
      },

      // 查询统计信息
      queryInfo() {
        this.$api.mark
          .getMarkInfo({
            userId: this.user.login,
            applicationId: this.appInfo.id
          })
          .then(res => {
            let {todo, back, todayCommit} = res;
            this.todo = todo;
            this.back = back;
            this.todayCommit = todayCommit;
          })
          .catch(() => {
          });
      },

      // 检查
      check(item) {
        if (item.started) {
          this.mark(item);
        } else {
          this.checkRow = item;
          this.$api.mark.getMarkSum({id: item.userTaskId}).then(res => {
            this.markSum = res;
            this.manualRejectDialog = true;
            this.defCheckRate = res.defCheckRate;
          });
        }
      },

      // 关闭弹窗
      closeCheck() {
        this.manualRejectDialog = false;
      },

      // 调整检查比例
      checkSure() {
        this.$api.mark
          .changeCheckRate({
            userTaskId: this.checkRow.userTaskId,
            checkRate: this.checkedType == 1 ? this.ratioData : -1
          })
          .then(res => {
            this.mark(this.checkRow);
            this.manualRejectDialog = false;
          })
          .catch(res => {
            this.$message.error(res.response.data.message);
          });
      },

      // 标注/检查
      mark(item, readonly) {
        // 跳转链接
        let toPath = item.internalUri;

        // 只读
        item.readonly = readonly;
        window.sessionStorage.setItem("task", JSON.stringify({...item}));
        window.sessionStorage.setItem(
          "taskQuery",
          JSON.stringify({...this.queryForm})
        );

        if (toPath) {
          this.$router.push(toPath);
        } else {
          this.$message.warning("该任务类型暂无标注页面");
        }
      },

      // 提交
      commitTask(item) {
        if (item.count > item.completeCount) {
          let text = this.queryForm.type == 1 ? "检查" : "标注";
          this.$message.warning("请先完成" + text);
          return;
        }
        this.$confirm("您确定提交吗？", "", {lockScroll: false})
          .then(_ => {
            this.$api.mark
              .commitMarkTask({userTaskId: item.userTaskId})
              .then(res => {
                this.$message.success(res.prompt);
                this.query(1);
                this.queryInfo();
              })
              .catch(() => {
              });
          })
          .catch(() => {
          });
      },

      // 打回
      rejectTask(item) {
        this.$confirm("您确定打回吗？", "", {lockScroll: false})
          .then(_ => {
            this.$api.mark
              .taskReject({userTaskId: item.userTaskId})
              .then(res => {
                this.$message.success("打回成功");
                this.query(1);
                this.queryInfo();
              })
              .catch(() => {
              });
          })
          .catch(() => {
          });
      },

      // 时间格式化
      dateFormat(row, column) {
        let time = row[column.property];
        if (!time) {
          return " ";
        }
        return this.$moment(time).format("YYYY-MM-DD HH:mm");
      }
    },

    watch: {
      appInfo() {
        if (this.appInfo.id) {
          this.queryForm.typeId = "";
          this.getTaskTypes();
          this.query();
          this.queryInfo();
        }
      }
    },

    mounted() {
      let taskQuery = this.$route.params.taskQuery;
      if (taskQuery) {
        let q = JSON.parse(taskQuery);
        this.queryForm = q;
        this.completed = q.completed ? "done" : "undo";
        this.page = q.page;
        this.size = q.size;
      }

      this.$nextTick(() => {
        this.setNavShow(true);
        if (this.appInfo.id) {
          sessionStorage.clear();
          this.getTaskTypes();
          this.query();
          this.queryInfo();
        }
      });
    },

    beforeRouteEnter(to, from, next) {
      setNavVisible("visible");
      next();
    }
  };
</script>


<style rel="stylesheet/less" lang="less" scoped>
  .mymark-list {
    .el-header {
      height: 100px !important;

      .mask-info {
        overflow: hidden;

        dl {
          margin-top: 20px;
          border-right: #eceef2 1px solid;
          width: 33%;
          float: left;
          text-align: center;
          font-size: 14px;

          &:nth-child(3) {
            border-right: 0;
          }

          dt {
            color: #909399;
            margin-bottom: 20px;
          }

          dd {
            font-size: 30px;
          }
        }
      }
    }

    .el-container .el-main {
      padding: 0px 15px;
    }

    .task-title {
      height: 32px;
    }

    .mask-content {
      padding: 0;
      margin: 0;

      li {
        position: relative;
        list-style: none;
        padding: 20px 10px;
        border-bottom: #ddd 1px dashed;

        .el-row {
          padding: 4px 0;
          font-size: 12px;

          strong {
            max-width: 60%;
            font-size: 15px;
          }
        }

        .main-font {
          margin-top: 5px;

          .el-col-2 {
            text-align: center;
          }
        }

        .el-icon-edit-outline {
          font-size: 18px;
          position: relative;
          left: -5px;

          &:hover {
            color: #4baffe;
          }
        }

        &:nth-child(2n) {
          background: #fafafa;
        }
      }

      .mask-content-empty {
        font-size: 14px;
        height: 430px;
        text-align: center;

        &:before {
          display: inline-block;
          width: 110px;
          height: 90px;
          background-image: url("~@/assets/images/nodata.png");
          background-size: cover;
          content: "";
          position: absolute;
          left: 50%;
          top: 50%;
        }

        &:after {
          content: "暂无数据";
          position: absolute;
          left: calc(~"50% + 28px");
          top: calc(~"50% + 100px");
          color: #909399;
        }
      }
    }
  }
</style>


<style rel="stylesheet/less" lang="less">
  .mymark-list {
    .receive-dialog {
      .el-form-item__label {
        font-weight: bold;
      }

      .dialog-footer {
        text-align: center;
        margin-top: 30px;
      }
    }

    .left-slider {
      display: block;
    }

    .nav-bar .current-local .icon-place {
      display: none !important;
    }

    .check-judge {
      .el-row {
        margin-bottom: 30px;
        position: relative;
        left: 60px;

        .rate-input {
          margin-left: 10px;
        }

        &:last-child {
          margin-bottom: 0px;
        }
      }
    }

    .manual-reject {
      .el-row {
        margin-left: 15px;
        margin-bottom: 20px;

        .title {
          height: 30px;
          line-height: 30px;
          font-size: 14px;
        }

        ul {
          li {
            float: left;
            width: 130px;
            height: 50px;
            text-align: center;

            div {
              height: 25px;
              line-height: 25px;
              border: #eceef2 1px solid;
            }

            .data-num {
              border-top: 0px;
            }
          }
        }
      }

      .check-ratio {
        margin-bottom: 0px;

        .ratio-num {
          margin-left: 15px;
        }
      }
    }

    .el-table {
      margin-bottom: 30px !important;

      .el-table__body-wrapper {
        overflow: hidden;
      }
    }

    .el-dialog {
      margin-top: 5vh !important;
    }
  }
</style>

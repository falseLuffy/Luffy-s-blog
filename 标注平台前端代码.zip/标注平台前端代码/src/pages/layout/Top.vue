<template>
  <div class="nav-bar">
    <!-- 头部信息 -->
    <div class="main-font">
      <div :title="user.cnName" class="user-info">
        <i class="iconfont icon-user"></i>
        欢迎你，
        <strong class="ellipsis" :title="user.cnName">{{user.cnName}}</strong>
      </div>
      <el-dropdown  size="small">
        <span class="el-dropdown-link">
          （{{roleName[user.role]}}）<i class="el-icon-arrow-down"></i>
        </span>
        <el-dropdown-menu slot="dropdown">
          <el-dropdown-item class="top-click">
            <a @click="openPwd">修改密码</a>
          </el-dropdown-item>
          <el-dropdown-item class="top-click">
            <a @click="logout">退出登录</a>
          </el-dropdown-item>
        </el-dropdown-menu>
      </el-dropdown>
    </div>
    <el-dialog width="460px" title="重置密码" :visible.sync="showResetPwdDalg" center :showClose="canClose" :lock-scroll="false">
      <reset-pwd :type="type" @hide="hideOpenPwd"></reset-pwd>
    </el-dialog>

    <!-- 面包导航 -->
    <div class="current-local"  id="datawoodControlNav">
      <div class="icon-control" @click="controlNav()">
        <i :class="['iconfont',{'icon-toleft2':navShow,'icon-toright2':!navShow}]"></i>
      </div>

      <el-breadcrumb class="app-levelbar" separator=">">
        <el-breadcrumb-item v-for="(item) in levelList" :key="item.path">
          <span class="no-redirect">{{item.name}}</span>
        </el-breadcrumb-item>
      </el-breadcrumb>
    </div>
  </div>
</template>
<script>
import { mapState, mapMutations } from "vuex";
import { setNavVisible } from "assets/scripts/common";
import { roleName } from "assets/scripts/code";
import ResetPwd from "pages/common/ResetPwd";
export default {
  components: { ResetPwd },
  data() {
    return {
      type: 1,
      roleName: roleName,
      navName: "收起",
      showResetPwdDalg: false,
      canClose: false,
      levelList: []
    };
  },
  computed: {
    ...mapState(["user", "navShow"])
  },
  methods: {
    ...mapMutations(["clearUserInfo", "setNavShow"]),
    // 控制菜单
    controlNav() {
      // 音频标注需要加载完音频后
      if (
        this.$route.name.includes("音频标注") &&
        window.sessionStorage.getItem("audioProgress")
      ) {
        this.$message.warning("请等音频加载完再操作");
        return;
      }
      this.setNavShow(this.navShow ? false : true);
      setNavVisible(this.navShow ? "visible" : "hidden");
    },

    // 退出登陆
    logout() {
      // this.$api.user
      //   .logout({})
      //   .then(() => {
      //     //移除用户信息
      //     this.clearUserInfo();
      //     //登录后 重新加载
      //     location.reload();
      //   }).catch(() => {});

      //移除用户信息
      this.clearUserInfo();
      //登录后 重新加载
      location.reload();
    },
    getBreadcrumb() {
      let matched = this.$route.matched.filter(item => item.name);
      this.levelList = matched;
    },
    openPwd() {
      this.showResetPwdDalg = true;
    },
    hideOpenPwd() {
      this.showResetPwdDalg = false;
    }
  },
  watch: {
    $route() {
      this.getBreadcrumb();
    }
  },
  mounted() {
    this.getBreadcrumb();
  }
};
</script>
<style rel="stylesheet/less" lang="less" scoped>
.nav-bar {
  height: 50px;
  border-bottom: 1px solid #e6ebf5;
  padding: 2px;
  box-sizing: border-box;
  background-color: #fff;
  .main-font {
    margin: 0;
    padding: 0;
    float: right;
    padding-right: 20px;
    line-height: 50px;
    height: 50px;
    box-sizing: border-box;
    margin-top: -2px;
    .el-dropdown-link {
      font-size: 14px;
    }
    .user-info {
      float: left;
      .icon-user {
        font-size: 18px;
        margin-right: 2px;
      }
      strong {
        max-width: 120px;
        line-height: initial;
        position: relative;
        top: 4px;
      }
    }
    .el-dropdown {
      float: left;
      font-size: 20px;
      .el-icon-arrow-down {
        cursor: pointer;
      }
    }
  }
  .current-local {
    position: relative;
    box-sizing: border-box;
    height: 50px;
    float: left;
    min-width: 50%;
    .icon-place {
      position: absolute;
      font-size: 22px;
      color: #606266;
      top: 10px;
      left: 30px;
    }
    .app-levelbar {
      &:before {
        display: inline-block;
        content: "当前位置：";
        position: absolute;
        left: 60px;
        color: #606266;
      }
      &.el-breadcrumb {
        display: inline-block;
        font-size: 14px;
        line-height: 50px;
        position: relative;
        min-width: 30%;
        margin-top: -2px;
        height: 50px;
        padding-left: 130px;
        .no-redirect {
          color: #606266;
          cursor: text;
        }
      }
    }
  }
}

.el-menu-item.is-active,
.el-menu--horizontal > .el-submenu.is-active .el-submenu__title {
  color: #2d2f33;
}

.el-dropdown-menu.el-popper {
  top: 28px !important;
}
.top-click {
  a {
    display: inline-block;
  }
}

.icon-control {
  position: absolute;
  left: 33px;
  color: #606266;
  top: 14px;
  cursor: pointer;
  z-index: 999;
}

.icon-hide {
  margin-left: -50px;
  .icon-control {
    display: none !important;
  }
}
</style>

import Cookies from 'js-cookie'

export default {
  //显示loading
  showLoading(state) {
    state.loading = true;
  },
  //关闭loading
  closeLoading(state) {
    state.loading = false
  },

  //设置应用权限
  // setDeputies(state, deputies) {
  //   state.deputies = deputies
  // },

  //设置用户信息
  setUserInfo(state, newUser) {
    Cookies.set('accessUser', JSON.stringify(newUser));
    state.user = newUser;
  },

  //设置token
  setToken(state, token) {
    Cookies.set('accessToken', token);
    state.accessToken = token;
  },

  //设置路由
  setRouters(state, newRouters) {
    state.routers = newRouters
  },

  //清空路由
  clearRouters(state) {
    state.routers = []
  },

  //清除Cookies
  clearUserInfo(state) {
    Cookies.remove('accessUser');
    Cookies.remove('accessToken');
    sessionStorage.removeItem('deputies')
    state.accessToken = "";
    state.user = {
      appId: "",
      role: "",
      authorities: [],
      cnName: "",
      login: ""
    };
  },

  // 设置当前应用信息
  setAppInfo(state, newApp) {
    state.appInfo = {
      ...newApp
    }
  },

  // 设置主体内容的重载
  resetContainer(state, boolean) {
    state.containerAlive = boolean;
  },

  // 设置导航的显示隐藏
  setNavShow(state, newState) {
    state.navShow = newState
  }
}

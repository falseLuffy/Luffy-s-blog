<!-- 应用首页 -->
<template>
  <div class="datawood-app">
    <!-- 任务信息 -->
    <el-row id="appInfo" class="app-info">
      <strong>{{appInfo.name}}</strong>
      <ul>
        <li>
          <span>创建人：</span>
          <span>{{appInfo.createdBy}}</span>
          <span style="margin-left:30px;">创建时间：</span>
          <span>{{appInfo.createdDate}}</span>
        </li>
        <li>
          <span>应用描述：</span>
          <span>{{appInfo.description}}</span>
        </li>
        <li>
          <span>标注类型：</span>
          <div class="mark-types" v-if="typeShow">
            <div
              class="type-item"
              v-for="item of markTypes"
              :key="item.id"
              @mouseover="showTypeDetail(item,true)"
              @mouseout="showTypeDetail(item,false)"
            >
              <span :style="{backgroundColor:item.color}">{{item.name}}</span>
              <dl v-if="item.show">
                <dt>{{item.name}}</dt>
                <dd>{{item.desc}}</dd>
              </dl>
            </div>
          </div>
        </li>
      </ul>
    </el-row>

    <!-- 任务统计 -->
    <el-row id="appCount" class="app-count">
      <strong class="app-title">
        任务统计
        <a href="#/task/list">任务列表</a>
      </strong>
      <div class="count-info">
        <dl class="app-tips">
          <dt>进行中</dt>
          <dd>{{count.ongoingAll}}</dd>
        </dl>
        <dl class="app-tips">
          <dt>已归档</dt>
          <dd>{{count.acceptedAll}}</dd>
        </dl>

        <div class="count-bars">
          <ve-bar
            :data="bar1Data"
            :settings="barSettings"
            :colors="bar1Colors"
            :legend-visible="false"
            :tooltip-visible="false"
            :grid="bar1Grid"
            :xAxis="barX"
            width="800px"
            :height="bar1Height"
            v-if="bar1Data.rows.length>0"
          ></ve-bar>
          <div class="data-empty" v-else>暂无数据😂</div>
        </div>

        <ul class="count-bars-tip">
          <li>进行中</li>
          <li>已归档</li>
        </ul>
      </div>
    </el-row>

    <!-- 数据龙虎榜 -->
    <el-row id="appRank" class="app-rank">
      <strong class="app-title">
        数据龙虎榜
        <a href="#/task/rank">查看全部数据</a>
      </strong>

      <div class="rank-info">
        <dl class="app-tips">
          <dt>检查员</dt>
          <dd>{{count.check}}</dd>
        </dl>
        <dl class="app-tips">
          <dt>标注员</dt>
          <dd>{{count.mark}}</dd>
        </dl>
        <a href="#/task/user">查看</a>

        <!-- tab页 -->
        <el-tabs v-model="taskType" @tab-click="queryRank(taskType)">
          <el-tab-pane label="标注排行" name="mark"></el-tab-pane>
          <el-tab-pane label="检查排行" name="check"></el-tab-pane>
        </el-tabs>

        <!-- 条件筛选 -->
        <div class="rank-radio">
          <span>排名：</span>
          <el-radio-group v-model="rankType" @change="changeRank" size="small">
            <template v-if="taskType === 'mark'">
              <el-radio :label="1">{{rankStatus["1"]}}</el-radio>
              <el-radio :label="2">{{rankStatus["2"]}}</el-radio>
              <el-radio :label="3">{{rankStatus["3"]}}</el-radio>
              <el-radio :label="4">{{rankStatus["4"]}}</el-radio>
            </template>
            <template v-else>
              <el-radio :label="5">{{rankStatus["5"]}}</el-radio>
              <el-radio :label="6">{{rankStatus["6"]}}</el-radio>
              <el-radio :label="7">{{rankStatus["7"]}}</el-radio>
            </template>
          </el-radio-group>
        </div>

        <div class="rank-bars">
          <ve-bar
            :data="bar2Data"
            :settings="barSettings"
            :colors="bar2Colors"
            :legend-visible="false"
            :tooltip-visible="false"
            :grid="bar2Grid"
            :xAxis="barX"
            width="800px"
            :height="bar2Height"
            v-if="bar2Data.rows.length>0"
          ></ve-bar>
          <div class="data-empty" v-else>暂无数据😂</div>
        </div>

        <div v-text="rankText" class="rank-text" v-if="bar2Data.rows.length>0"></div>
      </div>
    </el-row>
  </div>
</template>

<script>
import { mapState } from "vuex";
import "v-charts/lib/style.css";
import subNav from "pages/common/subNav";
export default {
  components: {
    subNav
  },
  computed: {
    ...mapState(["appInfo"])
  },
  watch: {
    appInfo() {
      if (this.appInfo.id) {
        this.queryCount();
        this.queryTaskType();
        this.userCount();
        this.queryRank(this.taskType);
      }
    }
  },
  data() {
    return {
      // 应用信息
      navData: [
        {
          name: "应用信息",
          id: "appInfo"
        },
        {
          name: "任务统计",
          id: "appCount"
        },
        {
          name: "数据龙虎榜",
          id: "appRank"
        }
      ],
      typeShow: false,
      buttonColors: [
        "#409EFF",
        "#67c23a",
        "#909399",
        "#e6a23c",
        "#f56c6c",
        "#9422e8"
      ],
      markTypes: [],
      // 任务统计
      bar1Height: "",
      bar1Grid: {
        show: false,
        top: "0px",
        containLabel: true,
        right: "100px"
      },
      bar1Data: {
        columns: ["名称", "a", "进行中", "b", "已归档", "c"],
        rows: []
      },
      count: {
        ongoingAll: 0,
        acceptedAll: 0
      },
      bar1Colors: ["", "#71e638", "", "#ffa205", ""],
      barSettings: {
        label: {
          show: true,
          position: "right",
          color: "#333"
        }
      },
      barX: [
        {
          splitNumber: 6,
          axisTick: {
            lineStyle: {
              color: "#333333"
            }
          },
          axisLine: {
            show: true,
            lineStyle: {
              color: "#333333",
              width: 1
            }
          },
          splitLine: {
            show: false
          }
        }
      ],

      // 龙虎榜
      rankType: 1,
      taskType: "mark",
      bar2Height: "",
      bar2Colors: ["#409eff"],
      bar2Grid: {
        show: false,
        top: "0px",
        containLabel: true,
        right: "100px"
      },
      bar2Data: {
        columns: ["账号", "a", "任务量", "b"],
        rows: []
      },
      rankStatus: {
        "1": "已标注数",
        "2": "已分配标注数",
        "3": "已提交标注数",
        "4": "合格率(%)",
        "5": "已完成检查",
        "6": "已分配检查",
        "7": "已提交检查"
      },

      rankProperty: {
        "1": "currentComplete",
        "2": "current",
        "3": "commitCount",
        "4": "correct",
        "5": "currentComplete",
        "6": "current",
        "7": "commitCount"
      },
      rankText: "已标注数",
      count: {
        mark: 0,
        check: 0
      }
    };
  },
  methods: {
    // 显示详情
    showTypeDetail(item, boolean) {
      this.$set(item, "show", boolean);
    },

    // 任务信息
    queryCount() {
      this.bar1Data.rows = [];
      if (!this.appInfo.id) {
        return;
      }

      // 获取数据
      this.$api.task.appStatistic({ id: this.appInfo.id }).then(
        res => {
          if (res === "") {
            this.count.ongoingAll = 0;
            this.count.acceptedAll = 0;
            return;
          }
          let { taskStats, ongoingAll, acceptedAll } = res;
          this.count.ongoingAll = ongoingAll;
          this.count.acceptedAll = acceptedAll;

          taskStats.forEach(item => {
            this.bar1Data.rows.push({
              名称: item.taskTypeName,
              进行中: item.ongoingNum,
              已归档: item.acceptedNum
            });
          });
          // 任务统计的图表高度根据数量的多少而改变，1个类型高度60--对接调整
          this.bar1Height = this.bar1Data.rows.length * 60 + "px";
          this.bar1Grid.height = this.bar1Height;
        },
        error => {
          this.count.ongoingAll = 0;
          this.count.acceptedAll = 0;
        }
      );
    },

    // 龙虎榜显示
    queryRank(type) {
      // 切换tab类型要改变
      if (type === "mark") {
        this.rankType = 1;
      } else {
        this.rankType = 5;
      }
      this.query(this.getParam(), this.rankProperty[this.rankType.toString()]);
      this.rankText = this.rankStatus[this.rankType.toString()];
    },

    // 龙虎榜状态切换
    changeRank(val) {
      this.query(this.getParam(), this.rankProperty[this.rankType.toString()]);
      this.rankText = this.rankStatus[this.rankType.toString()];
    },

    //获取龙虎榜统计数据
    query(param, property) {
      this.bar2Data.rows = [];
      if (!this.appInfo.id) {
        return;
      }

      this.$api.task.userWorkCount(param).then(
        res => {
          if (res === "") {
            return;
          }
          let { userWorkloadStats } = res;
          userWorkloadStats.forEach(item => {
            let userName = item.userName ? item.userName : "";
            if (userName.length > 12) {
              userName = userName.substring(0, 7) + "...";
            }
            this.bar2Data.rows.push({
              账号: userName + "(" + item.userId + ")",
              任务量: item[property]
            });
          });

          this.bar2Data.rows.reverse();
          // 龙虎榜的图表高度根据数量的多少而改变，1个类型高度40--对接调整
          this.bar2Height = this.bar2Data.rows.length * 40 + "px";
          this.bar2Grid.height = this.bar2Height;
        },
        error => {}
      );
    },

    //封装请求参数
    getParam() {
      if (!this.appInfo.id) {
        return;
      }

      let param = {
        page: 1,
        size: 5,
        sort: "DESC",
        appId: this.appInfo.id,
        type: this.taskType === "mark" ? 0 : 1,
        property: this.rankProperty[this.rankType.toString()]
      };
      return param;
    },

    //任务类型查询
    queryTaskType() {
      this.markTypes = [];
      if (!this.appInfo.id) {
        return;
      }

      this.$api.task.searchTaskType({ appId: this.appInfo.id }).then(res => {
        if (res === "") {
          return;
        }
        res.forEach(item => {
          this.markTypes.push({
            id: item.id,
            name: item.name,
            desc: item.description ? item.description : "暂无描述"
          });
        });
        // 对标注类型的颜色随机分配-对接调整
        this.markTypes.forEach((item, index) => {
          let i;
          i = index > 5 ? index % 5 : index;
          item.color = this.buttonColors[i];
        });
      });
    },

    //用户统计
    userCount() {
      if (!this.appInfo.id) {
        return;
      }

      this.$api.task
        .userCount({
          orgId: this.appInfo.orgId,
          roleNames: "ROLE_DW_MARKER,ROLE_DW_CHECKER"
        })
        .then(res => {
          this.count.mark = res[0];
          this.count.check = res[1];
        });
    }
  },
  mounted() {
    //标注类型
    this.queryTaskType();
    // 滚动条滚至最顶
    document.getElementsByTagName("html")[0].scrollTo(0, 0);
    // 任务统计
    this.queryCount();
    // 龙虎榜
    this.queryRank(this.taskType);
    this.userCount();
    this.typeShow = true;
  }
};
</script>
<style lang='less' scoped>
.el-row {
  background-color: #fff;
  padding: 40px;
  margin-bottom: 10px;
  strong {
    font-size: 16px;
  }
}
.app-info {
  z-index: 999;
  ul {
    margin: 15px 0 10px 0;
    li {
      color: #606060;
      margin-top: 25px;
      line-height: 1.5;
      span:first-child {
        display: inline-block;
      }
    }
  }
  .mark-types {
    z-index: 3000;
    margin-left: -30px;
    .type-item {
      position: relative;
      float: left;
      span {
        display: inline-block;
        line-height: 12px;
        color: #fff;
        background-color: #409eff;
        margin: 10px 0 10px 30px;
        padding: 6px 8px;
        border-radius: 4px;
        cursor: pointer;
      }
      dl {
        position: absolute;
        left: 10px;
        top: 47px;
        border: #dddddd 1px solid;
        background-color: #fff;
        width: 400px;
        display: block;
        padding: 10px;
        border-radius: 6px;
        dt {
          line-height: 30px;
          border-bottom: 1px #dddddd solid;
        }
        dd {
          padding: 20px 0;
        }
        &:before,
        &:after {
          display: inline-block;
          width: 0;
          height: 0;
          border: #fff 12px solid;
          content: "";
          position: absolute;
          left: 30px;
          top: -24px;
          border-top-color: transparent;
          border-left-color: transparent;
          border-right-color: transparent;
        }
        &:before {
          border: #dddddd 14px solid;
          border-top-color: transparent;
          border-left-color: transparent;
          border-right-color: transparent;
          left: 28px;
          top: -28px;
        }
      }
    }
  }
}

.app-count {
  .count-info {
    position: relative;
    float: left;
    margin-top: 26px;
    .count-bars-tip {
      position: absolute;
      right: -50px;
      top: 40%;
      li {
        position: relative;
        &::before {
          display: inline-block;
          width: 40px;
          height: 5px;
          background-color: #ffa205;
          content: "";
          position: absolute;
          left: -48px;
          top: 4px;
        }
        &:first-child {
          margin-bottom: 10px;
          &::before {
            background-color: #71e638;
          }
        }
      }
    }
  }
  .count-bars {
    margin-top: 30px;
    .data-empty {
      display: flex;
      justify-content: center;
      align-items: center;
      background-color: rgba(255, 255, 255, 0.7);
      color: #888;
      font-size: 14px;
    }
  }
}

.app-rank {
  padding-bottom: 50px;
  .rank-info {
    position: relative;
    a {
      position: absolute;
      right: -15px;
      top: 20px;
    }
  }
  .rank-radio {
    margin: 10px 0 30px 0;
  }

  .app-tips {
    float: right;
    width: 120px;
    &:first-child {
      border-left: #dddddd 1px solid;
      border-right: none;
    }
  }

  .rank-bars {
    padding-bottom: 20px;
    .data-empty {
      display: flex;
      justify-content: center;
      align-items: center;
      background-color: rgba(255, 255, 255, 0.7);
      color: #888;
      font-size: 14px;
    }
  }
  .rank-text {
    text-align: center;
    margin: 10px 0 20px 0;
  }
}

.app-title {
  position: relative;
  float: left;
  z-index: 2;
  a {
    font-size: 14px;
    display: block;
    margin-top: 10px;
    font-weight: normal;
  }
}

.app-tips {
  display: inline-block;
  width: 400px;
  text-align: center;
  font-size: 16px;
  dd {
    margin-top: 15px;
    font-weight: bold;
    font-size: 30px;
  }
  dt {
    color: #b6b6b6;
  }
  &:first-child {
    border-right: #dddddd 1px solid;
  }
}

.el-tabs {
  clear: both;
}
</style>
<template>
  <div class="user-statis">
    <el-row class="el-header">
      <span class="userName">{{userInfo.cnName}}</span>
      <div>
        <p>
          <strong>账号：</strong>
        </p>
        <span>{{userInfo.login}}</span>
      </div>
      <div>
        <p>
          <strong>注册日期：</strong>
        </p>
        <span>{{userInfo.createdDate}}</span>
      </div>
    </el-row>
    <el-row class="el-main">
      <div class="title">参与的任务</div>
      <!--筛选条件-->
      <el-form size="small" :inline="true" @submit.native.prevent>
        <el-row class="wood-radio-group">
          <el-form-item label="标注类型：">
            <el-radio-group size="small" v-model="markType" @change="query(1)">
              <el-radio-button
                v-for="item of markTypes"
                :label="item.id"
                :key="item.id"
              >{{item.name}}</el-radio-button>
            </el-radio-group>
          </el-form-item>
        </el-row>
        <el-row class="wood-radio-group">
          <el-form-item label="任务类型：">
            <el-radio-group size="small" v-model="taskType" @change="query(1)">
              <el-radio-button
                v-for="item of taskTypes"
                :label="item.id"
                :key="item.id"
              >{{item.name}}</el-radio-button>
            </el-radio-group>
          </el-form-item>
        </el-row>
        <el-row class="wood-radio-group">
          <el-form-item label="提交时间：">
            <el-date-picker
              @change="query(1)"
              size="small"
              class="detail-date-picker"
              v-model="dateArr"
              type="daterange"
              range-separator="至"
              start-placeholder="开始日期"
              end-placeholder="结束日期"
              format="yyyy-MM-dd"
              value-format="yyyy-MM-dd"
            ></el-date-picker>
          </el-form-item>
        </el-row>
        <el-row class="wood-radio-group">
          <el-form-item>
            <el-input
              placeholder="搜索任务名称"
              v-model="keyStr"
              :maxlength="30"
              clearable
              suffix-icon="el-icon-search"
              @keyup.enter.native="query(1)"
              @change="query(1)"
            ></el-input>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" size="mini" @click="openCountDialog">工作量统计</el-button>
          </el-form-item>
        </el-row>
      </el-form>
      <!--子任务列表-->
      <el-table size="small" :data="taskList" align="center" height="452">
        <el-table-column
          type="index"
          :index="(index)=>{return (page - 1) * size + index + 1}"
          label="序号"
          min-width="50"
        ></el-table-column>
        <el-table-column prop="name" label="任务名称" min-width="100" :show-overflow-tooltip="true"></el-table-column>
        <el-table-column prop="markType" label="标注类型" min-width="120" :show-overflow-tooltip="true"></el-table-column>
        <el-table-column prop="typeDesc" label="任务类型" min-width="140"></el-table-column>
        <el-table-column prop="count" label="数据数量" min-width="140"></el-table-column>
        <el-table-column prop="commitDate" label="提交时间" min-width="140"></el-table-column>
        <el-table-column label="合格率(%)" min-width="140">
          <template slot-scope="scope">
            <span v-text="parseFloat(getRate(scope.row.passcount,scope.row.checkCount))"></span>%
          </template>
        </el-table-column>
        <el-table-column label="判错率(%)" min-width="140">
          <template slot-scope="scope">
            <span v-text="parseFloat(getRate(scope.row.misjudgeBadCount,scope.row.count))"></span>%
          </template>
        </el-table-column>
      </el-table>
      <!-- 分页 -->
      <el-pagination
        v-if="total > 10"
        @size-change="sizeChange"
        @current-change="pageChange"
        align="right"
        layout="total, sizes, prev, pager, next, jumper"
        :current-page="page"
        :page-sizes="[5, 10, 20, 40]"
        :page-size="size"
        :total="total"
        class="pager-wrapper"
      ></el-pagination>

      <!--工作量统计弹窗-->
      <el-dialog :title="title" :visible.sync="countDialogVisible" width="350px">
        <ul class="data-count" v-if="taskType===0">
          <li>
            <strong>提交标注：</strong>{{workloadStatistic.totalCommit}}
          </li>
          <li>
            <strong>被检查数量：</strong>{{workloadStatistic.checkedCount}}
          </li>
          <li>
            <strong>平均正确率：</strong>{{workloadStatistic.correct}}%
          </li>
          <li>
            <strong>判错率：</strong>{{workloadStatistic.misjudge}}%
          </li>
        </ul>
        <ul class="data-count" v-if="taskType===1">
          <li>
            <strong>提交检查：</strong>{{workloadStatistic.totalCommit}}
          </li>
        </ul>
        <span slot="footer" class="dialog-footer">
          <el-button @click="countDialogVisible = false" size="small">取 消</el-button>
          <el-button type="primary" @click="countDialogVisible = false" size="small">确 定</el-button>
        </span>
      </el-dialog>
    </el-row>
  </div>
</template>
<script>
import { mapState } from "vuex";
import { getRate } from "assets/scripts/common";
export default {
  computed: {
    ...mapState(["appInfo"])
  },
  watch: {
    appInfo() {
      if (this.appInfo.id) {
        this.queryTaskType();
      }
    }
  },
  data() {
    return {
      countDialogVisible: false,
      getRate: getRate,
      keyStr: "",
      userInfo: {},
      taskList: [],
      markType: 0,
      markTypes: [
        {
          id: 0,
          name: "全部"
        }
      ],
      taskType: 0,
      taskTypes: [
        {
          id: 0,
          name: "标注任务"
        },
        {
          id: 1,
          name: "检查任务"
        }
      ],
      dateArr: [],
      page: 1,
      size: 10,
      total: 0,
      title: "标注工作量汇总",
      workloadStatistic:{}
    };
  },
  methods: {
    //打开工作汇总弹窗
    openCountDialog() {
      this.countDialogVisible = true;
      if (this.taskType == 0) {
        this.title = "标注工作量汇总";
      }

      if (this.taskType == 1) {
        this.title = "检查工作量汇总";
      }
      this.getWorkStatistic();
    },

    sizeChange(size) {
      this.size=size;
      this.query(1);
    },

    pageChange(page) {
      this.page=page;
      this.query();
    },

    //任务类型查询
    queryTaskType() {
      this.markTypes = [{ id: 0, name: "全部" }];
      if (!this.appInfo.id) {
        return;
      }

      this.$api.task.searchTaskType({ appId: this.appInfo.id }).then(res => {
        if (res === "") {
          return;
        }
        res.forEach(item => {
          this.markTypes.push({
            id: item.id,
            name: item.name
          });
        });
      });
    },

    query(resetPage) {
      if (resetPage == 1) {
        this.page = 1;
      }

      let param = {
        userId: this.userInfo.login,
        completed: true,
        page: this.page,
        size: this.size,
        type: this.taskType,
        applicationId: this.appInfo.id,
        from:
          this.dateArr && this.dateArr[0]
            ? new Date(this.dateArr[0]).getTime() - 28800000
            : null,
        to:
          this.dateArr && this.dateArr[1]
            ? new Date(this.dateArr[1]).getTime() - 28800000
            : null,
        name:this.keyStr
      };

      if (this.markType !== 0) {
        param.typeId = this.markType;
      }

      this.$api.task.getUserTaskList(param).then(res => {
        let { totalElements, content } = res;
        this.taskList = content;
        this.total = totalElements;
      });
    },

    getWorkStatistic() {
      let param = {
        userId: this.userInfo.login,
        type: this.taskType,
        appId: this.appInfo.id,
        from:
          this.dateArr && this.dateArr[0]
            ? new Date(this.dateArr[0]).getTime() - 28800000
            : null,
        to:
          this.dateArr && this.dateArr[1]
            ? new Date(this.dateArr[1]).getTime() - 28800000
            : null
      };

      if (this.markType !== 0) {
        param.taskTypeId = this.markType;
      }

      this.$api.task.workloadStatistic(param).then(res => {
        this.workloadStatistic=res;
      });
    }
  },
  created() {
    this.userInfo = JSON.parse(window.sessionStorage.getItem("userInfo"));
    this.queryTaskType();
    this.query(1);
  }
};
</script>
<style lang="less" scoped>
.user-statis {
  .el-header {
    background-color: #ffffff;
    height: 170px;
    .userName {
      font-size: 18px;
      font-weight: bolder;
      height: 50px;
      line-height: 50px;
      padding: 5px 10px;
      display: block;
    }
    p {
      display: inline-block;
      height: 30px;
      line-height: 30px;
      padding: 5px 10px;
      font-size: 14px;
    }
  }
  .el-main {
    margin-top: 15px;
    background-color: #ffffff;
    position: relative;
    .title {
      height: 40px;
      line-height: 40px;
      font-size: 18px;
      font-weight: bolder;
      padding: 5px 10px;
    }
    .wood-radio-group {
      padding-left: 5px;
    }
  }
  .data-count {
    width: 200px;
    margin:auto;
    li {
      height: 25px;
      line-height: 25px;
      strong {
        font-size: 15px;
      }
    }
  }
}
</style>



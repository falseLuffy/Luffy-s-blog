<template>
  <section class="new-processor">
    <!--处理器基本信息-->
    <el-form
      label-position="right"
      label-width="100px"
      :model="procInfo"
      :rules="rules"
      ref="procInfo"
      size="small"
    >
      <el-form-item label="处理器名称" prop="name">
        <el-input v-model="procInfo.name" size="small" placeholder="请输入处理器名称"></el-input>
      </el-form-item>
      <el-form-item label="处理器描述">
        <el-input type="textarea" placeholder="请输入处理器的简单描述" v-model="procInfo.desc" size="small"></el-input>
      </el-form-item>
      <el-form-item label="处理器类型" prop="type">
        <el-select v-model="procInfo.type" placeholder="请选择类型" size="small">
          <el-option
            v-for="item in options"
            :key="item.value"
            :label="item.label"
            :value="item.value"
          ></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="配置" prop="config" v-if="procInfo.type">
        <el-input v-model="procInfo.config" size="small" placeholder="请输入类型配置"></el-input>
      </el-form-item>
    </el-form>

    <!--过程-->
    <div class="process">
      <p class="title">过程</p>
      <el-row class="process-add">
        <el-button @click="createProcess" size="mini">
          <i class="iconfont icon-add"></i>添加新过程
        </el-button>
      </el-row>
      <el-table :data="processData" align="center" height="160" size="small">
        <el-table-column type="index" label="序号" min-width="50"></el-table-column>
        <el-table-column prop="step" label="过程序号" min-width="100"></el-table-column>
        <el-table-column prop="name" label="名称" min-width="100" :show-overflow-tooltip="true"></el-table-column>
        <el-table-column prop="desc" label="描述" min-width="100" :show-overflow-tooltip="true"></el-table-column>
        <el-table-column
          prop="engineTypeDesc"
          label="引擎类型描述"
          min-width="100"
          :show-overflow-tooltip="true"
        ></el-table-column>
        <el-table-column label="操作" min-width="150">
          <template slot-scope="scope">
            <el-button size="mini" type="primary" @click="editPro(scope.row.id)">编辑</el-button>
            <el-button size="mini" type="primary" @click="delPro(scope.row.id)">移除</el-button>
          </template>
        </el-table-column>
      </el-table>

      <!-- 分页 -->
      <!-- <el-pagination
        @size-change="sizeChange"
        @current-change="pageChange"
        align="right"
        :current-page="page"
        :page-size="size"
        layout="total, prev, pager, next"
        :total="total"
      ></el-pagination>-->
    </div>

    <!-- 操作按钮 -->
    <div class="dialog-footer">
      <el-button type="primary" size="small" @click="updateProcessor">确 定</el-button>
      <el-button @click="cancel" size="small">取 消</el-button>
    </div>
    <el-dialog
      class="create-process"
      width="800px"
      :title="titles"
      :visible.sync="innerVisible"
      center
      append-to-body
      :showClose="false"
      :lock-scroll="false"
    >
      <new-process
        @cancel="closeProcess"
        v-if="innerVisible"
        @query="queryProcessList(processorId)"
        :processorId="processorId"
        :processeDetail="processeDetail"
        :isEdit="isEdit"
      ></new-process>
    </el-dialog>
  </section>
</template>
<script>
import NewProcess from "./NewProcess";
export default {
  props: ["processorId"],
  data() {
    return {
      procInfo: {
        name: "",
        desc: "",
        type: "",
        config: "",
        version: "1"
      },
      options: [
        {
          value: "PRE",
          label: "预处理器"
        },
        {
          value: "ANALYSIS",
          label: "分析处理器"
        },
        {
          value: "EXPORT",
          label: "导出处理器"
        }
      ],
      processData: [],
      processesId: [],
      rules: {
        name: [
          { required: true, message: "请输入处理器名称", trigger: "blur" }
        ],
        type: [
          { required: true, message: "请输入处理器类型", trigger: "change" }
        ],
        config: [{ required: true, message: "请输入类型配置", trigger: "blur" }]
      },
      innerVisible: false,
      titles: "新建过程",
      processeDetail: {},
      isEdit: true
    };
  },
  components: {
    NewProcess
  },
  methods: {
    //关闭处理器弹窗
    cancel() {
      this.$emit("cancel");
    },

    //关闭过程弹窗
    closeProcess() {
      this.innerVisible = false;
    },

    //更新处理器
    updateProcessor() {
      this.$refs.procInfo.validate(valid => {
        this.procInfo.processesId = this.processesId;
        if (valid) {
          this.$api.project.updateProcessor(this.procInfo).then(res => {
            this.$emit("query");
            this.cancel();
          });
        }
      });
    },

    //编辑过程
    editPro(id) {
      this.titles = "编辑过程";
      this.isEdit = true;
      //获取处理过程的详细信息
      this.$api.project.getProcessDetail({ id: id }).then(res => {
        this.processeDetail = res;
        this.innerVisible = true;
      });
    },

    //删除过程
    delPro(id) {
      this.$api.project.delProcess({ id: id }).then(res => {
        this.queryProcessList(this.processorId);
      });
    },

    //获取过程列表
    queryProcessList(id) {
      let param = {
        processorId: id
      };
      this.$api.project.getProcessList(param).then(res => {
        let { content } = res;
        this.processData = content;

        //获取过程id
        this.processesId = [];
        this.processData.forEach(item => {
          this.processesId.push(item.id);
        });
      });
    },

    //获取处理器的详细信息
    queryProcessorDetail(id) {
      this.$api.project.getProcessorDetail({ id: id }).then(res => {
        this.procInfo = res;
      });
    },

    //打开新建过程窗口
    createProcess() {
      this.titles = "新建过程";
      this.innerVisible = true;
      this.processeDetail = {};
      this.isEdit = false;
    }
  },

  mounted() {
    if (this.processorId) {
      this.queryProcessList(this.processorId);
      this.queryProcessorDetail(this.processorId);
    }
  }
};
</script>
<style lang="less">
.new-processor {
  .el-input__inner {
    width: 300px;
  }
  .el-textarea__inner {
    width: 300px;
    height: 60px;
  }
  .process {
    .title {
      margin-top: 10px;
      margin-bottom: 10px;
      font-weight: bold;
      font-size: 16px;
    }
    .process-add {
      clear: both;
      margin-bottom: 10px;
      text-align: center;
      button {
        padding: 10px 0;
        border-style: dashed;
        width: 100%;
        margin: 0 auto;
        border-radius: 4px;
        font-size: 14px;
      }
      .icon-add {
        font-size: 16px;
      }
    }
    .el-pagination {
      min-height: 30px !important;
      margin-top: 10px;
    }
  }
  .dialog-footer {
    margin-top: 10px;
    margin-left: 320px;
  }
}
.create-process {
  .el-dialog--center {
    margin-top: 2% !important;
  }
}
</style>



import md5 from 'js-md5'
import Cookies from 'js-cookie'
let time = new Date().getTime().toString();
let accessToken = Cookies.get('accessToken');
let token = accessToken ? accessToken : '';
export default {
  timeout: 10000,
  withCredentials: true,
  responseType: 'json',
  Authorization: token ? `Bearer ${token}` : '',
  headers: {
    'Content-Type': 'application/json;charset=UTF-8'
  }
}

<template>
  <el-form class="register-form" autoComplete="on" ref="registForm" label-position="right" :model="registForm" :rules="registRules" :inline="true">
    <el-form-item prop="userName"  label="用户账号">
      <el-input v-model="registForm.userName" name="userName" :maxlength="30" placeholder="请输入用户账号"></el-input>
    </el-form-item>
    <el-form-item prop="realName" label="用户姓名">
      <el-input name="name" v-model="registForm.realName" :maxlength="30" placeholder="请输入用户姓名"></el-input>
    </el-form-item>
    <el-form-item prop="pwd" label="密码" class="password">
      <el-input type="password" v-model="registForm.pwd" name="pwd" placeholder="请输入密码"  @keyup="CheckIntensity(registForm.pwd)"></el-input>
      <p v-text="msgText" v-if="registForm.pwd&&(registForm.pwd.length>7&&registForm.pwd.length<17)" :style="{color:color}" ></p>
    </el-form-item>
    <el-form-item prop="repwd" label="确认密码">
      <el-input type="password" v-model="registForm.repwd" name="repwd" placeholder="请输入确认密码"></el-input>
    </el-form-item>
    <el-button type="primary" style="width:100%;margin-bottom:30px;" @click="regist">
      注册
    </el-button>
  </el-form>
</template>

<script>
import { formValid, checkStrong } from "assets/scripts/common";
export default {
  name: "Register",

  data() {
    let validateUserName = (rule, value, callback) => {
      var patt = /^[_’.@A-Za-z0-9-]*$/;
      if (!patt.test(value)) {
        callback(new Error("不能输入除 _ ’ . @ - 以外的特殊符号"));
      } else {
        callback();
      }
    };

    let validatePass2 = (rule, value, callback) => {
      if (value === "") {
        callback(new Error("请再次输入密码"));
      } else if (value !== this.registForm.pwd) {
        callback(new Error("两次输入密码不一致!"));
      } else {
        callback();
      }
    };
    return {
      registForm: {
        userName: "",
        realName: "",
        pwd: "",
        repwd: ""
      },
      registRules: {
        realName: [
          { required: true, message: "请输入用户姓名", trigger: "blur" },
          { validator: formValid.nullValidator, trigger: "blur" }
        ],
        userName: [
          { required: true, message: "请输入用户账号", trigger: "blur" },
          { validator: validateUserName, trigger: "blur" }
        ],
        pwd: [
          { required: true, message: "请输入密码", trigger: "blur" },
          { validator: formValid.passwordValidator, trigger: "blur" },
          { min: 8, max: 16, message: "长度在 8 到 16 个字符", trigger: "change" },
        ],
        repwd: [
          {
            required: true,
            message: "请输入确认密码",
            eq: "password",
            trigger: "blur"
          },
          { validator: formValid.passwordValidator, trigger: "blur" },
          { validator: validatePass2, trigger: "blur" }
        ]
      },
      company: [],
      project: [],
      roles: [],
      msgText: null
    };
  },
  methods: {
    // 注册
    regist() {
      this.$refs.registForm.validate(valid => {
        if (valid) {
          let param = this.registForm;
          this.$api.user
            .registUser({
              login: param.userName,
              cnName: param.realName,
              password: param.pwd,
              appId: "ec2642bb5add4127bc8a7d08a85fd45b",
              validType: 3
            })
            .then(() => {
              this.$emit("hide");
              this.$message.success("注册成功");
              this.resetForm(this.$refs.registForm);
            })
            .catch(() => {});
        }
      });
    },
    resetForm(form) {
      form.resetFields();
      form.clearValidate();
    }
  },
  mounted() {},
  watch: {
    show(val) {
      if (val) {
        this.resetForm(this.$refs.registForm);
      }
    },

    "registForm.pwd"(newValue, oldValue) {
      this.msgText = checkStrong(newValue);
    }
  },
  computed: {
    color(){
      if(this.msgText === "密码强度 中" || this.msgText === "密码强度 高"){
        return "rgb(144, 224, 144)"
      }else{
         return "#f56c6c";
      }    
    }
  }
};
</script>
<style lang="less">
.register-form {
  .el-input {
    width: 320px;
  }
  .password {
    .el-input {
      padding-left: 27px;
      width: 320px;
    }
    .el-form-item__error {
      margin-left: 27px;
    }
    p {
      color: #f56c6c;
      font-size: 12px;
      line-height: 1;
      padding-top: 4px;
      position: absolute;
      top: 100%;
      margin-left: 27px;
    }
  }
}
</style>


<template>
  <section class="dialog">
    <el-form
      size="small"
      ref="userForm"
      :model="userForm"
      :rules="userRules"
      label-width="110px"
      labelPosition="right"
      @submit.native.prevent
    >
      <el-form-item prop="userName" label="用户账号:">
        <el-input v-model="userForm.userName" placeholder="请输入用户账号"></el-input>
      </el-form-item>
      <el-form-item prop="realName" label="用户名称:">
        <el-input name="realName" v-model="userForm.realName" :maxlength="30" placeholder="请输入用户名称"></el-input>
      </el-form-item>
      <el-form-item prop="pwd" label="密码:">
        <el-input type="password" v-model="userForm.pwd" placeholder="密码"></el-input>
      </el-form-item>
      <el-form-item prop="rid" label="角色:">
        <el-select name="rid" v-model="userForm.rid" placeholder="请选择角色">
          <el-option v-for="item in rid" :key="item.value" :label="item.label" :value="item.value"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item prop="desc" label="描述:">
        <el-input
          type="textarea"
          :autosize="{ minRows: 2, maxRows: 4 }"
          name="desc"
          :maxlength="255"
          v-model="userForm.desc"
          placeholder="请输入描述"
        ></el-input>
      </el-form-item>
      <el-form-item prop="adminPwd" label="管理员密码:">
        <el-input
          name="adminPwd"
          type="password"
          v-model="userForm.adminPwd"
          :maxlength="30"
          placeholder="请输入"
        ></el-input>
      </el-form-item>
    </el-form>
    <div slot="footer" align="right" class="section-footer">
      <el-button size="small" @click="hide">取消</el-button>
      <el-button type="primary" size="small" @click="createUser">确定</el-button>
    </div>
  </section>
</template>

<script>
import { formValid } from "assets/scripts/common";
import { mapState } from "vuex";
export default {
  name: "CreateUser",
  data() {
    return {
      rid: [
        {
          value: "4",
          label: "标注人员"
        },
        {
          value: "3",
          label: "检查人员"
        }
      ],
      userForm: {
        name: "",
        account: "",
        password: "",
        company: "",
        rid: "",
        desc: "",
        adminPwd: ""
      },
      userRules: {
        realName: [
          { required: true, message: "请输入用户名称", trigger: "blur" }
        ],
        userName: [
          { required: true, message: "请输入用户账号", trigger: "blur" },
          { validator: formValid.accountValidator, trigger: "blur" },
          { min: 6, max: 20, message: "长度在 6 到 20 个字符", trigger: "blur" }
        ],
        pwd: [
          { required: true, message: "请输入密码", trigger: "blur" },
          { validator: formValid.passwordValidator, trigger: "blur" },
          { min: 8, max: 16, message: "长度在 8 到 16 个字符", trigger: "blur" }
        ],
        rid: [{ required: true, message: "请选择角色", trigger: "change" }],
        adminPwd: [{ required: true, message: "请输入密码", trigger: "blur" }]
      },
      company: []
    };
  },
  methods: {
    // 新建
    createUser() {
      this.$refs.userForm.validate(valid => {
        if (valid) {
          this.$api.user
            .createUser(this.userForm)
            .then(() => {
              this.hide();
              this.$message.success("创建成功");
              this.$emit("success");
            })
            .catch(() => {});
        } else {
          console.log("error create user!", this.userForm);
          return false;
        }
      });
    },
    resetForm() {
      this.$refs.userForm.resetFields();
      this.$refs.userForm.clearValidate();
    },

    // 获取项目信息
    getApps() {
      this.$api.project
        .getApps({})
        .then(data => {
          this.company = data;
        })
        .catch(() => {});
    },

    // 取消
    hide() {
      this.resetForm();
      this.$emit("hide");
    }
  },
  computed: {
    ...mapState(["user"])
  },
  mounted() {
    this.userForm.rid = this.proRid;
    this.getApps();
  }
};
</script>

<template>
  <section class="dialog">
    <el-form
      ref="projForm"
      :model="projForm"
      :rules="projRules"
      label-width="110px"
      labelPosition="right"
      size="small"
    >
      <el-form-item prop="name" label="应用名称:">
        <el-input name="name" v-model="projForm.name" placeholder="请选择应用名称"></el-input>
      </el-form-item>
      <el-form-item prop="description" label="应用描述:">
        <el-input
          type="textarea"
          :rows="4"
          name="description"
          v-model="projForm.description"
          :maxlength="255"
          placeholder="请输入标注应用的简单描述"
        ></el-input>
      </el-form-item>
    </el-form>
    <div slot="footer" align="center" class="section-footer">
      <el-button type="primary" @click="createProj" size="small">确定</el-button>
      <el-button @click="hide" size="small">取消</el-button>
    </div>
  </section>
</template>

<script>
import { mapMutations } from "vuex";
export default {
  name: "NewProj",
  data() {
    return {
      projForm: {
        name: "",
        description: ""
      },
      projRules: {
        name: [{ required: true, message: "请输入应用名称", trigger: "blur" }],
        description: [
          { required: true, message: "请输入应用描述", trigger: "blur" }
        ]
      }
    };
  },
  methods: {
    ...mapMutations(["showLoading", "closeLoading"]),

    //确定
    createProj() {
      this.showLoading();
      this.$refs.projForm.validate(valid => {
        if (valid) {
          let formData = new FormData();
          formData.append("name", this.projForm.name);
          formData.append("description", this.projForm.description);
          this.$api.project
            .createApp(formData)
            .then(() => {
              this.closeLoading();
              this.hide();
              this.$emit("success");
              this.$message.success("创建成功");
            })
            .catch(() => {});
        } else {
          this.closeLoading();
        }
      });
    },

    // 重置
    resetForm() {
      this.$refs.projForm.resetFields();
      this.$refs.projForm.clearValidate();
    },

    //隐藏
    hide() {
      this.resetForm();
      this.$emit("hide");
    }
  }
};
</script>

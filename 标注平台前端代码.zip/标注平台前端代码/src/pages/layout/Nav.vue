<template>
  <div class="left-slider">
    <div class="logo">
      <i class="iconfont icon-logo3"></i>
      <span>DataWood</span>
    </div>
    <div class="app-select" v-if="appNames.length > 0 && isAppAdmin">
      <el-select v-model="appValue" style="top:20px;" @change="changeApp" size="small">
        <el-option v-for="item of appNames" :value="item.id" :label="item.name" :key="item.id"></el-option>
      </el-select>
    </div>
    <el-menu mode="vertical" theme="dark" class="sidebar-container" :class="{'is-app': appNames.length > 0 && isAppAdmin}" background-color="#1a2226" active-background-color="#ffffff" text-color="#dae1f1" active-text-color="#409EFF" unique-opened :default-active="$route.path">
      <template v-for="(item,index) in routers">
        <router-link v-if="!item.hidden&&item.children&&item.children.length>0" :to="item.children[0].path" :key="index">
          <el-menu-item :index="item.path+'/'+item.children[0].path" class='submenu-title-noDropdown'>
            <i v-if="item.icon" :class="item.icon"></i>
            <span>{{item.children[0].name}}</span>
          </el-menu-item>
        </router-link>
      </template>
    </el-menu>
  </div>
</template>

<script>
import { mapState, mapMutations } from "vuex";
import { getAppInfo, setAppInfo } from "assets/scripts/common";
import { datawoodRole } from "assets/scripts/code";

export default {
  data() {
    return {
      isAppAdmin: false,
      appValue: null,
      appNames: [],
    };
  },
  computed: {
    ...mapState(["user", "routers", "appInfo"])
  },
  methods: {
    ...mapMutations([
      "setAppInfo",
      "resetContainer",
      "showLoading",
      "closeLoading"
    ]),

    /**
     * 切换应用
     */
    changeApp() {
      // 数据设置空
      this.setAppInfo({});

      // 更换应用
      this.$nextTick(() => {
        this.appNames.find(item => {
          if (item.id === this.appValue) {
            setAppInfo(item);
            this.getAppDetail(item.id);
            return true;
          }
        });

        // app管理员
        let path = this.$route.path;
        let targetUrl;
        if (this.user.role === datawoodRole.appAdmin) {
          targetUrl = "/task/index";
        } else {
          // 普通用户
          targetUrl = "/mark/index";
        }

        if (path !== targetUrl) {
          this.$router.push(targetUrl);
        }
      });
    },

    /**
     * 获取当前应用详情
     */

    getAppDetail(appId) {
      this.$api.project.getAppDetail({id: appId}).then(res => {
          // 将应用信息存储到vuex中
          this.setAppInfo(res);
        })
        .catch(() => {
          this.closeLoading();
        });
    }
  },

  mounted() {
    // 除了超管都显示应用
    this.isAppAdmin = this.user.role != datawoodRole.superAdmin ? true : false;

    // 获取应用信息
    if (this.isAppAdmin) {
      this.showLoading();
      this.$api.task
        .getMyInfos()
        .then(res => {
          this.closeLoading();
          let { applications, id } = res;
          this.appNames = [];
          this.appValue = null;

          if (applications && applications.length > 0) {
            // 将用户ID也存储到数据中
            applications.forEach(item => {
              item.userId = id;
            });

            this.appNames = applications;

            // 获取本地存储,设置默认值,必须是一个用户才行
            let appInfos = getAppInfo();
            if (appInfos && appInfos[id]) {
              this.appValue = appInfos[id].id;
            } else {
              this.appValue = applications[0].id;
              setAppInfo(applications[0]);
            }
            this.getAppDetail(this.appValue);
          }
        })
        .catch(() => {
          this.closeLoading();
          this.$message.error("应用获取失败");
        });
    }
  }
};
</script>
<style lang="less" scoped>
.left-slider {
  width: 200px;
  height: 100%;
  float: left;
  box-shadow: 2px 0 6px rgba(0, 21, 41, 0.35);
  .logo {
    position: fixed;
    top: 0;
    bottom: 0;
    width: 200px;
    background: #002140;
    height: 60px;
    line-height: 60px;
    color: #fff;
    font-family: "Century Gothic";
    font-size: 24px;
    box-sizing: border-box;
    span {
      margin-left: 20px;
      font-weight: bold;
    }
    .iconfont {
      font-size: 20px;
      position: relative;
      left: 20px;
      transform: rotate(30deg);
      display: inline-block;
      color: rgb(64, 158, 255);
    }
  }
  .app-select {
    position: fixed;
    top: 60px;
    bottom: 0;
    width: 200px;
    background: #1a2226;
    padding: 0 10px;
    box-sizing: border-box;
  }
  .sidebar-container {
    position: fixed;
    top: 60px;
    bottom: 0;
    width: 200px;
    min-height: calc(100% - 60px);
    overflow-y: auto;
    border-right: 0px;
    &::-webkit-scrollbar {
      display: none;
    }
    &.is-app {
      top: 120px;
    }
  }
  .el-menu-item i {
    color: rgb(218, 225, 241);
  }
  .router-link-active {
    .el-menu-item i {
      color: #409eff;
    }
  }
}
</style>

<template>
  <div class="container-block">
    <div class="exception-content">
      <img
        src="https://img.alicdn.com/tfs/TB1w4M7bNrI8KJjy0FpXXb5hVXa-260-260.png"
        class="imgException"
        alt="服务器出错"
      >
      <div>
        <h3 class="title" style="color: rgb(51, 51, 51);">抱歉，服务器出错了</h3>
        <p class="description" style="color: rgb(102, 102, 102);">
          服务器出错了，请重新刷新页面或返回
          <a href="#">首页</a>
        </p>
      </div>
    </div>
  </div>
</template>

<style lang="less" scoped>
.container-block {
  background-color: rgb(255, 255, 255);
  border-radius: 6px;
  padding: 20px;
  margin-bottom: 20px;
}
.exception-content {
  display: flex;
  justify-content: center;
  align-items: center;
}

@media screen and (max-width: 720px) {
  .exception-content {
    min-height: 200px;
    .imgException {
      max-width: 100px;
      margin-right: 10px;
    }
    .title {
      font-size: 14px;
      margin: 10px 0;
    }
    .description {
      font-size: 12px;
    }
  }
}

@media screen and (min-width: 721px) and (max-width: 1199px) {
  .exception-content {
    min-height: 300px;
    .imgException {
      max-width: 180px;
      margin-right: 30px;
    }
    .title {
      font-size: 20px;
      margin: 10px 0;
    }
    .description {
      font-size: 14px;
    }
  }
}

@media screen and (min-width: 1200px) {
  .exception-content {
    min-height: 500px;
    .imgException {
      max-width: 260px;
      margin-right: 50px;
    }
    .title {
      font-size: 24px;
      margin: 20px 0;
    }
    .description {
      font-size: 16px;
    }
  }
}
</style>


<template>
  <div>
    <mark-tpl
      class="en-mark"
      :appType="appType"
      :param="param"
      :keysList="keysList"
      @query="query"
      @setQueryData="setQueryData"
      @valid="valid"
      @save="save"
    >
      <div slot="answer">
        <div>
          {{param.wav_file}}
          <template>
            <el-button
              size="small"
              type="danger"
              v-if="param.valid_flg == '0'"
              @click="availableClick"
            >全部不可用
            </el-button>
            <el-button
              size="small"
              type="danger"
              class="btn-plain"
              v-if="param.valid_flg == '1'"
              @click="availableClick"
            >全部标为不可用
            </el-button>
          </template>
        </div>
        <!-- 音频 -->
        <div id="waveform" ref="waveform" class="wave-form">
          <el-progress :percentage="percent" :stroke-width="8" v-if="progress"></el-progress>
        </div>
        <!-- 音频控制按钮 -->
        <div class="audio-group">
          <el-button size="small" type="primary" @click="play">
            <i :class="['iconfont',{'icon-run':runIcon,'icon-pause':!runIcon}]"></i>
            <span>{{playText}}</span>
          </el-button>
          <el-button size="small" type="warning" @click="stop">
            <i class="iconfont icon-stop"></i>重置
          </el-button>

          <div class="volume">
            <div class="volume-content">
              <i class="iconfont icon-voice"></i>
              <el-slider v-model="volume" @change="setVolume"></el-slider>
            </div>
          </div>
        </div>

        <!-- 设置面板 -->
        <div class="content" v-show="param.valid_flg == '1'">
          <div class="main-content">
            <!-- 展示面板 -->
            <div class="main">
              <ul class="main-sents" v-for="(sent,index)  in param.sents" :key="index">
                <el-button
                  size="mini"
                  type="danger"
                  v-if="sent.valid_flg=='0'"
                  @click="sentAvailableClick(sent)"
                  style="margin-right: 24px;"
                >不可用
                </el-button>
                <el-button
                  size="mini"
                  type="danger"
                  class="btn-plain"
                  v-if="sent.valid_flg=='1'"
                  @click="sentAvailableClick(sent,index)"
                >标为不可用
                </el-button>

                <i class="iconfont icon-run" @click.stop.prevent="playSentence(sent)"></i>
                <li
                  v-for="(item,unit) in sent.words"
                  :key="unit"
                  @click.stop.prevent="selectedWord(item,index,unit)"
                >
                  <span
                    v-text="item.content"
                    :class="{'word-active':item.status==1,'word-wrong':item.status==2,'word-novalid':item.status==3}"
                  ></span>
                </li>
              </ul>
            </div>
          </div>
          <!-- 设置面板 -->
          <div class="side">
            <div v-if="activeWord">
              <dl>
                <dt :title="activeWord.content">{{activeWord.content}}</dt>
                <dd>
                  <el-radio-group v-model="activeWord.err_type" @change="wordErrChange">
                    <el-radio size="mini" label="正确" :disabled="readonly">正确</el-radio>
                    <el-radio size="mini" label="漏读" :disabled="readonly">漏读</el-radio>
                    <el-radio size="mini" label="增读" :disabled="readonly">增读</el-radio>
                    <el-radio size="mini" label="替换" :disabled="readonly">替换</el-radio>
                    <el-input
                      :disabled="readonly"
                      size="mini"
                      class="zd-number"
                      v-show="activeWord.err_type === '替换'"
                      :max="20"
                      :min="0"
                      v-model="activeWord.replace"
                    ></el-input>
                    <el-radio
                      size="mini"
                      label="不可用"
                      style="margin-left:8px;"
                      :disabled="readonly"
                    >不可用
                    </el-radio>
                  </el-radio-group>
                </dd>
              </dl>

              <dl
                v-for="(word,index) of activeWord.phone_info"
                :key="index"
                v-show="activeWord.showChild"
              >
                <dt>{{word.content}}</dt>
                <dd>
                  <el-radio-group v-model="word.err_type" @change="subWordErrChange(word,index)">
                    <el-radio size="mini" label="正确" :disabled="readonly">正确</el-radio>
                    <el-radio size="mini" label="漏读" :disabled="readonly">漏读</el-radio>
                    <el-radio size="mini" label="替换" :disabled="readonly">替换</el-radio>
                  </el-radio-group>

                  <div v-show="word.err_type === '替换'" class="label">
                    <el-select
                      :disabled="readonly"
                      size="mini"
                      v-model="word.replace"
                      clearable
                      @change="subWordErrChange(word)"
                    >
                      <el-option-group
                        v-for="group in enDataList"
                        :key="group.label"
                        class="replace-options"
                      >
                        <el-option
                          v-for="item in group.options"
                          :key="item.value"
                          :label="item.label"
                          :value="item.value"
                        ></el-option>
                      </el-option-group>
                    </el-select>
                  </div>
                </dd>
              </dl>
            </div>
          </div>
        </div>
      </div>
    </mark-tpl>
  </div>
</template>

<script>
  import MarkTpl from "./MarkTpl";
  import WaveSurfer from "wavesurfer.js";
  import RegionsPlugin from "wavesurfer.js/dist/plugin/wavesurfer.regions.min.js";
  import {APPTYPE, enDataList} from "assets/scripts/code";
  import {setMarkData} from "assets/scripts/common";

  export default {
    name: "EnMark",
    components: {
      MarkTpl
    },
    data() {
      return {
        keysList: [
          {
            name: "功能说明",
            key: "快捷键"
          },
          {
            name: "播放切换",
            key: "Q"
          },
          {
            name: "保存并下一条",
            key: "空格"
          }
        ],
        appType: APPTYPE.EN,
        mcType: "",
        readonly: false,
        progress: true,
        percent: 0,
        wavesurfer: {},
        volume: 50,
        enMarkType: "",
        param: {
          content: "",
          read_type: "", // "read_sent","read_para"
          valid_flg: "1", // 1表示可用，0表示不可以用
          wav_file: "", // 音频
          sents: []
        },
        activeWord: null, // 正在标注的单词
        activeRegion: null,
        playText: "播放",
        runIcon: true,
        enDataList: enDataList
      };
    },
    methods: {
      /**
       * 查询数据
       * @param param 请求参数
       * @param isCookie 是否是缓存
       */
      query(param, isCookie) {
        let id = param.userTaskItemId;
        let dataId = param.dataId;
        delete param.dataId;

        this.$api.mark
          .getMarkFile(param)
          .then(res => {
            res.userTaskItemId = id;
            res.dataId = dataId;
            if (isCookie) {
              setMarkData(id, res);
            } else {
              setMarkData(id, res);
              this.setQueryData(res);
            }
          })
          .catch(() => {
          });
      },

      /**
       * 请求数据后的内容处理
       * @param res 请求的数据
       */
      setQueryData(res) {
        // 数据重置
        this.runIcon = true;
        this.playText = "播放";
        this.activeWord = null;
        this.activeRegion = null;
        if (this.wavesurfer) {
          this.wavesurfer.clearRegions();
        }

        let mcType = this.mcType;
        let enData;

        // 1）检查
        if (mcType == 1) {
          enData = res.checkedData ? res.checkedData : res.markedData;
        } else if (res.markedData && mcType == 0) {
          // 2）标注
          enData = res.markedData;
        } else if (!res.markedData) {
          // 3）没有标注
          enData = res.data;
        }
        this.param = enData;

        if (this.param.valid_flg == undefined) {
          this.param.valid_flg = "1";
        }

        // 数据处理,如果err_type为空，默认显示正确
        this.param.sents = this.setSents(this.param.sents);

        // 初始默认选中第一个
        //   if (this.param.sents && this.param.sents[0]) {
        //     let sent0 = this.param.sents[0];
        //     if (sent0.words && sent0.words[0]) {
        //       let word0 = sent0.words[0];
        //       this.selectedWord(word0, 0, 0, true);
        //     }
        //   }

        this.progress = true;

        //音频加载
        let reqUrl = location.origin;
        let audio = `${reqUrl}/base/datawood-processor/download/source/${res.dataId}`;
        this.wavesurfer.load(audio);

        // 获取数据后，才可以点击下一条，防止快速点击事件
        this.param.clicked = false;
        if (this.param.keycodetimer) {
          this.param.keycodetimer = null;
          clearTimeout(this.param.keycodetimer);
        }
      },

      /**
       * 句子设置
       */
      setSents(sents) {
        sents.forEach(item => {
          // 可用设置
          if (item.valid_flg == undefined) {
            item.valid_flg = "1";
          }
          // 每个单词遍历
          item.words.forEach(unit => {
            let errType = unit.err_type;
            // 可用性
            if (unit.valid_flg == undefined) {
              unit.valid_flg = "1";
            }
            // 替换
            if (unit.replace) {
              unit.err_type = "替换";
            }

            // 标注状态赋值
            unit.status = 0;
            if (errType) {
              if (errType == "漏读" || errType == "增读" || errType == "替换") {
                unit.status = 2;
              }

              if (errType == "不可用") {
                unit.status = 3;
              }

              if (errType == "正确") {
                unit.status = 4;
              }
            }

            // 防止数据值与系统不符合
            let statusArr = ["正确", "漏读", "增读", "替换", "不可用"];
            if (!errType || !statusArr.includes(errType)) {
              unit.err_type = "正确";
            }

            // 如果子数据有错，词语的标注状态也是错
            let subWrongFlag = false;
            if (unit.phone_info && unit.phone_info.length > 0) {
              unit.phone_info.forEach(sub => {
                if (
                  (sub.err_type == "漏读" || sub.err_type == "替换") &&
                  !subWrongFlag
                ) {
                  subWrongFlag = true;
                }

                if (sub.err_type != "漏读" && !sub.replace) {
                  sub.err_type = "正确";
                }
              });
            }
            if (subWrongFlag) {
              unit.status = 2;
            }
          });
        });
        return sents;
      },

      /**
       * 播放句子
       */
      playSentence(sent) {
        let beg = parseFloat(sent.sent_beg_pos);
        let end = parseFloat(sent.sent_end_pos);

        //   this.wavesurfer.play(beg, end);
        this.addOneRegion(beg, end);
      },

      /**
       * 选中单词
       * @param item 点击的单词
       * @param sentIndex 对应的句子序号
       * @param itemIndex 对应的单词的序号
       * @param initFlag 是不是初始化触发的
       */
      selectedWord(item, sentIndex, itemIndex, initFlag) {
        if (this.param.sents[sentIndex].valid_flg == "0") {
          if (!initFlag) {
            this.$message.error("不可用数据不可标注");
          }
          return;
        }

        // 已选择的记录在册
        this.saveActiveWord();

        // 当前激活赋值
        item.sentIndex = sentIndex;
        item.itemIndex = itemIndex;
        item.lastStatus = item.status;
        item.status = 1; // 激活状态
        item.showChild = true;

        this.activeWord = {...item};
        if (!this.activeWord.err_type && !this.activeWord.replace) {
          this.activeWord.err_type = "正确";
        }

        // 绘制区域
        // 播放一下
        if (!initFlag) {
          let start = parseFloat(item.word_beg_pos);
          let end = parseFloat(item.word_end_pos);
          this.addOneRegion(start, end);
        }
      },

      /**
       * 添加播放的区域
       */
      addOneRegion(start, end) {
        this.wavesurfer.clearRegions();
        this.activeRegion = this.wavesurfer.addRegion({
          id: new Date().getTime(),
          start: start,
          end: end,
          loop: false,
          drag: false,
          resize: false,
          color: "rgba(235, 230, 230, 0.5)"
        });
        this.wavesurfer.play(start, end);
      },

      /**
       * 保存激活单词至params中
       */
      saveActiveWord() {
        if (this.activeWord) {
          let {sentIndex, itemIndex, lastStatus, status} = this.activeWord;

          if (status == 1) {
            this.activeWord.status = lastStatus == undefined ? 0 : lastStatus;
          }
          if (sentIndex !== undefined && itemIndex !== undefined) {
            this.param.sents[sentIndex].words[itemIndex] = {
              ...this.activeWord
            };
          }
        }
      },

      /**
       * 错误的change
       * 状态说明：0 未标，1正在标，2露读/增读/替换，3不可用，4已读
       */
      wordErrChange() {
        let errType = this.activeWord.err_type;
        let childWords = this.activeWord.phone_info;

        childWords.forEach(item => {
          // 正确/漏读，下跟随
          if (errType == "正确" || errType == "漏读") {
            childWords.forEach(item => {
              item.err_type = errType;
            });
          }

          if (errType != "替换") {
            item.replace = "";
          }
        });

        // 状态修改
        this.activeWord.status = errType == "正确" ? 4 : 2;

        // 增读/不可用，隐藏
        if (errType == "增读" || errType == "不可用") {
          this.activeWord.showChild = false;
          this.activeWord.status = errType == "增读" ? 2 : 3;
        } else {
          this.activeWord.showChild = true;
        }

        // 可用/不可用
        this.activeWord.valid_flg = errType == "不可用" ? "0" : "1";
      },

      /**
       * sub错误的change
       */
      subWordErrChange(word) {
        if (this.readonly) {
          return;
        }
        let {err_type} = word;
        this.activeWord.status = err_type == "正确" ? 4 : 2;
        if (err_type !== "替换") {
          word.replace = "";
        }
      },

      /**
       * 句子不可用
       */
      sentAvailableClick(sent, index) {
        // 只读
        if (this.readonly) {
          return;
        }

        let currentValid = sent.valid_flg;
        // 标为不可用
        if (currentValid == "1" || currentValid == undefined) {
          sent.valid_flg = "0";
          // 如果是当前句子则去除
          if (this.activeWord && index == this.activeWord.sentIndex) {
            this.saveActiveWord();
            this.activeWord = null;
            this.wavesurfer.clearRegions();
            this.activeRegion = null;
          }
        } else {
          sent.valid_flg = "1";
        }
      },

      /**
       * 文件可用点击
       */
      availableClick() {
        // 只读，检查员不可以改好数据
        if (this.readonly || (this.mcType == 1 && this.param.valid_flg == "1")) {
          return;
        }

        this.sentAvailableClick(this.param);
      },

      // 音频初始化
      audioPlay() {
        this.wavesurfer = WaveSurfer.create({
          container: this.$refs.waveform,
          waveColor: "#368666",
          progressColor: "#6d9e8b",
          cursorColor: "#fff",
          height: 64,
          responsive: true,
          scrollParent: true,
          plugins: [RegionsPlugin.create()]
        });

        // 加载
        this.wavesurfer.on("loading", percents => {
          this.percent = percents;
          window.sessionStorage.setItem("audioProgress", true);
        });

        // 加载成功
        this.wavesurfer.on("ready", () => {
          this.progress = false;
          window.sessionStorage.removeItem("audioProgress");
          this.duration = parseInt(this.wavesurfer.getDuration());
        });

        // 播放中
        this.wavesurfer.on("audioprocess", () => {
          this.currentTime = parseInt(this.wavesurfer.getCurrentTime());
          this.runIcon = false;
          this.playText = "暂停";
          if (this.currentTime === this.duration) {
            this.runIcon = true;
            this.playText = "播放";
          }
        });

        // 加载失败
        this.wavesurfer.on("error", () => {
          this.progress = false;
          window.sessionStorage.removeItem("audioProgress");
        });

        // 暂停
        this.wavesurfer.on("pause", () => {
          this.runIcon = true;
          this.playText = "播放";
        });
      },

      // 播放
      play() {
        if (this.progress) {
          this.$message.warning("请等音频加载完再操作");
          return;
        }

        if (this.playText === "播放") {
          if (this.activeRegion) {
            this.activeRegion.play();
          } else {
            this.wavesurfer.play();
          }
        } else {
          this.wavesurfer.pause();
        }
      },

      // 停止
      stop() {
        if (this.progress) {
          this.$message.warning("请等音频加载完再操作");
          return;
        }
        this.wavesurfer.stop();
      },

      // 设置音量
      setVolume(value) {
        this.volume = value;
        this.wavesurfer.setVolume(value / 100);
      },

      /**
       * 校验
       */
      valid() {
        return true;
      },

      /**
       * 保存标注内容
       */
      save() {
        this.saveActiveWord();
        this.param.bad = this.param.valid_flg == "0" ? true : false;

        // 去除自定义的状态
        this.param.sents.forEach(item => {
          item.words.forEach(unit => {
            delete unit.itemIndex;
            delete unit.sentIndex;
            delete unit.lastStatus;
            delete unit.status;
          });
        });
      },

      /**
       * 快捷键设置
       */
      setKeyCode() {
        const type = this.type,
          that = this;

        // 阻止默认空格事件
        document.addEventListener("keydown", e => {
          const keyCode = e.keyCode || e.which;
          if (keyCode === 32) {
            e.preventDefault();
          }
        });
        document.addEventListener("keyup", that.setKeyUpEvt);
      },

      /**
       * 点击空格控制音乐
       */
      setKeyUpEvt(e) {
        const that = this;
        const keyCode = e.keyCode || e.which;
        if (keyCode === 81) {
          e.preventDefault();
          that.play();
        }
      }
    },

    created() {
      var task = JSON.parse(window.sessionStorage.getItem("task"));
      // 1检查,0标注
      this.mcType = task.type;
      this.readonly = task.readonly;

      // 获取当前标注类型
      this.enMarkType = this.$route.params.id;

      this.$nextTick(() => {
        this.audioPlay();
        this.setKeyCode();
      });
    },

    /**
     * 离开前操作，暂停播放音乐
     */
    beforeRouteLeave(to, from, next) {
      this.wavesurfer.pause();
      this.runIcon = true;
      this.playText = "播放";
      document.removeEventListener("keyup", this.setKeyUpEvt);
      next();
    }
  };
</script>

<style rel="stylesheet/less" lang="less" scoped>
  .wave-form {
    width: 100%;
    position: relative;
    background: #000;
    margin: 20px auto 10px;

    .el-progress {
      position: absolute;
      top: 20px;
      left: 0;
      width: 100%;
      color: #fff;
    }
  }

  .audio-group {
    button {
      padding: 6px 10px 6px 25px;
      position: relative;

      .iconfont {
        position: absolute;
        top: 4px;
        left: 7px;
        font-size: 16px;
      }
    }

    .volume {
      display: inline-block;
      width: 100px;
      vertical-align: middle;
      margin-left: 30px;
      position: relative;

      .iconfont.icon-voice {
        position: absolute;
        left: -25px;
        top: 10px;
        color: #585757;
      }
    }
  }

  .content {
    margin: 20px auto;
    overflow: hidden;

    .main-content {
      position: relative;
      float: left;
      width: 60%;
      padding-bottom: 10px;
      border-radius: 2px;
      background: #f3f4f5;
      height: 440px;
      overflow-y: auto;
      box-sizing: border-box;
    }

    .main {
      width: 100%;
      background-size: 40px 40px;

      .main-sents {
        background-color: #cce7f1;
        margin-bottom: 10px;
        padding: 5px;
        box-sizing: border-box;

        .icon-run {
          font-size: 13px;
          padding: 3px;
          color: #009688;
          border: #009688 1px solid;
          border-radius: 100%;
          margin: 0 0 0 4px;
          cursor: pointer;
        }

        li {
          display: inline-block;
          cursor: pointer;

          span {
            padding: 8px;
          }

          .word-active {
            color: #fff;
            background-color: #009688;
          }

          .word-done {
            color: #999;
          }

          .word-wrong {
            color: rgb(243, 19, 243);
          }

          .word-novalid {
            color: #ed3f14;
          }
        }

        button {
          margin-left: 4px;
        }
      }
    }

    .side {
      float: right;
      width: calc(~"40% - 5px");
      background: #f3f4f5;
      color: #333;
      height: 440px;
      border-radius: 2px;

      dl {
        border-bottom: 1px solid #d8d8d8;
        height: 47px;
        line-height: 47px;

        &.zcl {
          height: auto;
          line-height: normal;

          dd {
            padding: 10px;
          }
        }
      }

      dt {
        display: inline-block;
        width: 60px;
        text-align: center;
        font-size: 14px;
        text-overflow: ellipsis;
        overflow: hidden;
      }

      dd {
        display: inline-block;
        border-left: 1px solid #d8d8d8;
        position: relative;
        top: -18px;
        padding-left: 4px;

        .name {
          display: inline-block;
          text-align: center;
          width: 100px;
          margin-right: 20px;
          font-size: 14px;
          text-overflow: ellipsis;
          overflow: hidden;
          white-space: nowrap;
          position: relative;
          top: 7px;
          line-height: 22px;
        }

        .label {
          display: inline-block;
          margin-left: 2px;

          .el-select {
            width: 75px;
          }

          .el-input__inner {
            padding: 0 3px;
          }
        }

        span {
          font-size: 14px;
        }

        button {
          padding: 5px 15px;
        }

        .zd-number {
          width: 75px;
          height: 26px;
          margin-left: 10px;
        }
      }

      .grade {
        text-align: center;
        margin-top: 20px;
        padding-bottom: 20px;
      }
    }
  }

  .modal-list {
    margin-bottom: 40px;

    dt {
      display: inline-block;
      width: 75px;
      font-size: 14px;
      vertical-align: top;
    }

    dd {
      display: inline-block;

      .label {
        display: inline-block;
        width: 85px;
        margin-left: 10px;
      }

      p {
        margin-bottom: 10px;
      }

      em {
        font-style: normal;
        color: red;
      }

      &.center {
        position: relative;
        top: -8px;
        left: -11px;
      }
    }
  }
</style>

<style lang="less" scoped>
  .en-mark {
    wave {
      overflow: hidden !important;
    }

    .el-radio__input.is-disabled + span.el-radio__label {
      color: #7a7c7f;
    }

    .wavesurfer-region {
      z-index: 1000;
    }

    .el-radio__input.is-disabled.is-checked .el-radio__inner {
      border-color: #409eff;
      background: #409eff;
    }

    .el-radio__input.is-disabled.is-checked .el-radio__inner::after {
      background-color: #fff;
    }
  }

  .volume .el-slider__button {
    width: 12px;
    height: 12px;
  }

  .numbers {
    .el-radio {
      margin-bottom: 5px;
    }

    .el-input-number__decrease,
    .el-input-number__increase {
      display: none;
    }
  }

  .side {
    .el-input__inner {
      padding: 0 2px;
      height: 26px;
      line-height: 26px;
    }

    .el-radio__label {
      padding-left: 2px;
      font-size: 13px;
    }

    .el-radio + .el-radio {
      margin-left: 8px;
    }
  }

  .replace-options {
    overflow: hidden;

    .el-select-dropdown__item {
      float: left;
      padding: 0 5px;
      width: 34px;
      border: #e8e8e8 1px solid;
      border-right: none;
      border-bottom: none;
      text-align: center;

      &:last-of-type {
        border-right: #e8e8e8 1px solid;
      }
    }

    &.el-select-group__wrap:not(:last-of-type) {
      padding-bottom: 0;
    }

    &.el-select-group__wrap:not(:last-of-type)::after {
      display: none;
    }

    &.el-select-group__wrap:last-of-type {
      border-bottom: #e8e8e8 1px solid;
    }
  }

  .el-select-dropdown__list {
    padding: 5px;
  }
</style>




<template>
  <div class="edit-config" v-loading="loading" element-loading-text="正在请求">
    <ul>
      <li>
        <span>任务权限：</span>
        <template v-if="infoEdit">
          <el-radio-group v-model="projInfo.openLevel" size="small">
            <el-radio :label="20">公开任务</el-radio>
            <el-radio :label="21">私有任务</el-radio>
          </el-radio-group>
        </template>
        <span class="task-unset" v-else>{{data.openLevel.desc}}</span>
        <span class="task-tip" v-if="projInfo.openLevel=='21' && infoEdit">（私有任务只能被管理员分配）</span>
      </li>

      <li v-if="(projInfo.openLevel=='20' && infoEdit)">
        <span>最大可领取数：</span>
        <el-input-number
          size="small"
          v-if="infoEdit"
          :precision="0"
          :min="0"
          placeholder="最大可领取数"
          v-model="projInfo.maxApplyNumber"
        ></el-input-number>
        <span class="task-unset" v-else>{{data.maxApplyNumber}}</span>
      </li>

      <li>
        <span>标注方式：</span>
        <template v-if="infoEdit">
          <el-radio-group v-model="projInfo.markMethod" size="small">
            <el-radio :label="30">单次标注</el-radio>
            <el-radio :label="31">多次标注</el-radio>
          </el-radio-group>
        </template>
        <span class="task-unset" v-else>{{data.markMethod.desc}}</span>
      </li>

      <li v-if="(projInfo.markMethod=='31' && infoEdit)">
        <span>标注次数：</span>
        <el-input-number
          size="small"
          v-if="infoEdit"
          :min="1"
          :precision="0"
          placeholder="标注次数"
          v-model="projInfo.markRound"
        ></el-input-number>
        <span class="task-unset" v-else>{{data.markRound}}</span>
      </li>

      <li>
        <span>是否检查：</span>
        <template v-if="infoEdit">
          <el-radio-group v-model="projInfo.whetherCheck" size="small">
            <el-radio :label="41">是</el-radio>
            <el-radio :label="40">否</el-radio>
          </el-radio-group>
        </template>
        <span class="task-unset" v-else>{{data.whetherCheck.desc}}</span>
      </li>

      <li v-if="projInfo.whetherCheck === 41 && infoEdit">
        <span>检查比例：</span>
        <template>
          <el-input-number
            size="small"
            :precision="0"
            :max="100"
            :min="0"
            placeholder="检查比例"
            v-model="projInfo.checkRate"
          ></el-input-number>
          <span class="task-tip">（检查员可以领取不低于此比例的检查任务）</span>
        </template>
      </li>

      <li v-if="!infoEdit && data.whetherCheck.code === 41">
        <span>检查比例：</span>
        <span class="task-unset">{{data.checkRate}}%</span>
      </li>

      <li>
        <span>打回方式:</span>
        <template v-if="infoEdit">
          <el-radio-group v-model="projInfo.rejectBy" @change="rejectByChange">
            <el-radio :label="70">手动打回</el-radio>
            <el-radio :label="71">自动打回</el-radio>
          </el-radio-group>
        </template>
        <span class="task-unset" v-else>{{data.rejectBy.desc}}</span>
      </li>

      <li v-if="projInfo.rejectBy === 71 && infoEdit">
        <span>合格阈值：</span>
        <template>
          <el-input-number
            size="small"
            :precision="0"
            :max="100"
            :min="1"
            placeholder="合格阈值"
            v-model="projInfo.passRateThreshold"
          ></el-input-number>
        </template>
      </li>

      <li v-if="!infoEdit && data.rejectBy.code === 71">
        <span>合格阈值：</span>
        <span class="task-unset">{{data.passRateThreshold}}</span>
      </li>

      <li>
        <span>正确率统计：</span>
        <template v-if="infoEdit">
          <el-radio-group v-model="projInfo.checkBy" size="small">
            <el-radio :label="50">检查员统计</el-radio>
            <el-radio :label="51">机器统计</el-radio>
          </el-radio-group>
        </template>
        <span class="task-unset" v-else>{{data.checkBy.desc}}</span>
        <span class="task-tip" v-if="projInfo.checkBy == '50'&& infoEdit">（检查员的检查结果计算正确率）</span>
        <span class="task-tip" v-if="projInfo.checkBy == '51'&& infoEdit">（机器的检查结果计算正确率）</span>
      </li>

      <li>
        <span>坏数据检查:</span>
        <template v-if="infoEdit">
          <el-radio-group v-model="projInfo.badDataProcess">
            <el-radio :label="80">检查</el-radio>
            <el-radio :label="81">不检查</el-radio>
            <span class="task-tip" v-if="projInfo.badDataProcess == '80'">（坏数据需要检查员核对）</span>
            <span class="task-tip" v-if="projInfo.badDataProcess == '81'">（坏数据不需要检查员核对）</span>
          </el-radio-group>
        </template>
        <span class="task-unset" v-else>{{data.badDataProcess.desc}}</span>
      </li>

      <li>
        <span>机器质检：</span>
        <template v-if="infoEdit">
          <el-radio-group v-model="projInfo.checkByMachine" size="small">
            <el-radio :label="60">是</el-radio>
            <el-radio :label="61">否</el-radio>
          </el-radio-group>
        </template>
        <span class="task-unset" v-else>{{data.checkByMachine.desc}}</span>
      </li>

      <li v-if="projInfo.checkByMachine=='60'">
        <span>质检结果：</span>
        <el-radio-group
          v-if="infoEdit"
          v-model="projInfo.machineCheckType"
          class="robot-result"
          size="small"
        >
          <el-row>
            <el-radio :label="62">机器质检标注员结果</el-radio>
          </el-row>
          <el-row>
            <el-radio :label="63">机器质检检查员结果</el-radio>
          </el-row>
          <el-row>
            <el-radio :label="64">机器质检标注员和检查员结果</el-radio>
          </el-row>
        </el-radio-group>
      </li>

      <li v-if="!infoEdit && data.checkByMachine.code === 60">
        <span>质检结果：</span>
        <span class="task-unset" style="width:200px">{{data.machineCheckType.desc}}</span>
      </li>
    </ul>

    <el-button type="primary" size="small" v-if="infoEdit" class="but-submit" @click="submit">确定编辑</el-button>
    <el-button size="small" v-if="infoEdit" @click="cancle" class="but-cancle">取消编辑</el-button>
  </div>
</template>
<script>
export default {
  props: ["data"],
  data() {
    return {
      projInfo: {
        taskId: "",
        openLevel: "",
        maxApplyNumber: 100,
        markMethod: "",
        markRound: "",
        whetherCheck: "",
        checkRate: 100,
        checkBy: "",
        checkByMachine: "",
        machineCheckType: "",
        rejectBy: "",
        passRateThreshold: 100,
        badDataProcess: ""
      },
      infoEdit: false,
      loading: false
    };
  },

  methods: {
    update() {
      this.projInfo.openLevel = this.data.openLevel.code
        ? this.data.openLevel.code
        : 20;
      this.projInfo.markMethod = this.data.markMethod.code
        ? this.data.markMethod.code
        : 30;
      this.projInfo.whetherCheck = this.data.whetherCheck.code
        ? this.data.whetherCheck.code
        : 41;
      this.projInfo.checkBy = this.data.checkBy.code
        ? this.data.checkBy.code
        : 50;
      this.projInfo.checkByMachine = this.data.checkByMachine.code
        ? this.data.checkByMachine.code
        : 60;
      this.projInfo.machineCheckType = this.data.machineCheckType.code
        ? this.data.machineCheckType.code
        : 62;
      this.projInfo.markRound = this.data.markRound ? this.data.markRound : "1";
      this.projInfo.checkRate = this.data.checkRate ? this.data.checkRate : 100;
      this.projInfo.maxApplyNumber = this.data.maxApplyNumber
        ? this.data.maxApplyNumber
        : 100;
      this.projInfo.rejectBy = this.data.rejectBy
        ? this.data.rejectBy.code
        : 71;
      this.projInfo.passRateThreshold = this.data.passRateThreshold
        ? this.data.passRateThreshold
        : 100;
      this.projInfo.badDataProcess = this.data.badDataProcess.code
        ? this.data.badDataProcess.code
        : 80;
    },

    cancle() {
      this.$emit("cancle");
    },

    submit() {
      this.projInfo.taskId = this.data.id;
      let formData = new FormData();
      for (var i in this.projInfo) {
        formData.append(i, this.projInfo[i]);
      }
      this.loading = true;
      this.$api.task.updateConfig(formData).then(
        data => {
          this.$emit("query");
          this.loading = false;
          this.$message.success("任务配置编辑成功");
          this.cancle();
        },
        error => {
          this.loading = false;
          this.$message.error("配置信息不能为空,编辑失败");
          this.cancle();
        }
      );
    }
  },

  mounted() {
    console.log(this.data);
    if (JSON.stringify(this.data) !== "{}" && this.data.status === 1) {
      this.infoEdit = true;
      this.update();
    }
  }
};
</script>
<style lang="less" scoped>
.edit-config {
  font-size: 16px;
  margin-bottom: 10px;
  strong {
    min-width: 100px;
    display: inline-block;
    text-align: right;
  }
  ul {
    margin-top: 15px;
    li {
      font-size: 14px;
      line-height: 34px;
    }
    span {
      display: inline-block;
      width: 100px;
      text-align: right;
    }
    .task-tip {
      width: 300px;
      text-align: left;
    }
    .task-unset {
      text-align: left;
    }
  }
  .robot-result {
    .el-row {
      line-height: 22px;
    }
  }
  .but-submit {
    margin-left: 420px;
  }
  .but-cancle {
    margin-left: 20px;
  }
  .el-button {
    margin-top: 20px;
  }
}
</style>




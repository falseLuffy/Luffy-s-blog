<template>
  <el-container class="project-index">
    <el-header height="10%">
      <!-- 查询条件 -->
      <el-form :inline="true" class="query-form" @submit.native.prevent size="small">
        <el-form-item>
          <el-input
            size="small"
            v-model="appName"
            placeholder="搜索应用名称"
            :maxlength="30"
            clearable
            suffix-icon="el-icon-search"
            @keyup.enter.native="query(1)"
            @change="query(1)"
          ></el-input>
        </el-form-item>
      </el-form>
      <el-button size="small" class="task-add" type="success" @click="openNew">
        <i class="iconfont icon-add"></i>
        新增应用
      </el-button>
    </el-header>

    <el-main>
      <el-table
        size="small"
        :data="projData"
        align="center"
        height="500"
        v-loading="loading"
        element-loading-text="正在请求"
      >
        <el-table-column
          type="index"
          :index="(index)=>{return (page - 1) * size + index + 1}"
          label="序号"
          min-width="50"
        ></el-table-column>
        <el-table-column prop="name" label="应用名称" width="180" :show-overflow-tooltip="true"></el-table-column>
        <el-table-column prop="createdDate" label="创建时间" :formatter="dateFormat" width="200"></el-table-column>
        <el-table-column
          prop="appAdmin"
          label="应用管理员"
          min-width="250"
          :show-overflow-tooltip="true"
        ></el-table-column>
        <el-table-column label="操作" min-width="180">
          <template slot-scope="scope">
            <el-button size="mini" type="primary" @click.native="openEdt(scope.row)">配置</el-button>
            <el-button size="mini" type="primary" @click.native="delProj(scope.row.id)">移除</el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-pagination
        @size-change="sizeChange"
        @current-change="pageChange"
        align="right"
        :current-page="page"
        :page-sizes="[10, 20, 50, 100]"
        :page-size="size"
        layout="total, sizes, prev, pager, next, jumper"
        :total="total"
        v-show="total > 10"
      ></el-pagination>
      <el-dialog
        width="460px"
        title="创建标注应用"
        :visible.sync="isShowNewDailog"
        center
        :showClose="canClose"
        :lock-scroll="false"
      >
        <new-proj @hide="hideAddDialog" @success="query" v-if="isShowNewDailog"></new-proj>
      </el-dialog>
    </el-main>
  </el-container>
</template>

<script>
import NewProj from "./NewProj";
import EditProj from "./EditProj";
import { mapState } from "vuex";
export default {
  name: "Project",
  components: {
    NewProj,
    EditProj
  },
  data() {
    return {
      loading: false,
      canClose: false,
      project: null,
      appName: "",
      page: 1,
      size: 10,
      total: 0,
      projData: [],
      isShowNewDailog: false,
      isShowEdtDailog: false,
      isOne: false
    };
  },
  methods: {
    //分页
    sizeChange(size) {
      this.size = size;
      this.query(1);
    },
    pageChange(page) {
      this.page = page;
      this.query();
    },

    //查询
    query(resetPage) {
      this.loading = true;
      if (resetPage) {
        this.page = resetPage;
      }

      this.$api.project
        .appList({
          page: this.page,
          size: this.size,
          sort: "createdDate,DESC",
          name: this.appName
        })
        .then(res => {
          this.loading = false;
          let { content, totalElements } = res;
          this.projData = content;

          if (this.projData.length === 1) {
            this.isOne = true;
          } else {
            this.isOne = false;
          }
          this.total = totalElements;
        })
        .catch(() => {
          this.loading = false;
        });
    },

    //移除项目
    delProj(id) {
      this.$confirm("确认移除应用吗？")
        .then(() => {
          //如果当页只有一条数据，删除数据后跳转到上一页
          if (this.isOne && this.page !== 1) {
            this.page = this.page - 1;
          }
          this.$api.project.delApp({ id: id }).then(res => {
            this.$message.success("移除成功");
            this.query();
          });
        })
        .catch(() => {});
    },

    //新增
    openNew() {
      this.isShowNewDailog = true;
    },

    //编辑
    openEdt(row) {
      window.sessionStorage.setItem("appInfo", JSON.stringify(row));
      this.$router.push("/project/edit");
    },

    //隐藏新增diaolog
    hideAddDialog() {
      this.isShowNewDailog = false;
    },

    //隐藏编辑的dialog
    hideEditDialog(desc) {
      this.isShowEdtDailog = false;
      this.project.desc = desc;
    },

    // 时间格式化
    dateFormat(row, column) {
      let time = row[column.property];
      if (time === undefined || !time) {
        return "";
      }
      return this.$moment(time).format("YYYY-MM-DD HH:mm");
    }
  },
  mounted() {
    this.query();
  }
};
</script>
<style lang="less">
.project-index {
  .el-header {
    position: relative;
    padding: 20px 25px 0 25px;
    .icon-add {
      font-size: 14px;
    }
    .task-add {
      position: absolute;
      right: 24px;
      top: 20px;
    }
  }
  .el-button--mini,
  .el-button--mini.is-round {
    padding: 5px 10px;
  }
}
</style>



<template>
    <section class="dialog">
    <el-form style="width: 70%"  label-width="80px" labelPosition="left" size="small">
      <el-form-item label="用户账号">
        <el-input name="login" :disabled="isReadonly" :value="userdata.login"></el-input>
      </el-form-item>
      <el-form-item label="用户姓名">
        <el-input name="cnName" :disabled="isReadonly" :value="userdata.cnName"></el-input>
      </el-form-item> 
      <el-form-item label="用户类型">
        <el-input name="roleName" :disabled="isReadonly" :value="userdata.roleName"></el-input>
      </el-form-item>
    </el-form>
    <el-table :data="roleAppData" align="center" height="200" border  size="small">
      <el-table-column type="index" label="序号" min-width="50"></el-table-column>
      <el-table-column prop="orgName" label="所属应用" min-width="140" :show-overflow-tooltip="true"></el-table-column>
      <el-table-column label="用户角色" min-width="140">
        <template slot-scope="scope">
          <el-button type="primary" size="mini" v-if="scope.row.authorities.indexOf('ROLE_DW_MARKER')>-1" :disabled="true">标注员</el-button>
          <el-button type="primary" size="mini" v-if="scope.row.authorities.indexOf('ROLE_DW_CHECKER')>-1" :disabled="true">检查员</el-button>
          <el-button type="primary" size="mini" v-if="scope.row.authorities.indexOf('ROLE_DW_APPADMIN')>-1" :disabled="true">管理员</el-button>
        </template>
      </el-table-column>
    </el-table>
  </section>
</template>
<script>
import { APPID } from "assets/scripts/code";
export default {
  props: {
    userdata: Object
  },
  created() {
    this.getUserDeputies();
  },

  data() {
    return {
      roleAppData: [],
      isReadonly: true
    };
  },

  methods: {
    //获取人员兼职列表
    getUserDeputies() {
      let param = {
        appId: APPID,
        login: this.userdata.login
      };
      this.$api.project.getDeputiesList(param).then(
        res => {
          let appData = [];
          let map = new Map();
          let data = res;
          data.forEach(element => {
            let { org, role } = element;
            let e = {
              orgName: org.name,
              roleName: role.name
            };
            appData.push(e);
          });
          //合并相同应用下的角色
          appData.forEach(app => {
            let orgName = app.orgName;
            let roleName = app.roleName;
            if (!map.has(orgName)) {
              let value = [];
              value.push(roleName);
              map.set(orgName, value);
            } else {
              let v = map.get(orgName);
              v.push(roleName);
              map.set(orgName, v);
            }
          });
          //map集合转成数组，数组元素为map的key、value的数组
          let mapArray = [...map];
          //集合数组转换成对象数组
          mapArray.forEach(array => {
            let d = {
              orgName: array[0],
              authorities: array[1]
            };
            this.roleAppData.push(d);
          });
        },
        error => {}
      );
    }
  }
};
</script>
<style lang="less">
</style>


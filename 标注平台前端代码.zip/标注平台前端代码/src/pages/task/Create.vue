<template>
  <el-container class="task-create">
    <!-- 按钮 -->
    <el-header height="5%">
      <ul class="header-tips">
        <li :class="{current: currentTab==='1',success: oneSuccess===true}">
          <i :class="['iconfont',oneSuccess ? 'icon-done' : 'icon-one' ]"></i>填写任务信息
        </li>
        <li :class="{current: currentTab==='2',success: twoSuccess===true}">
          <i :class="['iconfont',twoSuccess ? 'icon-done' :'icon-two' ]"></i>配置任务信息
        </li>
        <li :class="{current: currentTab==='3',success: threeSuccess===true}">
          <i :class="['iconfont',threeSuccess ? 'icon-done' :'icon-three' ]"></i>创建完成
        </li>
      </ul>
    </el-header>
    <!-- 表单 -->
    <el-main>
      <div id="task">
        <!-- 表单1 -->
        <el-form
          size="small"
          label-width="100px"
          ref="oneForm"
          :model="oneForm"
          :rules="oneRules"
          v-show="currentTab === '1'"
        >
          <el-form-item prop="taskTypeId" label="任务类型" v-if="marktypes.length">
            <el-select placeholder="请选择任务类型" v-model="oneForm.taskTypeId">
              <el-option
                v-for="item in marktypes"
                :key="item.id"
                :label="item.name"
                :value="item.id"
              ></el-option>
            </el-select>
          </el-form-item>
          <el-form-item prop="name" label="任务名称">
            <el-input placeholder="请输入任务名称" v-model="oneForm.name" @change="judgeName"></el-input>
          </el-form-item>
          <el-form-item prop="description" label="任务描述">
            <el-input type="textarea" rows="5" placeholder="请输入任务描述" v-model="oneForm.description"></el-input>
          </el-form-item>
          <el-form-item prop="uploadMethod" label="上传方式" v-if="!isBadDataCreate">
            <el-radio-group v-model="oneForm.uploadMethod" @change="uploadMethodChange">
              <el-radio :label="11">输入地址</el-radio>
              <el-radio :label="10">文件上传</el-radio>
            </el-radio-group>
          </el-form-item>
          <!-- 文件上传：点击 -->
          <el-form-item label-width="0px" class="upload-item" v-if="uploadShow&&!isBadDataCreate">
            <span class="label-required">导入文件</span>
            <div class="upload-wrapper">
              <i class="iconfont icon-upload"></i>
              <input
                @change="upload"
                type="file"
                accept=".csv,application/x-rar,application/zip,text/plain,application/json"
              >
              <span class="upload-name" v-text="fileName"></span>
            </div>
            <div class="upload-error" v-show="fileEmptyInfo">请上传文件</div>
          </el-form-item>
          <!-- 文件上传：地址 -->
          <el-form-item prop="filePath" label="文件地址" v-if="urlShow&&!isBadDataCreate">
            <el-input v-model="oneForm.filePath" placeholder="请输入上传地址"></el-input>
            <a v-if="pathUrl" :href="pathUrl" target="_blank">文件上传地址</a>
          </el-form-item>
        </el-form>
        <!-- 表单22   -->
        <el-form
          size="small"
          label-width="110px"
          ref="twoForm"
          :model="twoForm"
          :rules="twoRules"
          v-show="currentTab === '2'"
        >
          <el-form-item prop="openLevel" label="任务权限">
            <el-radio-group v-model="twoForm.openLevel" @change="openLevelChange">
              <el-radio :label="20">公开任务</el-radio>
              <el-radio :label="21">私有任务</el-radio>
            </el-radio-group>
            <span class="task-tip" v-if="twoForm.openLevel===21">（私有任务只能被管理员分配）</span>
          </el-form-item>
          <el-form-item prop="maxApplyNumber" label="最大可领取数" v-if="twoForm.openLevel===20">
            <el-input-number
              :precision="0"
              :min="0"
              placeholder="最大可领取数"
              v-model="twoForm.maxApplyNumber"
            ></el-input-number>
          </el-form-item>
          <el-form-item prop="markMethod" label="标注方式">
            <el-radio-group v-model="twoForm.markMethod" @change="markMethodChange">
              <el-radio :label="30">单次标注</el-radio>
              <el-radio :label="31">多次标注</el-radio>
            </el-radio-group>
          </el-form-item>
          <el-form-item prop="markRound" label="标注次数" v-if="twoForm.markMethod===31">
            <el-input-number :min="1" :precision="0" placeholder="标注次数" v-model="twoForm.markRound"></el-input-number>
          </el-form-item>
          <el-form-item prop="whetherCheck" label="是否检查">
            <el-radio-group v-model="twoForm.whetherCheck" @change="whetherCheckChange">
              <el-radio :label="41">是</el-radio>
              <el-radio :label="40">否</el-radio>
            </el-radio-group>
          </el-form-item>

          <el-form-item prop="whetherCheck" label="检查时可修改">
            <el-radio-group v-model="twoForm.checkWithRevision">
              <el-radio :label="0">是</el-radio>
              <el-radio :label="1">否</el-radio>
            </el-radio-group>
          </el-form-item>

          <el-form-item prop="checkRate" label="检查比例" v-if="twoForm.whetherCheck===41 ">
            <el-input-number
              :precision="0"
              :max="100"
              :min="1"
              placeholder="检查比例"
              v-model="twoForm.checkRate"
            ></el-input-number>
            <span class="task-tip">（检查员可以领取不低于此比例的检查任务）</span>
          </el-form-item>
          <el-form-item prop="rejectBy" label="打回方式">
            <el-radio-group v-model="twoForm.rejectBy" @change="rejectByChange">
              <el-radio :label="70">手动打回</el-radio>
              <el-radio :label="71">自动打回</el-radio>
            </el-radio-group>
          </el-form-item>
          <el-form-item prop="passRateThreshold" label="合格阈值" v-if="twoForm.rejectBy===71 ">
            <el-input-number
              :precision="0"
              :max="100"
              :min="1"
              placeholder="合格阈值"
              v-model="twoForm.passRateThreshold"
            ></el-input-number>
          </el-form-item>
          <el-form-item prop="checkBy" label="正确率统计">
            <el-radio-group v-model="twoForm.checkBy">
              <el-radio :label="50">检查员统计</el-radio>
              <el-radio :label="51">机器统计</el-radio>
              <span class="task-tip" v-if="twoForm.checkBy === 50">（检查员的检查结果计算正确率）</span>
              <span class="task-tip" v-if="twoForm.checkBy === 51">（机器的检查结果计算正确率）</span>
            </el-radio-group>
          </el-form-item>
          <el-form-item prop="badDataProcess" label="坏数据检查">
            <el-radio-group v-model="twoForm.badDataProcess">
              <el-radio :label="80">检查</el-radio>
              <el-radio :label="81">不检查</el-radio>
              <span class="task-tip" v-if="twoForm.badDataProcess === 80">（坏数据需要检查员核对）</span>
              <span class="task-tip" v-if="twoForm.badDataProcess === 81">（坏数据不需要检查员核对）</span>
            </el-radio-group>
          </el-form-item>
          <el-form-item prop="checkByMachine" label="机器质检" class="datawood-hidden">
            <el-radio-group v-model="twoForm.checkByMachine">
              <el-radio :label="60">是</el-radio>
              <el-radio :label="61">否</el-radio>
            </el-radio-group>
          </el-form-item>
          <el-form-item
            prop="machineCheckType"
            label="质检结果"
            v-if="twoForm.checkByMachine===60"
            class="datawood-hidden"
          >
            <el-radio-group v-model="twoForm.machineCheckType" class="robot-result">
              <el-row>
                <el-radio :label="62">机器质检标注员结果</el-radio>
              </el-row>
              <el-row>
                <el-radio :label="63">机器质检检查员结果</el-radio>
              </el-row>
              <el-row>
                <el-radio :label="64">机器质检标注员和检查员结果</el-radio>
              </el-row>
            </el-radio-group>
          </el-form-item>
        </el-form>
        <!-- 成功3 -->
        <div v-if="currentTab === '3'" class="task-done">
          <i class="iconfont icon-done2"></i>
          <ul class="task-done-list">
            <li>
              <span>任务名称：</span>
              <span>{{threeForm.taskTypeName}}</span>
            </li>
            <li>
              <span>创建时间：</span>
              <span>{{threeForm.createDate}}</span>
            </li>
            <li>
              <span>任务性质：</span>
              <span>{{threeForm.taskQuality}}</span>
            </li>
            <li>
              <span>标注模式：</span>
              <span>{{threeForm.markTypeName}}</span>
            </li>
            <li>
              <span>检查模式：</span>
              <span>{{threeForm.checkTypeName}}</span>
            </li>
            <li>
              <span>打回方式：</span>
              <span>{{threeForm.rejectByName}}</span>
            </li>
            <li>
              <span>&nbsp;&nbsp;&nbsp;正确率：</span>
              <span>{{threeForm.correct}}</span>
            </li>
            <li>
              <span>坏数据检查：</span>
              <span>{{threeForm.badDataProcessName}}</span>
            </li>
            <li>
              <span>机器质检：</span>
              <span>{{threeForm.checkByMachine}}</span>
            </li>
          </ul>
        </div>
      </div>
    </el-main>
    <!-- 按钮组合 -->
    <el-footer class="create-btns">
      <template v-if="currentTab==='1'">
        <el-button size="small" type="primary" @click="oneSubmit">下一步</el-button>
        <el-button size="small" @click="backList">返回任务列表</el-button>
      </template>
      <template v-if="currentTab==='2'">
        <el-button size="small" type="primary" @click="twoSubmit">完成任务创建</el-button>
        <el-button size="small" @click="backOne">返回上一步</el-button>
      </template>
      <template v-if="currentTab==='3'">
        <el-button size="small" type="primary" @click="startDispense">开始分配</el-button>
        <el-button size="small" @click="backList">返回任务列表</el-button>
      </template>
    </el-footer>
  </el-container>
</template>

<script>
  import {mapState, mapMutations} from "vuex";

  export default {
    name: "CreateTask",
    computed: {
      ...mapState(["user", "appInfo"]),
      user() {
        let user = this.$store.state.user,
          pid = this.$store.state.pid;
        this.oneForm.pid = pid;
        return user;
      }
    },
    data() {
      return {
        currentTab: "1",
        nameExisted: false,
        oneSuccess: false,
        twoSuccess: false,
        threeSuccess: false,
        marktypes: [],
        uploadShow: false,
        urlShow: true,
        pathUrl: "",
        fileName: "请选择文件",
        fileEmptyInfo: false,

        // 表单1
        oneForm: {
          taskTypeId: "",
          name: "",
          description: "",
          uploadMethod: 11,
          filePath: "",
          file: null
        },
        oneRules: {
          name: [
            {required: true, message: "请输入任务名称", trigger: "blur"},
            {max: 20, message: "任务名称不可多于20个字符", trigger: "blur"}
          ],
          taskTypeId: [
            {required: true, message: "请选择任务类型", trigger: "change"}
          ],
          filePath: [
            {required: true, message: "请输入文件地址", trigger: "blur"}
          ]
        },

        // 表单2
        setBaseInfoStatus: false,
        twoForm: {
          checkWithRevision: 0,
          rejectBy: 71,
          badDataProcess: 80,
          passRateThreshold: 100,
          openLevel: 20,
          maxApplyNumber: 100,
          markMethod: 30,
          markRound: 1,
          whetherCheck: 41,
          checkRate: 100,
          checkBy: 50,
          checkByMachine: 60,
          machineCheckType: 62
        },
        twoRules: {
          maxApplyNumber: [
            {required: true, message: "请输入最大可领取数", trigger: "blur"}
          ],
          checkRate: [
            {required: true, message: "请输入检查比例", trigger: "change"}
          ],
          passRateThreshold: [
            {required: true, message: "请输入合格阈值", trigger: "change"}
          ],
          markRound: [
            {required: false, message: "请输入标注次数", trigger: "change"}
          ]
        },

        threeForm: {
          taskTypeName: "",
          createDate: "",
          taskQuality: "",
          markTypeName: "",
          checkTypeName: "",
          correct: "",
          checkByMachine: "",
          badDataProcessName: "",
          rejectByName: ""
        },

        isBadDataCreate: false
      };
    },
    methods: {
      ...mapMutations(["showLoading", "closeLoading"]),
      /**
       * 返回主页
       */
      backList() {
        this.$router.push({path: "/task/list"});
      },

      /**
       * 返回第一步
       */
      backOne() {
        this.currentTab = "1";
      },

      /**
       * 判断任务名称是否存在
       */

      judgeName() {
        this.$api.task
          .judgeName({
            name: this.oneForm.name,
            applicationId: this.appInfo.id
          })
          .then(res => {
            this.nameExisted = res;
            if (this.nameExisted) {
              this.$message.error("该任务名称已存在");
            }
          })
          .catch(() => {
          });
      },
      /**
       * 是否检查
       */
      sureCheck() {
        this.checkShow = this.oneForm.needCheck == 1 ? false : true;
      },

      /**
       * 上传文件
       */
      upload(event) {
        const file = event.target.files[0];
        this.fileName = file.name;
        this.fileEmptyInfo = false;
        this.oneForm.file = file;
      },

      /**
       * 第1步保存
       */
      oneSubmit() {
        if (this.nameExisted) {
          this.$message.error("任务名称重复，请重新命名！");
          return;
        }
        this.$refs.oneForm.validate(valid => {
          if (this.uploadShow && !this.oneForm.file) {
            this.fileEmptyInfo = true;
            this.fileName = "请选择文件";
            return;
          } else {
            this.fileEmptyInfo = false;
          }
          if (valid) {
            this.oneSuccess = true;
            this.currentTab = "2";

            this.getBaseInfo();
          }
        });
      },

      /**
       * 获取从应用管理员默认的配置
       */
      getBaseInfo() {
        // 初始值赋值
        if (this.appInfo && !this.setBaseInfoStatus) {
          let {
            checkBy,
            checkByMachine,
            checkRate,
            machineCheckType,
            markMethod,
            markRound,
            maxApplyNumber,
            openLevel,
            whetherCheck
          } = this.appInfo;

          this.twoForm.checkBy = checkBy && checkBy.code ? checkBy.code : 50;
          this.twoForm.checkByMachine =
            checkByMachine && checkByMachine.code ? checkByMachine.code : 60;
          this.twoForm.checkRate = checkRate ? checkRate : 100;
          this.twoForm.machineCheckType =
            machineCheckType && machineCheckType.code
              ? machineCheckType.code
              : 62;
          this.twoForm.markMethod =
            markMethod && markMethod.code ? markMethod.code : 30;
          this.twoForm.markRound = markRound ? markRound : 1;
          this.twoForm.maxApplyNumber = maxApplyNumber ? maxApplyNumber : 100;
          this.twoForm.openLevel =
            openLevel && openLevel.code ? openLevel.code : 20;
          this.twoForm.whetherCheck =
            whetherCheck && whetherCheck.code ? whetherCheck.code : 41;

          this.setBaseInfoStatus = true;
        }
      },

      /**
       * 第2步保存
       */
      twoSubmit() {
        this.$refs.twoForm.validate(valid => {
          if (valid) {
            let param = Object.assign({}, this.oneForm, this.twoForm);
            param.applicationId = this.appInfo.id;

            let formData = new FormData();
            for (var i in param) {
              formData.append(i, param[i]);
            }

            this.showLoading();
            // 文件上传
            this.$api.task
              .createTask(formData)
              .then(res => {
                this.closeLoading();
                this.createSuccess(res);
              })
              .catch(() => {
              });
          }
        });
      },

      /**
       * 请求创建成功
       */
      createSuccess(res) {
        this.$message.success("创建成功！");

        // 任务名称
        this.threeForm.taskTypeName = res.name;
        // 创建时间
        this.threeForm.createDate = this.$moment(res.createDate).format(
          "YYYY年MM月DD日 HH:mm:ss"
        );
        // 任务性质
        if (res.openLevel.desc == "公开任务") {
          this.threeForm.taskQuality = `公开，单次可领取最多${
            res.maxApplyNumber
            }条数据`;
        } else {
          this.threeForm.taskQuality = "私有";
        }
        // 标注模式
        this.threeForm.markTypeName = res.markMethod.desc;
        // 检查模式
        this.threeForm.checkTypeName =
          res.whetherCheck.desc == "检查"
            ? `需要检查，检查比例是${res.checkRate}%`
            : "不需要检查";
        // 打回方式
        this.threeForm.rejectByName = res.rejectBy.desc;
        if (res.rejectBy.code == 71) {
          this.threeForm.rejectByName =
            res.rejectBy.desc + `，合格阈值是${res.passRateThreshold}%`;
        }

        // 正确率
        this.threeForm.correct = res.checkBy.desc + "确定正确率";
        // 机器质检情况
        let machineCheckType = "否";
        if (res.checkByMachine.desc == "是") {
          machineCheckType = res.machineCheckType.desc;
        }
        this.threeForm.checkByMachine = machineCheckType;

        // 坏数据检查
        this.threeForm.badDataProcessName = res.badDataProcess.desc;

        this.twoSuccess = true;
        this.threeSuccess = true;
        this.currentTab = "3";
        window.sessionStorage.setItem("taskInfo", JSON.stringify(res));
      },

      /**
       * 上传方式改变
       */
      uploadMethodChange(val) {
        this.oneRules.filePath[0].required = val === 10 ? false : true;
        if (val === 10) {
          this.uploadShow = true;
          this.urlShow = false;
          this.fileEmptyInfo = this.oneForm.file ? false : this.fileEmptyInfo;
          if (!this.fileEmptyInfo) {
            this.fileName = "请选择文件";
          }
        } else {
          this.uploadShow = false;
          this.urlShow = true;
          this.fileEmptyInfo = false;
          this.fileName = "请选择文件";
          this.oneForm.file = null;
        }
      },

      /**
       * 任务权限切换
       */
      openLevelChange(val) {
        this.twoRules.maxApplyNumber[0].required = val === 20 ? true : false;
      },

      /**
       * 是否检查切换
       */
      whetherCheckChange(val) {
        this.twoRules.checkRate[0].required = val === 41 ? true : false;
      },

      /**
       * 合格阈值切换
       */
      rejectByChange(val) {
        this.twoRules.passRateThreshold[0].required = val === 71 ? true : false;
      },

      /**
       * 标注次数切换
       */
      markMethodChange(val) {
        this.twoRules.markRound[0].required = val === 31 ? true : false;
      },

      /**
       * 获取文件访问的baseurl
       */
      getBaseUrl() {
        this.$api.task.getStorageUrl({}).then(res => {
          this.pathUrl = res;
        });
      },

      /**
       * 开始分配
       */
      startDispense() {
        this.$router.push({path: "/task/dispense"});
      },

      // 获取类型名称
      getTypes() {
        this.showLoading();
        this.$api.project
          .taskTypesList({
            appId: this.appInfo.id
          })
          .then(res => {
            this.closeLoading();
            this.marktypes = res;
          })
          .catch(() => {
          });
      }
    },
    watch: {
      appInfo() {
        if (this.appInfo.id) {
          this.getTypes();
        }
      }
    },
    mounted() {
      if (!this.appInfo.id) {
        return;
      }
      // 获取任务类型
      this.getTypes();
      this.getBaseUrl();
      let taskTypeId = this.$route.params.taskTypeId;
      if (taskTypeId) {
        this.isBadDataCreate = this.$route.params.isBadDataCreate;
        this.oneForm.taskTypeId = taskTypeId;
        this.oneForm.uploadMethod = 12;
      }
    }
  };
</script>

<style rel="stylesheet/less" lang="less">
  .el-container.task-create {
    background: #ffffff;

    .el-header {
      background: #fff;
      padding: 10px 40px;

      .header-tips {
        li {
          float: left;
          position: relative;
          width: calc(~"(100% - 140px)/2");
          box-sizing: border-box;
          line-height: 32px;

          .iconfont {
            font-size: 24px;
            position: relative;
            left: 6px;
            top: 3px;
            color: #d4d7d9;
          }

          &:after {
            display: block;
            height: 1px;
            background-color: #d4d7d9;
            position: absolute;
            left: 138px;
            top: 20px;
            content: "";
            width: calc(~"100% - 150px");
          }

          &:last-child {
            width: 140px;

            &:after {
              display: none;
            }
          }

          &.success {
            color: #5daf34;

            .iconfont {
              color: #5daf34;
            }

            &:after {
              background-color: #5daf34;
            }
          }

          &.current {
            color: #409eff;

            .iconfont {
              color: #409eff;
            }

            &:after {
              background-color: #409eff;
            }
          }
        }
      }
    }

    .el-main {
      padding-top: 30px;
      margin: 0 auto;
      width: 584px;

      .file-item {
        .form-label,
        .upload-file {
          float: left;
        }

        .el-upload__tip {
          display: inline-block;
          margin-left: 10px;
        }
      }
    }

    .el-footer {
      padding-bottom: 100px;

      &.create-btns {
        text-align: center;
      }
    }

    .el-icon-upload {
      font-size: 30px;
      color: #6ea5de;
    }

    .upload-tip {
      margin-left: 10px;
      font-size: 12px;
      position: relative;
      top: -5px;
    }

    .task-tip {
      margin-left: 10px;
      font-size: 12px;
    }

    .robot-result {
      .el-row {
        line-height: 22px;
      }
    }

    .task-done {
      text-align: center;

      .iconfont {
        position: relative;
        font-size: 50px;
        color: #5daf34;
        margin-bottom: 40px;
        display: inline-block;

        &:after {
          display: block;
          position: absolute;
          content: "\4EFB\52A1\521B\5EFA\6210\529F\FF01";
          font-size: 20px;
          left: -30px;
          bottom: -30px;
          width: 140px;
        }
      }

      .task-done-list {
        width: 500px;
        padding-left: 150px;
        box-sizing: border-box;
        margin: 20px auto;

        li {
          line-height: 40px;
          text-align: left;

          span:first-child {
          }
        }
      }
    }

    .upload-wrapper {
      input {
        width: 41px;
        height: 32px;
        z-index: 100;
        position: absolute;
        opacity: 0;
        cursor: pointer;
        line-height: 32px;
        overflow: hidden;
      }

      .icon-upload {
        font-size: 30px;
        position: absolute;
        color: #6ea5de;
        cursor: pointer;
        z-index: 99;
      }

      .upload-name {
        padding-left: 50px;
      }
    }

    .upload-item {
      .label-required {
        display: inline-block;
        text-align: right;
        float: left;
        font-size: 14px;
        color: #606266;
        line-height: 40px;
        padding: 0 12px 0 0;
        box-sizing: border-box;
        width: 100px;

        &::before {
          content: "*";
          color: #f56c6c;
          margin-right: 4px;
        }
      }

      .el-form-item__error {
        display: none;
      }
    }

    .upload-error {
      color: #f56c6c;
      font-size: 12px;
    }
  }
</style>















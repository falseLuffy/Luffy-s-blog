<template>
    <div class="task-detail">
        <el-row class="task-info">
            <strong class="task-name">{{taskInfo.name}}</strong>
                <ul>
                    <li>
                        <span><strong>创建人：</strong></span>
                        <span>{{taskInfo.createBy}}</span>
                        <span style="margin-left:30px;"><strong>创建时间：</strong></span>
                        <span>{{taskInfo.createDate}}</span>
                    </li>
                    <li>
                        <span><strong>任务类型：</strong></span>
                        <span>{{taskInfo.taskTypeName}}</span>
                        <span style="margin-left:30px;"><strong>任务数量：</strong></span>
                        <span>{{taskInfo.count}}</span>
                    </li>
                    <li>
                        <span><strong>标注领取进度：</strong></span>
                        <el-progress :percentage="taskInfo.count==0?0:parseInt(((parseInt(taskInfo.markAssignedNum)/parseInt(taskInfo.count))*100))"></el-progress> 
                    </li>
                     <li>
                        <span><strong>检查领取进度：</strong></span>
                        <el-progress :percentage="taskInfo.count==0?0:parseInt(((parseInt(taskInfo.checkAssignedNum)/parseInt(taskInfo.count))*100))"></el-progress> 
                    </li>
                </ul>
        </el-row>
        <el-row class="task-desc">
             <strong>任务描述：</strong>
             <div class="content"></div>
             <div class="foot">
                <el-button size="small" type="primary">领取任务</el-button>
                <el-button size="small" @click="backToTaskPool">返  回</el-button>               
             </div>
        </el-row>
    </div>
</template>
<script>
export default {
  created() {
    this.taskInfo = JSON.parse(window.sessionStorage.getItem("canGetTaskInfo"));
  },
  data() {
    return {
      taskInfo: {}
    };
  },
  methods: {
    backToTaskPool() {
      this.$router.push({ path: "/mark/taskpool" });
    }
  }
};
</script>
<style lang="less" scoped>
.task-detail {
  .el-row {
    background-color: #fff;
    padding: 40px;
    margin-bottom: 10px;
    .task-name {
      font-size: 16px;
    }
    ul {
      margin: 15px 0 10px 0;
      li {
        color: #606060;
        margin-top: 25px;
        line-height: 1.5;
        span:first-child {
          display: inline-block;
        }
        .el-progress.el-progress--line {
          float: right;
          width: 200px;
          margin-right: 81%;
          line-height: 21px;
        }
      }
    }
  }
  .task-desc {
    height: 90%;
    .content {
      height: 380px;
    }
    .foot{
        margin-left: 40%;
    }
  }
}
</style>


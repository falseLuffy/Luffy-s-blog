<template>
  <div class="login-main">
    <div class="login-container">
      <div class="login-logo"></div>
      <el-form
        class="card-box login-form"
        autocomplete="on"
        ref="loginForm"
        label-position="left"
        :model="loginForm"
        :rules="loginRules"
      >
        <div class="logo">标注平台</div>
        <div class="login-form-bg">
          <div class="login-form-top">
            <div class="login-title">用户登录</div>
            <a class="register" @click="register">新用户注册</a>
          </div>
          <el-form-item prop="account" class="user-name">
            <el-input
              size="small"
              name="account"
              v-model="loginForm.account"
              :maxlength="30"
              placeholder="请输入用户账号"
              @keyup.enter.native="login"
              v-if="hasCode"
            ></el-input>
            <el-input
              size="small"
              name="account"
              v-model="loginForm.account"
              :maxlength="30"
              placeholder="请输入用户账号"
              @keyup.enter.native="nocodeLogin"
              v-else
            ></el-input>
            <i class="iconfont icon-user"></i>
          </el-form-item>
          <el-form-item prop="password" class="pass-word">
            <el-input
              size="small"
              name="password"
              type="password"
              v-model="loginForm.password"
              :maxlength="30"
              placeholder="请输入密码"
              @keyup.enter.native="login"
              v-if="hasCode"
            ></el-input>
            <el-input
              size="small"
              name="password"
              type="password"
              v-model="loginForm.password"
              :maxlength="30"
              placeholder="请输入密码"
              @keyup.enter.native="nocodeLogin"
              v-else
            ></el-input>
            <i class="iconfont icon-password"></i>
          </el-form-item>

          <el-form-item prop="code" class="code" v-if="hasCode">
            <el-input
              name="code"
              v-model="loginForm.code"
              placeholder="请输入验证码"
              @keyup.enter.native="login"
            ></el-input>
            <img :src="`${baseurl}`" alt="验证码" @click="getCode" ref="codeimg">
          </el-form-item>
          <el-button size="small" class="login-btn" type="primary" @click="login" v-if="hasCode">登录</el-button>
          <el-button size="small" class="login-btn" type="primary" @click="nocodeLogin" v-else>登录</el-button>
        </div>
      </el-form>
      <el-dialog
        width="460px"
        title="新用户注册"
        :visible.sync="showreg"
        center
        top="5%"
        :lock-scroll="false"
      >
        <register :show.sync="showreg" @hide="hidereg"/>
      </el-dialog>
    </div>
    <div class="copyright">版权所有 @科大讯飞股份有限公司</div>
  </div>
</template>
<script>
import Register from "./Register";
import { setRouterMap } from "assets/scripts/common";
import { datawoodRole } from "assets/scripts/code";
import { mapMutations, mapState } from "vuex";

export default {
  components: { Register },
  data() {
    return {
      hasCode: process.env.HAS_CODE,
      baseurl: "/getCode",
      showreg: false,
      loginForm: {
        account: "",
        password: ""
      },
      loginRules: {
        account: [
          { required: true, message: "请输入用户账号", trigger: "change" }
        ],
        password: [
          { required: true, message: "请输入密码", trigger: "change" }
        ],
        code: [{ required: true, message: "请输入验证码", trigger: "blur" }]
      }
    };
  },
  methods: {
    ...mapMutations([
      "setUserInfo",
      "setToken",
      "clearRouters",
      "setRouters",
      "showLoading",
      "closeLoading"
    ]),

    // 有验证码登陆
    login(registForm) {
      this.$refs.loginForm.validate(valid => {
        // 验证码
        if (valid) {
          let formData = new FormData();
          formData.append("account", this.loginForm.account);
          formData.append("password", this.loginForm.password);
          formData.append("code", this.loginForm.code);

          this.$api.user
            .login(formData)
            .then(role => {
              if (!role) {
                return;
              }
              //信息保存到store
              delete role.permissions;
              this.setUserInfo(role);
              //路由权限分配
              const routers = setRouterMap(role);
              this.$router.push({
                path: routers[0].path
              });
            })
            .catch(() => {
              if (this.hasCode) {
                this.getCode();
              }
            });
        }
      });
    },

    // 无验证码登陆
    nocodeLogin(registForm) {
      this.$refs.loginForm.validate(valid => {
        if (valid) {
          // 不要验证码;
          this.showLoading();
          this.$api.user
            .login({
              username: this.loginForm.account,
              password: this.loginForm.password
            })
            .then(res => {
              this.closeLoading();
              // 获取token
              let { access_token } = res;
              this.setToken(access_token);
              this.getUser();
              this._getDeputiesList(this.loginForm.account)
            });
        }
      });
    },

    // 获取个人兼职列表
    _getDeputiesList(name){
        const param = {login:name}
        this.$api.user.getDeputiesList(param).then(res=>{
            let result = [];
            res.forEach(item=>{
              let param = {
                name: item.org.name,
                role:item.role.name
              }
              if(param.role !== 'ROLE_USER'){
                result.push(param)
              }
            })
            localStorage.deputies = JSON.stringify(result);
        })
    },

    // 获取用户信息
    getUser() {
      this.$api.user.getUserInfo({}).then(res => {
          let { appId, authorities, cnName, login } = res;
          let roleInfo = {
            appId: appId,
            authorities: authorities,
            cnName: cnName,
            login: login
          };

          // 角色设定
          if (
            authorities.includes(datawoodRole.user) ||
            authorities.includes(datawoodRole.marker) ||
            authorities.includes(datawoodRole.checker)
          ) {
            roleInfo.role = datawoodRole.user;
          }
          if (authorities.includes(datawoodRole.appAdmin)) {
            roleInfo.role = datawoodRole.appAdmin;
          }
          if (authorities.includes(datawoodRole.superAdmin)) {
            roleInfo.role = datawoodRole.superAdmin;
          }

          this.setUserInfo(roleInfo);
          //路由权限分配
          const routers = setRouterMap(roleInfo);
          this.$router.push({
            path: routers[0].path
          });
        })
        .catch(() => {});
    },

    register() {
      this.showreg = true;
    },

    hidereg() {
      this.resetForm(this.$refs.loginForm);
      this.showreg = false;
    },

    getCode() {
      this.$refs.codeimg.src = this.baseurl + "?" + new Date().getTime();
    },

    resetForm(form) {
      form.resetFields();
      form.clearValidate();
    }
  },
  mounted() {
    //清除 权限列表
    this.clearRouters();
    this.$refs.loginForm.resetFields();

    // 根据ip和公网地址判断baseURL
    // if (process.env.NODE_ENV === "production") {
    //   // 获取浏览器地址
    //   let locationUrl = location.origin;
    //   this.baseurl =
    //     locationUrl.indexOf("mark") > -1
    //       ? process.env.IP_URL + "/getCode"
    //       : "/getCode"; // ip公网
    // } else {
    //   this.baseurl = "/getCode";
    // }
  },
  created() {},
  computed: {
    ...mapState["loading"]
  }
};
</script>
<style rel="stylesheet/less" lang="less">
.el-dialog__wrapper {
  overflow: hidden;
}
.login-main {
  min-height: 500px;
  .login-container {
    display: flex;
    flex-flow: row;
    justify-content: space-between;
    align-items: center;
    height: 90vh;
    background: url("~@/assets/images/login_bg.png") no-repeat;
    background-size: 100% 100%;
    min-height: 500px;
    min-width: 800px;
    .user-name,
    .pass-word {
      position: relative;
      .icon-user,
      .icon-password {
        position: absolute;
        right: 0px;
        top: 1px;
        font-size: 20px;
        color: #888;
      }
    }
    .pass-word .icon-password {
      font-size: 24px;
      top: 3px;
      right: 0px;
    }
    .login-btn {
      float: right;
      width: 100%;
      margin-top: 5px;
    }
  }
  .login-logo {
    position: absolute;
    left: 50%;
    width: 600px;
    height: 500px;
    background: url("~@/assets/images/login_bg_loginform.png");
    background-size: 100% 100%;
    margin-left: -300px;
    opacity: 0.2;
  }

  .logo {
    font-size: 22px;
    color: #fff;
    font-weight: bold;
    position: relative;
    font-family: "幼圆";
    padding-left: 50px;
    &:before {
      display: block;
      background: url("~@/assets/images/logo.png");
      width: 40px;
      height: 33px;
      content: "";
      position: absolute;
      left: 0px;
      top: -6px;
    }
  }

  .login-form {
    position: absolute;
    left: 50%;
    width: 330px;
    margin-left: -165px;
  }

  .login-form-bg {
    background: #f3f9fe;
    padding: 15px 30px;
    border-radius: 10px;
    margin-top: 10px;
    border: 10px solid #359eeb;
    padding-bottom: 52px;
  }

  .login-form-top {
    color: #3da9f7;
    display: flex;
    flex-flow: row;
    justify-content: space-between;
    height: 40px;
    align-items: center;
    padding: 5px;
  }

  .login-title {
    font-size: 20px;
  }

  .login-more {
    display: inline-flex;
    flex-direction: row;
    justify-content: space-between;
    width: 100%;
    color: #fff;
    cursor: pointer;
  }

  .register {
    font-size: 12px;
    text-decoration: underline;
    cursor: pointer;
  }

  .code {
    position: relative;
    img {
      cursor: pointer;
      width: 110px;
      height: 35px;
      position: absolute;
      right: 0;
      top: 0;
    }
    input {
      width: 50%;
      width: 50%;
      border: none;
      background: #f3f9fe;
      border-bottom: #c0c4cc 1px solid;
      border-radius: 0;
    }
  }
}

.copyright {
  color: #8f8f8f;
  height: 10vh;
  font-size: 14px;
  background-color: #f6f6f6;
  width: 100%;
  text-align: center;
  line-height: 60px;
}
</style>

<template>
  <div class="map-content">
    <el-input placeholder="请输入内容" clearable v-model="searchName" class="input-search">
      <el-button slot="append" icon="el-icon-search" ref="search" @click="handleSearch"></el-button>
    </el-input>
    <baidu-map class="map" scroll-wheel-zoom>
      <bm-view class="map"></bm-view>
      <bm-local-search
        @searchcomplete="searchList"
        :keyword="keyword"
        :panel="false"
        auto-viewport
        :location="location"
      ></bm-local-search>
    </baidu-map>
    <div class="place-list" ref="placeList" v-if="placeShow">
      <ul>
        <li v-for="item in placeList" :key="item.uid" @click="detail(item.uid)">
          <el-popover
            popper-class="popover"
            placement="right-end"
            :title="placeInfo?placeInfo.detail_info.tag:''"
            width="200"
            trigger="click"
            :content="placeInfo?placeInfo.address:''"
          >
            <div slot="reference" class="item-list">
              <p>{{item.title}}</p>
              <span>{{item.address}}</span>
            </div>
          </el-popover>
        </li>
      </ul>
    </div>
  </div>
</template>

<script>
import jsonp from "jsonp";

export default {
  props: {
    FsearchName: {
      type: String,
      default: ""
    },
    Fkeyword: {
      type: String,
      default: ""
    },
    Flocation: {
      type: String,
      default: ""
    }
  },
  data() {
    return {
      placeInfo: null,
      placeShow: true,
      searchName: "",
      keyword: "",
      location: "",
      placeList: []
    };
  },

  watch: {
    FsearchName(val) {
      this.searchName = val;
    },
    Fkeyword(val) {
      this.keyword = val;
    },
    Flocation(val) {
      this.location = val;
    }
  },

  created() {
    this.searchName = this.FsearchName;
    this.keyword = this.Fkeyword;
    this.location = this.Flocation;
  },

  methods: {
    handleSearch() {
      this.placeShow = true;
      this.keyword = this.searchName;
    },
    searchList(data) {
      if (data) {
        this.placeList = data.Ar;
      }
    },

    detail(uid) {
      new Promise((resolve, reject) => {
        jsonp(
          `http://api.map.baidu.com/place/v2/detail?uid=${uid}&output=json&scope=2&ak=w4POp2AmwnCd35rKPWSYX3NdWuG6Dq0h`,
          {},
          (err, data) => {
            resolve(data);
          }
        );
      }).then(res => {
        if (res.message === "ok") {
          this.placeInfo = res.result;
        }
      });
    }
  }
};
</script>

<style lang="less" scoped>
.map-content {
  position: relative;
  width: 530px;
  height: 400px;
  .input-search {
    position: absolute;
    z-index: 2999;
    width: 200px;
    left: 10px;
    top: 10px;
  }
  .map {
    width: 530px;
    height: 400px;
  }
  .place-list {
    position: absolute;
    top: 45px;
    left: 10px;
    background: rgba(255, 255, 255, 0.9);
    font-size: 12px;
    padding: 10px;
    width: 180px;
    box-shadow: 0 0 3px 2px #ccc;
    color: #333;
    border-radius: 2px;
    overflow: auto;
    max-height: 330px;
    li {
      cursor: pointer;
      p {
        text-align: left;
        font-size: 13px;
        margin-bottom: 4px;
        color: #409eff;
      }
      span {
        color: #888;
      }
    }
    .item-list {
      margin-bottom: 10px;
    }
  }
}
</style>

<style>
.popover {
  position: fixed !important;
  top: 190px !important;
}
</style>
